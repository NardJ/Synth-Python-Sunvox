# SynthRig 0.10.1 — reparatie portamento en duidelijkere chorus

## Portamento (MIDImix CC59)

In 0.10.0 werd een nieuwe note-on afgestemd vanaf de vorige **MIDI-doelnoot**.
Bij een octaafglide die nog niet voltooid was, kon daardoor vooral het
C3/C4/C4/C3/C3-speelpatroon abrupte toonhoogtesprongen veroorzaken.

In 0.10.1:

- neemt iedere nieuwe aanslag de **actueel klinkende pitch** van de voorgaande
  stem over, inclusief een onvoltooide glide;
- houdt een note-off de laatste klinkende pitch vast tijdens de AMP Release;
- blijft de oude pitch bij een korte toets-pauze beschikbaar, ook nadat de
  released voice is vrijgegeven (maximaal 1,25 s);
- wordt de glijdduur per interval berekend op basis van het aantal semitonen:
  CC59 maximaal ongeveer 1,0 s per octaaf;
- blijven de fasevaste SunVox 05/06-bend-events behouden, evenals de
  pitchbend en oscillator-fijnregelingen uit 0.9.12.

Deze reparatie maakt portamento niet monofonisch: oude release-tails blijven
hoorbaar zolang AMP Release duurt. Voor een heldere glide-test AMP Release
kort zetten.

## Chorus (MIDImix CC60)

De twee stereo Flanger-routes hebben nu een verhoogd maximaal wet-level
(van 72 naar 172 op een schaal van 0-256), sterkere modulatie en een iets
andere timing tussen links en rechts. De droge directe signaalroute blijft
intact bij CC60=0. CC60-beweging wordt nog steeds circa 100 ms afgevlakt.

Een vaste SIN-offlineproef liet bij maximaal CC60 een stereo verschil zien
van 0,03167 naar 0,07081 RMS (vergelijkbare configuratie). Het eindgeluid
kan luider zijn; houd de master tijdens het testen gematigd.

## Zelf draaien

```bash
cd ~/Synth/Python-sunvox/SynthRig_0101
source ../.venv/bin/activate
python synthrig_0101.py --debug-ui --midi-log

# Echte SunVox-rendering zonder hardware:
python synthrig_0101.py --offline-check --offline-no-wav
python synthrig_0101.py --offline-check --pitch-lfo-mode events --offline-no-wav
python -m unittest discover -s tests
```

In deze omgeving: 165/165 native-audio, 165/165 events-audio en
113/113 Python-tests geslaagd. Daaronder vier nieuwe audio-controles
(herhaald C4, herhaald C3, vervallen historie en diepere chorus).
