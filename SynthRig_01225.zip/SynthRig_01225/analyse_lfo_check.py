#!/usr/bin/env python3
"""Controleer SynthRig 0.9.6 LFO A/B diagnose-ZIP zonder externe packages.

Waarden zijn indicatief: Linux monitor-audio kan vertraging en externe audio bevatten.
Een native Vibrato is delay-based audio processing: beoordeel ook de WAV op gehoor.
"""
from __future__ import annotations
import argparse
import json
import math
from pathlib import Path
from statistics import median
import zipfile
from analyse_pitchcheck import read_wav, window_stats


def extract(path):
    path=Path(path)
    rate,samples=read_wav(path)
    if path.suffix.lower()!='.zip':
        raise ValueError('Voor fasetiming is een opname-ZIP nodig, geen losse WAV')
    with zipfile.ZipFile(path) as z:
        logs=[name for name in z.namelist() if name.endswith('.jsonl')]
        if len(logs)!=1:raise ValueError('Een JSONL-eventslog in ZIP verwacht')
        events=[json.loads(line) for line in z.read(logs[0]).decode().splitlines() if line.strip()]
    meta=next((e.get('data',{}).get('metadata',{}) for e in events if e['event']=='record_start'),{})
    phases=[e for e in events if e['event']=='lfo_check_step']
    if len(phases)<6:raise ValueError('Geen complete --lfo-check events gevonden')
    if not samples or max(abs(v) for v in samples)==0:
        raise ValueError('WAV is stil; controleer de audio-opname')
    result=[]
    for i,evt in enumerate(phases):
        start=evt['t']+.20 # laat niveau- en faseovergang even uitdempen
        end=phases[i+1]['t']-.10 if i+1<len(phases) else min(len(samples)/rate-.20,evt['t']+1.0)
        if end-start<.4:
            result.append({'name':evt['data']['label'],'error':'te weinig audio'});continue
        frequencies=[]; rms=[]
        t=start
        while t+.14<=end:
            s=window_stats(samples,rate,t,t+.14)
            if s['frequency_hz'] is not None:frequencies.append(s['frequency_hz'])
            if s['rms_dbfs'] is not None:rms.append(s['rms_dbfs'])
            t+=.075
        hz=median(frequencies) if frequencies else None
        swing=(1200*math.log2(max(frequencies)/min(frequencies)) if len(frequencies)>3 and min(frequencies)>0 else None)
        result.append({'name':evt['data']['label'], 'depth':evt['data'].get('pitch_depth'),
                       'median_frequency_hz':round(hz,2) if hz else None,
                       'frequency_span_cents':round(swing,1) if swing is not None else None,
                       'rms_dbfs':round(median(rms),2) if rms else None,
                       'windows':len(frequencies)})
    return meta,result


def main():
    p=argparse.ArgumentParser(description='Vergelijk de vibrato-eigenschappen van 0.9.6 LFO-opnames')
    p.add_argument('zonder_of_native',help='Een ZIP van --lfo-check --record')
    p.add_argument('andere',nargs='?',help='Optioneel tweede ZIP (native tegenover events)')
    a=p.parse_args()
    for file in filter(None,(a.zonder_of_native,a.andere)):
        meta,rows=extract(file)
        print('\n',Path(file).name,'| modus:',meta.get('pitch_lfo_mode','onbekend'))
        print(' Fase              mediaan Hz      variatie (cent)      RMS dBFS')
        for r in rows:
            if 'error' in r: print(r['name'],r['error']);continue
            f='--' if r['median_frequency_hz'] is None else f"{r['median_frequency_hz']:.2f}"
            c='--' if r['frequency_span_cents'] is None else f"{r['frequency_span_cents']:.1f}"
            z='--' if r['rms_dbfs'] is None else f"{r['rms_dbfs']:.1f}"
            print(f" {r['name']:<18} {f:>8}        {c:>10}            {z:>8}")
        print('Opmerking: frequentiespreiding is geen directe vervormingsmeting. Upload beide ZIPs voor spectrale analyse.')

if __name__=='__main__':main()
