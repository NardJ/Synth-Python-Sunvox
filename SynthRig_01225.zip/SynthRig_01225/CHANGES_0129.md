# SynthRig 0.12.9 — Noise-fix en herhaalde Matrix Audit

## Gevonden oorzaak

SunVox gebruikt 16 virtuele eventtracks. SynthRig laat per stem de sub en
noise dezelfde MultiSynth-router gebruiken. In 0.12.8 richtten de initiële
SET_PITCH- en latere 05/06-pitch-events zich nog op de sub-Generator zelf.
Daardoor kon de noise-Generator zijn noot niet houden: een echte bug, geen
fout in de controllerwaarden.

## Reparatie

Alle pitch-events voor de gezamenlijke sub/noise-track gaan nu naar de
MultiSynth-router. Zo ontvangen beide Generator-modules dezelfde stem- en
Note On/Off-events. Het bestaande volume blijft afzonderlijk instelbaar.
Dit verandert geen MIDI-mapping, presets, APC-matrixbediening of soundrouting.

## Testen

Zie NOISE_TEST_0129.md en MATRIX_AUDIT_0129.md voor reproduceerbare resultaten.
De audit gebruikt een statische bronstimulus; een meetbare PCM-verandering
betekent niet dat een verbinding in elke patch muzikaal nuttig is.
