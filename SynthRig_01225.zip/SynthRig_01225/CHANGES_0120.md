# SynthRig 0.12.0 — eerste APC Mini Mk2-integratie

- APC Mk2 Control-poort automatisch herkennen, optioneel MIDI-output met
  RGB-padfeedback volgens het officiële AKAI-protocol v1.0.
- Twee modi op dezelfde 8×8 matrix: PATCH (acht bestaande modulatie- en
  effectdieptes) en SEQ (acht lanes × 16 stappen, pagina 1/2).
- Acht onafhankelijk opgeslagen sequencerpatronen, BPM via APC masterfader,
  lane-pitch en SHIFT+velocity via eerste acht faders.
- Optionele synchronisatie met inkomende SWING MIDI Clock en Start/Stop.
- Beschermde gecombineerde MIDI-notenrouter voor Swing en APC, zodat
  overlappende noten elkaar niet onbedoeld afsluiten.
- APC-aanpassingen aan bestaande synthparameters gebruiken de bestaande
  MIDImix-soft-takeover en sessiebewaring.
- Optionele APC-status in het bestaande MIDImix-debugvenster.
- Uitgangs- en audiocode van 0.11.3 ongemoeid gelaten, op het nieuwe optionele
  APC-MIDI-invoegpunt na. Presets, MIDI-mapping en outputgain behouden.
- Nieuwe Python-protocoltests en drie extra offline-SunVox-audiocontroles.

**Scope:** PATCH is nog geen vrij configureerbare audio-/modulatierouter;
alleen de acht expliciet getoonde verbindingen/parameters zijn instelbaar.
**Hardwaretest ontbreekt nog:** de LED-uitvoer en APC MIDI-bediening zijn
volgens de fabrikant geïmplementeerd en gesimuleerd, maar moeten op de
fysieke APC Mini Mk2 bevestigd worden.
