#!/usr/bin/env python3
"""Vergelijk twee reproduceerbare SynthRig 0.8.5 opnamen.

Gebruik: python vergelijk_opnamen.py opname_zonder_dc.zip opname_met_dc.zip
Geen extra dependencies; vergelijk PWM-fase 1-7s, niet het opstarttransient.
"""
from __future__ import annotations
import argparse
import statistics
from pathlib import Path
from analyse_debug import load


def _safe_stats(summary, windows, start=1.0, end=7.0):
    selection=[w for w in windows if start <= float(w['t_s']) < end]
    def nums(key):
        return [float(w[key]) for w in selection if str(w.get(key,'')).strip()]
    dc=[abs(x) for x in nums('dc_offset_approx')]
    rms=nums('rms_dbfs_approx')
    peak=nums('peak_dbfs_approx')
    return {
        'dc_mean': statistics.mean(dc) if dc else None,
        'dc_max': max(dc) if dc else None,
        'rms_mean': statistics.mean(rms) if rms else None,
        'peak_max': max(peak) if peak else None,
        'samples': len(selection),
        'dc_enabled': bool(summary.get('metadata',{}).get('dc_blocker_enabled')),
    }


def compare(a,b):
    su1, events1, win1=load(Path(a))
    su2, events2, win2=load(Path(b))
    u,v=_safe_stats(su1,win1),_safe_stats(su2,win2)
    return u,v


def fmt(x,kind='dec'):
    return 'n.v.t.' if x is None else (f'{x:.5f}' if kind=='dec' else f'{x:.1f} dBFS')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('zonder',type=Path)
    p.add_argument('met',type=Path)
    args=p.parse_args()
    a,b=compare(args.zonder,args.met)
    print('SynthRig 0.8.5 — vergelijking van 1.0 tot 7.0 s PWM\n')
    print(f"{'':27} {'opname A':>15} {'opname B':>15}")
    for label,key,kind in (
        ('Per-osc DC-blockers','dc_enabled','bool'),
        ('Gemiddelde |DC|','dc_mean','dec'),
        ('Maximum |DC|','dc_max','dec'),
        ('Gemiddelde RMS','rms_mean','db'),
        ('Hoogste piek','peak_max','db'),
    ):
        av=str(a[key]) if kind=='bool' else fmt(a[key],kind)
        bv=str(b[key]) if kind=='bool' else fmt(b[key],kind)
        print(f'{label:27} {av:>15} {bv:>15}')
    print('\nRMS/dB is het gemiddelde van 100ms-vensters, DC is bemonsterd.')
    print('Alle metingen komen van de Linux-output-monitor (niet een interne SunVox-bus).')
    if a['dc_enabled'] == b['dc_enabled']:
        print('LET OP: beide opnamen hebben dezelfde DC-blockerinstelling.')


if __name__=='__main__':
    main()
