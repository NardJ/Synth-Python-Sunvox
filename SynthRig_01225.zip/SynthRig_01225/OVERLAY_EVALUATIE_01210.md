# Voorlopige beoordeling van de APC-modulatiematrix — SynthRig 0.12.10

Deze versie wijzigt geen modulatiebronnen, bestemmingen of presetformaten.
De matrix is muzikaal nog niet definitief; toets ideeën eerst in een volgende versie.

## Huidige acht rijen (twee bronnen per rij)
1. LFO / LFO2: behouden; twee onafhankelijke bewegingsbronnen zijn belangrijk.
2. Filter ENV / AMP ENV: behouden voor nu; een zelfstandige, vrij instelbare Mod ENV zou op termijn beter zijn dan de AMP ENV hergebruiken.
3. Velocity / inverse velocity: tweede laag is weinig onderscheidend; inverse is met een negatieve modulatie-amount en/of BIAS grotendeels benaderbaar.
4. Aftertouch / inverse aftertouch: zelfde aandachtspunt.
5. Mod Wheel / inverse mod wheel: zelfde aandachtspunt.
6. Keytrack / inverse keytrack: exact de tegengestelde polariteit van de bestaande KEYTRACK (-key). Redundant bij negatieve diepte.
7. Gate / Trigger: nuttig voor aan/uit en korte impulsen, maar aanvullende audiotests van snelle triggers zijn belangrijk.
8. BIAS / Sample & Hold: BIAS is handig als constante offset; S&H geeft meer klankbeweging.

Prioriteit voor mogelijke vervangers van inverse-bronnen: vrij programmeerbare Mod ENV, extra onafhankelijke LFO, langzaam vloeiende Random en een instelbare MIDI-expressionbron (indien hardware beschikbaar).

## Huidige acht kolommen (twee bestemmingen per kolom)
1. OSC1 Pitch / SUB level: beide zinvol.
2. OSC2 Pitch / Noise level: beide zinvol.
3. OSC1 PWM / Filter ENV Amount: zinvol, PWM werkt alleen als betreffende golfvorm die parameter gebruikt.
4. OSC2 PWM / Keytracking Amount: zinvol maar de tweede bestemming is eerder macro-modulatie dan een direct hoorbaar effect.
5. Cutoff / Delay Mix: sterk.
6. Resonance / Reverb Mix: sterk.
7. OSC1 Level / Chorus Mix: sterk.
8. OSC2 Level / Output Level: OSC2 Level goed, Output Level vraagt veiligheidsbegrenzing/clippingcontrole.

Mogelijk interessante ontbrekende bestemmingen: filter drive, LFO rate, envelope attack/decay, stereo pan, delay feedback (met feedbackbeperking), chorus depth.

## Vergelijking met bestaande instrumenten
- Arturia PolyBrute: bronnen als LFO's, VCF/Mod ENV, detune, velocity, aftertouch en modulatiecontroles; modmatrix rijen bron/kolommen bestemming; meerdere bronnen op bestemming; 64 routes per preset.
  https://support.arturia.com/hc/en-us/articles/4405748080914-PolyBrute-Modulation-Matrix
- ASM Hydrasynth: 35 bronnen, 191 bestemmingen en 32 routingslots; brede keuze zonder vaste 8×8-overlay.
  https://www.asmhydrasynth.com/hydrasynth-specifications.html
- Novation Summit: 16 main modslots, LFO1/2, velocity, aftertouch, mod envelopes; destinaties inclusief oscillatorpitch/shape, filter, LFO en envelopetijden; aparte FX-modmatrix.
  https://userguides.novationmusic.com/hc/en-gb/articles/25003971047186-Summit-in-detail

## Advies
Behoud de vaste overlaylogica (acht fysieke rijen/kolommen met twee labels) en de vijf kleuren.
Vervang de tweede laag pas nadat vervangende bronnen/bestemmingen in de SunVox-engine werken én de presetmigratie is uitgewerkt. Verander nooit stilletjes de betekenis van bestaande presets.
