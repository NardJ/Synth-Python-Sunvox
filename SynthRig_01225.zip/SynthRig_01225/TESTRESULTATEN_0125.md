# SynthRig 0.12.5 — uitgevoerde controles

- Python-regressietests: **184/184 geslaagd** (`unittest discover`).
- Native SunVox, zonder fysieke geluidskaart: **233/233 geslaagd**.
- SunVox events-modus, zonder fysieke geluidskaart: **233/233 geslaagd**.
- APC-Mk2-venster gestart onder Linux Xvfb, zonder GUI-fout; virtuele afmetingen: 687 × 1017.

## Nieuwe audiocontroles

1. Constante BIAS → OSC1 level: RMS van 0.066319 naar 0.099442.
2. Verbinding verwijderen: RMS keert terug naar 0.066628.
3. BIAS → filter-cutoff: genormaliseerde spectrale verhouding verandert van 0.079123 naar 0.063112.
4. BIAS → OSC1 pitch: +24.72 cent zonder SET_PITCH tijdens de aangehouden noot.
5. Alle routes verwijderen geeft een lege matrix.
6. LFO → OSC1 pitch bij SIN: grootste samplesprong 0.003424 tegenover 0.003400 stabiel.
7. BIAS → OSC1 PWM op PULSE: SunVox-duty van 511 naar 695.

De 226 bestaande SunVox-regressies bevatten o.a. sequencer, notenrouter, portamento,
chorus, release-/voice-steal-controles, gain en 16 presets.

## Nog op echte hardware te bevestigen

- Beeld en LED-kleuren op de fysieke APC Mini Mk2.
- Bronkeuze via fysieke knoppen rechts van de matrix.
- Het speelgevoel van snel veranderende modulatie en pickup-bewegingen.
- Geluidsbalans bij complexe patches met meerdere gelijktijdige verbindingen.

De LED-kleuren zijn software-opdrachten; niet op de hardware teruggelezen.
