# Overlays 0.12.13 — maximaal 8 tekens, monospaced

| Fysieke rij (onder naar boven) | Laag A | Laag B |
|---|---|---|
| 1 | `LFO1` | `LFO2` |
| 2 | `FLT ENV` | `AMP ENV` |
| 3 | `VELOCITY` | `MOD ENV` |
| 4 | `AFTTOUCH` | `LFO3` |
| 5 | `MODWHL` | `SMOOTH R` |
| 6 | `KEYTRACK` | `NOTE RMP` |
| 7 | `GATE` | `TRIGGER` |
| 8 | `BIAS` | `S&HOLD` |

| Fysieke kolom (links naar rechts) | Laag C | Laag D |
|---|---|---|
| 1 | `O1 PITCH` | `SUB LVL` |
| 2 | `O2 PITCH` | `NOISE LV` |
| 3 | `O1 PWM` | `ENV AMT` |
| 4 | `O2 PWM` | `LFO RATE` |
| 5 | `CUTOFF` | `DLY MIX` |
| 6 | `RESON` | `REV MIX` |
| 7 | `O1 LEVEL` | `CHO MIX` |
| 8 | `O2 LEVEL` | `DLY FDBK` |

De volledige semantische namen blijven in `synthrig/mod_matrix.py` staan.
