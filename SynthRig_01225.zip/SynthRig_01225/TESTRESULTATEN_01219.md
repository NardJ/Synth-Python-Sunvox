# SynthRig 0.12.19 — regressietesten

## Reparatie

Bij SOLO kort zonder geselecteerde preset (`PresetManager.selected == -1`)
wordt de PANIC-functie uitgevoerd, maar er wordt geen enkele MIDImix-LED-
opdracht verzonden of opnieuw gesynchroniseerd. Het debugvenster behoudt zijn
vorige 16 LED-standen. De algemene gedwongen synchronisatie bij `note_off`
wordt voortaan overgeslagen voor de SOLO-toets; de overige MIDImix-knoppen
blijven hun normale synchronisatie behouden.

## Uitgevoerd

- Python `unittest discover -s tests -q`: **255/255 PASS**.
- Nieuw: `test_01219_solo_no_selection_leds.py`: **5/5 PASS** (PANIC zonder preset,
  herhaald SOLO, preset 1/8/11/16, lange SOLO, normale knoppen).
- Live-path simulatie onder Xvfb en Tkinter via UDP: **PASS**, 5 keer SOLO zonder
  gekozen preset, geen nieuwe fysieke MIDI-LED-opdrachten en identieke GUI-knopkleuren.
- Bestaande SOLO + preset teller GUI proef: **PASS**, alle 16 presetposities,
  tijdsoverlay, herstel en APC SCENE-vormen.
- SunVox offline audio native mode: **248/248 PASS**.
- SunVox offline audio events mode: **248/248 PASS**.

## Grenzen

De fysieke MIDImix is niet beschikbaar in deze testomgeving. De fysieke
LED-uitgang is met een MIDI-berichtensink gecontroleerd; de echte Tkinter-GUI
is onder Xvfb via UDP aangestuurd. De SunVox-engine en klankpresets zijn niet
gewijzigd. De matrix zelf is in 0.12.19 niet opnieuw geaudit omdat de matrixcode
niet is veranderd; voorgaande 0.12.18 audits blijven van toepassing.
