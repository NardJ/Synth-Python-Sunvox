# APC-looplengte kiezen: 4, 8 of 16 stappen

Dit verandert de lengte van jouw APC-rondje. Het tempo blijft hetzelfde. Een loop van 4 stappen herhaalt stap 1 vier keer zo vaak als een loop van 16 stappen.

## De knoppen vinden

- De acht kleine knoppen **onder** het grote 8×8-rooster noemen we TRACK 1–8, van links naar rechts.
- De acht kleine knoppen **rechts naast** het rooster kiezen normaal een patroonplaats. Voor de looplengte gebruik je hiervan de **bovenste drie**.
- Gebruik de **SHIFT-knop op de APC**, rechtsonder naast de rij TRACK-knoppen.

## Lengte instellen

1. Druk onder het rooster op de tweede kleine knop: **TRACK 2 — SEQ**.
2. Houd **APC-SHIFT** ingedrukt. In het APC-venster verandert de rechterkolom van PATROON naar LENGTE met de labels **4**, **8**, **16**.
3. Druk rechts naast het rooster op de bovenste knop voor **4**, de tweede voor **8** of de derde voor **16**.
4. Laat SHIFT los. Het venster blijft bovenaan **LOOP 4 STAPPEN**, **LOOP 8 STAPPEN** of **LOOP 16 STAPPEN** tonen.
5. Gebruik **TRACK 5 — PLAY** om met de interne clock te spelen, of PAUSE/PLAY op de SWING als de APC de SWING-clock volgt.
6. Druk **TRACK 6 — SAVE** om de lengte bij het huidige patroon op te slaan.

SHIFT blijft tijdens de keuze ingedrukt. Zonder SHIFT kiezen de rechterknoppen weer een van de acht patroonplaatsen. De overige vijf rechterknoppen hebben tijdens deze lengtekeuze geen functie.

## Voorbeeld: alleen noot 48 op stap 1

Laat de SWING op STOP en start SynthRig met `--apc-clock internal`. Kies SEQ. Druk op TRACK 3 om stappen 1–8 te bekijken. De onderste rij hoort bij de eerste notenlane; standaard is dat MIDI-noot 48. Laat alleen de pad helemaal linksonder groen staan.

Kies loop 4 en druk TRACK 5 — PLAY. De markering doorloopt kolommen 1, 2, 3, 4 en springt terug naar 1. Je hoort de noot op elke nieuwe stap 1. Kies daarna 8 of 16 om dezelfde aanslag minder vaak te laten terugkomen, met dezelfde BPM.

Bij zestiende stappen en 120 BPM zijn de rondjes:

| Lengte | Tijd per rondje |
|---|---|
| 4 stappen | 0,5 seconde |
| 8 stappen | 1 seconde |
| 16 stappen | 2 seconden |

## Opgeslagen noten blijven behouden

Stap 5–16 blijven in het patroonbestand aanwezig wanneer je loop 4 kiest. Opgeslagen noten buiten de loop zijn gedimd en klinken niet. Uitbreiden naar 8 of 16 maakt ze weer actief. Je kunt ook buiten de loop blijven bewerken; de statusmelding geeft dan aan dat die stap buiten de huidige loop ligt.

De pagina-knoppen TRACK 3/4 kiezen nog steeds stappen 1–8 of 9–16 om te bekijken en bewerken. Dat is iets anders dan de looplengte. Bij een loop van 4 zijn alleen kolommen 1–4 van de eerste pagina in het afspeelrondje opgenomen.

## Opslag en oudere bestanden

Elk van de acht APC-patroonplaatsen bewaart zijn eigen looplengte met SAVE. Zonder SAVE blijven wijzigingen alleen in de huidige speelsessie. Een oud opgeslagen patroon zonder lengteveld begint op 16. De SWING-sequence wordt door deze keuze niet veranderd.
