# Een rijtoon horen door op een pad te drukken

1. Druk op de APC op de **tweede kleine knop onder het grote rooster: TRACK 2 — SEQ**.
2. Druk op een pad in het rooster. Je hoort direct de toon van die rij, ook als de sequencer stilstaat.
3. De pad zet tegelijk de betreffende stap aan of uit, zoals voorheen. Elke nieuwe druk laat de rijtoon kort horen.
4. Gebruik de bijbehorende APC-fader om de toonhoogte van de rij te wijzigen. De eerste fader hoort bij de onderste rij. Tik daarna op een pad in die rij om de nieuwe toonhoogte te horen.
5. Gebruik **TRACK 6 — SAVE** om het bewerkte patroon te bewaren.

Een korte pad-druk geeft een luistertoon met een gate van een kwart seconde. Hij klinkt met je huidige synthesizerklank: attack en release blijven dus hoorbaar. Delay en reverb kunnen na Note Off uitklinken.

Bij een lopende sequence blijft de clock doortellen. Als een echte sequencer- of SWING-noot binnenkomt, krijgt die voorrang boven het voorluisteren. Een preview mag geen van de vier bezette muziekstemmen stelen; in dat geval blijft de stapbewerking geldig en staat `stemmen bezet` in de statusmelding.

De luistertoon is tijdelijk. Zijn timer en noot worden niet bewaard bij SAVE. Beide PANIC-functies ruimen hem op. In PATCH-modus houden de pads hun matrixfunctie en klinken ze niet door een druk.

Opgeslagen stappen buiten een korte loop worden tijdens PLAY niet gespeeld. Bij het bewerken van zo'n pad hoor je wel de rijtoon: dat is de losse preview, geen uitbreiding van de afspeelloop.
