# 0.11.3 — stuck notes bij akkoorden

- Verholpen: voice-stealing tijdens overlappende akkoorden verwijderde soms de verkeerde `active_notes`-verwijzing wanneer een oudere release-stem dezelfde pitch had als een nieuwe stem.
- Preventie: verwijder een notetoewijzing alleen als die werkelijk eigendom is van de gestolen stem.
- Regressie: exacte MIDI-tijdlijnen van beide opnamen uit 0.11.2 nagespeeld en minimal-case test in `tests/test_0113.py`.
- Geen wijziging aan audio, oscillatorpitch, portamento, chorus of presets.
- Versie in debugvenster en diagnose bijgesteld naar 0.11.3; MIDI mapping blijft 1.1.
