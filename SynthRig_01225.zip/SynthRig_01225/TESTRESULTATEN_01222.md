# Testresultaten SynthRig 0.12.22

| Controle | Resultaat |
|---|---|
| Volledige Python-regressiesuite | **306 tests geslaagd** |
| Interne clock | 4-, 8- en 16-stapsloops herhalen exact de gekozen lengte |
| SWING-clock | 4/8/16-lussen; zes clockpulsen per stap behouden |
| Eén noot op stap 1 | Bij loop 4 exact één Note On per vier stappen; opgeslagen noten op 5/16 klinken niet |
| STOP/CONTINUE | Pulspositie behouden, ook bij korte loop |
| Live inkorten | APC-gate buiten nieuwe grens los; volgende stap 1; transport en tempo behouden |
| Noten van andere bron | Gedeelde SWING-noot wordt niet door inkorten afgebroken |
| Controllerbediening | SHIFT + bovenste drie rechterknoppen selecteren 4/8/16 zonder bankwissel |
| Normale bediening | Rechterknoppen selecteren zonder SHIFT nog alle acht patronen; PATCH-bediening behouden |
| LEDs | Lengtekeuze en terugkeer naar bankweergave gelijk aan verstuurde MIDI-opdrachten |
| Bewaren | Eigen lengte per patroon; SAVE en herstart/reload gecontroleerd |
| Compatibiliteit | Oud patroon zonder lengte = 16; ongeldige lengtes afgewezen zonder huidige patroon te veranderen |
| Databehoud | Volledig 16-stapsrooster blijft bij inkorten behouden; uitbreiden herstelt actieve noten |
| Upgrade | 0.12.21 heeft prioriteit; huidige bestanden worden niet overschreven |
| Echte Tk/UDP | SHIFT-labels, loopheader, LEDs, stapnoemer, dimmen, SAVE/reload en beide clockmodi geslaagd |
| Zoom | Nieuwe teksten passen bij 50%, 90% en 100%; geen groei canvas-itemaantal |
| Regressie synchronisatie | START, STOP, CONTINUE, clockverlies en herstel geslaagd in Tk/UDP |
| Regressie ADSR | 16 presets, faders, pickup en zoom geslaagd |
| Regressie SOLO | 16 presetnummers en 5 PANIC-cycli zonder gekozen preset geslaagd |
| Bronvergelijking | Native DSP alleen versieteksten anders; ADSR-geometrie, mappings en fabriekspresets gelijk aan 0.12.21 |
| Aflevering | ZIP-integriteit, syntax en nieuwe tests/startfile uit afzonderlijk uitgepakte ZIP gecontroleerd |

De GUI-tests gebruiken echte Tk-canvassen en localhost-UDP, gesimuleerde MIDI-gebaren/LED-uitvoer en FakeSlot voor SunVox. De fysieke APC, SWING en MIDImix waren hier niet aangesloten. Er zijn geen native DSP-audiotests opnieuw uitgevoerd; de sequencer-nootroutering en gates zijn in de nieuwe tests gecontroleerd.

Logs staan in `reports_01222/`: `python_tests.log`, `loop_tests.log`, `gui_loop_length.log`, `gui_sync.log`, `gui_adsr.log`, `gui_solo_session.log` en `gui_solo_presets.log`. `GUI_APC_LOOP4_01222.png` is een echte Tk-schermafdruk uit de simulatie.

De oudere startfiles, verslagen en schermafdrukken in het pakket horen bij eerdere releases. Start voor deze functie `synthrig_01222.py`.
