#!/usr/bin/env python3
"""Meet de vijf fasen van --tonecheck --record uit een diagnose-ZIP.

Pure Python FFT. Fasen volgen timestamps uit log; opname via output-monitor
is NIET sample-precies. Uitkomsten zijn aanwijzingen, geen laboratoriummeting.
"""
from __future__ import annotations
import argparse
from array import array
import io
import json
import math
import sys
import wave
import zipfile


def fft(signal):
    n=len(signal);a=[complex(x) for x in signal]
    j=0
    for i in range(1,n):
        bit=n>>1
        while j&bit:j^=bit;bit>>=1
        j^=bit
        if i<j:a[i],a[j]=a[j],a[i]
    length=2
    while length<=n:
        angle=-2*math.pi/length
        root=complex(math.cos(angle),math.sin(angle))
        half=length>>1
        for start in range(0,n,length):
            w=1+0j
            for k in range(start,start+half):
                t=w*a[k+half];u=a[k]
                a[k]=u+t;a[k+half]=u-t;w*=root
        length*=2
    return [abs(z) for z in a[:n//2]]


def spectrum(samples,rate,t):
    N=32768
    begin=max(0,int((t+.42)*rate))
    if begin+N>len(samples):return None
    block=samples[begin:begin+N]
    average=sum(block)/N
    window=[(x-average)*(0.5-0.5*math.cos(2*math.pi*i/(N-1))) for i,x in enumerate(block)]
    bins=fft(window)
    lo=max(1,int(60*N/rate));hi=min(len(bins)-2,int(1450*N/rate))
    k=max(range(lo,hi),key=lambda i:bins[i])
    # Quadratic interpolation on log-magnitudes.
    a,b,c=[math.log(max(1e-20,bins[z])) for z in (k-1,k,k+1)]
    delta=max(-.5,min(.5,.5*(a-c)/(a-2*b+c))) if a-2*b+c else 0
    f=(k+delta)*rate/N
    def peak_near(freq):
        center=freq*N/rate
        idx=round(center)
        if idx<1 or idx>=len(bins)-1:return 0
        return max(bins[max(0,idx-2):min(len(bins),idx+3)])
    fundamental=peak_near(f)
    ratios=[peak_near(f*i)/fundamental for i in range(2,7) if f*i<rate*.49]
    thd=math.sqrt(sum(r*r for r in ratios))
    rms=math.sqrt(sum(x*x for x in block)/N)/32768
    return {'dominant_hz':round(f,2),'rms_dbfs':round(20*math.log10(max(rms,1e-15)),2),
            'harmonic_2_db':round(20*math.log10(max(ratios[0],1e-10)),1) if ratios else None,
            'harmonic_3_db':round(20*math.log10(max(ratios[1],1e-10)),1) if len(ratios)>1 else None,
            'thd_est_percent':round(thd*100,2)}


def load_bundle(path):
    with zipfile.ZipFile(path) as z:
        wavs=[n for n in z.namelist() if n.endswith('.wav')]
        logs=[n for n in z.namelist() if n.endswith('.jsonl')]
        if len(wavs)!=1 or len(logs)!=1:raise ValueError('ZIP bevat niet precies 1 WAV + 1 JSONL')
        events=[json.loads(x) for x in z.read(logs[0]).splitlines() if x]
        with wave.open(io.BytesIO(z.read(wavs[0]))) as w:
            if w.getsampwidth()!=2:raise ValueError('16-bit PCM vereist')
            rate=w.getframerate();channels=w.getnchannels()
            pcm=array('h');pcm.frombytes(w.readframes(w.getnframes()))
            if sys.byteorder!='little':pcm.byteswap()
        mono=pcm[::channels]
        return rate,mono,[e for e in events if e['event']=='tonecheck_step']


def analyze(path):
    rate,pcm,steps=load_bundle(path)
    print(f'Audio {len(pcm)/rate:.2f}s · {rate} Hz · {len(steps)} fasen')
    if len(steps)!=5:print('WAARSCHUWING: verwacht 5 tonecheck-fasen')
    results=[]
    for event in steps:
        data=event['data'];res=spectrum(pcm,rate,event['t'])
        print(f"{data['label']}: golfvorm vraag={data['waveform_requested']} "
              f"echt={data['waveform_readback']} | {res}")
        results.append((data,res))
    for data,res in results:
        if data['waveform_requested']!=data['waveform_readback']:
            print('FOUT: golfvormreadback wijkt af in:',data['label'])
    if len(results)==5 and all(r is not None for _,r in results):
        hz0=results[1][1]['dominant_hz'];hz1=results[2][1]['dominant_hz']
        print(f'Kale Generator SET_PITCH(261.6 Hz) => {hz0:.2f} Hz; '
              f'SET_PITCH(130.8 Hz) => {hz1:.2f} Hz')
        print(f"RMS verschil direct/vibrato A=0: {results[4][1]['rms_dbfs']-results[1][1]['rms_dbfs']:+.2f} dB")
        if abs(1200*math.log2(hz0/261.625565))>35:
            print('AFWIJKING: kale Generator reageert niet op 261.63Hz als 261.63Hz.')
        if results[1][1]['harmonic_2_db']>-35:
            print('AFWIJKING: al bij kale SIN sterk tweede harmonische aanwezig.')
    print('Opgelet: monitor-audio is niet sample-synchroon; gebruik het rapport naast de WAV.')
    return results

if __name__=='__main__':
    a=argparse.ArgumentParser(description=__doc__);a.add_argument('bestand');
    analyze(a.parse_args().bestand)
