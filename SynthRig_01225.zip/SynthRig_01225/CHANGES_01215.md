# SynthRig 0.12.15 — regressie-audit en MIDImix presetfeedback

Gebaseerd op 0.12.14. De SunVox-engine, factory-presetklanken, matrixindeling,
MIDI-CC-mapping en APC-sequencer zijn inhoudelijk ongewijzigd.

## Belangrijkste wijzigingen

1. **BANK LEFT/RIGHT → preset laden → MIDImix-LED-teller** wordt nu door
   dezelfde productiehandler als de live MIDI-loop uitgevoerd en met
   gesimuleerde MIDI-invoer in alle zestien slots getest. Na 1 seconde keren
   de normale golfvorm- en bron-LEDs terug.
2. Bij iedere ontvangen BANK-druk meldt de terminal expliciet of zestien
   LED-opdrachten zijn verzonden of dat de MIDImix-uitgang ontbreekt/faalt.
   Ontbrekende LED-feedback mag de presetselectie niet stoppen.
3. **Zelfstandige hardwarediagnose**, zonder SunVox:
   `python synthrig_01215.py --midimix-led-test`.
   De MIDImix moet 1, 8 en 16 LEDs laten zien; sluit de normale synth eerst af.
4. Afsluiten tijdens een preset-LED-overlay wist alle gecontroleerde LEDs;
   voorheen kon de LED-cache leeg zijn terwijl hardware-LEDs nog brandden.
5. De teststub `FakeSlot` is zelfstandig gemaakt. Voorheen slaagde de volledige
   regressiesuite, terwijl de 0.11.1-presettest **zelfstandig faalde** door een
   toevallige importvolgorde.
6. Bij upgrade worden eerst de nieuwste bestanden uit `SynthRig_01214`
   meegenomen: sessie, gebruikerspresets, APC-patronen en outputgain.

## Wat we WEL en NIET hebben aangetoond

De werkelijke Python-productiehandler, presetmanager en gesimuleerde MIDI-output
zijn integraal getest. De echte SunVox-engine is offline getest, inclusief beide
pitchmodi, sequencer- en modulatieregressies. Een echte hardware-LED-uitlezing
bestaat niet voor de MIDImix; de MIDI-uitvoer en timing op jouw concrete Linux-
installatie zijn hier niet fysiek te bevestigen. Gebruik `--midimix-led-test` om
te onderscheiden of de LED-uitvoer zelf of de BANK-invoer de oorzaak is.

Zie `REGRESSIEAUDIT_01215.md` voor aantallen en testdekking.
