# SynthRig 0.12.19 — SOLO zonder geselecteerd presetnummer

- Keuze B: SOLO kort doet nog steeds PANIC, maar bij `selected == -1` worden geen nieuwe hardware-LED-commando's verzonden en de GUI-LEDs blijven ongewijzigd.
- Bugfix: na een SOLO note_off geen generieke geforceerde LED-verversing meer; de aparte SOLO-gesture bepaalt uitsluitend of preset-LEDs worden getoond.
- Bij geselecteerde preset 1–16 blijft de tijdelijke tellende weergave een seconde werken, inclusief GUI-spiegeling.
- Lange SOLO blijft SAVE. BANK, APC, SunVox-audio-engine en presets zijn functioneel ongewijzigd.
- Data-upgradeprioriteit: gebruikersdata uit 0.12.18 eerst.
- Nieuwe regressietests voor geen geselecteerd presetnummer en voor andere MIDImix-drukknoppen.
