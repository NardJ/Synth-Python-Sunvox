# SynthRig 0.12.18 — SOLO: PANIC én huidige preset tonen

## Exacte bediening

- **SOLO kort indrukken en loslaten:** een enkele druk doet twee dingen in dezelfde handeling. De echte `rig.panic()` (of bij een aangesloten APC: `apc.set_playing(False)` en `apc.router.panic()`) stopt lopende stemmen, effectbuffers en APC-sequencer. Daarna geeft `MidiMixLEDs.show_preset()` een seconde lang het reeds geselecteerde presetnummer als 1–16 brandende LEDs. Het gecombineerde UDP-pakket bevat de presetidentiteit en dezelfde *daadwerkelijk verstuurde* LED-status voor de MIDI-debug-GUI. Geen dubbele druk vereist.
- **SOLO >= 1,5 s vasthouden:** bestaande SAVE-actie blijft behouden; geen PANIC.
- **BANK LEFT/RIGHT:** wisselt presets met natuurlijke effectstaart, zoals voorheen.
- **APC PANIC:** blijft directe noodstop, zonder preset-LED-overlay als extra bijwerking.
- **Geen geselecteerde preset:** SOLO blijft PANIC uitvoeren, maar toont geen verzonnen nummer.

De SOLO-actie wordt bij het loslaten bepaald, om onderscheid te houden tussen kort en lang indrukken. De noodstop maakt de audio *na die korte druk* direct stil. Voor onmiddellijk stoppen ongeacht drukduur blijft APC PANIC beschikbaar.

## APC-pixelartefacten

De acht SCENE/bronrij-knoppen rechts van de matrix, de acht trackknoppen en SHIFT worden nu als Tk Canvas-rechthoeken getekend in plaats van met `smooth=True` afgeronde splines. Dit voorkomt de gekartelde pixels langs de randen, ook bij niet-gehele zoomfactoren. Kleuren, eventverwerking en layoutposities blijven gelijk.

## Migratie

Sessiestatus, gebruikerspresets, APC-patronen en aparte outputgain zoeken eerst naar een aanwezige `SynthRig_01217` naast de nieuwe map. Bestaande eigen bestanden in de huidige versie worden niet overschreven.

## Regressiedekking

- Alle 16 SOLO-short-press-cases, volledige PANIC incl. SunVox-CLEAN_SYNTHS, MIDI LED-notes en GUI-UDP-snapshot.
- Long SOLO remains SAVE; herhaalde korte drukken, herstel na één seconde, geen preset geselecteerd, LED-poortfout en lopende APC-sequencer.
- De daadwerkelijke Tk Canvas knoppen via Xvfb. 16 SOLO-events -> 16 hardware-MIDI LED-opdrachten -> UDP -> genummerde GUI-knoppen; screenshots zijn afkomstig van echte Tk-vensters.
- Complete Python-regressie, native + events audio en 256 routes per modus.

Niet veranderd: klankengine, 16 fabriekspresets, APC SEQ/PATCH, 256 modulatieroutes, modulatieparameters, MIDI-mapping of outputgainwerking.
