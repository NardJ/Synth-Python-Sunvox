# SynthRig 0.12.15 — grondige regressie-audit

## Gevonden problemen / risico's

- **Defecte testisolatie** in 0.12.14: `test_0111.py` liep standalone vast bij
  ontbrekende `FakeSlot.ctl_defs['ADSR']`. De volledige suite werkte door een
  onbedoelde wijziging van de gedeelde teststub vanuit `test_09.py`. Hersteld.
- **Ontbrekende end-to-end-dekking**: de oude test riep alleen
  `MidiMixLEDs.show_preset(12)` direct aan. De complete productieflow met
  BANK-druk, alle presets, MIDI-uitvoer en automatische LED-restauratie was
  niet getest. Nu wel.
- **Afsluiten tijdens LED-telling**: `clear()` vertrouwde op een cache die bij
  `show_preset` leeg wordt gemaakt. Daardoor konden LEDs aanblijven.
  Hersteld, nu wist `clear()` de volledige zestien fysieke knop-LEDs.
- **Upgradevolgorde**: 0.12.15 neemt nu 0.12.14 als eerste bron voor sessie,
  gebruikerspresets, APC-patronen en outputgain.
- **Diagnostisch tekort**: in de oude code was de preset-LED-feedback niet
  afzonderlijk gelogd. Nu wordt per BANK-druk vermeld of MIDI-output beschikbaar
  was en of de 16 LED-opdrachten door de software zijn verstuurd.

## Uitgevoerde tests

| Onderdeel | Resultaat | Reikwijdte |
|---|---|---|
| Python volledig | **233/233 PASS** | Alle bestaande tests plus 16 nieuwe |
| Preset/LED-tests los gestart | **26/26 PASS** | Importvolgorde-onafhankelijk |
| SunVox PCM native | **242/242 PASS** | Bestaande audio-, pitch-, filter-, ADSR-, chorus-, portamento-, sub/noise- en sequencercontroles |
| SunVox PCM events | **242/242 PASS** | Alternatieve pitchbesturingsmodus |
| Matrixaudit native | **256/256 correct gerouteerd** | 254 meetbare PCM-verschillen, 2 akoestisch onbeslist |
| Matrixaudit events | **256/256 correct gerouteerd** | 254 meetbare PCM-verschillen, 2 akoestisch onbeslist |
| Matrixstress | **5/5 per modus PASS** | Meerdere routes, signaalbereik en schakelen |
| Fabriekspresets native | **37/37 PASS** | 16 presets, routes, PCM en expressie |
| Fabriekspresets events | **37/37 PASS** | Hetzelfde in events-modus |
| GUI-plaatsing/zoom | **PASS** | Tk-monitor op virtuele Linux-desktop (1600×900) |
| Python-syntax | **PASS** | compileall |

**De twee akoestisch onbesliste routes** betreffen envelope-naar-delay-feedback
in de gekozen losse A/B-situatie; de controller- en routeringstests slagen.
Dit is geen nieuwe afwijking in 0.12.15 en wordt niet als akoestisch bewezen
beschouwd.

## Extra nieuwe fysieke LED-tests (gesimuleerd)

- BANK RIGHT van niet-geselecteerd naar preset 1 en vervolgens alle 16 slots.
- BANK LEFT vanaf sessiestand naar slot 16; terug naar slot 1.
- Voor elk slot worden 16 LED Note-On-berichten verzonden, waarvan exact N
  branden bij presetnummer N.
- De overlay blijft zichtbaar ondanks geforceerde normale LED-synchronisatie.
- Exact één seconde na de laatste BANK-druk volgt de originele LED-status.
- Herhaald BANK drukken begint de éénsecondeperiode opnieuw.
- Note Off, Note On velocity 0 en andere toetsen schakelen geen presets.
- Bij ontbreken van MIDImix-MIDI-uitgang blijft presetselectie beschikbaar.
- Bij I/O-fout wordt de fout gelogd, zonder de geladen preset ongedaan te maken.
- Tijdens akkoord spelen mag presetladen geen actieve stem laten hangen.
- Zelftest 1 / 8 / 16 LEDs; alle LEDs uitschakelen bij stoppen.
- Gebruikersslot behouden na BANK-navigatie en opslaan.
- Migratie vanaf nieuwste versie mag de bestaande bestanden niet overschrijven.

## Wat zonder jouw hardware niet te testen is

- Of de daadwerkelijke MIDImix de verstuurde Note-On LED-berichten weergeeft.
- Of de Linux-MIDI-poort tijdens spelen correct bereikbaar is en niet door een
  ander proces bezet wordt.
- Het complete samenspel met MIDImix, APC, Swing en Cinnamon samen, inclusief
  hun echte eventtiming.

Om de hardwarekant te isoleren sluit je SynthRig af en voer je uit:

```bash
python synthrig_01215.py --midimix-led-test
```

Verwacht: 1 LED, dan 8 LEDs, dan 16 LEDs (elk ongeveer een seconde), daarna uit.
Als dit werkt maar BANK niet, start normaal met `--midi-log` en controleer op
`MIDIMIX RAW` en `MIDImix preset feedback` in de terminal.
