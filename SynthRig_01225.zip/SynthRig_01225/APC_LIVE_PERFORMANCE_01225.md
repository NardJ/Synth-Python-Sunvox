# Patronen live aan elkaar spelen

## Voorbereiden

Maak en bewaar de gewenste APC-patronen. In SEQ kiezen de acht kleine knoppen rechts naast het rooster de patroonplaats, van boven naar beneden 1 t/m 8. Gebruik bij deze keuze geen SHIFT. TRACK 6 — SAVE bewaart de huidige plaats, met noten, velocity, ties, looplengte en tempo.

Voor een zelfstandige APC-performance: zet de SWING op STOP en start met `--apc-clock internal`. Kies SEQ met TRACK 2.

## Een eenvoudige performance

1. Kies met de bovenste rechterknop patroon 1.
2. Druk op TRACK 5 — PLAY.
3. Druk tijdens het spelen op de tweede rechterknop. Die knop gaat knipperen; de eerste blijft branden.
4. Patroon 1 maakt zijn huidige loop af. Op de volgende stap 1 neemt patroon 2 over.
5. Zodra patroon 2 actief is, kun je opnieuw een volgende plaats kiezen. Herhaal dit bijvoorbeeld voor 1 → 2 → 1 → 3.

De overgang volgt de ingestelde looplengte van het huidige patroon: 4, 8 of 16 stappen. Het nieuwe patroon begint bij zijn eigen stap 1 en gebruikt zijn eigen looplengte. Het venster toont de huidige en volgende plaats als bijvoorbeeld **P01 → P02**. De volgende knop knippert amber in het venster; na de wissel blijft hij groen als actieve plaats.

## Je keuze wijzigen

- Een andere rechterknop kiest een andere volgende plaats: de laatste geldige keuze telt.
- Druk op de knop van het huidige patroon om de voorselectie te annuleren. De huidige loop blijft dan herhalen.
- STOP en PANIC wissen de voorselectie. Na hervatten wordt niet alsnog een oude keuze uitgevoerd.
- Zonder afspelen wordt een gekozen patroon meteen geladen.

Er staat één volgend patroon klaar. Wil je achtereenvolgens 2 en 3 horen, kies dan 3 zodra 2 actief is. Als je beide vóór de overgang kiest, vervangt 3 de voorselectie van 2.

## Tempo en klank

Tijdens live wisselen blijft het huidige tempo gelijk. De rechter APC-fader verandert bij interne clock het live tempo; bij SWING-clock gebruik je TEMPO op de SWING. Een opgeslagen ander patroon-BPM wordt wel geladen bij kiezen terwijl de sequencer stilstaat.

Een overgang laat de oude APC-gates los en geeft nieuwe noten hun eigen aanslag. Release en effecten kunnen uitklinken. SWING-noten blijven via hun eigen bron beschermd. Er wordt geen PANIC uitgevoerd, zodat effectstaarten behouden blijven.

## SAVE en LOAD

SAVE hoort steeds bij de plaats die nu speelt, niet bij de knipperende volgende plaats. Sla bewerkingen op voordat je ze wilt bewaren voor later. De voorselectie zelf wordt niet in patroonbestanden opgeslagen. LOAD herlaadt de actieve plaats direct en wist een voorselectie.

Patroonbestanden worden bij het kiezen alvast ingelezen. Een wijziging van zo'n bestand buiten SynthRig na de keuze verandert die voorbereide overgang niet. Opnieuw op dezelfde volgende knop drukken leest die plaats opnieuw in.

## Eerste controle op de rig

Gebruik twee duidelijk verschillende opgeslagen patronen, bijvoorbeeld een lage noot op plaats 1 en een hogere op plaats 2. Controleer dat de nieuwe noot pas na het einde van de huidige loop begint, dat PLAY blijft branden en dat het getoonde BPM gelijk blijft. Probeer vervolgens de voorselectie te vervangen en te annuleren met de huidige patroonknop.
