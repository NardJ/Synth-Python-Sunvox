# SynthRig 0.12.25 — live patroonwissels

- Rechter patroonknoppen in SEQ stoppen het transport niet meer tijdens spelen. Een volgende keuze wordt voorbereid en op de huidige loopgrens geactiveerd bij stap 1.
- Actieve plaats blijft branden; volgende plaats knippert fysiek. GUI toont P01 → P02 met amber knipperende voorselectie. Na de wissel wordt de nieuwe plaats actief. Eerste bewerkingspagina wordt getoond.
- Laatste geldige keuze vervangt de eerdere voorselectie; huidige patroonknop annuleert. STOP/PANIC/close, clockbronwissel, externe STOP en afhankelijke clockuitval wissen de voorselectie.
- Nieuwe bestandslezing en validatie vóór de overgang, geen disk-I/O op de muzikale grens. Een ongeldige keuze verandert actieve data of eerdere geldige voorselectie niet. Lege plaats blijft een spelend leeg patroon.
- Live tempo blijft behouden. Bij stilstaand laden wordt het opgeslagen tempo gebruikt. De inkomende SWING-clock en zijn pulspositie worden bij een patroonovergang niet opnieuw gestart.
- Oude APC-gates/ties worden op de overgang losgelaten; het nieuwe patroon krijgt eigen aanslagen. Andere nootbronnen en natuurlijke effectstaarten blijven beschermd; geen PANIC op de overgang.
- Interne scheduler blijft bij kleine pollingvertragingen op zijn bestaande tijdlijn. Grote stalls veroorzaken nog steeds geen inhaal-burst van noten.
- SAVE blijft de actieve plaats bewaren. Voorselecties worden niet opgeslagen; expliciete LOAD herlaadt de actieve plaats en wist de voorselectie.
- Nieuwe startfile `synthrig_01225.py`; upgrade geeft 0.12.24 prioriteit zonder bestaande nieuwe bestanden te overschrijven. Geen nieuwe dependencies; DSP, ADSR, mappings en factory presets ongewijzigd buiten versieteksten.
