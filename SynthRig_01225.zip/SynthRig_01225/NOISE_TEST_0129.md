# Geluidsregressie sub/noise — 0.12.9

Gemeten met de aangeleverde `sunvox-dll-python==0.4.0.2.1.4.0` native SunVox-engine,
44100 Hz, stereo float32, zonder geluidskaart of MIDI-hardware. `--noise-check`
controleert onderstaande situaties in **native** en **events**-modus.

| Controle | Native | Events |
|---|---|---|
| Alleen sub hoorbaar | PASS | PASS |
| Alleen noise hoorbaar | PASS | PASS |
| Sub en noise samen hoorbaar | PASS | PASS |
| Sub blijft juist gestemd | PASS | PASS |
| BIAS→NOISE LEVEL verandert echt audio | PASS | PASS |
| Sub blijft pitchbend +2 semitonen volgen | PASS | PASS |
| Beide stoppen na Note Off | PASS | PASS |
| Vier stemmen, geen hangende noise | PASS | PASS |

Meetwaarden van de offline-proef: sub RMS ≈0,03110, noise RMS ≈0,01849,
samen RMS ≈0,03659. Matrixversterking noise: RMS-factor ≈1,506.
Subpitch bij maximale positieve bend: ≈73,35 Hz; na Note Off
stopt het geluid volledig (RMS=0 in de meetperiode).

Opmerking: een combinatie van twee ongecorreleerde bronnen kan niet worden
beoordeeld door hun RMS-waarden simpel op te tellen. De gezamenlijke meting
bevestigt wel dat beide hoorbaar bijdragen.
