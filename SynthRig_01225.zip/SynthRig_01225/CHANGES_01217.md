# SynthRig 0.12.17 — preset-LEDs zichtbaar op de MIDImix-debugmonitor

## Probleem

In 0.12.16 werkte de fysieke LED-telling bij BANK LEFT/RIGHT, maar bleef de telling bij de gebruiker weg uit de GUI. De oude test stuurde de LED-stand **rechtstreeks naar een Tkinter-methode**; hij testte het transport vanaf een echte BANK-druk niet. De code stuurde bovendien de `preset`-melding vóór de fysieke LED-telling en de LED-stand pas later in een afzonderlijk UDP-pakket. Dat was een kwetsbare afhankelijkheid; zonder extra logging op de gebruikersmachine is niet vastgesteld of dit de enige oorzaak van het ontbrekende beeld was.

## Oplossing

- `handle_bank_press()` verstuurt eerst de zestien MIDI-LED-opdrachten en daarna **één atomair `preset`-UDP-pakket** met presetidentiteit én een snapshot van de daadwerkelijk verzonden LED-standen.
- De GUI verwerkt dat pakket samen. Daardoor kan een ontvangen presetmelding niet langer zonder bijpassende LED-toestand binnenkomen.
- Het bestaande aparte `midimix_leds`-bericht blijft bestaan. Tijdens het ongeveer 1 seconde durende presetvenster wordt de LED-snapshot maximaal circa zevenmaal per seconde opnieuw gestuurd, als extra best-effort bescherming tegen een verloren UDP-pakket.
- Op de virtuele knop-LEDs verschijnt tijdelijk het cijfer **1 t/m 16**: eerste acht oranje, volgende acht rood. Brandende knoppen krijgen ook een beter zichtbare rand. De cijfers verdwijnen bij het herstel naar de normale golfvorm- en bron-LEDs.
- Zowel fysieke als virtuele LEDs worden nog steeds afgeleid van **dezelfde daadwerkelijk verzonden MIDI-LED-opdrachten**. De GUI stuurt zelf geen MIDI.
- Migratie zoekt eerst in `SynthRig_01216`, daarna de oudere releases. Eigen presets of sessies in de nieuwe map worden niet overschreven.

## Niet gewijzigd

SunVox-engine, PANIC, BANK-presetnummering, 16 presets, APC SEQ/PATCH, 256 modulatieroutes, MIDImix-toewijzingen en outputgain.

## Testdekking

- 242 Python-unittests (238 bestaande + 4 nieuwe tests voor atomaire BANK/LED/UDP-payload).
- Extra end-to-end GUI-test onder Xvfb: **alle 16 fysieke MIDI-tellingen door de productie-BANK-handler en de echte UDP-transportmethodes naar de Tkinter-Canvas**; kleur/cijfer, presetnaam en terugkeer gecontroleerd.
- 248/248 SunVox-audiocontroles in native-modus en 248/248 in events-modus, inclusief PANIC.
- 256/256 correcte matrixrouteringen per modus; 254 routes per modus akoestisch meetbaar en 2 onbeslist (onveranderd).
- De hardware-LEDs zelf kunnen hier niet worden waargenomen; deze regressies simuleren de MIDI-output en testen de daadwerkelijke GUI.
