# SynthRig 0.12.10 — APC labels en overlay-voorbereiding

- De twee laaglabels (A/B rijen en C/D kolommen) staan ieder op een eigen regel.
- De bestemmingslabels staan direct boven de 8×8 padmatrix.
- De kolom-groepsfactor (×1.00 etc.) staat onder de bijbehorende kolom.
- Rijlabels staan rechts uitgelijnd, links van de matrix.
- Lettergrootte voor bron- en bestemmingslabels is gelijk (9 pt vóór zoom).
- In SEQ-modus blijven stapnummers boven de matrix staan; laaglabels/depth verdwijnen.
- **Geen wijziging** aan modulatiebronnen, bestemmingen, MIDI, DSP, presets of sequencer.
- De huidige laag-2-toewijzingen zijn voorlopig: stel overlay-printen nog uit.

Start: `python synthrig_01210.py --debug-ui --midi-log`.
