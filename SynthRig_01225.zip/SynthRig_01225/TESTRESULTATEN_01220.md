# Testresultaten SynthRig 0.12.20

## Uitgevoerde controles

| Controle | Resultaat |
|---|---|
| Volledige Python-unittests | 260 tests geslaagd |
| Envelopegeometrie | 256 combinaties van uiterste/middenstanden; begrenzing en volgorde correct |
| A/D/R-segmenten | Elke tijdsfader vergroot zijn eigen segment monotoon |
| Sustain | Wijzigt hoogte, niet de segmentbreedtes; minimum en maximum correct |
| Opstarten zonder ADSR-waarden | Geen verzonnen curve; verschijnt na ontvangst volledige stand |
| Echte Tk / UDP / softwarestanden | Alle 16 fabriekspresets gecontroleerd |
| MIDI / pickup | Niet-overgenomen fysieke faderbeweging verandert de curve niet |
| MIDI / toegepaste faders | Alle vier ADSR-faders veranderen de curve |
| Zoom | 50%, 100% en 90%; nieuwe updates blijven correct geschaald |
| Canvaslagen en hergebruik | Curve achter faders; geen toename itemaantal tijdens updates |
| SOLO zonder preset | 5 PANIC-cycli; nul fysieke LED-opdrachten en nul virtuele LED-veranderingen |
| SOLO met preset | 16/16 presetnummers, PANIC en herstel van LED-weergave geslaagd |
| APC-scene-randen | Bestaande rechthoekvormen bevestigd in echte GUI |
| Upgrade | Sessie, presets, APC-patronen en outputgain uit 0.12.19 hebben prioriteit boven 0.12.18; bestaande 0.12.20-bestanden blijven behouden |
| Audiobronvergelijking | engine09.py bevat uitsluitend gewijzigde versieteksten; APC-logica, factory presets en MIDImix-mapping bytegelijk aan 0.12.19 |
| Aflevering | ZIP-integriteit en nieuwe tests/startfile uit afzonderlijk uitgepakte ZIP gecontroleerd |

## Reikwijdte

GUI-controles gebruiken echte Tk-canvassen en localhost-UDP, met gesimuleerde MIDI-events en FakeSlot voor de audio-engine. `GUI_ADSR_01220.png` is een echte schermafdruk van het nieuwe venster, geen ontwerpafbeelding.

Er zijn in deze versie geen SunVox-audiotests opnieuw uitgevoerd: de audiocode is buiten versieteksten gelijk aan de aangeleverde 0.12.19. Historische testverslagen in het pakket zijn resultaten van eerdere versies. Fysieke SWING, MIDImix en APC-hardware zijn hier niet aangesloten.

De testlogs staan in `reports_01220/`. De nieuwe GUI-check is reproduceerbaar met `PYTHONPATH=.:tests xvfb-run -a python tests/gui_udp_adsr_probe_01220.py --capture` op een Linux-omgeving met Pillow, Tkinter en Xvfb. De ontwikkelomgeving gebruikte een lokaal beschikbare Xvfb-server en de ongewijzigde Python-dependencies uit requirements.txt voor mido en SunVox.
