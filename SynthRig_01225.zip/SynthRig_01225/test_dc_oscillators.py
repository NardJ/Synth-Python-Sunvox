#!/usr/bin/env python3
"""Objectieve DC-test via de volledige OSC1/OSC2 -> (DC) -> Gain -> Filter -> Output route.

Dezelfde zes toestanden (OSC 1 en 2, elk 25/50/75% PULSE) worden
opgenomen met --no-dc-blocker en met --dc-blocker. Geen MIDI nodig.
Opname is via de Linux-sinkmonitor, dus niet sample-precies gesynchroniseerd.
"""
from __future__ import annotations

import argparse
from array import array
import json
import math
from pathlib import Path
import sys
import time
import wave
import zipfile

from sunvox.api import Slot, deinit, init
from synthrig.controls import load_mappings
from synthrig.engine import SynthRig
from synthrig.recording import AudioDebugRecorder, RecordingError

SAMPLE_RATE = 44100
STAGES = (25, 50, 75)
NOTE = 48
VELOCITY = 85


def analyse_wav(wav_path: Path, stages: list[dict], enabled: bool):
    """Analyse op stabiele stukjes (geen aanslag, release of extra systeemgeluid)."""
    with wave.open(str(wav_path), 'rb') as wav:
        channels, rate, frames = wav.getnchannels(), wav.getframerate(), wav.getnframes()
        if wav.getsampwidth() != 2:
            raise RuntimeError('Verwacht 16-bit PCM in de WAV')
        raw = wav.readframes(frames)
    samples = array('h')
    samples.frombytes(raw)
    if sys.byteorder != 'little':
        samples.byteswap()
    result = []
    for stage in stages:
        # 0.8 sec settling na begin, 0.35 sec marge voor note-off.
        start = stage['note_on_s'] + .8
        end = stage['note_off_s'] - .35
        lo = max(0, round(start * rate))
        hi = min(frames, round(end * rate))
        if hi - lo < rate * .6:
            raise RuntimeError(f'Onvoldoende audio om OSC{stage["osc"]} PW{stage["width_percent"]}% te meten')
        # DC per kanaal en gemiddelde van de kanalen apart bewaren.
        sums = [0.0] * channels
        sumsq = 0.0
        peak = 0.0
        for i in range(lo, hi):
            pos = i * channels
            for channel in range(channels):
                v = samples[pos + channel] / 32768.0
                sums[channel] += v
                sumsq += v * v
                peak = max(peak, abs(v))
        n = hi - lo
        dc_channels = [x / n for x in sums]
        rms = math.sqrt(sumsq / (n * channels))
        result.append({
            'osc': stage['osc'], 'width_percent': stage['width_percent'],
            'native_requested': stage['native_requested'],
            'native_readback': stage['native_readback'],
            'dc_channel_signed': [round(v, 7) for v in dc_channels],
            'dc_mean_signed': round(sum(dc_channels) / channels, 7),
            'dc_abs_mean_channels': round(sum(abs(v) for v in dc_channels) / channels, 7),
            'rms_dbfs': round(20 * math.log10(max(rms, 1e-12)), 2),
            'peak_dbfs': round(20 * math.log10(max(peak, 1e-12)), 2),
            'analysis_start_s_approx': round(start, 3),
            'analysis_end_s_approx': round(end, 3),
        })
    return {
        'experiment': 'dc_per_oscillator_before_mix_and_filter',
        'dc_blocker_enabled': enabled,
        'sample_rate': rate, 'channels': channels,
        'recorded_seconds': round(frames / rate, 3),
        'note': NOTE, 'velocity': VELOCITY,
        'routing': 'OSC -> (optional individual DC Blocker) -> AMP -> common LPF -> Output',
        'audio_source': 'Linux output monitor; other system sounds can contaminate recordings',
        'audio_alignment': 'Approximate; WAV/audio and events are not sample synchronous',
        'results': result,
    }


def run(args):
    enabled = not args.no_dc_blocker
    print(f'\nDC-test per oscillator: {"AAN" if enabled else "UIT"} vóór de mixer/filter')
    print('Zet extern volume laag en sluit andere audiotoepassingen. Geen MIDI nodig.')
    recorder = AudioDebugRecorder(args.record_dir, source=args.record_source, bundle=True)
    version = init(None, SAMPLE_RATE, 2, 0)
    if version < 0:
        raise RuntimeError(f'SunVox initialiseert niet: {version}')
    stages = []
    try:
        with Slot() as slot:
            rig = SynthRig(slot, load_mappings(), dc_blocker=enabled)
            # Twee identieke PULSE-oscillatoren; alleen de geteste bron hoorbaar.
            rig.select_wave(1, 3)
            rig.select_wave(2, 3)
            rig.set_parameter('osc1.level', 100)
            rig.set_parameter('osc2.level', 100)
            rig.set_parameter('filter.cutoff', 127)  # zo open mogelijk
            rig.set_parameter('filter.resonance', 0)
            rig.set_parameter('master.level', 50)   # veilig, headroom
            rig.pwm.depth = 0.0                     # géén automatische PWM
            recorder.start(metadata={
                'experiment': 'dc_per_oscillator', 'synthrig_version': '0.8.5',
                'dc_blocker_enabled': enabled,
                'dc_blocker_placement': 'per_osc_before_mixer_filter' if enabled else 'disabled',
                'oscillators': [1, 2], 'widths': list(STAGES),
                'duration_per_stage_s': args.seconds,
                'filter_type': 'LPF', 'filter_cutoff': 'maximum',
                'pwm_depth': 0, 'sunvox_version': hex(version),
            })
            try:
                time.sleep(.6)
                for osc in (1, 2):
                    # Mute de andere oscillator via bestaande mixer, niet via note-routing.
                    rig.set_parameter('osc.mix', 0 if osc == 1 else 127)
                    time.sleep(.15)
                    module = rig.osc1 if osc == 1 else rig.osc2
                    ctl = rig.duty1 if osc == 1 else rig.duty2
                    for width in STAGES:
                        native = round(ctl[1] + (ctl[2] - ctl[1]) * width / 100)
                        written = rig.set_ctl(module, ctl, native)
                        time.sleep(.20)
                        readback = slot.get_module_ctl_value(module, ctl[0], 0)
                        if abs(readback - written) > 1:
                            raise RuntimeError(f'OSC{osc}: Duty readback {readback} != {written}')
                        stage = {
                            'osc': osc, 'width_percent': width,
                            'native_requested': written,
                            'native_readback': readback,
                        }
                        recorder.log('stage_setup', stage)
                        stage['note_on_s'] = time.monotonic() - recorder.started_at
                        recorder.log('note_on', {'osc': osc, 'width_percent': width, 'note': NOTE})
                        rig.note_on(NOTE, VELOCITY)
                        print(f'OSC{osc}: PULSE {width}% (native {readback}), {args.seconds:g}s')
                        time.sleep(args.seconds)
                        rig.note_off(NOTE)
                        stage['note_off_s'] = time.monotonic() - recorder.started_at
                        recorder.log('note_off', {'osc': osc, 'width_percent': width})
                        stages.append(stage)
                        time.sleep(.6)
            finally:
                rig.all_notes_off()
                if recorder.active:
                    recorder.stop()
    finally:
        if recorder.active:
            recorder.stop()
        deinit()

    if len(stages) != 6:
        raise RuntimeError('Test niet volledig afgerond')
    report = analyse_wav(recorder.wav_path, stages, enabled)
    report_path = recorder.wav_path.with_name(recorder.wav_path.stem + '_osc_dc_analysis.json')
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    with zipfile.ZipFile(recorder.bundle_path, 'a', zipfile.ZIP_DEFLATED) as archive:
        archive.write(report_path, arcname=report_path.name)
    print('\nRESULTATEN (DC-offset per kanaal gemiddeld, lager is beter):')
    print('OSC  PW      DC-mean      |DC|       RMS      piek')
    for row in report['results']:
        print(f" {row['osc']}  {row['width_percent']:>3}%  {row['dc_mean_signed']:+11.6f}  "
              f"{row['dc_abs_mean_channels']:>9.6f}  "
              f"{row['rms_dbfs']:>7.2f}  {row['peak_dbfs']:>7.2f} dBFS")
    if max(row['peak_dbfs'] for row in report['results']) < -65:
        print('WAARSCHUWING: zeer stille opname; controleer of de juiste monitor is opgenomen.')
    print(f'\nUpload deze ZIP: {recorder.bundle_path}')
    print('Voor de A/B-vergelijking ook de identieke test met de andere DC-instelling maken.')
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--dc-blocker', dest='no_dc_blocker', action='store_false', default=False,
                       help='Per-osc DC-blockers AAN (standaard)')
    group.add_argument('--no-dc-blocker', action='store_true',
                       help='A/B-referentie zonder DC-blockers')
    parser.add_argument('--seconds', type=float, default=3.0)
    parser.add_argument('--record-dir', default='recordings')
    parser.add_argument('--record-source', default=None)
    args = parser.parse_args()
    if args.seconds < 2.5:
        parser.error('--seconds >= 2.5 nodig voor een stabiel meetvenster')
    try:
        return run(args)
    except (RecordingError, OSError, RuntimeError) as error:
        print(f'FOUT: {error}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
