# Analyse vastlopende akkoorden — SynthRig 0.11.2 naar 0.11.3

**Diagnose van twee opnamen van 31 oktober 2026**

| Diagnose | Note On | Note Off | Herkende vastlopende stem | Oorsprong van de fout |
|---|---:|---:|---|---|
| 22:57:54 | 93 | 93 | B4 (MIDI 71) | om t=17,695 s |
| 22:58:30 | 58 | 58 | E4 (MIDI 64) | om t=19,486 s |

De opname-eindstatus toont in beide gevallen `active_notes: {}`, terwijl een stem actief blijft. AMP Release ~130 ms en delay/reverb 0; hierdoor is een normale release uitgesloten. Alle afgedrukte MIDI Note On-berichten zijn gepaard met een Note Off. De opgenomen Linux monitor-audio kan andere systeemgeluiden bevatten; deze conclusies steunen op MIDI- en stemstatusmetingen, niet op automatische audioherkenning.

**Oorzaak:** bij het stelen van een oude, reeds losgelaten stem kan een nieuwe stem dezelfde noot spelen. De oude code gebruikte `if v.note in active_notes: pop(v.note)` en verwijderde daarbij de registratie van de *nieuwe* stem. Zijn latere `note_off()` kon de stem daarna niet meer vinden. De synth hield onbedoeld de oscillator aan.

**Correctie:** alleen een MIDI-naar-stem-toewijzing verwijderen als `active_notes.get(v.note) == v.index`. De daaropvolgende noot krijgt zijn Note Off en de oscillator stopt na de ingestelde release. Geen wijzigingen aan pitch, effectketen, MIDI-mapping of master.

**Tests:**

- Beide oorspronkelijke MIDI-note-reeksen zijn in de ontwikkelomgeving opnieuw verwerkt met een gesimuleerde tijdlijn (186 en 116 note-events). Geen orphan-voices, na 1 seconde geen klinkende stem.
- Synthetische herhaalbare Python-test voor noot 71 en 64 plus snel wisselende akkoorden.
- Echte native SunVox-DSP-tests in twee modi spelen het scenario en meten na Note Off stilte.
- Bestaande tests van presets, chorus, portamento, filters en outputgain ongewijzigd.

**Grenzen:** De fysieke Swing is hier niet verbonden. De fix is op basis van de trace en native DSP getest; luistercontrole op de daadwerkelijke hardware blijft verstandig.
