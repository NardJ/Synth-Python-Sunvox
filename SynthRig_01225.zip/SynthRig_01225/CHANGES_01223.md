# SynthRig 0.12.23 — APC-pad voorluisteren

- Elke geaccepteerde SEQ-grid Note On laat direct de ingestelde toon en velocity van die rij horen, bij zowel aanzetten als uitzetten. Beide pagina's en alle looplengtes worden ondersteund.
- Eén tijdelijke preview tegelijk, met een automatische Note Off na 250 ms. Een nieuwe pad vervangt de vorige preview. Fysieke pad-release verandert het aan/uit-patroon niet opnieuw.
- Preview krijgt een eigen source in de bestaande NoteRouter. Echte SWING- en APC-sequencernoten hebben voorrang: gelijke noten worden niet door een preview hertriggerd/verlengd, en een oude preview-timer kan een overgenomen noot niet stoppen.
- Een nieuwe echte Note On ruimt de preview eerst op; een preview wordt overgeslagen als alle vier audiostemmen bezet zijn. Daardoor gebruikt preview geen voice stealing ten koste van een vastgehouden muzieknoot.
- Stop, PATCH-selectie, patroonladen/-wisselen, afsluiten en beide PANIC-paden ruimen de preview op. Preview wijzigt geen tempo, clock, looplengte of afspeelcursor en wordt niet in patroonbestanden opgeslagen.
- De actieve engine-noten worden na APC-bediening direct naar het bestaande NOTEN-veld gestuurd.
- Nieuwe startfile `synthrig_01223.py`; upgrade geeft 0.12.22 prioriteit voor sessie, presets, APC-patronen en outputgain, zonder bestaande nieuwe bestanden te overschrijven.
- Nieuwe routerings-, native PCM-, GUI/UDP- en upgradechecks. Bestaande PANIC-tests controleren ook de derde tijdelijke previewbron. Geen nieuwe dependencies of DSP-wijzigingen.
