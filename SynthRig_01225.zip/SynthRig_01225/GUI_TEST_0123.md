# SynthRig 0.12.3 — GUI-test

- 169 Python-regressietests geslaagd (`python -m unittest discover -s tests -q`).
- Fader-assen gecontroleerd: APC acht kolommen elk één fader in het exacte midden, master apart.
- MIDImix en APC delen exact het verticaal faderbereik 658–775 in ontwerpcoördinaten.
- GUI onder Xvfb getest op 1920×1080 en 1600×900.
- Live zoom (50%, 70%, 90%, 100%, 90%) zonder Tk-fouten en zonder overlap getest.
- Offline SunVox Native: 226 PASS, 0 FAIL.
- Offline SunVox Events: 226 PASS, 0 FAIL.
- Fysieke APC en Cinnamon-desktop nog niet op deze versie gecontroleerd.
