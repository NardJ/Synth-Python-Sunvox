# Outputgain — echte offline SunVox-audiometingen

| Gemeten instelling | Gemeten gain bij SIN (native) |
|---|---:|
| -6 dB | -6,025 dB |
| +3 dB | +3,004 dB |
| +6 dB | +5,998 dB |

De output wordt ná de mixer voor oscillatoren, chorus, delay en reverb
versterkt. Pitch en stereo blijven intact. Bij 0 dB klinkt de synth gelijk
als 0.11.1. Eerdere tests zijn opnieuw doorlopen.

### Veiligheid

Bij +3 dB bleven de piekwaarden van alle 16 fabriekspresets onder 0 dBFS met
vier aangehouden noten. De hoogste piek was 0,78892 (-2,06 dBFS) bij Bright
Lead. Dit is geen garantie voor aangepaste presets, hogere velocity,
maximale fysieke masterfader of grotere effect- en resonantie-instellingen.
Boven +3 dB geeft de GUI daarom een waarschuwing. Er is bewust geen
compressor/limiter geplaatst die de klankdynamiek kan veranderen.
