# Testresultaten — SynthRig 0.12.17

| Onderdeel | Resultaat |
|---|---|
| Python-unittests, inclusief nieuwe BANK/UDP-tests | 242/242 PASS |
| Grafische keten BANK → MIDI-LED → UDP → Tk Canvas onder Xvfb | 16/16 presets PASS, LED-herstel PASS |
| SunVox native DSP regressie | 248/248 PASS |
| SunVox events DSP regressie | 248/248 PASS |
| MATRIX native | 256/256 routering correct; 254 meetbaar, 2 akoestisch onbeslist |
| MATRIX events | 256/256 routering correct; 254 meetbaar, 2 akoestisch onbeslist |
| PANIC en uitklinkende staarten bij BANK | Geslaagd binnen beide DSP-suites |

**Interpretatie:** Hiermee is de volledige gesimuleerde bediening-keten, niet slechts de GUI-tekenfunctie, gevalideerd. Het testresultaat bevestigt niet rechtstreeks wat de LEDs van de werkelijke MIDImix op de gebruikerscomputer doen. De twee akoestisch onbesliste matrixroutes zijn de eerder bekende envelope→delay-feedbackgevallen, niet een nieuwe routeringsfout.

Bestanden in `reports_01217/`: volledige Python- en audiosuite-logs, matrix-audits en end-to-end GUI-log. `GUI_PRESET_11_01217.png` is een echte opname van de Tkinter-Canvas tijdens de preset-telling.
