# SynthRig 0.12.24 — SAVE-bevestiging, tempo en ties

- Fysieke APC-SAVE-LED één seconde aan na succesvol schrijven; GUI-knop groen met OK. De bevestigingsduur begint na de schrijfactie, ook bij een trage schijf. Nieuwe poging vernieuwt het venster.
- Schrijven met flush/fsync en atomaire vervanging. Mislukken geeft SAVE MISLUKT, geen succes-LED en behoud van het vorige bestand bij een mislukte vervanging.
- De meest rechtse fader krijgt in SEQ het label TEMPO en een BPM-uitlezing. Bestaande interne range 60–180 BPM blijft behouden. Externe clock toont SWING en geeft bij faderbeweging aan waar tempo geregeld wordt.
- Optionele 8×16-tiegegevens per patroon; ontbreken betekent alle ties uit. SHIFT + een actieve pad verbindt die met zijn actieve voorgaande pad in dezelfde rij. Nogmaals SHIFT + pad verwijdert de tie. Cyaan onderscheidt verbonden stappen van gewone groene stappen.
- Gate blijft open over de tussenliggende stapgrenzen; vervolg geeft geen nieuwe Note On. Laatste stap krijgt de normale gate. Loopgrens, STOP/CONTINUE, tempoverandering, rusten en gewijzigde rijtoon worden meegenomen.
- Zelfde toonhoogte op meerdere lanes wordt als één gate afgehandeld; een geldige tie binnen een rij wordt niet voortijdig door een andere rij afgebroken.
- Lang aangehouden ties herstellen bij de volgende stap als de engine tussentijds door een preset/session-reset zijn gate is kwijtgeraakt.
- Patroonladen/wisselen ruimt oude APC-gates op zodat geen tie uit het oude patroon kan blijven hangen. SWING-bron blijft via NoteRouter beschermd. Preview, looplengte en clockfuncties blijven behouden.
- Nieuwe startfile `synthrig_01224.py`; upgrade geeft 0.12.23 prioriteit en overschrijft geen huidige bestanden.
- Nieuwe unit-, native PCM- en Tk/UDP-checks; geen nieuwe dependencies of DSP-wijzigingen.
