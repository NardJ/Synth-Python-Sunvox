#!/usr/bin/env python3
"""Vergelijk twee SynthRig 0.8.5 DC-testbundels zonder extra pakketten.
Gebruik: python vergelijk_dc_oscillators.py opname_ZONDER.zip opname_MET.zip
"""
import argparse
import json
from pathlib import Path
import zipfile


def load(path):
    with zipfile.ZipFile(path) as archive:
        names = [n for n in archive.namelist() if n.endswith('_osc_dc_analysis.json')]
        if len(names) != 1:
            raise ValueError(f'{path}: verwacht één _osc_dc_analysis.json')
        return json.loads(archive.read(names[0]))


def compare(without, with_blocker):
    a, b = load(without), load(with_blocker)
    if a.get('dc_blocker_enabled') or not b.get('dc_blocker_enabled'):
        raise ValueError('Volgorde onjuist: eerst ZIP zonder DC-blockers, daarna met DC-blockers.')
    ax = {(x['osc'], x['width_percent']): x for x in a['results']}
    bx = {(x['osc'], x['width_percent']): x for x in b['results']}
    if ax.keys() != bx.keys():
        raise ValueError('Onvergelijkbare teststappen')
    print('OSC   PW      |DC| zonder     |DC| met    afname')
    for key in sorted(ax):
        x = ax[key]['dc_abs_mean_channels']
        y = bx[key]['dc_abs_mean_channels']
        reduction = f'{(1 - y / x) * 100:.1f}%' if x > 0.00001 else 'n.v.t. (basis ~0)'
        print(f'{key[0]:>3}  {key[1]:>3}%   {x:>12.6f}  {y:>12.6f}   {reduction}')
    print('\nLet op: WAV op basis van Linux-monitor, audio/events niet sample-nauwkeurig;')
    print('DC-verschillen tonen effect van de routing, niet de volledige klankkwaliteit.')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('zonder', type=Path)
    p.add_argument('met', type=Path)
    args = p.parse_args()
    compare(args.zonder, args.met)


if __name__ == '__main__':
    main()
