# Offline SunVox-audiotest — SynthRig 0.10.2

Start met `python synthrig_0102.py --offline-check`.
De test gebruikt `sunvox.dll.audio_callback` en laat de complete vierstemmige
engine met een virtuele 80Hz-besturing draaien. Er zijn geen fysieke MIDI- of
audioapparaten nodig. Resultaat: `recordings/offline_0100_*/report.json`,
`report.txt`, en desgewenst `offline_tests.wav`.

De 153 bestaande audio-checks uit 0.9.13 (waveforms, individuele stemmen,
pitch/tuning-sweeps, vibrato, ADSR, filter, mod-CC1-transiënten) blijven
behouden. Nieuw in 0.10.1 zijn acht checks:

1. Velocity-volume bij drie aanslagsnelheden.
2. Nagenoeg gelijk volume bij velocity-sensitivity 0%.
3. Werkelijk filteraudio-effect van channel aftertouch.
4. Gescheiden filterinstelling bij poly aftertouch op twee noten.
5. Hoorbaar/meetsbaar stereoverschil door chorus.
6. Snel wisselende chorus-CC zonder grote samplesprong.
7. Glijdende grondtoon C4 → C5, correcte eindfrequentie.
8. Geen grote samplesprongen tijdens portamento.

Daarna worden `output_nonzero`, `no_clipping` (voor de gemeten testpatches),
en stereo-output opnieuw gecontroleerd. De oude controle-uitkomsten zijn
niet per se geldig voor *elke* extreme combinatie van master en oscillatoren.

In de hier uitgevoerde tests: 161 PASS / 0 FAIL in beide modi.

## Nieuwe scenario's 0.10.1

De offline suite test nu ook het snelle patroon C3 → C4 → C4 → C3 → C3.
De tweede aanslag van dezelfde toets moet de huidige toonhoogte van de
onvoltooide glide overnemen; na meer dan 1,25 s pauze vervalt de vorige
hoogte. Chorus wordt kwantitatief beoordeeld met een SIN-noot, en moet bij
volledige instelling een duidelijk stereoverschil en RMS-toename laten zien.

## Specifieke regressie 0.10.2

De echte diagnose-patch wordt nagebouwd. Zeven extra controles meten OSC1, OSC2 en sub bij dezelfde portamento-glide, inclusief gecontroleerd hergebruik van de eerste stem met korte AMP Release en een gemengde eindtest. Totale suite: 172 controles per modus.
