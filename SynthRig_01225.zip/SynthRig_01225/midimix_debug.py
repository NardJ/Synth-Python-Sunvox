#!/usr/bin/env python3
"""Optionele, MIDImix-monitor en software-outputgain voor SynthRig 0.12.25.

Ontvangt JSON/MIDI-events via UDP op localhost. Opent GEEN MIDI-poort en
roept GEEN SunVox-functies aan. Alleen de software-outputgain is instelbaar:
de synth ontvangt die via UDP en blijft spelen wanneer dit venster sluit.
"""

from __future__ import annotations

import argparse
import json
import math
import socket
import tkinter as tk
from synthrig.window_layout import monitor_layout
from synthrig.scaled_canvas import ScaledCanvas
from synthrig.adsr_preview import AMP_CCS, envelope_points
from collections import deque
from datetime import datetime

UI_VERSION = "0.12.25"

# Fabrieksindeling. x van links naar rechts, y van boven naar beneden.
KNOB_CC = (
    (16, 20, 24, 28, 46, 50, 54, 58),
    (17, 21, 25, 29, 47, 51, 55, 59),
    (18, 22, 26, 30, 48, 52, 56, 60),
)
FADER_CC = (19, 23, 27, 31, 49, 53, 57, 61, 62)

# ADSR: A/D/R zijn tijdinstellingen; alleen S stelt een niveau in.
AMP_FADER_LABELS = {19: 'AMP A · tijd', 23: 'AMP D · tijd',
                    27: 'AMP S · niveau', 31: 'AMP R · tijd'}

def fader_label(cc, label):
    return AMP_FADER_LABELS.get(cc, label)
MUTE_NOTES = tuple(1 + i * 3 for i in range(8))
SOLO_LAYER_NOTES = tuple(2 + i * 3 for i in range(8))
REC_NOTES = tuple(3 + i * 3 for i in range(8))
BANK_LEFT_NOTE = 25
BANK_RIGHT_NOTE = 26
SOLO_NOTE = 27

# De GUI leest dezelfde mappinglabels als de synth, maar is verder onafhankelijk.
# Zonder deze debugmodule werkt de geluidsengine gewoon door.
ASSIGNMENTS = {}


def read_assignments(mapping_path):
    from pathlib import Path
    path = Path(mapping_path)
    data = json.loads(path.read_text(encoding="utf-8"))
    if "pages" in data:
        current={**data["pages"][0]["controls"], **data["global"]}
    elif "controls" in data: current=data["controls"]
    else: current=data
    return {int(k): v.get("label", v["target"]) for k, v in current.items()}


BG = '#141920'
CASE = '#222932'
PANEL = '#29323d'
OUTLINE = '#465260'
TEXT = '#e9eef5'
MUTED = '#9aaab9'
DIM = '#657380'
TRACK = '#0b1016'
CYAN = '#62d0d0'
AMBER = '#ffb75d'
RED = '#ff6876'
GREEN = '#7fe1a6'

W, H = 1170, 1065
XS = tuple(98 + 118 * i for i in range(8))
MASTER_X = 1060
KNOB_YS = (160, 286, 412)
MUTE_Y = 529
REC_Y = 592
FADER_TOP, FADER_BOTTOM = 658, 775
AMP_ENVELOPE_BOUNDS = (58, 665, 492, 775)


def cc_location(cc: int):
    for row, numbers in enumerate(KNOB_CC):
        if cc in numbers:
            return ('knob', numbers.index(cc), row)
    if cc in FADER_CC:
        return ('fader', FADER_CC.index(cc))
    return None


def note_location(note: int):
    if note in MUTE_NOTES:
        return ('mute', MUTE_NOTES.index(note))
    if note in SOLO_LAYER_NOTES:
        return ('solo_layer', SOLO_LAYER_NOTES.index(note))
    if note in REC_NOTES:
        return ('rec', REC_NOTES.index(note))
    return {BANK_LEFT_NOTE: ('bank_left',), BANK_RIGHT_NOTE: ('bank_right',),
            SOLO_NOTE: ('solo',)}.get(note)


class MidiMixMonitor:
    def __init__(self, root: tk.Tk, port: int):
        self.root = root
        self.zoom = 0.90  # leaves one zoom-in step while respecting desktop bounds
        self.layout = monitor_layout(root.winfo_screenwidth(), root.winfo_screenheight(), self.zoom)
        self.root.title(f'SynthRig {UI_VERSION} — MIDImix monitor + outputgain')
        self.root.configure(bg=BG)
        L = self.layout
        self.root.geometry(f'{L.left_w}x{L.left_h}+{L.left_x}+{L.top_y}')
        self.root.resizable(False, False)
        self.root.protocol('WM_DELETE_WINDOW', self.close)
        self.canvas = ScaledCanvas(root, scale=L.scale, width=L.left_w, height=L.left_h,
                                   bg=BG, highlightthickness=0)
        self.canvas.pack()
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.bind(('127.0.0.1', port))
        self.socket.setblocking(False)
        self.values = {}       # CC -> software settings (do not overwrite on pickup)
        self.physical_values = {}  # CC -> actual hardware positions from motion / SEND ALL
        self.buttons = {}      # ingedrukt, momentaan
        self.midimix_leds = None  # MIDI-uitvoer, niet de softwarekeuze
        self.led_overlay = False
        self.led_preset = None
        self.engine_state = {'wave1':2,'wave2':3,'enabled':{'osc1':True,'osc2':True,'sub':True,'noise':True}}
        self.last_applied = ''
        self.status_detail = None
        self.last_event = 'Wacht op MIDI-events van SynthRig...'
        self.swing_state = {'bend':0.0,'bend_semitones':0.0,'modwheel':0.0,'mod_vibrato_cents':0.0,'active_notes':[]}
        self.events = deque(maxlen=3)
        self.event_clear_job=None
        self.online = False
        self.engine_address = None
        self._gain_syncing = False
        self.output_gain_db = 0.0
        self.knob_parts = {}
        self.knob_labels = {}
        self.fader_parts = {}
        self.fader_labels = {}
        self.button_parts = {}
        self.preset_number_parts = {}  # nummer 1..16 tijdelijk OP de virtuele knoppen
        self.draw_static()
        # Separate, read-only APC mirror, placed to the right like the physical rig.
        from synthrig.apc_monitor import APCMonitor
        self.apc_monitor=APCMonitor(root, layout=self.layout)
        self.apc_monitor.set_zoom_label(self.zoom)
        for key, delta in (('<Control-plus>', 0.10), ('<Control-equal>', 0.10),
                           ('<Control-KP_Add>', 0.10), ('<Control-minus>', -0.10),
                           ('<Control-KP_Subtract>', -0.10)):
            self.root.bind_all(key, lambda event, step=delta: self.change_zoom(step))
        self.root.bind_all('<Control-0>', lambda event: self.set_zoom(1.0))
        self.root.bind_all('<Control-KP_0>', lambda event: self.set_zoom(1.0))
        self.set_engine_state(self.engine_state)
        self.root.after(30, self.poll)

    def change_zoom(self, step):
        self.set_zoom(self.zoom + step)
        return 'break'

    def set_zoom(self, value):
        # Zoom both canvases together, without restarting the synth or the monitors.
        new_zoom = round(max(0.50, min(1.0, float(value))), 2)
        if new_zoom == self.zoom:
            return 'break'
        L = monitor_layout(self.root.winfo_screenwidth(),
                           self.root.winfo_screenheight(), new_zoom)
        self.zoom, self.layout = new_zoom, L
        self.canvas.set_scale(L.scale)
        self.apc_monitor.canvas.set_scale(L.scale)
        self.canvas.configure(width=L.left_w, height=L.left_h)
        self.apc_monitor.canvas.configure(width=L.right_w, height=L.right_h)
        self.gain_scale.configure(length=round(193*L.scale),
                                  width=max(6,round(11*L.scale)),
                                  sliderlength=max(8,round(14*L.scale)))
        self.root.geometry(f'{L.left_w}x{L.left_h}+{L.left_x}+{L.top_y}')
        w = self.apc_monitor.window
        w.geometry(f'{L.right_w}x{L.right_h}+{L.right_x}+{L.top_y}')
        self.apc_monitor.layout = L
        self.apc_monitor.set_zoom_label(self.zoom)
        return 'break'

    def draw_text(self, x, y, message, *, color=TEXT, size=11,
                  weight='normal', anchor='center', width=None):
        return self.canvas.create_text(x, y, text=message, fill=color,
                                       font=('DejaVu Sans', size, weight),
                                       anchor=anchor, width=width)

    def rounded_rect(self, x1, y1, x2, y2, radius, fill, outline='', width=1):
        # Native canvas polygon met afgeronde hoeken.
        points = [
            x1 + radius, y1, x2 - radius, y1, x2, y1,
            x2, y1 + radius, x2, y2 - radius, x2, y2,
            x2 - radius, y2, x1 + radius, y2, x1, y2,
            x1, y2 - radius, x1, y1 + radius, x1, y1,
        ]
        return self.canvas.create_polygon(points, smooth=True, splinesteps=12,
                                          fill=fill, outline=outline, width=width)

    def draw_static(self):
        c = self.canvas
        self.rounded_rect(22, 20, W - 22, 886, 24, CASE, '#3b4652', 2)
        self.draw_text(65, 58, 'AKAI  /  MIDImix', size=21,
                       weight='bold', anchor='w')
        self.page_id = self.draw_text(W - 62, 58, f'SYNTHRIG {UI_VERSION}  ·  MIDI-MAPPING 1.1',
                       color=CYAN, size=11, anchor='e', weight='bold')
        c.create_line(55, 88, W - 55, 88, fill=OUTLINE, width=1)
        self.draw_text(57, 97, 'Toegewezen functies · waarden zijn softwarestanden',
                       color=MUTED, size=10, anchor='w')
        self.preset_id=self.draw_text(W - 59, 97, 'Preset — | Sessiestand',
                       color=GREEN, size=10, anchor='e')

        for y, ccs in zip(KNOB_YS, KNOB_CC):
            for x, cc in zip(XS, ccs):
                self.draw_knob(x, y, cc)

        self.draw_button(MASTER_X, KNOB_YS[0], 'send_all', 'SEND ALL',
                         note=None, color=AMBER)
        self.draw_button(MASTER_X, KNOB_YS[1], 'bank_left', 'BANK LEFT',
                         note=BANK_LEFT_NOTE, color=AMBER)
        self.draw_button(MASTER_X, KNOB_YS[2], 'bank_right', 'BANK RIGHT',
                         note=BANK_RIGHT_NOTE, color=AMBER)

        c.create_line(58, 488, W - 56, 488, fill=OUTLINE, width=1)
        for i, x in enumerate(XS):
            self.draw_button(x, MUTE_Y, f'mute_{i}',
                             ('OSC1 ' if i<4 else 'OSC2 ')+('SIN','TRI','SAW','PULSE')[i%4],
                             note=MUTE_NOTES[i], color=AMBER)
            self.draw_button(x, REC_Y, f'rec_{i}',
                             (('OSC1','OSC2','SUB','NOISE')[i]+' ON' if i<4 else 'VRIJ'),
                             note=REC_NOTES[i], color=RED)
        self.draw_button(MASTER_X, MUTE_Y, 'solo', 'PANIC/SAVE',
                         note=SOLO_NOTE, color=AMBER)

        c.create_line(58, 633, W - 56, 633, fill=OUTLINE, width=1)
        self.draw_amp_envelope()
        for i, (x, cc) in enumerate(zip(XS + (MASTER_X,), FADER_CC)):
            self.draw_fader(x, cc, is_master=(i == 8))

        # Tweede controller: Behringer Swing met actuele pitchbend en CC1.
        self.rounded_rect(24, 902, W-24, 992, 12, CASE, OUTLINE, 1)
        self.draw_text(50, 917, 'BEHRINGER SWING  ·  LIVE MIDI',
                       color=CYAN, size=10, weight='bold', anchor='w')
        self.bend_label = self.draw_text(70, 938, 'PITCH BEND  +0.00 semitonen',
                                         color=TEXT, size=10, anchor='w')
        self.mod_label = self.draw_text(468, 938, 'MODULATION CC1  0/127',
                                        color=TEXT, size=10, anchor='w')
        self.notes_label = self.draw_text(858, 938, 'NOTEN  —',
                                          color=TEXT, size=10, anchor='w')
        self.sync_label = self.draw_text(50, 979, 'SWING SYNC · wacht op clock/transport',
                                         color=MUTED, size=9, anchor='w')
        c.create_rectangle(72,950,424,961,fill=TRACK,outline=OUTLINE)
        c.create_line(248,949,248,962,fill=MUTED,width=1)
        self.bend_bar=c.create_rectangle(248,951,249,960,fill=AMBER,outline='')
        c.create_rectangle(468,950,820,961,fill=TRACK,outline=OUTLINE)
        self.mod_bar=c.create_rectangle(469,951,470,960,fill=CYAN,outline='')
        # Swing Note/CC/Pitch events are displayed in the shared bottom event strip.
        # Compact interactive global output gain in the otherwise unused
        # right-hand portion of the Swing monitor; window height unchanged.
        self.gain_value_label=self.draw_text(855,954,'OUTPUT +0.0 dB',
                                             color=GREEN,size=9,anchor='w',weight='bold')
        self.gain_hint=self.draw_text(855,987,'Na alle effecten · apart opgeslagen',
             color=MUTED,size=8,anchor='w')
        self.gain_scale=tk.Scale(self.root,from_=-6,to=9,resolution=.5,
            orient='horizontal',showvalue=False,length=round(193*self.layout.scale),
            width=max(6,round(11*self.layout.scale)),
            sliderlength=max(8,round(14*self.layout.scale)),bg=CASE,fg=TEXT,troughcolor=TRACK,
            activebackground=CYAN,highlightthickness=0,borderwidth=0,
            command=self.on_gain_change)
        c.create_window(1037,966,window=self.gain_scale)
        self.gain_scale.set(0)
        c.create_line(28, 1004, W - 28, 1004, fill=OUTLINE, width=1)
        self.status_id = self.draw_text(34, 1020, '●  Softwarestanden; fysieke positie onbekend tot bewegen',
                                        color=MUTED, size=10, anchor='w')
        self.event_id = self.draw_text(34, 1048, '',
                                       color=TEXT, size=9, anchor='w')
        self.state_id = self.draw_text(34, 867, '', color=CYAN, size=10, anchor='w')
        self.apc_id=self.draw_text(W-34, 1020,
                       'APC: niet aangesloten · Outputgain blijft onafhankelijk van presets.',
                       color=DIM, size=9, anchor='e')
        # Do not repeat controller help in the event/status footer.

    def draw_knob(self, x, y, cc):
        c = self.canvas
        assigned = cc in ASSIGNMENTS
        c.create_oval(x - 32, y - 32, x + 32, y + 32,
                      fill='#10151c', outline=OUTLINE, width=2)
        c.create_oval(x - 25, y - 25, x + 25, y + 25,
                      fill='#3a424b', outline='#0c1218', width=2)
        for idx in range(11):
            rad = math.radians(135 + idx * 27)
            c.create_line(x + 36 * math.cos(rad), y + 36 * math.sin(rad),
                          x + 41 * math.cos(rad), y + 41 * math.sin(rad),
                          fill=CYAN if assigned else DIM, width=1)
        indicator = c.create_line(x, y - 2, x, y - 22,
                                  fill=DIM, width=3, capstyle='round')
        # CC en actuele waarde op ÉÉN regel boven de knop, zodat de
        # rijlabels niet meer tegen de volgende knoprij aanlopen.
        readout = self.draw_text(x, y - 47, f'CC {cc}   —',
                                 color=CYAN if assigned else MUTED,
                                 size=9, weight='bold' if assigned else 'normal')
        label = ASSIGNMENTS.get(cc, 'vrij')
        label_id = self.draw_text(x, y + 50, label,
                                  color=TEXT if assigned else DIM,
                                  size=9, width=112)
        self.knob_labels[cc] = label_id
        self.knob_parts[cc] = (x, y, indicator, readout)

    def draw_amp_envelope(self):
        """One shared background behind faders 1–4, below all fader items."""
        c = self.canvas
        left, top, right, bottom = AMP_ENVELOPE_BOUNDS
        c.create_line(left, bottom, right, bottom, fill='#394b53', width=1)
        self.amp_area = c.create_polygon(
            left, bottom, right, bottom, right, bottom,
            fill='#263b42', outline='', state='hidden')
        self.amp_curve = c.create_line(
            left, bottom, right, bottom, fill='#4d999f', width=2,
            joinstyle='round', state='hidden')
        self.amp_hint = self.draw_text(
            (left + right) / 2, 789, 'AMP ADSR · wacht op softwarestanden',
            color=MUTED, size=8)

    def update_amp_envelope(self):
        points = envelope_points(self.values, AMP_ENVELOPE_BOUNDS)
        if points is None:
            return
        coords = [coordinate for point in points for coordinate in point]
        self.canvas.coords(self.amp_curve, *coords)
        self.canvas.coords(self.amp_area, *coords)
        self.canvas.itemconfigure(self.amp_curve, state='normal')
        self.canvas.itemconfigure(self.amp_area, state='normal')
        self.canvas.itemconfigure(
            self.amp_hint,
            text='AMP ADSR · relatieve tijd → · S: zolang toets vast',
            fill='#85b0b5')

    def draw_fader(self, x, cc, *, is_master):
        c = self.canvas
        assigned = cc in ASSIGNMENTS
        c.create_line(x, FADER_TOP, x, FADER_BOTTOM, fill=TRACK, width=16)
        c.create_line(x, FADER_TOP, x, FADER_BOTTOM, fill=OUTLINE, width=2)
        thumb_y = (FADER_TOP + FADER_BOTTOM) / 2
        thumb = self.rounded_rect(x - 25, thumb_y - 7, x + 25, thumb_y + 7,
                                  3, '#758494', '#bbc7d2', 1)
        self.draw_text(x, FADER_TOP - 19, f'CC {cc}',
                       color=CYAN if assigned else MUTED, size=9)
        label = fader_label(cc, ASSIGNMENTS.get(cc, '— vrij —'))
        self.fader_labels[cc] = self.draw_text(x, 807, label, color=TEXT if assigned else DIM,
                       size=9, width=111)
        readout = self.draw_text(x, 830, '—',
                                 color=CYAN if assigned else MUTED, size=10,
                                 weight='bold')
        self.fader_parts[cc] = (x, thumb, readout)

    def draw_button(self, x, y, key, label, *, note, color):
        self.draw_text(x, y - 21, label, color=MUTED, size=8,
                       weight='bold')
        r = self.rounded_rect(x - 31, y - 9, x + 31, y + 11,
                              5, '#48515b', OUTLINE)
        desc = '—' if note is None else f'Note {note}'
        self.draw_text(x, y + 24, desc, color=DIM, size=8)
        self.button_parts[key] = (r, color)
        if key.startswith(('mute_', 'rec_')):
            self.preset_number_parts[key] = self.draw_text(
                x, y + 1, '', size=10, weight='bold', color=TEXT)

    def update_control(self, cc: int, raw: int):
        raw = min(127, max(0, raw))
        self.values[cc] = raw
        if cc in self.knob_parts:
            x, y, needle, readout = self.knob_parts[cc]
            rad = math.radians(135 + raw / 127 * 270)
            self.canvas.coords(needle, x, y,
                               x + 22 * math.cos(rad),
                               y + 22 * math.sin(rad))
            self.canvas.itemconfigure(needle,
                                      fill=CYAN if cc in ASSIGNMENTS else TEXT)
            self.canvas.itemconfigure(readout, text=f'CC {cc}  {raw:3d}/127')
        elif cc in self.fader_parts:
            x, thumb, readout = self.fader_parts[cc]
            yy = FADER_BOTTOM - raw / 127 * (FADER_BOTTOM - FADER_TOP)
            # Polygon gecreëerd door rounded_rect: verplaats t.o.v. huidige bbox.
            x1, y1, x2, y2 = self.canvas.bbox(thumb)
            self.canvas.move(thumb, 0, yy * self.canvas.ui_scale - (y1 + y2) / 2)
            self.canvas.itemconfigure(readout, text=f'{raw:3d} / 127')
        if cc in AMP_CCS:
            self.update_amp_envelope()

    def update_button(self, key: str, down: bool):
        if key not in self.button_parts:
            return
        self.buttons[key] = down
        self._draw_button_state(key)

    def _draw_button_state(self,key):
        if key not in self.button_parts:return
        button_id,accent=self.button_parts[key]
        selected=False
        if key.startswith('mute_'):
            i=int(key.rsplit('_',1)[1])
            selected=(self.engine_state.get('wave1' if i<4 else 'wave2')==i%4)
        elif key.startswith('rec_'):
            i=int(key.rsplit('_',1)[1])
            if i<4:
                selected=self.engine_state.get('enabled',{}).get(('osc1','osc2','sub','noise')[i],False)
        if self.midimix_leds is not None and (key.startswith('mute_') or key.startswith('rec_')):
            i=int(key.rsplit('_',1)[1])
            note=MUTE_NOTES[i] if key.startswith('mute_') else REC_NOTES[i]
            selected=self.midimix_leds.get(note,False)
        down=self.buttons.get(key,False)
        # Vulling spiegelt de echt verstuurde MIDI LED-opdracht indien bekend.
        self.canvas.itemconfigure(button_id,
                                  fill=accent if selected else '#48515b',
                                  outline=TEXT if down or (self.led_overlay and selected)
                                  else (GREEN if selected else OUTLINE),
                                  width=2 if self.led_overlay and selected else 1)
        if key in self.preset_number_parts:
            if self.led_overlay:
                i=int(key.rsplit('_', 1)[1])
                count=i+1 if key.startswith('mute_') else i+9
                self.canvas.itemconfigure(self.preset_number_parts[key],
                                          text=str(count),
                                          fill='#141920' if selected else MUTED)
            else:
                self.canvas.itemconfigure(self.preset_number_parts[key],text='')

    def set_midimix_leds(self, snapshot):
        """Mirror MIDI-uitvoer, incl. tijdelijke presetcount en herstel.

        Nooit zelf voorspellen welke lampjes branden: de hardware output
        en deze GUI krijgen EXACT dezelfde door MidiMixLEDs verstuurde stand.
        """
        notes=snapshot.get('notes')
        if not isinstance(notes,dict):
            return
        self.midimix_leds={int(k):bool(v) for k,v in notes.items() if str(k).isdigit()}
        overlay=bool(snapshot.get('overlay'))
        number=snapshot.get('preset')
        if overlay and isinstance(number,int) and (not self.led_overlay or number!=self.led_preset):
            self.show_event(f'MIDImix · preset {number:02d}: LED-teller actief (1 seconde)')
        self.led_overlay=overlay
        self.led_preset=number
        for i in range(8):
            self._draw_button_state(f'mute_{i}')
            self._draw_button_state(f'rec_{i}')

    def set_engine_state(self,state):
        self.engine_state=state
        for i in range(8):self._draw_button_state(f'mute_{i}')
        for i in range(4):self._draw_button_state(f'rec_{i}')
        if self.state_id is not None:
            names=('SIN','TRI','SAW','PULSE')
            w1=state.get('wave1',2);w2=state.get('wave2',3)
            en=state.get('enabled',{})
            sources='   '.join(f'{k.upper()}: {"AAN" if en.get(k,False) else "UIT"}' for k in ('osc1','osc2','sub','noise'))
            self.canvas.itemconfigure(self.state_id,text=f'OSC1: {names[w1]}  |  OSC2: {names[w2]}  |  {sources}')

    def set_output_gain(self, db):
        try:
            db = max(-6, min(9, round(float(db)*2)/2))
        except (ValueError,TypeError):
            return
        self._gain_syncing = True
        try:
            self.output_gain_db=db
            self.gain_scale.set(db)
        finally:
            self._gain_syncing = False
        self._refresh_gain_label()

    def _refresh_gain_label(self):
        db=self.output_gain_db
        self.canvas.itemconfigure(self.gain_value_label,
            text=f'OUTPUT {db:+.1f} dB  ({10**(db/20):.2f}×)',
            fill=AMBER if db>3 else GREEN)
        self.canvas.itemconfigure(self.gain_hint,
            text=('LET OP: clipping mogelijk!'
                  if db>3 else '−6 tot +9 dB · niet in presets'),
            fill=AMBER if db>3 else MUTED)

    def on_gain_change(self, value):
        if self._gain_syncing:
            return
        db=round(float(value)*2)/2
        # Tk may dispatch Scale.set() callbacks after the sync flag is cleared.
        # An unchanged echo from the engine must never become a user command.
        if db == self.output_gain_db:
            return
        self.output_gain_db=db
        self._refresh_gain_label()
        if self.engine_address is not None:
            payload=json.dumps({'kind':'set_output_gain','db':db}).encode('utf8')
            try:
                self.socket.sendto(payload,self.engine_address)
            except OSError:
                pass

    def set_preset(self,info):
        slot=info.get('slot')
        name=str(info.get('name','Sessiestand'))[:48]
        user=' • USER' if info.get('user') else ''
        value=f'Preset {slot:02d}/16  |  {name}{user}' if slot else 'Preset —/16  |  Sessiestand (niet geselecteerd)'
        self.canvas.itemconfigure(self.preset_id,text=value)

    def set_page(self, page, labels):
        ASSIGNMENTS.clear()
        ASSIGNMENTS.update({int(cc):label for cc,label in labels.items()})
        self.canvas.itemconfigure(self.page_id, text=f'SYNTHRIG {UI_VERSION}  ·  {page}')
        for cc, item in self.knob_labels.items():
            self.canvas.itemconfigure(item, text=ASSIGNMENTS.get(cc, 'vrij'),
                                      fill=TEXT if cc in ASSIGNMENTS else DIM)
        for cc, item in self.fader_labels.items():
            self.canvas.itemconfigure(item, text=fader_label(cc, ASSIGNMENTS.get(cc, 'vrij')),
                                      fill=TEXT if cc in ASSIGNMENTS else DIM)

    def _clear_event(self):
        self.event_clear_job=None
        self.canvas.itemconfigure(self.event_id,text='')

    def show_event(self,message):
        self.canvas.itemconfigure(self.event_id,text=str(message)[:135])
        if self.event_clear_job is not None:
            self.root.after_cancel(self.event_clear_job)
        self.event_clear_job=self.root.after(6000,self._clear_event)

    def on_midi(self, message: dict, applied: str | None):
        kind = message.get('type')
        if kind == 'control_change':
            cc, raw = message.get('control'), message.get('value')
            if isinstance(cc, int) and isinstance(raw, int):
                if cc_location(cc) is not None and 0<=raw<=127:
                    self.physical_values[cc]=raw
                    count=len(self.physical_values)
                    self.canvas.itemconfigure(self.status_id,
                        text=(f'● MIDImix fysiek: {count}/33 bekend'
                              + (' · SEND ALL voltooid' if count==33 else ' · druk SEND ALL')),
                        fill=GREEN if count==33 else MUTED)
                # Bij soft takeover is de fysieke waarde nog NIET de synthwaarde.
                if not (isinstance(applied,str) and applied.startswith('pickup ')):
                    self.update_control(cc, raw)
                if cc in (52, 56) and isinstance(applied, str):
                    for wave_name in ('SIN', 'TRI', 'SAW', 'PULSE'):
                        if f'golfvorm {wave_name}' in applied:
                            self.canvas.itemconfigure(
                                self.knob_labels[cc],
                                text=f'OSC{1 if cc == 52 else 2} · {wave_name}')
                            break
                loc = cc_location(cc)
                self.last_event = f'CC {cc} = {raw}' + (f'  → {applied}' if applied else '')
        elif kind in ('note_on', 'note_off'):
            note = message.get('note')
            velocity = message.get('velocity', 0)
            if not isinstance(note, int):
                return
            down = kind == 'note_on' and isinstance(velocity, int) and velocity > 0
            loc = note_location(note)
            if loc:
                name = loc[0]
                if name in ('mute', 'rec', 'solo_layer'):
                    name = f'{"mute" if name == "solo_layer" else name}_{loc[1]}'
                self.update_button(name, down)
            self.last_event = f'Note {note}: {"ingedrukt" if down else "los"}' + (f'  → {applied}' if applied else '')
        else:
            return
        self.show_event(self.last_event)

    def update_swing(self, state, message=None):
        self.swing_state=state
        bend=max(-1.0,min(1.0,float(state.get('bend',0))))
        semis=float(state.get('bend_semitones',0))
        mod=max(0.0,min(1.0,float(state.get('modwheel',0))))
        native=state.get('pitch_lfo_mode')=='native'
        cents=float(state.get('mod_vibrato_cents') or 0)
        native_amp=state.get('mod_native_amplitude') or 0
        vibrato_txt=(f'native amplitude {native_amp}/256' if native else f'vibrato ±{cents:.1f} cent')
        self.canvas.itemconfigure(self.bend_label,text=f'PITCH BEND   {semis:+.2f} semitonen')
        pos=248+175*bend
        self.canvas.coords(self.bend_bar,min(248,pos),951,max(249,pos),960)
        self.canvas.itemconfigure(self.mod_label,text=f'MODULATION CC1   {round(mod*127)}/127   ·  {vibrato_txt}')
        self.canvas.coords(self.mod_bar,469,951,469+350*mod,960)
        notes=state.get('active_notes',[])
        self.canvas.itemconfigure(self.notes_label,text='NOTEN  '+(', '.join(map(str,notes)) if notes else '—'))
        if isinstance(message,dict):
            k=message.get('type','')
            if k=='pitchwheel':
                event=f'PITCH BEND  {message.get("pitch",0)}  → {semis:+.2f} semitonen'
            elif k=='control_change' and message.get('control')==1:
                event=f'MODULATION CC1  {message.get("value",0)}  → {vibrato_txt}'
            elif k in ('note_on','note_off'):
                event=f'{k.upper()}  noot {message.get("note","?")}  velocity {message.get("velocity",0)}'
            else:
                return
            self.show_event('SWING · '+event)

    def update_sync(self, status):
        state = status.get('transport', 'stopped')
        bpm = status.get('bpm')
        tempo = f'{bpm:.1f} BPM' if isinstance(bpm, (int, float)) else 'tempo —'
        following = status.get('apc_clock') == 'swing'
        if state == 'lost':
            text, color = 'SWING SYNC · CLOCK WEG · druk START op SWING', RED
            if status.get('clock_receiving'):
                text = 'SWING CLOCK TERUG · druk START voor nieuwe synchronisatie'
            if not following and status.get('apc_playing'):
                text = 'SWING CLOCK WEG · SWING-noten los · APC speelt op interne clock'
            if status.get('input_error') is not None:
                text = 'SWING MIDI WEG · sluit opnieuw aan en herstart SynthRig'
        elif state == 'waiting':
            text, color = 'SWING SYNC · wacht op CLOCK · controleer SWING sync: INTERN', AMBER
        else:
            clock = tempo if status.get('clock_receiving') else 'geen clock ontvangen'
            run = 'SPEELT' if state == 'playing' else 'STOP'
            follows = status.get('apc_playing') and state == 'playing'
            apc = ('APC volgt' if follows else 'APC gereed' if status.get('apc_playing') else 'APC gestopt') if following else 'APC interne clock'
            if not status.get('apc_connected'):
                apc = 'APC niet aangesloten'
            elif status.get('apc_playing') and (not following or follows):
                apc += f' · stap {status.get("apc_step", 0):02d}/{status.get("apc_length",16)}'
            text, color = f'SWING SYNC · {run} · {clock} · {apc}', GREEN if status.get('clock_receiving') else MUTED
        self.canvas.itemconfigure(self.sync_label, text=text, fill=color)

    def poll(self):
        try:
            # Max. 100 pakketten per poll, zodat de GUI responsief blijft.
            for _ in range(100):
                try:
                    packet, addr = self.socket.recvfrom(8192)
                except BlockingIOError:
                    break
                try:
                    payload = json.loads(packet.decode('utf-8'))
                except (ValueError, UnicodeDecodeError):
                    continue
                if addr[0] == '127.0.0.1':
                    self.engine_address = addr
                if payload.get('kind') == 'sync':
                    self.update_sync(payload.get('status',{}))
                elif payload.get('kind') == 'output_gain':
                    self.set_output_gain(payload.get('db',0))
                elif payload.get('kind') == 'buttons':
                    self.set_engine_state(payload.get('state',{}))
                elif payload.get('kind') == 'page':
                    self.set_page(payload.get('name', 'pagina'), payload.get('assignments', {}))
                elif payload.get('kind') == 'apc':
                    a=payload.get('status',{})
                    self.apc_monitor.update_status(a)
                    if a.get('connected') is False:
                        state='APC: niet aangesloten'
                    else:
                        run='PLAY' if a.get('playing') else 'STOP'
                        state=(f"APC {str(a.get('mode','?')).upper()} · {run}")
                    self.canvas.itemconfigure(self.apc_id,text=state)
                elif payload.get('kind') == 'midimix_leds':
                    self.set_midimix_leds(payload.get('status',{}))
                elif payload.get('kind') == 'preset':
                    self.set_preset(payload.get('info',{}))
                    # Gelijktijdige presetnaam en LED-telling: een gemiste
                    # losse UDP-update mag de GUI niet zonder teller laten.
                    if isinstance(payload.get('leds'),dict):
                        self.set_midimix_leds(payload['leds'])
                elif payload.get('kind') == 'values':
                    for cc,raw in payload.get('values',{}).items():
                        try:self.update_control(int(cc),int(raw))
                        except (ValueError,TypeError):pass
                elif payload.get('kind') == 'swing':
                    self.update_swing(payload.get('state',{}),payload.get('message'))
                elif payload.get('kind') == 'midi':
                    self.on_midi(payload.get('message', {}), payload.get('applied'))
                    if not self.online:
                        self.online = True
                        if not self.physical_values:
                            self.canvas.itemconfigure(self.status_id,
                                                      text='● MIDI actief · druk SEND ALL voor 33 fysieke standen',
                                                      fill=MUTED)
        except OSError:
            return
        self.root.after(30, self.poll)

    def close(self):
        try:
            self.socket.close()
        finally:
            self.root.destroy()


def main():
    parser = argparse.ArgumentParser(description='Optionele MIDImix debugmonitor')
    parser.add_argument('--port', type=int, required=True,
                        help='UDP-poort op 127.0.0.1, opgegeven door SynthRig')
    parser.add_argument('--mappings', required=True, help='Pad naar controls.json')
    args = parser.parse_args()
    ASSIGNMENTS.update(read_assignments(args.mappings))
    root = tk.Tk()
    MidiMixMonitor(root, args.port)
    root.mainloop()


if __name__ == '__main__':
    main()
