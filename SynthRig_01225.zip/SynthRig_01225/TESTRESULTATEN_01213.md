# SynthRig 0.12.13 — teststatus

- 214/214 Python-regressietests geslaagd (`tests/`).
- 242/242 SunVox-audiocontroles geslaagd in native modus.
- 242/242 SunVox-audiocontroles geslaagd in events-modus.
- Alle 32 overlaylabels voldoen aan maximaal 8 monospaced tekens.
- GUI geïnspecteerd op een virtuele Linux-desktop (1935×1156).
- 256 routes **muzikaal beoordeeld**; dit is géén nieuwe 256-route-audit en géén onderzoek naar werkelijk gebruik.
- MIDI-mapping, DSP en presetsemantiek zijn ongewijzigd ten opzichte van 0.12.12.

## Muzikale categorieën

- Veelzijdig: 103
- Situationeel: 112
- Niche/vaak redundant: 41
- Bij alleen AC+BD verdwijnen 128 routes, waaronder 50 als veelzijdig beoordeelde routes.

*Er is geen fysieke APC-test op de gebruikerscomputer uitgevoerd.*
