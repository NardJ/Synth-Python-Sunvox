# SynthRig 0.12.14 — automatische testresultaten

| Controle | Resultaat |
|---|---:|
| Python regressietests | 217/217 geslaagd |
| Echte SunVox native DSP-regressie | 242/242 geslaagd |
| Echte SunVox events DSP-regressie | 242/242 geslaagd |
| Nieuwe preset PCM, routes en expressie (native) | 37/37 geslaagd |
| Nieuwe preset PCM, routes en expressie (events) | 37/37 geslaagd |
| Fabriekspresets getest | 16/16 |
| A/B featureverschil meetbaar (indicatie) | 12/16 |
| Hoogste piek bij vierstemmige tests | 0.570 (0 dB extra outputgain) |

De PCM is echt door `sunvox-dll-python` met native SunVox Library gerenderd, zonder geluidskaart. De volledige 256-route-audit uit 0.12.13 is niet opnieuw uitgewerkt: de modulatierouter en MIDI-mapping zijn ongewijzigd. De bestaande 242 SunVox-tests per modus zijn wel opnieuw uitgevoerd.

### Belangrijke beperkingen

- Een FFT/RMS-featuretest bewijst niet dat het menselijke oor elke route als nuttig ervaart.
- Mod Wheel, aftertouch en speelgevoel moeten nog op de fysieke Swing worden beoordeeld.
- Extra Output Gain van +6 tot +9 dB kan bij aangepaste patches en akkoorden alsnog clippen.
- Eigen opgeslagen slots zijn bewust NIET aangepast; de fabriekspreset is pas hoorbaar zolang voor dat slot geen gebruikerskopie actief is.

### Voorbeeldcommandos

```bash
python synthrig_01214.py --preset-audit --record-dir recordings/preset_audit
python synthrig_01214.py --preset-audit --pitch-lfo-mode events --record-dir recordings/preset_audit_events
python synthrig_01214.py --offline-check --offline-no-wav
```
