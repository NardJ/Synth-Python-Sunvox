# SynthRig 0.9.13 — modulation / CC1 klikdiagnose

Opgenomen met de volledige, echte SunVox-engine offline, 44.1 kHz stereo.
De PCM-waardes zijn maximale absolute sprongen tussen twee samples.

| Controle | Vorige 0.9.12 | Nieuwe 0.9.13 |
|---|---:|---:|
| SIN, OSC1, CC1-sweep | 0.02224 | 0.00824 |
| SIN, OSC1, constante toon | 0.00420 | 0.00421 |
| TRI, OSC1, CC1-sweep | 0.01971 | 0.00642 |

De test heeft daarnaast SIN/TRI op OSC1/2 bij een plotselinge stap
en bij extreem snelle CC1-wisselingen gecontroleerd. De waarden liggen
onder de ingestelde PCM-discontinuïteitslimieten, maar zijn niet nul.

## Vibratodiepte (native modus)

| CC1-waarde | Gemeten piekafwijking |
|---|---:|
| 0 | 0.07 cent |
| 64 | 32.41 cent |
| 127 | 66.02 cent |

## Suites

- Native DSP offline: 153 geslaagd, 0 mislukt.
- Events DSP offline: 153 geslaagd, 0 mislukt.
- Python regressietests: 100 geslaagd, 0 mislukt.

De aanpassing verhoogt de control-resolutie met `Exponential amplitude`
op de Swing-vibratobus, met een worteltransformatie van CC1 en
een afvlakkingstijd van 160 ms. De andere native LFO krijgt deze wijziging niet.

De echte hardware en desktop-audio-driver zijn niet getest.
