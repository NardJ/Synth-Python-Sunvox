# Testresultaten SynthRig 0.12.23

| Controle | Resultaat |
|---|---|
| Volledige Python-regressiesuite | **325 tests geslaagd** |
| Gerichte echte SunVox-audio | **32/32 cases geslaagd**: 8 rijtonen × aan/uit × native/events-modus |
| Gemeten toonhoogte | Elke rij binnen 2,5 Hz van zijn MIDI-doelfrequentie |
| Auto Note Off | Preview eindigt zonder loslaatbericht; stille meetstaart in de droge audio-baseline |
| Rijtoon en velocity | Actuele lane-instelling gebruikt, inclusief wijzigingen via APC-fader |
| Stap uitzetten | Preview klinkt; stap blijft daadwerkelijk uit |
| Snelle herhaling | Nieuwe deadline vervangt oude; geen vroege Note Off of hangende preview |
| Wisselen van rij | Vorige preview los; nieuwe rijtoon klinkt |
| Afspelen | Cursor, next-step-tijd, BPM en 4/8/16-loop blijven intact |
| SWING/APC gelijke toon | Preview hertriggert of verlengt geen bestaande muzieknoot |
| Overname door echte noot | Echte attack en gate krijgen voorrang; oude preview-timer kan die niet afbreken |
| Vier bezette stemmen | Preview overgeslagen; muziekstemmen en padbewerking blijven behouden |
| Oppervlakken en controls | PATCH, bedieningsknoppen, verkeerde MIDI-kanalen en releases starten geen preview |
| Opruimen | Stop, PATCH, patroonwissel/-load, close en PANIC gecontroleerd |
| Bewaren | Alleen normale patroonwijzigingen opgeslagen; geen preview-noot of timer |
| Upgrade | 0.12.22 krijgt prioriteit; huidige bestanden blijven behouden |
| Echte Tk/UDP | Onmiddellijk NOTEN 48/84, wissen na gate, rijlabel/fader en PANIC geslaagd |
| GUI-regressies | 4/8/16-loop, SWING-sync, ADSR en SOLO geslaagd |
| Bronvergelijking | DSP alleen versieteksten anders; ADSR-geometrie, mappings, loopkeuzes en fabriekspresets gelijk aan 0.12.22 |
| Aflevering | ZIP-integriteit, syntax en nieuwe tests/startfile uit los uitgepakte ZIP gecontroleerd |

## Meetbereik

De 32 audiocases genereren echte native SunVox-PCM zonder geluidskaart. Ze gebruiken een droge sinus-baseline met korte attack/release om toonhoogte en Note Off eenduidig te meten. Bij normaal spelen worden de huidige ADSR, velocity en effecten gebruikt; een lange release of effectstaart mag dus hoorbaar blijven. De volledige historische DSP-suite is niet opnieuw uitgevoerd.

De GUI-tests gebruiken echte Tk-canvassen en localhost-UDP met gesimuleerde MIDI en FakeSlot. De fysieke APC, SWING en MIDImix waren hier niet aangesloten.

Logs staan in `reports_01223/`: `python_tests.log`, `preview_tests.log`, `audio_preview.log`, `audio_preview.json`, `gui_preview.log`, `gui_loop_length.log`, `gui_sync.log`, `gui_adsr.log`, `gui_solo_session.log` en `gui_solo_presets.log`.

De oudere startfiles en verslagen in het pakket horen bij hun eigen release. Start voor deze functie `synthrig_01223.py`.
