# SynthRig 0.11.2 — softwarematige outputgain

- Nieuwe post-FX SunVox Amplifier als gemeenschappelijke eindtrap voor dry,
  chorus, echo en reverb. Bij 0 dB is het bestaande geluid onveranderd.
- Outputgain -6..+9 dB in het debugvenster, zonder extra MIDImix-CC.
- De fader in de GUI is interactief en communiceert via UDP over 127.0.0.1;
  alle overige MIDImix-controls blijven een alleen-lezen monitor.
- Een dB-smoothing van 60 ms voorkomt abrupte amplitudesprongen.
- Gain wordt atomair bewaard in `state/output_gain.json`, **niet** in presets.
- +3 dB getest met 16 fabriekspresets, telkens vier stemmen. Hogere gain
  kan bij hoge levels / akkoorden clippen; geen ingrijpende limiter toegevoegd.
- Upgrade kopieert laatste sessie en gebruikersslots bij voorkeur uit 0.11.1,
  met fallback naar 0.11.0.
- 139/139 Python-unit-tests; 221/221 SunVox DSP-tests per modus.
