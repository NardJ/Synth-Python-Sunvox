# SynthRig 0.12.21 — SWING clock en transport

## Gedrag

- Nieuwe onafhankelijke SWING-inputwaarnemer: werkelijke clock-/transporttellers, BPM-schatting, nootstatus en laatste 32 transportgebeurtenissen.
- Correcte downbeat: START op zichzelf speelt geen noot; de eerste clockpuls erna speelt APC-stap 1. De oude zes-pulsenvertraging bij de eerste stap is verwijderd.
- STOP bewaart puls- en stappositie; CONTINUE hervat die positie. Een verse START wist oude APC-gates en begint opnieuw.
- Een korte pauze wordt niet als een traag clockinterval in de BPM-schatting opgenomen.
- Bij 0,75 s clockverlies tijdens actief transport: SWING-noten los, externe APC stoppen en APC-noten los. Een zelfstandige intern geklokte APC blijft doorlopen. Een verse START is nodig na timeout; terugkerende clocks starten geen onverwachte noten.
- SWING MIDI-inputfouten worden opgevangen; de andere controllers blijven beschikbaar. Na opnieuw aansluiten is een herstart nodig.
- Lokale APC-bediening vervalst geen ontvangen START/STOP-tellers. PLAY bij externe clock en gestopt mastertransport zet de volger gereed. Klokbronwissels stoppen de APC eerst.
- Een opnieuw getriggerde APC-noot krijgt een nieuwe gate, zodat een oude geplande Note Off hem niet te vroeg afbreekt bij tempoveranderingen.

## Vensters en diagnose

- Eén compacte synchronisatieregel in het bestaande SWING-vak: transport, BPM, APC-status/stap of clock-/inputverlies.
- De bestaande APC-statusregel toont clockbron, tempo en stap; geen nieuwe panelen.
- `sync` in de terminal toont de status; `--sync-report PAD.json` bewaart diagnose bij q/Ctrl+C. Transportstatus wordt ook opgenomen in bestaande audio-/diagnoselogboeken wanneer die actief zijn.
- De werkelijke engine-nootstatus wordt periodiek ververst in de GUI, ook na watchdog-loslaten.

## Compatibiliteit en bereik

- Startfile `synthrig_01221.py`; overname van bestaande sessie, presets, APC-patronen en outputgain geeft 0.12.20 prioriteit. Bestaande bestanden blijven behouden.
- ADSR, MIDImix-SOLO/PANIC/SAVE, mappings en fabriekspresets blijven beschikbaar. De SunVox-DSP-code verschilt alleen in versieteksten.
- Geen nieuwe dependencies. Deze versie implementeert clock/transport en diagnose; nog geen bewerkbare MIDI-opname of trackerexport.
- Fysieke SWING-/APC-hardware niet aangesloten tijdens ontwikkeling; echte Tk/UDP en MIDI-opdrachten zijn automatisch gesimuleerd getest.
