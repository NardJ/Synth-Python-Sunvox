# SynthRig 0.12.2 — monitorvensters naast elkaar

Dit is een **GUI-gerichte correctie op 0.12.1**. Geen wijzigingen aan MIDI-controllerafhandeling, SunVox-signaalverwerking, sequencerlogica of presets.

- MIDImix- en APC-vensters krijgen nu **één gedeeld plaatsingsplan**. De MIDImix wordt links geplaatst; de APC staat met een kleine tussenruimte rechts ervan. De Linux-windowmanager mag niet langer zelfstandig de MIDImix-positie kiezen waarna de APC op een vaste x-coördinaat wordt gezet.
- Breedte en hoogte worden bepaald uit de actuele schermresolutie. Op compactere schermen wordt de inhoud van beide monitors proportioneel geschaald (inclusief de live LED- en fadercoördinaten).
- Beide titelbalken blijven bereikbaar; de APC-monitor blijft alleen-lezen, en de outputgain-schuif blijft bedienbaar.
- De weergave kan door desktop-panelen of bijzonder hoge display-scaling enigszins afwijken. De vensters blijven als gewone Linux-vensters handmatig verplaatsbaar.
- Automatische overname van de laatste 0.12.1 sessie, gebruikerspresets, APC-patronen en outputgain als de map `SynthRig_0121` naast de nieuwe versie staat.

Start zoals gebruikelijk:

```bash
cd ~/Synth/Python-sunvox/SynthRig_0122
source ../.venv/bin/activate
python synthrig_0122.py --debug-ui --midi-log
```
