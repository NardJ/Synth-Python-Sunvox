# SynthRig 0.12.5 — modulatierouter / patchmatrix

- De oude 8 kolommen in PARAM-modus zijn vervangen door een echte 8×8
  modulatiematrix met acht bronnen en acht bestemmingen.
- Alle 64 pads kunnen **onafhankelijke verbindingen** aan/uit zetten.
- De acht APC-scene-knoppen selecteren een modulatiebron in PATCH-modus;
  dezelfde knoppen blijven sequencerpatronen selecteren in SEQ-modus.
- Faders 1–8 regelen bipolaire diepte voor de geselecteerde bron met
  soft-takeover, ook na presetwisselingen. Fader 9 blijft de SEQ-tempo-fader.
- De matrix wordt in gebruikerspresets en de sessie opgeslagen, met
  achterwaartse compatibiliteit voor eerdere opgeslagen patches.
- APC-monitor toont labels en werkelijk aangestuurde padkleuren.
- SunVox-audio-engine beschikt over fasevaste pitchmodulatie en tijdsvariërende
  cutoff/PWM/resonantie/oscillator-levelmodulatie per stem. Geen wijzigingen
  in de bestaande Note Off/voice-stealing architectuur.
- SEQ-modus en bestaande MIDImix/Swing-bediening behouden.

**Teststatus:** zie bijgesloten `TESTRESULTATEN_0125.md`.
