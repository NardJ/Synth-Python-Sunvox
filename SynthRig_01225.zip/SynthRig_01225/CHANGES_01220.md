# SynthRig 0.12.20 — AMP ADSR-visualisatie

- Eén relatieve AMP-envelope achter MIDImix-faders 1–4, met subtiele vlakvulling en dunne turquoise lijn. De canvasitems worden vóór de faders gemaakt en blijven erachter.
- A/D/R sturen relatieve segmentbreedtes; S stuurt alleen de hoogte. Een vast breed sustainplateau staat voor een onbepaalde toetsduur. Minimale segmentbreedtes houden nulstanden leesbaar.
- Actuele software-CCs zijn de bron: de bestaande MIDI- en values-UDP-berichten sturen zowel de faders als de curve. Daardoor werken opstartstand, presetwissels en pickup zonder extra protocol of audio-enginekoppeling.
- Geen nieuwe MIDI-poorten, canvasbediening, dependencies of audioaanroepen. Hergebruik van bestaande canvasitems, ook tijdens zoom.
- Nieuwe startfile `synthrig_01220.py`; 0.12.19 heeft de hoogste prioriteit bij overname van sessie, presets, APC-patronen en outputgain. Bestaande nieuwe bestanden blijven behouden.
- Nieuwe geometrie-, upgrade- en echte Tk/UDP-integratiechecks. Het bestaande SOLO-GUI-probescript slaat zijn schermafdruk nu relatief op, zodat het ook buiten `/mnt/data` bruikbaar is.
- Audio-enginecode verschilt alleen in het versienummer; bestaande APC-sequencer, MIDI-mappings en fabriekspresets zijn ongewijzigd.
