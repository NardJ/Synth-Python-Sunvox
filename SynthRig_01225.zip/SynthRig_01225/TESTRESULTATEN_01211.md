# SynthRig 0.12.11 — testresultaten

De tests zijn uitgevoerd met de aangeleverde SunVox 0.4.0.2.1.4.0 wheel en de echte native SunVox Library, offline PCM, zonder fysieke audiohardware.

| Test | Native | Events |
|---|---:|---:|
| Bestaande SunVox-audio | 239/239 PASS | 239/239 PASS |
| Nieuwe LFO RATE / DELAY FEEDBACK A/B-audio | 3/3 PASS | 3/3 PASS |
| Matrixroutering/controller | 256/256 correct | 256/256 correct |
| Routes met meetbare audio in de standaard audit | 254/256 | 254/256 |
| Inconclusief in de standaard audit | 2 | 2 |
| Matrix-stresstests | 5/5 PASS | 5/5 PASS |

Python-tests: **208/208 PASS**.

De twee inconclusieve gevallen zijn FILTER ENV en AMP ENV als bron voor DELAY FEEDBACK. De route en de echte controllerverandering zijn correct; de specifieke korte standaard-A/B-meting geeft geen voldoende groot spectrum- of volumeverschil. De afzonderlijke BIAS → DELAY FEEDBACK-test meet wel een gewijzigd echo-feedbackniveau en hoorbaar ander PCM. Geen routes zijn als geslaagd aangemerkt wanneer alleen de LED- of Python-status wijzigde.

Nieuwe functies en testvensters zijn geen garantie dat een modulatieroute bij iedere synthpatch even goed hoorbaar is. Er is geen test uitgevoerd op de fysieke APC-controller in deze omgeving.
