# SynthRig 0.12.1 — APC live monitor

- Tweede Tk-venster verschijnt automatisch rechts van het MIDImix-debugvenster.
- Het APC-venster toont de exact door SynthRig verstuurde palette-kleuren voor alle 64 pads en LED-standen voor de onderste 8 en rechter 8 knoppen.
- Live modus, sequencerpagina, actieve stap, BPM, patroon en klokbron; faderposities zodra ontvangen.
- Bestaande PATCH-modus heet in de UI voortaan **PARAM**: acht 8-staps parameterinstellingen, geen vrije patchmatrix. De werking van de hardware blijft ongewijzigd.
- Zowel fysieke APC/SEQ bediening als MIDImix/Swing, audiorouting, presets, MIDI-noten en outputgain blijven hetzelfde.
- Upgrade leest eerst 0.12.0-sessie en kopieert ontbrekende APC-patroonbestanden uit de vorige map.
- Debugwindow blijft optioneel: sluiten verandert de synth-engine niet.
