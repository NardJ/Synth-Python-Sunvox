#!/usr/bin/env python3
"""SynthRig 0.8.5: stabiele synth + reproduceerbare debugopnamen.

  python synthrig_085.py --debug-ui
  (typ r en Enter in de terminal om opname te starten/stoppen)
  python synthrig_085.py --debug-ui --record
"""
import argparse
from contextlib import ExitStack
from pathlib import Path
import queue
import sys
import threading
import time

import mido
from sunvox.api import init, deinit, Slot
from synthrig.controls import load_mappings, DEFAULT_CONFIG
from synthrig.engine import SynthRig, find_midi_port
from synthrig.demos import wave_demo, resonance_demo, resonance_midi_demo, pwm_demo
from synthrig.pwm_observe import pwm_snapshot
from synthrig.diagnostics import (environment_snapshot, state_snapshot,
                                  run_pwm_check, run_pwm_onset_check, ReadbackAudit)

# De recorder is een losse debugmodule: ontbreekt hij, dan speelt de synth
# gewoon door. Alleen het optionele opnamecommando is dan niet beschikbaar.
try:
    from synthrig.recording import AudioDebugRecorder, RecordingError
except ModuleNotFoundError as exc:
    if exc.name != 'synthrig.recording':
        raise

    class RecordingError(RuntimeError):
        pass

    class AudioDebugRecorder:
        active = False
        started_at = None
        def __init__(self, *args, **kwargs):
            pass
        def start(self, *args, **kwargs):
            raise RecordingError('Optionele synthrig/recording.py ontbreekt')
        def log(self, *args, **kwargs):
            pass
        def stop(self):
            return None

POLL_INTERVAL = .002


def read_terminal_commands(inbox):
    """Blokkerende stdin in een daemonthread; raakt SunVox nooit aan."""
    try:
        for line in sys.stdin:
            command = line.strip().lower()
            if command in ('r', 'record'):
                inbox.put('record-toggle')
            elif command in ('m', 'marker'):
                inbox.put('marker')
            elif command in ('s', 'state'):
                inbox.put('state')
            elif command in ('h', 'help', '?'):
                inbox.put('help')
    except (OSError, ValueError):
        pass


def main():
    parser = argparse.ArgumentParser(description='SynthRig 0.8.5 met optionele volledige diagnostiek')
    parser.add_argument('--debug-ui', action='store_true', help='Losse MIDImix monitor')
    parser.add_argument('--diagnose', action='store_true', help='SunVox-controllerwaarden')
    parser.add_argument('--no-retrigger-wave', action='store_true')
    parser.add_argument('--wave-demo', action='store_true')
    parser.add_argument('--resonance-demo', action='store_true')
    parser.add_argument('--resonance-midi-demo', action='store_true')
    parser.add_argument('--pwm-demo', action='store_true')
    parser.add_argument('--mappings', default=str(DEFAULT_CONFIG))
    parser.add_argument('--list-controls', action='store_true')
    parser.add_argument('--record', action='store_true', help='Start opname direct bij opstarten; r+Enter stopt/start')
    parser.add_argument('--record-seconds', type=float, default=None,
                        help='Stop opname na N seconden, synth blijft spelen')
    parser.add_argument('--record-dir', default='recordings',
                        help='Map voor WAV, JSONL en samenvatting')
    parser.add_argument('--pwm-check', action='store_true',
                        help='Reproduceerbare proef: vaste F3, 3s PWM-uit, 7s aan, 2s uit')
    parser.add_argument('--pwm-onset-check', action='store_true',
                        help='Test PWM vanaf aanslag F3 (8s aan + 2s uit)')
    dc = parser.add_mutually_exclusive_group()
    dc.add_argument('--dc-blocker', dest='dc_blocker', action='store_true', default=True,
                    help='DC-blocker PER oscillator, vóór mixer/filter (standaard aan)')
    dc.add_argument('--no-dc-blocker', dest='dc_blocker', action='store_false',
                    help='A/B-referentie zonder DC-blockers')
    parser.add_argument('--no-bundle', action='store_true', help='Maak geen ZIP bij opname')
    parser.add_argument('--record-source', default=None,
                        help='PulseAudio/PipeWire monitor-bron, indien automatische selectie niet werkt')
    args = parser.parse_args()
    if args.record_seconds is not None and args.record_seconds <= 0:
        parser.error('--record-seconds moet groter zijn dan nul')

    mappings = load_mappings(args.mappings)
    if args.list_controls:
        for cc, entry in sorted(mappings.items()):
            print(f"CC{cc:3d}  {entry['target']:<21}  {entry['label']}")
        return

    monitor = None
    names = mido.get_input_names()
    print('MIDI-ingangen:')
    for n, name in enumerate(names):
        print(f'  [{n}] {name}')
    swing = find_midi_port(names, 'behringer swing')
    midimix = find_midi_port(names, 'midi mix', 'midimix')
    standalone_demo = args.pwm_onset_check or args.pwm_check or args.pwm_demo or args.wave_demo or args.resonance_demo
    if not standalone_demo and (not swing or not midimix):
        raise RuntimeError('Swing en/of MIDImix niet gevonden. Bekijk MIDI-poorten hierboven.')
    if swing and midimix:
        print(f'\nSwing: {swing}\nMIDImix: {midimix}')
    if args.debug_ui:
        from synthrig.debug import OptionalMidiMixDebug
        monitor = OptionalMidiMixDebug(args.mappings)

    recorder = AudioDebugRecorder(args.record_dir, source=args.record_source,
                                  bundle=not args.no_bundle)
    inbox = queue.Queue()
    threading.Thread(target=read_terminal_commands, args=(inbox,), daemon=True).start()
    try:
        version = init(None, 44100, 2, 0)
        if version < 0:
            raise RuntimeError(f'SunVox init mislukt: {version}')
        try:
            with Slot() as slot:
                rig = SynthRig(slot, mappings=mappings, diagnose=args.diagnose,
                               retrigger_wave=not args.no_retrigger_wave,
                               dc_blocker=args.dc_blocker)
                def start_capture():
                    metadata = environment_snapshot(swing, midimix, version)
                    metadata['dc_blocker_enabled'] = args.dc_blocker
                    metadata['dc_blocker_placement'] = ('per_osc_before_mixer_filter'
                                                        if args.dc_blocker else 'disabled')
                    metadata['synthrig_version'] = '0.8.5'
                    recorder.start(metadata=metadata)
                    rig.pwm_trace = lambda data: recorder.log('pwm_written', data)
                    rig.pwm_tick_trace = lambda data: recorder.log('pwm_tick', data)
                    recorder.log('state_snapshot', state_snapshot(rig))
                    return True

                def stop_capture():
                    rig.pwm_trace = None
                    rig.pwm_tick_trace = None
                    if recorder.active:
                        return recorder.stop()
                    return None

                audit = ReadbackAudit(rig, recorder)

                if args.pwm_check or args.pwm_onset_check:
                    print('\nAutomatische PWM-diagnose. Zorg dat de audio-opnamebron beschikbaar is.')
                    try:
                        start_capture()
                        # Allow audio/SunVox to settle before the actual note.
                        time.sleep(.15)
                        audit.schedule('test_setup')
                        audit.poll()
                        if args.pwm_onset_check:
                            def progress(stage):
                                if stage:
                                    audit.schedule(stage)
                                audit.poll()
                            run_pwm_onset_check(rig, recorder, progress=progress)
                        else:
                            # The old baseline test remains available unchanged.
                            run_pwm_check(rig, recorder)
                        audit.schedule('test_end')
                        for _ in range(5):
                            audit.poll()
                            time.sleep(.12)
                    except RecordingError as exc:
                        print(f'OPNAME NIET GESTART: {exc}')
                        return
                    finally:
                        rig.all_notes_off()
                        stop_capture()
                    return

                # Bestaande demo's blijven intact.
                if args.pwm_demo:
                    pwm_demo(rig)
                    return
                if args.wave_demo:
                    wave_demo(rig)
                    return
                if args.resonance_demo:
                    resonance_demo(rig)
                    return
                if args.resonance_midi_demo:
                    resonance_midi_demo(rig, midimix, monitor)
                    return
                with ExitStack() as stack:
                    swing_in = stack.enter_context(mido.open_input(swing))
                    midimix_in = stack.enter_context(mido.open_input(midimix))
                    print('\nSpeel op de Swing. MIDImix regelt SunVox. Ctrl+C stopt.')
                    print('PWM: CC28=PW1 | CC46=PW2 | CC29=snelheid | CC47=diepte.')
                    print('Debug: r+Enter opname aan/uit | m+Enter marker | s+Enter toestand | h+Enter hulp')
                    print('De opname neemt de Linux-audio-uitgang op (ook andere apps).\n')
                    if args.record:
                        try:
                            start_capture()
                        except RecordingError as exc:
                            print(f'OPNAME NIET GESTART: {exc}')
                    next_pwm_log = time.monotonic()
                    next_state_log = time.monotonic()
                    if recorder.active:
                        audit.schedule('manual_record_start')
                    previous_poll = None
                    try:
                        while True:
                            while not inbox.empty():
                                command = inbox.get_nowait()
                                if command == 'record-toggle':
                                    if recorder.active:
                                        stop_capture()
                                    else:
                                        try:
                                            start_capture()
                                            next_pwm_log = time.monotonic()
                                            next_state_log = time.monotonic()
                                            audit.schedule('manual_record_start')
                                        except RecordingError as exc:
                                            print(f'OPNAME NIET GESTART: {exc}')
                                elif command == 'marker':
                                    if recorder.active:
                                        recorder.log('manual_marker', {'text': 'm+Enter'})
                                        print('Marker toegevoegd aan het diagnosebestand')
                                    else:
                                        print('Start eerst een opname met r+Enter')
                                elif command == 'state':
                                    import json
                                    snapshot = state_snapshot(rig)
                                    print(json.dumps(snapshot, indent=2, ensure_ascii=False))
                                    if recorder.active:
                                        recorder.log('state_snapshot', snapshot)
                                        audit.schedule('manual_state')
                                elif command == 'help':
                                    print('r = opname aan/uit, m = marker, s = toestand, Ctrl+C = afsluiten')
                            for msg in swing_in.iter_pending():
                                if recorder.active and msg.type in ('note_on', 'note_off'):
                                    recorder.log('midi_swing', msg.dict())
                                rig.handle_swing(msg)
                            for msg in midimix_in.iter_pending():
                                applied = rig.handle_midimix(msg)
                                if recorder.active and msg.type == 'control_change':
                                    recorder.log('midi_midimix', {
                                        'cc': msg.control, 'value': msg.value,
                                        'applied': applied,
                                    })
                                    if msg.control in (52, 56) and applied:
                                        audit.schedule('waveform_cc')
                                if monitor is not None:
                                    monitor.send(msg, applied)
                            rig.tick_pwm()
                            rig.check_verifications()
                            if recorder.active: audit.poll()
                            now = time.monotonic()
                            if recorder.active:
                                if now >= next_pwm_log:
                                    recorder.log('pwm', pwm_snapshot(rig))
                                    next_pwm_log = now + .05  # berekende PWM; niet echte DSP-aanroep
                                if now >= next_state_log:
                                    recorder.log('sunvox_readback', {
                                        'osc1_duty': rig.slot.get_module_ctl_value(rig.osc1, rig.duty1[0], 0),
                                        'osc2_duty': rig.slot.get_module_ctl_value(rig.osc2, rig.duty2[0], 0),
                                        'filter_cutoff': rig.slot.get_module_ctl_value(rig.filt, rig.cutoff[0], 0),
                                        'filter_resonance': rig.slot.get_module_ctl_value(rig.filt, rig.resonance[0], 0),
                                    })
                                    next_state_log = now + .5
                                if previous_poll is not None and now - previous_poll > .018:
                                    recorder.log('event_loop_delay', {'delay_ms': round(1000*(now-previous_poll), 2)})
                                if args.record_seconds is not None and now - recorder.started_at >= args.record_seconds:
                                    stop_capture()
                            previous_poll = now
                            time.sleep(POLL_INTERVAL)
                    except KeyboardInterrupt:
                        print('\nStoppen...')
                    finally:
                        rig.all_notes_off()
                        if recorder.active:
                            stop_capture()
        finally:
            deinit()
            print('SunVox afgesloten')
    finally:
        if recorder.active:
            recorder.stop()
        if monitor is not None:
            monitor.close()


if __name__ == '__main__':
    main()
