# Testresultaten SynthRig 0.12.18

- **Python:** 250/250 tests, inclusief SOLO→PANIC→LED en migratievolgorde.
- **SunVox native:** 248/248 audiocontroles, 0 fout. PANIC wist effecten, er klinkt weer een nieuwe noot; presetwissel behoudt uitklank.
- **SunVox events:** 248/248 audiocontroles, 0 fout.
- **Matrix-audit native + events:** 256/256 per modus correct gerouteerd. 254/256 meetbaar per modus; twee envelope→delay-feedbackproeven akoestisch onbeslist (bekend en onveranderd).
- **GUI Xvfb:** 16/16 SOLO-drukken: fysieke LED-commando's en UDP/Tk-visualisatie correct, inclusief 1s-herstel. Acht scene-knoppen rechts van de matrix en alle kleine track/SHIFT-bedieningen zijn Canvas-rechthoeken.
- **Hardware:** niet fysiek verbonden in de testomgeving; bovenstaande hardware-MIDI-LED-controle betreft uitgestuurde MIDI-berichten, geen teruggelezen LEDs.

Zie `tests/test_01218_solo_panic_count_and_apc_edges.py`, `tests/gui_udp_solo_probe_01218.py` en de bijgesloten testscripts voor reproduceerbaarheid.
