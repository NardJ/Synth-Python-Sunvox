# Wijzigingen SynthRig 0.11.1

- 16 genummerde fabriekspresets; acht nieuwe klanken toegevoegd met behoud van de oorspronkelijke 1–8.
- Slot-overrides in `presets/user/slot_XX.json`; originele fabriekspresets blijven apart beschikbaar.
- SOLO kort = PANIC; SOLO ten minste 1,5 s ingedrukt + loslaten = geselecteerde preset opslaan.
- BANK L/R doorloopt uitsluitend slots 1–16. Een seconde lang licht een uniaire teller op met acht MUTE- en acht REC-ARM-LEDs. Daarna worden de originele oscillator- en bron-LEDs hersteld.
- Debugvenster toont presetnummer, presetnaam en eventueel USER.
- CC47 = delay mix; CC48 = reverb mix. CC46 blijft PWM diepte. De mapping wordt daarmee v1.1.
- Migratie van oude 0.11.0-sessies en JSON-presets; FX-staten synchroniseren met de twee nieuwe CC-waarden.
- Nieuw terminalcommando `p restore <slot>` om de fabrieksklank terug te halen.
- In native en events offline-audiotests: 195/195 geslaagd; 134 Python-regressietests geslaagd.

Beperkingen: hardware-LEDs en lange SOLO-druk kunnen hier niet fysiek worden getest. De interne MIDI-eventlogica is met tests gecontroleerd. De engine is verder gebaseerd op 0.11.0 en bewaart de 0.10.2 portamento-fix.

- Niet-destructieve eenmalige kopie van 0.11.0 sessie en eigen presets bij installeren naast oude versie.
