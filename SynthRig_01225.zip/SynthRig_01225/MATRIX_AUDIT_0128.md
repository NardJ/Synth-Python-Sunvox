# Matrix Audit — meetmethode en interpretatie

## Dekking

Voor elk van de acht fysieke rijen en acht kolommen worden **vier** routes
gecontroleerd: AC, AD, BC en BD. Samen: 256 routes per testmodus en 512 over
de twee modi. Elke test gebruikt één actief pad en één kunstmatig vastgezet
modulatiesignaal van sterkte +1 voor de specifieke bron. De matrix levert
alleen een offset op de aangevraagde bestemming; dat is ook afzonderlijk
wiskundig geverifieerd. Daarna draait de echte SunVox-engine met passende
oscillatorgolfvorm en andere broninstellingen. Het resultaat wordt als PCM
vergeleken met de route uit.

Per route: `router_isolated`, `sunvox_control_changed`, controller vóór en
ná de route, baseline/route RMS, RMS-verandering in dB, spectrale afstand,
peak en status. De 16 *natuurlijke* bronnen worden apart aangeroepen met
gecontroleerde toets/velocity/aftertouch/modulation/trigger-input.

## Grenzen van de audit

- Een constant testsignaal bewijst dat een bronroute technisch werkt. Het
  bewijst niet dat de bron in iedere muzikale situatie automatisch beweegt.
- Akoestische tests zijn per bestemming geoptimaliseerd, bijvoorbeeld PULSE
  bij PWM, C5 voor filter-keytracking en een verhoogde filter-envelope-sustain.
- `MEASURABLE`: > 0,28 dB RMS-verschil **of** > 0,018 genormaliseerde
  spectrumafstand; dit is een drempel voor technische meetbaarheid.
- Het testsignaal is géén menselijke luistertest en meet niet alle mogelijke
  ongewenste clicks onder sterk variërende modulaties.
- Gelijktijdige routes in grote complexe patches zijn niet exhaustief
  getest (het aantal van alle mogelijke routeverzamelingen is enorm).

## Aanvullende stresstests

Vijf SunVox-controles per modus: dubbele modulatie op cutoff, één route
verwijderen terwijl de andere actief blijft, tegengestelde modulatiedieptes,
clipping in de gecombineerde situatie en snelle pitch-modulatiewisselingen
op een zuivere sinus zonder grote samplesprongen. Alle 5/5 slagen in
beide modi.

## Huidige afwijking — NOISE LEVEL

Alle 16 routes naar NOISE LEVEL per modus veranderen de SunVox-controller,
maar een patch met alleen de noise-generator produceert in de audit geen
meetbaar audiosignaal. Ook afzonderlijke proeven met verschillende
noise-generatorgolfvormen bleven in deze solo-situatie stil. De audit meldt
`INCONCLUSIVE`, niet `PASS`. Dit kan een probleem met de note-routering,
de noise-voice of de gebruikte audioschakeling zijn; de oorzaak is nog
niet afdoende bepaald. Dit verdient een aparte fix met regresserende audiotest
voordat we de definitieve overlay vastleggen.

## Herhalen

```bash
python synthrig_0128.py --matrix-audit --record-dir recordings/audit_native
python synthrig_0128.py --matrix-audit --pitch-lfo-mode events --record-dir recordings/audit_events
python synthrig_0128.py --offline-check --offline-no-wav
python -m unittest discover -s tests -q
```
