# SynthRig 0.12.8 — uitgevoerde Matrix Audit

Twee echte offline SunVox-modi, 256 routes per modus.

| Controle | Native | Events |
|---|---:|---:|
| Isolatie + native controller gewijzigd | 256/256 | 256/256 |
| Meetbare PCM-verandering | 240/256 | 240/256 |
| Onbeslist: NOISE LEVEL | 16 | 16 |
| Routeringsfouten | 0 | 0 |
| Clipping (piek ≥1.0) | 0 | 0 |
| Aanvullende audio-stresstests | 5/5 | 5/5 |

## Per bestemming

| Bestemming | Native meetbaar | Events meetbaar |
|---|---:|---:|
| OSC1 PITCH | 16/16 | 16/16 |
| OSC2 PITCH | 16/16 | 16/16 |
| OSC1 PWM | 16/16 | 16/16 |
| OSC2 PWM | 16/16 | 16/16 |
| CUTOFF | 16/16 | 16/16 |
| RESONANCE | 16/16 | 16/16 |
| OSC1 LEVEL | 16/16 | 16/16 |
| OSC2 LEVEL | 16/16 | 16/16 |
| SUB LEVEL | 16/16 | 16/16 |
| NOISE LEVEL | 0/16 | 0/16 |
| ENV AMOUNT | 16/16 | 16/16 |
| KEYTRACK AMOUNT | 16/16 | 16/16 |
| DELAY MIX | 16/16 | 16/16 |
| REVERB MIX | 16/16 | 16/16 |
| CHORUS MIX | 16/16 | 16/16 |
| OUTPUT LEVEL | 16/16 | 16/16 |

## Technische interpretatie

Alle 256 routes veranderen de bedoelde interne SunVox-parameter, maar alleen bij 240 routes is een uitwerking op de uitvoer meetbaar. Bij alle 16 routes naar NOISE LEVEL is de gemoduleerde ampliferwaarde aangepast terwijl de solo-noise-PCM onder de meetgrens blijft. Deze 16 tellen daarom NIET mee als akoestisch geslaagd.

De tests gebruiken een per bestemming gekozen patch en één gecontroleerde bron tegelijk. Natuurlijke bronnen zijn apart gestimuleerd. Dat is niet gelijk aan het exhaustief testen van alle meervoudige verbindingen onder alle muzikale omstandigheden.

## Oudere regressies

- Native DSP: 239/239 PASS
- Events DSP: 239/239 PASS
- Python: 197/197 PASS
- GUI: 64/64 pads getekend als rechte Tk Canvas-rechthoek
