# SynthRig 0.12.14 — 16 muzikale matrix-fabriekspresets

- Alle 16 fabrieksklanken (de bestaande posities en namen) krijgen 2–3 zorgvuldig gekozen actieve matrixroutes.
- Over de bibliotheek zijn alle vier de APC-kleurvarianten AC/AD/BC/BD daadwerkelijk vertegenwoordigd.
- Noot- en akkoordaudio en expressie zijn offline met de SunVox-engine gecontroleerd.
- Nieuw: `--preset-audit` schrijft rapporten en een WAV met alle 16 klanken.
- Per preset is er een luisterkaart met concrete testhandelingen en een lijst routes.
- Opgeslagen gebruikerspresets, `slot_XX.json`, sessies, MIDImix-mapping en APC-sequencer blijven ongewijzigd.
- De matrix- en audio-engine zelf zijn niet functioneel aangepast; alleen de factory state en testgereedschap.

Het is een ontwerp-/luisterrelease: de presets zijn objectief veilig en functioneel getest, maar de muzikale smaak blijft een luisterbeoordeling.
