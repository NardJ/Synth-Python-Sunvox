"""AKAI APC mini Mk2 (Control port) for SynthRig 0.12.6.

Hardware protocol: AKAI Communications Protocol v1.0:
- pads: notes 0..63, row 0 at physical bottom; channel 6 (= MIDI ch 7)
  controls full brightness LEDs, velocity is palette index.
- track buttons: notes 100..107, scene: 112..119, shift: 122.
- faders: CC 48..56 on channel 0.

Pure-Python control and sequencer; not dependent on a physical MIDI device.
PATCH controls 64 independently stored routing connections.
SEQ stores 16 steps per lane with selectable 4/8/16-step playback loops.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from .mod_matrix import SOURCES, SOURCES_B, DESTINATIONS, DESTINATIONS_D, VARIANTS, decode
import json
import math
import os
from pathlib import Path
import time
from .swing_sync import SwingSync, CLOCKS_PER_STEP
from .sequence_lengths import SEQUENCE_LENGTHS, LENGTH_NOTES, validate_length

# Palette indexes from the manufacturer (not RGB triplets).
OFF, DIM, WHITE, RED, AMBER, YELLOW, GREEN, CYAN, BLUE, PURPLE = 0, 1, 3, 5, 9, 13, 21, 37, 45, 49
PAD_LED_CHANNEL = 6
TRACK_FIRST, SCENE_FIRST, SHIFT = 100, 112, 122
# Pads: physical bottom row = source 1; columns = destinations 1..8.
# Matrix routes are stored in SynthRig presets and session, NOT APC patterns.
PATCH_TARGETS = tuple((name, name) for name in DESTINATIONS)

DEFAULT_NOTES = (48, 50, 52, 53, 55, 57, 59, 60)
PATTERN_VERSION = 1
PREVIEW_SECONDS = .25
SAVE_CONFIRM_SECONDS = 1.0
PATTERN_BLINK_SECONDS = .25

# AKAI APC mini mk2 Communications Protocol v1.0, pp. 13-14.
# mido.Message('sysex', data=...) omits the F0 and F7 delimiters.
# 0 / 12 / 4 is our application version triplet, not a firmware update.
APC_INTRODUCTION = (0x47, 0x7F, 0x4F, 0x60, 0x00, 0x04, 0x00, 0x00, 0x0C, 0x04)
APC_INTRODUCTION_REPLY_PREFIX = (0x47, 0x7F, 0x4F, 0x61, 0x00, 0x04)


def parse_fader_introduction(message):
    """Nine physical fader positions, or None for an unrelated/malformed SysEx.

    AKAI's published reply uses length bytes 00 04 even though nine values
    follow. Verify the entire manufacturer/model/reply prefix and 9 values.
    """
    if getattr(message, 'type', None) != 'sysex':
        return None
    try:
        data = tuple(message.data)
    except (TypeError, ValueError, AttributeError):
        return None
    if len(data) != 15 or data[:6] != APC_INTRODUCTION_REPLY_PREFIX:
        return None
    values = data[6:15]
    if any(type(v) is not int or v < 0 or v > 127 for v in values):
        return None
    return list(values)


def choose_control_port(names):
    """Prefer mk2 Control endpoint, never its separate Notes endpoint."""
    possible = [x for x in names if 'apc' in x.casefold() and 'mini' in x.casefold()
                and ('mk2' in x.casefold() or 'mk 2' in x.casefold() or 'mkii' in x.casefold())]
    possible = [x for x in possible if not any(bad in x.casefold() for bad in ('midiin2','midiout2','notes'))]
    return sorted(possible, key=lambda x: (0 if 'control' in x.casefold() else 1, x))[0] if possible else None


class NoteRouter:
    """Source-owned gates; real notes take priority over a transient preview."""
    def __init__(self, rig, sources=('swing', 'apc')):
        self.rig = rig
        self.held = {source: set() for source in sources}

    def on(self, source, note, velocity):
        note = int(note)
        if source not in self.held: raise ValueError(source)
        if source == 'preview' and any(note in held for name, held in self.held.items() if name != source):
            return False  # already sounding: do not retrigger or extend its gate
        if source != 'preview' and 'preview' in self.held:
            for preview_note in list(self.held['preview']):
                if preview_note == note:
                    self.held['preview'].discard(note)  # real attack takes over
                else:
                    self.off('preview', preview_note)  # free its voice for real music
        prev = note in self.held[source]
        others = any(note in held for name,held in self.held.items() if name != source)
        self.held[source].add(note)
        if not others:  # retriggering own note is intentional
            self.rig.note_on(note, int(velocity))
        return not others or prev

    def off(self, source, note):
        note = int(note)
        if note not in self.held[source]:return False
        self.held[source].remove(note)
        if not any(note in notes for notes in self.held.values()):
            self.rig.note_off(note)
        return True

    def clear(self, source):
        for note in list(self.held[source]):
            self.off(source, note)

    def panic(self):
        for values in self.held.values():values.clear()
        self.rig.panic()


@dataclass
class Pattern:
    notes: list[int] = field(default_factory=lambda: list(DEFAULT_NOTES))
    velocity: list[int] = field(default_factory=lambda: [100] * 8)
    steps: list[list[bool]] = field(default_factory=lambda: [[False]*16 for _ in range(8)])
    bpm: float = 120.0
    gate: float = .55
    length: int = 16
    ties: list[list[bool]] = field(default_factory=lambda: [[False]*16 for _ in range(8)])

    def dump(self):
        return {'version': PATTERN_VERSION, 'notes': list(self.notes), 'velocity': list(self.velocity),
                'steps': [[int(flag) for flag in row] for row in self.steps],
                'bpm': self.bpm, 'gate': self.gate, 'length': self.length,
                'ties': [[int(flag) for flag in row] for row in self.ties]}

    @classmethod
    def parse(cls, data):
        if data.get('version') != PATTERN_VERSION:raise ValueError('Onbekende pattern-versie')
        notes, velocity, steps = data['notes'], data['velocity'], data['steps']
        if not (len(notes)==len(velocity)==len(steps)==8 and all(len(row)==16 for row in steps)):
            raise ValueError('Pattern moet 8 lanes en 16 stappen hebben')
        if any(not isinstance(x,int) or not 36<=x<=84 for x in notes):raise ValueError('Ongeldige noten')
        if any(not isinstance(x,int) or not 1<=x<=127 for x in velocity):raise ValueError('Ongeldige velocity')
        if any(type(x) not in (bool,int) or x not in (0,1) for row in steps for x in row):
            raise ValueError('Ongeldig steprooster')
        bpm=float(data['bpm']);gate=float(data['gate'])
        if not math.isfinite(bpm) or not 40<=bpm<=240:raise ValueError('Ongeldig BPM')
        if not math.isfinite(gate) or not .1<=gate<=.95:raise ValueError('Ongeldig gate')
        length=validate_length(data.get('length',16))
        ties=data.get('ties',[[False]*16 for _ in range(8)])
        if not isinstance(ties,list) or len(ties)!=8 or any(not isinstance(row,list) or len(row)!=16 for row in ties):
            raise ValueError('Ties moeten 8 lanes en 16 stappen hebben')
        if any(type(x) not in (bool,int) or x not in (0,1) for row in ties for x in row):
            raise ValueError('Ongeldig tie-rooster')
        return cls(list(notes),list(velocity),[[bool(x) for x in row] for row in steps],bpm,gate,length,
                   [[bool(x) for x in row] for row in ties])

    def previous_step(self, step):
        return (step-1)%self.length if step<self.length else step-1

    def tied(self, row, step):
        return (self.ties[row][step] and self.steps[row][step]
                and self.steps[row][self.previous_step(step)])


class APCminiMk2:
    """Hardware interpreter + LED feedback + beat scheduler; one thread owns all state."""
    def __init__(self, output, rig, controls=None, pattern_dir='patterns', clock='internal', logger=print,
                 swing_sync=None):
        if clock not in ('internal','swing'):raise ValueError(clock)
        self.output=output;self.rig=rig;self.controls=controls;self.logger=logger
        self.pattern_dir=Path(pattern_dir)
        self.mode='patch';self.page=0;self.bank=0;self.clock=clock
        self.selected_source=0
        self.focus_col=None          # fader currently being edited
        self.focus_deadline=0.0      # no actual fader-release event exists
        self.patch_pickup=[False]*8
        self.patch_previous=[None]*8
        self.pattern=Pattern();self.playing=False;self.shift=False
        self.step=-1;self.next_step=None;self.pending_off=[]
        self.clock_pulses=0;self.router=NoteRouter(rig, sources=('swing','apc','preview'))
        self.preview_note=None
        self.preview_until=None
        self.lane_notes={}
        self.save_confirmed=False
        self.save_until=None
        self.save_error=None
        self.pending_bank=None
        self.pending_pattern=None
        self.pending_since=None
        self.pending_blink=False
        self.swing_sync = swing_sync if swing_sync is not None else SwingSync()
        self.last_color={};self.last_button={};self.last_patch_values=None
        self._matrix_load_epoch=self.rig.mod_matrix.load_epoch
        self.last_external_step=None
        self.dirty=True
        self.gui_revision=0
        self.faders=[None]*9  # True physical positions: SysEx introduction or CC motion.
        self.fader_intro_status='unavailable' if output is None else 'waiting'
        self.fader_intro_requested_at=None
        self.last_action='APC wacht op bediening'
        self.load_pattern(silent=True)
        self.request_initial_faders()  # introduction MUST precede device-specific LED messages
        self.refresh(force=True)

    def request_initial_faders(self):
        """Read physical positions without setting synth parameters or pattern BPM.

        If the APC does not answer (or its output port is unavailable), faders
        stay unknown until CC messages arrive. Never fabricate positions.
        """
        if self.output is None:
            self.fader_intro_status='unavailable'
            return False
        import mido
        try:
            self.output.send(mido.Message('sysex',data=APC_INTRODUCTION))
        except (OSError, IOError, RuntimeError, ValueError) as exc:
            self.fader_intro_status='failed'
            self.logger('APC: initialisatieverzoek mislukt: '+str(exc))
            return False
        self.fader_intro_requested_at=time.monotonic()
        self.fader_intro_status='waiting'
        self.gui_revision+=1
        return True

    def _receive_fader_introduction(self, msg):
        values=parse_fader_introduction(msg)
        if values is None:
            return None
        # Preserve newer CC positions if a fader was already moved after
        # requesting the snapshot but before this reply reached SynthRig.
        for i,raw in enumerate(values):
            if self.faders[i] is None:
                self.faders[i]=raw
        self.fader_intro_status='received'
        self._arm_patch_pickup()
        return self._info('9 APC-faderposities bij opstarten ontvangen (SysEx)')

    def _send_led(self, pad, color):
        if self.output is not None:
            import mido
            self.output.send(mido.Message('note_on',channel=PAD_LED_CHANNEL,note=pad,velocity=color))

    def _send_button(self, note, status):
        if self.output is not None:
            import mido
            self.output.send(mido.Message('note_on',channel=0,note=note,velocity=(1 if status else 0)))

    def _arm_patch_pickup(self):
        """Re-arm on preset changes; faders control gains RELATIVELY, not stored depths."""
        self.patch_pickup=[False]*8
        self.patch_previous=list(self.faders[:8])

    def refresh(self, force=False):
        # Preset/session load replaces the matrix container. Re-arm fader pickup
        # so a fader previously live on another preset cannot cause a jump.
        if self.rig.mod_matrix.load_epoch!=self._matrix_load_epoch:
            self._matrix_load_epoch=self.rig.mod_matrix.load_epoch
            self._arm_patch_pickup()
            self.dirty=True
        display_changed=bool(force)
        if self.mode=='patch':
            values=(self.rig.mod_matrix.revision,self.selected_source,self.focus_col)
            if values!=self.last_patch_values:
                self.dirty=True;self.last_patch_values=values
        if not self.dirty and not force:return
        for note in range(64):
            row,col=divmod(note,8)
            if self.mode=='patch':
                cell=self.rig.mod_matrix.route(row,col)
                # OFF / AC green / AD blue / BC amber / BD purple.
                color=(GREEN,BLUE,AMBER,PURPLE)[cell[0]] if cell is not None else OFF
            else:
                at=self.page*8+col
                active=self.pattern.steps[row][at]
                in_loop=at<self.pattern.length
                color=((CYAN if self.pattern.tied(row,at) else GREEN) if in_loop else DIM) if active else OFF
                if in_loop and self.playing and at==self.step:
                    color=YELLOW if active else AMBER
            if force or self.last_color.get(note)!=color:
                self._send_led(note,color);self.last_color[note]=color
                display_changed=True
        for n in range(TRACK_FIRST,TRACK_FIRST+8):
            status = (n==100 and self.mode=='patch') or (n==101 and self.mode=='seq') or \
                     (n==102 and self.page==0) or (n==103 and self.page==1) or \
                     (n==104 and self.playing) or (n==105 and self.save_confirmed)
            if force or self.last_button.get(n)!=status:
                self._send_button(n,status);self.last_button[n]=status
                display_changed=True
        for n in range(SCENE_FIRST,SCENE_FIRST+8):
            if self.mode=='seq' and self.shift:
                status=n in LENGTH_NOTES and self.pattern.length==SEQUENCE_LENGTHS[LENGTH_NOTES.index(n)]
            elif self.mode=='seq' and self.pending_bank is not None:
                index=n-SCENE_FIRST
                status=index==self.bank or (index==self.pending_bank and self.pending_blink)
            elif self.mode=='patch' and self.focus_col is not None:
                row=7-(n-SCENE_FIRST)
                status=row in self.rig.mod_matrix.groups['rows'][self.focus_col]
            else:
                index=(7-self.selected_source if self.mode=='patch' else self.bank)
                status=n-SCENE_FIRST==index
            if force or self.last_button.get(n)!=status:
                self._send_button(n,status);self.last_button[n]=status
                display_changed=True
        self.dirty=False
        if display_changed:self.gui_revision+=1

    def _info(self, info):
        self.logger('APC Mini Mk2: '+info)
        self.last_action=info
        self.gui_revision+=1
        return info

    def handle(self, msg, now=None):
        if now is None:now=time.monotonic()
        if msg.type=='sysex':
            return self._receive_fader_introduction(msg)
        if msg.type in ('note_on','note_off'):
            pressed=msg.type=='note_on' and msg.velocity>0
            if msg.note==SHIFT:
                self.shift=pressed
                self.gui_revision+=1
                self.dirty=True
                self.refresh()
                return 'SHIFT' if pressed else None
            if not pressed or msg.channel!=0:return None
            note=msg.note
            if 0<=note<64:
                row,col=divmod(note,8)
                if self.mode=='patch':
                    # One press advances OFF→AC→AD→BC→BD→OFF; SHIFT+pad clears.
                    self.selected_source=row
                    if self.shift:
                        self.rig.mod_matrix.clear(row,col)
                        encoded=None
                    else:encoded=self.rig.mod_matrix.cycle(row,col)
                    self.rig.tick(force=True)
                    route=decode(encoded)
                    if route is None:
                        result=self._info(f'Pad rij {row+1}, kolom {col+1}: UIT')
                    else:
                        variant,depth=route
                        src=(SOURCES_B if variant>=2 else SOURCES)[row]
                        dst=(DESTINATIONS_D if variant%2 else DESTINATIONS)[col]
                        result=self._info(f'{VARIANTS[variant]} {src} → {dst}: diepte {depth}/127')
                else:
                    pos=self.page*8+col
                    if self.shift:
                        previous=self.pattern.previous_step(pos)
                        if not (self.pattern.steps[row][pos] and self.pattern.steps[row][previous]):
                            return self._info('TIE: zet eerst deze en de voorgaande stap in dezelfde rij aan')
                        self.pattern.ties[row][pos]=not self.pattern.ties[row][pos]
                        self.preview(row, now)
                        self.dirty=True
                        self.refresh()
                        return self._info(f'Rij {row+1}: stap {previous+1} → {pos+1} TIE '+
                                          ('AAN' if self.pattern.ties[row][pos] else 'UIT'))
                    self.pattern.steps[row][pos]=not self.pattern.steps[row][pos]
                    if not self.pattern.steps[row][pos]:self.pattern.ties[row][pos]=False
                    preview=self.preview(row, now)
                    result=self._info(f'patroon {self.bank+1} lane {row+1} stap {pos+1}: '+('AAN' if self.pattern.steps[row][pos] else 'UIT')+
                                      (f' (buiten loop van {self.pattern.length})' if pos>=self.pattern.length else '')+
                                      (' · voorluisteren: stemmen bezet' if preview=='busy' else ''))
                self.dirty=True
                self.refresh()
                return result
            if TRACK_FIRST<=note<TRACK_FIRST+8:
                action=note-TRACK_FIRST
                if action==0:
                    self.stop_preview()
                    self.mode='patch';self._arm_patch_pickup();result='PATCH-modulatiematrix'
                elif action==1:self.mode='seq';result='sequencer'
                elif action==2:self.page=0;result='stappen 1-8'
                elif action==3:self.page=1;result='stappen 9-16'
                elif action==4:
                    self.set_playing(not self.playing,now)
                    result='PLAY' if self.playing else 'STOP'
                    if self.playing and self.clock=='swing' and not self.swing_sync.running:
                        result='GEREED — wacht op SWING START'
                elif action==5:self.save_pattern(now);result=f'patroon {self.bank+1} opgeslagen'
                elif action==6:self.load_pattern();result=f'patroon {self.bank+1} geladen'
                else:self.set_playing(False,now);self.router.panic();result='PANIC — alles stil'
                self.dirty=True;self.refresh();return self._info(result)
            if SCENE_FIRST<=note<SCENE_FIRST+8:
                if self.mode=='seq' and self.shift:
                    if note in LENGTH_NOTES:
                        return self.set_length(SEQUENCE_LENGTHS[LENGTH_NOTES.index(note)])
                    return self._info('SHIFT: kies 4/8/16 met de bovenste drie rechterknoppen')
                if self.mode=='patch':
                    row=7-(note-SCENE_FIRST)
                    if self.focus_col is not None and now<=self.focus_deadline:
                        if self.rig.mod_matrix.grid[row][self.focus_col] is None:
                            action=f'Fader {self.focus_col+1}: rij {row+1} heeft geen actieve route'
                        else:
                            active=self.rig.mod_matrix.toggle_assignment(self.focus_col,row)
                            action=(f'Fader {self.focus_col+1}: rij {row+1} '+('GEKOPPELD' if active else 'ONTKOPPELD'))
                        self.focus_deadline=now+1.0
                    else:
                        self.selected_source=row
                        action=f'Rij {row+1}: {SOURCES[row]} / {SOURCES_B[row]}'
                    self.dirty=True;self.refresh()
                    return self._info(action)
                return self.select_pattern(note-SCENE_FIRST,now)
            return None
        if msg.type=='control_change' and msg.channel==0 and 48<=msg.control<=56:
            col=msg.control-48
            raw=int(msg.value)
            previous=self.faders[col]
            self.faders[col]=raw
            self.gui_revision+=1
            if self.mode=='patch' and col<8:
                # Every column owns an INDEPENDENT group of source rows.
                # Relative fader delta prevents abrupt jumps when the stored
                # depth/positions differ. The exact original depths remain saved.
                self.focus_col=col
                self.focus_deadline=now+1.0
                self.dirty=True
                self.patch_previous[col]=raw
                if previous is not None and raw!=previous:
                    delta=(raw-previous)/63.0
                    if self.rig.mod_matrix.adjust_gain(col,delta):
                        self.rig.tick(force=True)
                        self.refresh()
                        return self._info(f'Fader {col+1}: {len(self.rig.mod_matrix.groups["rows"][col])} rijen, '
                                          f'factor {self.rig.mod_matrix.groups["gains"][col]:.2f}x')
                self.refresh()
                return None
            if msg.control==56:
                if self.mode=='patch':
                    return None  # master fader is reserved for sequencer tempo
                # Avoid changing tempo from fader when external clock is master.
                if self.clock=='internal':
                    self.pattern.bpm=round(60+msg.value*120/127,1)
                    return self._info(f'{self.pattern.bpm:.1f} BPM')
                return self._info('Tempo volgt SWING; gebruik TEMPO op de SWING')
            if self.mode=='seq':
                lane=msg.control-48
                if self.shift:
                    self.pattern.velocity[lane]=max(1,int(msg.value))
                    return self._info(f'lane {lane+1} velocity {self.pattern.velocity[lane]}')
                self.pattern.notes[lane]=36+round(msg.value*48/127)
                return self._info(f'lane {lane+1} MIDI-noot {self.pattern.notes[lane]}')
        return None

    def stop_preview(self):
        if self.preview_note is not None:
            self.router.off('preview', self.preview_note)
            self.preview_note=None
            self.preview_until=None
            self.gui_revision+=1

    def preview(self, row, now):
        """One short lane-pitch audition; never changes the sequence clock."""
        self.stop_preview()
        note=self.pattern.notes[row]
        velocity=self.pattern.velocity[row]
        active=getattr(self.rig,'active_notes',None)
        voices=getattr(self.rig,'voices',None)
        if active is not None and voices is not None and note not in active and len(active)>=len(voices):
            return 'busy'  # a preview may never steal one of the four held voices
        if self.router.on('preview', note, velocity):
            self.preview_note=note
            self.preview_until=now+PREVIEW_SECONDS
            self.gui_revision+=1
            return 'played'
        return 'already_sounding'

    def _cancel_pattern_queue(self):
        if self.pending_bank is not None:
            self.pending_bank=None
            self.pending_pattern=None
            self.pending_since=None
            self.pending_blink=False
            self.dirty=True
            self.gui_revision+=1

    def _read_pattern(self, bank):
        if type(bank) is not int or not 0<=bank<8:raise ValueError('Patroonplaats moet 1–8 zijn')
        path=self.pattern_dir/f'apc_{bank+1:02d}.json'
        if not path.is_file():return Pattern()
        try:
            return Pattern.parse(json.loads(path.read_text(encoding='utf8')))
        except (KeyError,TypeError,AttributeError) as exc:
            raise ValueError(f'Ongeldig patroonbestand {path.name}: {exc}') from exc

    def _activate_pattern(self, bank, candidate, *, live=False):
        bpm=self.pattern.bpm
        self.stop_preview()
        self.router.clear('apc')
        self.pending_off=[]
        self.lane_notes={}
        self.bank=bank
        self.pattern=candidate
        self.page=0
        if live:self.pattern.bpm=bpm
        self.step=-1
        self._fit_loop()
        self.dirty=True

    def select_pattern(self, bank, now=None):
        if now is None:now=time.monotonic()
        if self.playing and self.step>=0 and bank==self.bank:
            self._cancel_pattern_queue()
            self.refresh()
            return self._info(f'Patroon {self.bank+1} blijft spelen; voorselectie gewist')
        try:
            candidate=self._read_pattern(bank)  # disk I/O/validation BEFORE a musical boundary
        except (OSError,ValueError,KeyError,TypeError) as exc:
            self._info(f'Patroon {bank+1} niet geladen: {exc}')
            raise
        if self.playing and self.step>=0:
            self.pending_bank=bank
            self.pending_pattern=candidate
            self.pending_since=now
            self.pending_blink=True
            self.dirty=True
            self.refresh()
            return self._info(f'Patroon {bank+1} volgt aan het einde van loop {self.bank+1}')
        self._cancel_pattern_queue()
        self._activate_pattern(bank,candidate,live=self.playing)
        self.refresh()
        return self._info(f'Patroon {bank+1} gekozen')

    def _fit_loop(self):
        """Keep saved steps intact; remove only a sounding cursor outside the loop."""
        if self.step>=self.pattern.length:
            self.router.clear('apc')
            self.pending_off=[]
            self.lane_notes={}
            self.step=-1
        if self.page*8>=self.pattern.length:
            self.page=0

    def set_length(self, length):
        self.pattern.length=validate_length(length)
        self._fit_loop()
        self.dirty=True
        self.refresh()
        return self._info(f'Patroon {self.bank+1}: loop {length} stappen (SAVE bewaart)')

    def set_clock(self, clock, now=None):
        if clock not in ('internal','swing'):raise ValueError('clock moet internal/swing zijn')
        if now is None:now=time.monotonic()
        self.set_playing(False, now)
        self.clock=clock
        self.clock_pulses=0;self.last_external_step=None
        return self._info('clock '+clock)

    def set_playing(self, playing, now=None, *, preserve=False):
        if now is None:now=time.monotonic()
        self._cancel_pattern_queue()
        self.stop_preview()
        self.playing=bool(playing)
        self.router.clear('apc')
        self.pending_off=[]
        self.lane_notes={}
        if self.playing:
            self.step=-1;self.clock_pulses=0;self.last_external_step=None
            self.next_step=now if self.clock=='internal' else None
        else:
            if not preserve:self.step=-1
            self.next_step=None
        self.dirty=True

    def _watch_swing_clock(self, now):
        if not self.swing_sync.check_timeout(now):return False
        # A disconnected SWING can no longer deliver its Note Offs. Release
        # only that source; an independently clocked APC may keep playing.
        self.router.clear('swing')
        self.swing_sync.held_notes.clear()
        if self.clock=='swing':
            self.set_playing(False, now)
        self._info('SWING clock weg: noten losgelaten; START nodig voor synchronisatie')
        return True

    def swing_clock(self, msg, now=None):
        if now is None:now=time.monotonic()
        self._watch_swing_clock(now)
        event = self.swing_sync.feed(msg, now)
        if self.clock!='swing' or event is None:return
        if event.kind=='start':
            self.set_playing(True, now)
        elif event.kind=='stop':
            self.set_playing(False, now, preserve=True)
        elif event.kind=='continue':
            self.playing=True
            self.last_external_step=None
            self.dirty=True
        elif event.kind=='clock' and self.playing and event.tick is not None:
            self.clock_pulses=event.tick % CLOCKS_PER_STEP
            if self.clock_pulses==0:
                interval=(now-self.last_external_step) if self.last_external_step is not None else None
                self.last_external_step=now
                self._step(now,interval)

    def _step(self, now,actual_interval=None):
        if self.pending_bank is not None and (self.step<0 or self.step==self.pattern.length-1):
            bank,candidate=self.pending_bank,self.pending_pattern
            self._cancel_pattern_queue()
            self._activate_pattern(bank,candidate,live=True)
            self._info(f'Patroon {bank+1} speelt; live tempo behouden')
        self.step=(self.step+1)%self.pattern.length
        bpm=(self.swing_sync.bpm if self.clock=='swing' else None) or self.pattern.bpm
        duration=(actual_interval if actual_interval is not None and .02<actual_interval<1.0
                  else 60.0/bpm/4)
        active={lane:self.pattern.notes[lane] for lane in range(8)
                if self.pattern.steps[lane][self.step]}
        notes=set(active.values())
        # An edited/broken tie cannot leave its old gate held past the boundary.
        for note in set(self.lane_notes.values())-notes:
            self.router.off('apc',note)
            self.pending_off=[(due,n) for due,n in self.pending_off if n!=note]
        next_step=(self.step+1)%self.pattern.length
        for note in sorted(notes):
            lanes=[lane for lane,n in active.items() if n==note]
            sounding=(not hasattr(self.rig,'active_notes') or note in self.rig.active_notes)
            continued=(sounding and note in self.router.held['apc'] and any(
                self.lane_notes.get(lane)==note and self.pattern.tied(lane,self.step) for lane in lanes))
            if not continued:
                self.router.on('apc',note,self.pattern.velocity[lanes[-1]])
            self.pending_off=[(due,n) for due,n in self.pending_off if n!=note]
            if not any(self.pattern.tied(lane,next_step) for lane in lanes):
                self.pending_off.append((now+duration*self.pattern.gate,note))
        self.lane_notes=active
        self.dirty=True

    def tick(self, now=None):
        if now is None:now=time.monotonic()
        self._watch_swing_clock(now)
        if self.pending_bank is not None:
            blink=int(max(0,now-self.pending_since)/PATTERN_BLINK_SECONDS)%2==0
            if blink!=self.pending_blink:
                self.pending_blink=blink
                self.dirty=True
                self.gui_revision+=1
        if self.save_confirmed and now>=self.save_until:
            self.save_confirmed=False
            self.save_until=None
            self.dirty=True
            self.gui_revision+=1
        if self.preview_until is not None and now>=self.preview_until:
            self.stop_preview()
        if self.focus_col is not None and now>self.focus_deadline:
            self.focus_col=None
            self.dirty=True
        if (self.fader_intro_status=='waiting' and self.fader_intro_requested_at is not None
                and now-self.fader_intro_requested_at > 2.0):
            self.fader_intro_status='no_response'
            self.gui_revision+=1
        if self.pending_off:
            expired=[n for due,n in self.pending_off if due<=now]
            self.pending_off=[(due,n) for due,n in self.pending_off if due>now]
            for n in expired:
                self.router.off('apc',n)
                self.lane_notes={lane:note for lane,note in self.lane_notes.items() if note!=n}
        if self.playing and self.clock=='internal' and self.next_step is not None:
            if now>=self.next_step:
                due=self.next_step
                self._step(now)
                duration=60.0/self.pattern.bpm/4
                # Keep small polling delays from accumulating as tempo drift.
                # A real stall still skips beats instead of piling up Note Ons.
                self.next_step=due+duration
                if self.next_step<=now:self.next_step=now+duration
        self.refresh()

    def _path(self):
        return self.pattern_dir / f'apc_{self.bank+1:02d}.json'

    def save_pattern(self, now=None):
        started=time.monotonic()
        if now is None:now=started
        self.save_confirmed=False
        self.save_until=None
        self.save_error=None
        self.dirty=True
        self.refresh()
        target=self._path()
        partial=target.with_suffix('.json.tmp')
        try:
            self.pattern_dir.mkdir(parents=True,exist_ok=True)
            with partial.open('w',encoding='utf8') as handle:
                handle.write(json.dumps(self.pattern.dump(),indent=2)+'\n')
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(partial,target)
        except OSError as exc:
            self.save_error=str(exc)
            self._info('SAVE MISLUKT: '+str(exc))
            raise
        finally:
            try:partial.unlink(missing_ok=True)
            except OSError:pass
        self.save_confirmed=True
        self.save_until=now+max(0,time.monotonic()-started)+SAVE_CONFIRM_SECONDS
        self.dirty=True
        self.refresh()
        return target

    def load_pattern(self,silent=False):
        path=self._path()
        candidate=self._read_pattern(self.bank)
        self._cancel_pattern_queue()
        self.stop_preview()
        self.router.clear('apc')
        self.pending_off=[]
        self.lane_notes={}
        self.pattern=candidate
        self._fit_loop()
        self.dirty=True
        if not silent:self._info('geladen: '+str(path))

    def display_snapshot(self):
        """State of the LED commands we sent, not an unverified hardware readback.

        Pads use manufacturer palette indexes, bottom row notes 0..7.
        This is consumed by the separate, read-only Tk monitor.
        """
        result=self.status()
        result.update({
            'connected':True,
            'sources':list(SOURCES), 'destinations':list(DESTINATIONS),
            'sources_b':list(SOURCES_B),'destinations_d':list(DESTINATIONS_D),
            'focus_col':self.focus_col,'groups':self.rig.mod_matrix.dump_groups(),
            'matrix':self.rig.mod_matrix.dump(),
            'selected_source':self.selected_source,
            'patch_pickup':list(self.patch_pickup),
            'pads':[self.last_color.get(i, OFF) for i in range(64)],
            'track_leds':[bool(self.last_button.get(i,False)) for i in range(100,108)],
            'scene_leds':[bool(self.last_button.get(i,False)) for i in range(112,120)],
            'faders':list(self.faders),
            'fader_intro_status':self.fader_intro_status,
            'shift':self.shift,
            'lanes':list(self.pattern.notes),
            'velocity':list(self.pattern.velocity),
            'columns':[{'name':name,'raw':self.rig.mod_matrix.grid[self.selected_source][i],
                         'factor':self.rig.mod_matrix.groups['gains'][i]}
                       for i,name in enumerate(DESTINATIONS)],
            'last_action':self.last_action,
            'revision':self.gui_revision,
        })
        return result

    def status(self):
        return {'mode':self.mode,'page':self.page+1,'bank':self.bank+1,
                'playing':self.playing,'clock':self.clock,
                'bpm':self.pattern.bpm,'step':self.step+1 if self.step>=0 else 0,
                'length':self.pattern.length,
                'pending_bank':self.pending_bank+1 if self.pending_bank is not None else None,
                'pending_blink':self.pending_blink,
                'save_confirmed':self.save_confirmed,'save_error':self.save_error,
                'preview_note':self.preview_note if self.preview_note in self.router.held['preview'] else None,
                'sync':self.swing_sync.snapshot()}

    def close(self):
        self.set_playing(False)
        if self.output is not None:
            try:
                for pad in range(64):self._send_led(pad,OFF)
                for note in list(range(100,108))+list(range(112,120)):
                    self._send_button(note,False)
            except (OSError,RuntimeError):pass
