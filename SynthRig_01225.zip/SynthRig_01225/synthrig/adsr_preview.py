"""Read-only, relative AMP envelope geometry; no audio or GUI dependency.

Segment widths follow the fader positions, with a small minimum so very short
times remain visible. Sustain has a fixed display width: its actual duration
depends on when the key is released. This is not a seconds-calibrated plot.
"""

AMP_CCS = (19, 23, 27, 31)


def envelope_points(values, bounds):
    """Return five (x, y) vertices, or None until all four values are known."""
    if any(cc not in values for cc in AMP_CCS):
        return None
    attack, decay, sustain, release = (
        max(0, min(127, values[cc])) / 127 for cc in AMP_CCS
    )
    left, top, right, bottom = bounds
    width, height = right - left, bottom - top
    # A/D/R share 78% of the width. Reserve 22% for the held sustain stage.
    weights = [0.12 + value for value in (attack, decay, release)]
    a, d, r = [width * 0.78 * value / sum(weights) for value in weights]
    peak_x = left + a
    sustain_x = peak_x + d
    release_x = right - r
    sustain_y = bottom - sustain * height
    return ((left, bottom), (peak_x, top), (sustain_x, sustain_y),
            (release_x, sustain_y), (right, bottom))
