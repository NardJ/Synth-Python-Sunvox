"""Shared loop sizes and top-to-bottom SHIFT scene-button assignments."""

SEQUENCE_LENGTHS = (4, 8, 16)
LENGTH_NOTES = (112, 113, 114)


def validate_length(value):
    if type(value) is not int or value not in SEQUENCE_LENGTHS:
        raise ValueError('Patroonlengte moet 4, 8 of 16 stappen zijn')
    return value
