"""SynthRig 0.12.25 - 4 echte, afzonderlijke SunVox-stemmen.

SunVox verzorgt ALLE audio. Amp ADSR is een native SunVox-ADSR.
Filter ADSR/PWM blijven Python control-rate (~80 Hz). Pitch-LFO en CC1-vibrato zijn native SunVox Vibrato (of optioneel legacy).
De bestaande 0.8.5-engine blijft in engine.py als test-/terugvalbasis.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import math
import time
from sunvox.api import NOTECMD
from .pwm import PWM
from .mod_matrix import ModMatrix, blank_matrix
from .tracks098 import voice_track, send_checked
from .engine import (WAVEFORMS, WAVE_TRIMS, choose_wave_index,
                     display_controller, controller, clamp, find_midi_port)

VOICES = 4
TICK_HZ = 80
MASTER_MAX = 256

# Metingen 0.9.9 op echte audio: de SunVox Generator klinkt bij SAW
# één octaaf hoger dan bij SIN voor dezelfde SET_PITCH-waarde.
# Dit zijn correcties T.O.V. de bestaande globale -12-calibratie.
# SIN en PULSE zijn onderbouwd door de 0.9.9-opname; TRI is in de 0.9.10-wavecheck gemeten op +1 octaaf en gecorrigeerd.
DEFAULT_WAVE_PITCH_OFFSETS = {"SIN":12.0, "TRI":0.0, "SAW":0.0, "PULSE":12.0}

# Het native Vibrato-effect ontvangt audio en verwerkt vibrato intern; de
# standaard modulaties worden NIET via SET_PITCH op 80 Hz doorgestuurd.
# SunVox Frequency unit=0 is Hz/64. Max amplitude wordt bewust voorzichtig
# begrensd tot de klassieke Vibrato-stand 16/256, want dit is geen cent-schaal.
VIBRATO_MAX_NATIVE_AMP = 16
# V0.10.0: alleen voor Swing CC1: hogere native control-resolutie door
# Exponential amplitude. Native amp=64 in exp-mode is akoestisch vrijwel
# gelijk aan amp=16 in linear-mode (gemeten met SunVox offline DSP).
MOD_EXP_NATIVE_AMP = 64
MOD_SMOOTH_SECONDS = .16
VIBRATO_SMOOTH_SECONDS = .045
FILTER_SMOOTH_SECONDS = .030
VELOCITY_SMOOTH_SECONDS = .035

def midi_frequency(midi_note):
    """Exacte 12-TET MIDI standaard: A4 (MIDI 69) = 440 Hz."""
    return 440.0 * 2.0 ** ((midi_note - 69.0) / 12.0)

def sunvox_pitch_from_hz(freq):
    """Officiële sv_send_event SET_PITCH conversie (Hz -> 0..32768)."""
    return int(clamp(round(30720 - math.log2(freq / 16.333984375) * 3072), 0, 32768))

class SmoothParameter:
    """Exponentiële afvlakking in de control-loop (geen 7-bit input-mutatie)."""
    def __init__(self, value=0.0, tau=VIBRATO_SMOOTH_SECONDS):
        self.value=float(value)
        self.tau=float(tau)
    def update(self, target, elapsed):
        if elapsed > 0:
            self.value += (float(target)-self.value)*(1-math.exp(-elapsed/max(1e-5,self.tau)))
        if abs(self.value-target)<.0005:
            self.value=float(target)
        return self.value


def env_seconds(raw, maximum):
    return 0.005 + (raw / 127.0) ** 2 * (maximum - 0.005)


class Envelope:
    """Besturings-envelope voor filter-cutoff; audio-envelope is native ADSR."""
    def __init__(self, attack=.04, decay=.25, sustain=.25, release=.35):
        self.attack, self.decay, self.sustain, self.release = attack, decay, sustain, release
        self.gate = False
        self.started = 0.0
        self.released = None
        self.from_level = 0.0

    def on(self, now):
        self.gate = True
        self.started = now
        self.released = None
        self.from_level = 0.0

    def off(self, now):
        if self.gate:
            self.from_level = self.value(now)
            self.released = now
            self.gate = False

    def value(self, now):
        if not self.gate:
            if self.released is None:
                return 0.0
            return max(0.0, self.from_level * (1 - (now-self.released)/max(.005, self.release)))
        t = max(0.0, now-self.started)
        if t < self.attack:
            return t / max(.005, self.attack)
        t -= self.attack
        if t < self.decay:
            return 1.0 + (self.sustain - 1.0) * t / max(.005,self.decay)
        return self.sustain


@dataclass
class Voice:
    index: int
    r1: int
    r2: int
    o1: int
    o2: int
    dc1: int | None
    dc2: int | None
    a1: int
    a2: int
    sub: int
    sub_gain: int
    noise: int
    noise_gain: int
    filt: int
    adsr: int
    velocity_amp: int
    ctls: dict = field(default_factory=dict)
    note: int | None = None
    velocity: int = 0
    started: float = 0.0
    released: float | None = None
    filter_env: Envelope = field(default_factory=Envelope)
    amp_env_mod: Envelope = field(default_factory=Envelope)
    patch_mod_env: Envelope = field(default_factory=Envelope)
    last_cutoff: int | None = None
    last_duty: dict = field(default_factory=lambda:{1:None,2:None})
    last_fine: dict = field(default_factory=lambda:{1:None,2:None})
    last_transpose: dict = field(default_factory=lambda:{1:None,2:None})
    sub_router: int | None = None
    last_sub_transpose: int | None = None
    last_sub_fine: int | None = None
    last_pitch: dict = field(default_factory=lambda:{1:None,2:None,3:None})
    pitch_base: dict = field(default_factory=lambda:{1:None,2:None,3:None})
    smoothed_cutoff: float | None = None
    glide_from: float = 0.0  # absolute start offset in semitones
    glide_started: float = 0.0
    glide_seconds: float = 0.0
    glide_hold: float | None = None  # fixed pitch offset during amp release
    pressure: float = 0.0
    smoothed_velocity: float | None = None
    last_velocity_native: int | None = None
    patch_pitch_smooth: dict = field(default_factory=lambda:{1:0.,2:0.})
    patch_last_levels: dict = field(default_factory=lambda:{1:None,2:None})
    patch_last_resonance: int | None = None
    patch_last_sub: int | None = None
    patch_last_noise: int | None = None


class SynthRig:
    def __init__(self, slot, mappings=None, diagnose=False, dc_blocker=True, pitch_lfo_mode="native", **_kw):
        self.slot, self.diagnose = slot, diagnose
        self.dc_blocker_enabled = bool(dc_blocker)
        if pitch_lfo_mode not in ("native", "events"):
            raise ValueError("pitch_lfo_mode moet native of events zijn")
        self.pitch_lfo_mode = pitch_lfo_mode
        self.vib_lfo = None
        self.vib_mod = None
        self.vib_ctl = {}
        self._lfo_amp_smoothed = SmoothParameter()
        self._mod_amp_smoothed = SmoothParameter(tau=MOD_SMOOTH_SECONDS)
        self._last_vibrato_native = {"lfo_amp":None,"mod_amp":None,"lfo_freq":None}
        self.mappings = mappings or {}
        self.pwm = PWM()
        self.mod_matrix = ModMatrix()
        self._matrix_was_active = False
        self._patch_fx_offsets=[0.]*16
        self.pwm_trace = None
        self.pwm_tick_trace = None
        self.wave_selection = {1:2, 2:3}
        self.osc_tuning = {1:{'semitones':0,'cents':0},2:{'semitones':0,'cents':0}}
        self.osc1_level, self.osc2_level = .8, .8
        self.velocity_sensitivity = .7
        self.portamento_seconds = 0.0
        self._previous_note = None
        self._previous_voice = None
        self._previous_pitch = None
        self._previous_released_at = None
        self.channel_pressure = 0.0
        self.poly_pressure = {}
        self.chorus_mix = 0.0
        self.chorus = []  # two detuned SunVox wet taps, hard-panned L/R
        self.chorus_ctl = []
        self._chorus_smoothed = SmoothParameter(tau=.10)
        self._last_chorus_wet = None
        self.source_enabled = {'osc1':True,'osc2':True,'sub':True,'noise':True}
        self.sub_level, self.noise_level = .0, .0
        self.cutoff_hz = 2000.
        self.resonance_frac = .12
        self.filter_env_amount, self.keytrack = .0, .0
        self.amp = {'attack':.025,'decay':.25,'sustain':.7,'release':.3}
        self.fenv = {'attack':.03,'decay':.28,'sustain':.15,'release':.28}
        self.lfo_rate, self.lfo_pitch, self.lfo_filter = 1.4, .0, .0
        # Behringer Swing: bend +/-2 semitonen; CC1: vibrato max +/-40 cent bij 5Hz.
        self.bend_range = 2.0
        self.pitch_bend = 0.0
        # Initialisatie: eenmalig SET_PITCH; live bend/tuning: fasevaste effecten 05/06.
        self.pitch_target = "generator"
        # Kalibratie gemeten op de echte SunVox-output van 0.9.6: +1 octaaf.
        # NIET aan de officiële SunVox SET_PITCH-formule veranderen: die is juist.
        # De interne Generator-respons wordt voorlopig apart gekalibreerd.
        self.pitch_calibration_semitones = float(_kw.get('pitch_calibration_semitones', -12.0))
        overrides = _kw.get('wave_pitch_offsets') or {}
        self.wave_pitch_offsets = dict(DEFAULT_WAVE_PITCH_OFFSETS)
        for name, value in overrides.items():
            if name not in self.wave_pitch_offsets or not -24 <= float(value) <= 24:
                raise ValueError(f'Ongeldige golfvorm-pitchcorrectie: {name}={value}')
            self.wave_pitch_offsets[name] = float(value)
        self._waveform_next_audit = 0.0
        self.mod_wheel = 0.0
        self._mod_phase = 0.0
        self._lfo_phase, self._last_tick = 0.0, None
        self._lfo2_phase = 0.0
        self._lfo3_phase = 0.0
        self._effective_lfo_rate = self.lfo_rate
        self._matrix_lfo_rate_smoothed = SmoothParameter(value=self.lfo_rate,tau=.09)
        # Independent patch sources, adjustable from presets/terminal API.
        self.patch_mod_env_settings={'attack':.035,'decay':.40,'sustain':.22,'release':.30}
        self.patch_ramp_seconds=1.2
        self._mod_legacy_routes=[]
        self._last_cycle = 0.0
        self.last_cc = {}
        # Final SunVox stage for GLOBAL output gain, independent of MIDImix master
        # and of all patch/preset settings. Every dry/wet route feeds this bus.
        self.output_gain_db = 0.0
        self._output_gain_smoothed = SmoothParameter(value=0.0, tau=.060)
        self._last_output_volume = None
        self.output_amp = self.add('Amplifier', 'GLOBAL software output gain', 2050, 400)
        self.output_volume_ctl = self.lookup(self.output_amp, 'Volume')
        self.set_ctl(self.output_amp, self.output_volume_ctl, 256)
        rc = self.slot.connect_module(self.output_amp, 0)
        if rc is not None and rc < 0:
            raise RuntimeError(f'SunVox output boost -> output connect: {rc}')
        self.voices = []
        self.active_notes = {}  # pitch -> index (only keys held down)
        self._create_voices()
        if self.pitch_lfo_mode == "native":
            self._create_native_vibrato()
        self._create_chorus()
        self._create_spatial_fx()
        self.slot.volume(round(MASTER_MAX * 96 / 127))
        self.slot.set_event_t(1, 0)
        self._update_amp_envelopes()
        self._update_osc_levels()
        self._update_all_waveforms()
        self._update_resonance()
        self.tick(force=True)
        # SunVox-controllerwrites worden via events verwerkt: readback kan
        # bij een eerste schrijfopdracht nog een oudere waarde bevatten.
        # Eerst actieve afstemming vóór er een echte toets wordt afgespeeld.
        if not _kw.get('offline', False) and not self.ensure_waveforms(timeout=.8, strict=False):
            print('WAARSCHUWING: golfvormen bij opstart nog niet bevestigd; '
                  'achtergrondcontrole blijft actief.',flush=True)
        print('SynthRig 0.12.25: 4 stemmen, velocity, portamento, chorus, delay, reverb en presets.')
        print('DC-blockers per hoofdoscillator:', 'AAN' if self.dc_blocker_enabled else 'UIT')
        print(f'Pitch-LFO: {self.pitch_lfo_mode} | filter ADSR/PWM: Python control-rate 80 Hz')
        print('Per-golfvorm pitchcorrecties (sem., bovenop globale calibratie):',
              self.wave_pitch_offsets)

    def add(self, kind, name, x, y):
        module = self.slot.new_module(kind, name, x, y, 0)
        if module < 0:
            raise RuntimeError(f'SunVox kan module {name} ({kind}) niet maken: {module}')
        return module

    def connect(self, source, target):
        # IMPORTANT: Audio from all voices and all FX goes through ONE master amp.
        # This intercepts only final output routes, not internal voice routing.
        if target == 0 and source != self.output_amp:
            target = self.output_amp
        rc = self.slot.connect_module(source,target)
        if rc is not None and rc < 0:
            raise RuntimeError(f'SunVox connect {source}->{target}: {rc}')

    def lookup(self, module, *candidates):
        try:
            return controller(self.slot, module, *candidates)
        except RuntimeError:
            pass
        options = []
        for index in range(self.slot.get_number_of_module_ctls(module)):
            name = self.slot.get_module_ctl_name(module,index)
            if isinstance(name,bytes): name=name.decode('utf8','replace')
            options.append((index,name))
        for candidate in candidates:
            for idx,name in options:
                if str(name).lower().startswith(candidate.lower()+' ('):
                    return (idx, self.slot.get_module_ctl_min(module,idx,0),
                            self.slot.get_module_ctl_max(module,idx,0))
        raise RuntimeError(f'Geen SunVox-controller {candidates} in module {module}: {options}')

    def set_ctl(self, mod, ctl, value):
        index,low,high = ctl
        raw = int(clamp(round(value),low,high))
        rc=self.slot.set_module_ctl_value(mod,index,raw,0)
        if rc is not None and rc<0:
            raise RuntimeError(f'SunVox set_module_ctl_value {mod}/{index}: {rc}')
        return raw

    def set_display(self,mod,ctl,displayed):
        idx,low,high,offset = ctl
        raw = int(clamp(round(displayed-offset),low,high))
        rc=self.slot.set_module_ctl_value(mod,idx,raw,0)
        if rc is not None and rc<0:
            raise RuntimeError(f'SunVox display control {mod}/{idx}: {rc}')
        return raw

    def _create_voices(self):
        for i in range(VOICES):
            y=250+i*390
            r1=self.add('MultiSynth',f'V{i+1} OSC1 notes',60,y)
            r2=self.add('MultiSynth',f'V{i+1} OSC2 notes',60,y+100)
            o1=self.add('Generator',f'V{i+1} OSC1',230,y)
            o2=self.add('Generator',f'V{i+1} OSC2',230,y+100)
            d1=self.add('DC Blocker',f'V{i+1} DC1',390,y) if self.dc_blocker_enabled else None
            d2=self.add('DC Blocker',f'V{i+1} DC2',390,y+100) if self.dc_blocker_enabled else None
            a1=self.add('Amplifier',f'V{i+1} gain1',550,y)
            a2=self.add('Amplifier',f'V{i+1} gain2',550,y+100)
            sub_router=self.add('MultiSynth',f'V{i+1} sub notes',60,y+190)
            sub=self.add('Generator',f'V{i+1} sub',230,y+190)
            sub_gain=self.add('Amplifier',f'V{i+1} subgain',550,y+190)
            noise=self.add('Generator',f'V{i+1} noise',230,y+275)
            noise_gain=self.add('Amplifier',f'V{i+1} noisegain',550,y+275)
            filt=self.add('Filter',f'V{i+1} filter',770,y+90)
            adsr=self.add('ADSR',f'V{i+1} AMP ADSR',940,y+90)
            velocity_amp=self.add('Amplifier',f'V{i+1} velocity gain',1050,y+90)
            voice=Voice(i,r1,r2,o1,o2,d1,d2,a1,a2,sub,sub_gain,noise,noise_gain,filt,adsr,velocity_amp)
            voice.sub_router=sub_router
            self.voices.append(voice)
            for r,o,dc,amp in ((r1,o1,d1,a1),(r2,o2,d2,a2)):
                self.connect(r,o)
                if dc is not None:
                    self.connect(o,dc); self.connect(dc,amp)
                else:
                    self.connect(o,amp)
                self.connect(amp,filt)
            # Één MIDI-track per stem voor zowel sub als noise.
            # De bronnen behouden afzonderlijke audiogains.
            self.connect(sub_router,sub)
            self.connect(sub_router,noise)
            self.connect(sub,sub_gain); self.connect(sub_gain,filt)
            self.connect(noise,noise_gain); self.connect(noise_gain,filt)
            self.connect(filt,adsr)
            self.connect(adsr,velocity_amp)
            c=voice.ctls
            c['velocity_vol']=self.lookup(velocity_amp,'Volume')
            c['velocity_unity']=self.slot.get_module_ctl_value(velocity_amp,c['velocity_vol'][0],0)
            # In native modus routeert elke voice ADSR naar een gedeelde vibratobus.
            # In legacy-modus blijft de oude directe output voor A/B-tests.
            if self.pitch_lfo_mode == "events":
                self.connect(velocity_amp,0)
            c=voice.ctls
            for j,(m,g) in enumerate(((o1,a1),(o2,a2)),start=1):
                c[f'wave{j}']=self.lookup(m,'Waveform')
                c[f'duty{j}']=self.lookup(m,'Duty cycle')
                c[f'vol{j}']=self.lookup(g,'Volume')
                c[f'unity{j}']=self.slot.get_module_ctl_value(g,c[f'vol{j}'][0],0)
                c[f'transpose{j}']=display_controller(self.slot,r1 if j==1 else r2,'Transpose')
                c[f'fine{j}']=display_controller(self.slot,r1 if j==1 else r2,'Finetune','Fine tune')
            c['sub_transpose']=display_controller(self.slot,sub_router,'Transpose')
            c['sub_fine']=display_controller(self.slot,sub_router,'Finetune','Fine tune')
            # MultiSynth uitsluitend voor Note On/Off-routing; pitch blijft neutraal.
            for j,r in ((1,r1),(2,r2)):
                self.set_display(r,c[f'transpose{j}'],0)
                self.set_display(r,c[f'fine{j}'],0)
            self.set_display(sub_router,c['sub_transpose'],0)
            self.set_display(sub_router,c['sub_fine'],0)
            c['subwave']=self.lookup(sub,'Waveform')
            c['noisewave']=self.lookup(noise,'Waveform')
            self.set_ctl(sub,c['subwave'],5)    # sine
            self.set_ctl(noise,c['noisewave'],3) # white noise
            for kind, mod in (('sub',sub_gain),('noise',noise_gain)):
                c[kind+'vol']=self.lookup(mod,'Volume')
                c[kind+'unity']=self.slot.get_module_ctl_value(mod,c[kind+'vol'][0],0)
            c['cutoff']=self.lookup(filt,'Frequency','Freq')
            c['resonance']=self.lookup(filt,'Resonance')
            for name,aliases,val in (
                ('type',('Type',),0),('mix',('Mix',),256),
                ('mode',('Mode',),0),('rolloff',('Roll-off','Roll off','Rolloff'),1),
                ('response',('Response',),1)):
                ctl=self.lookup(filt,*aliases)
                c['filter_'+name]=ctl
                self.set_ctl(filt,ctl,val)
            c['amp_attack']=self.lookup(adsr,'Attack','Attack (ms)')
            c['amp_decay']=self.lookup(adsr,'Decay','Decay (ms)')
            c['amp_sustain']=self.lookup(adsr,'Sustain level')
            c['amp_release']=self.lookup(adsr,'Release','Release (ms)')
            c['amp_mode']=self.lookup(adsr,'Mode')
            c['amp_sustain_switch']=self.lookup(adsr,'Sustain')
            c['amp_on']=self.lookup(adsr,'On NoteON','On Note ON')
            c['amp_off']=self.lookup(adsr,'On NoteOFF','On Note OFF')
            # Standalone gate MIDI -> native ADSR amplitude-modulator mono.
            self.set_ctl(adsr,c['amp_mode'],1)
            self.set_ctl(adsr,c['amp_sustain_switch'],1)
            self.set_ctl(adsr,c['amp_on'],2)  # start bij iedere Note ON
            self.set_ctl(adsr,c['amp_off'],2) # stop bij iedere Note OFF

    def _create_native_vibrato(self):
        """Twee gedeelde SunVox Vibrato modules na de polyfone stemmix.

        De eerste module volgt MIDImix LFO→pitch, de tweede de Swing CC1
        Modulation (vaste 5Hz). Beide effecten verwerken het audiosignaal
        intern en genereren géén 80Hz SET_PITCH events.
        """
        self.vib_lfo = self.add('Vibrato','LFO pitch (native)',1100,500)
        self.vib_mod = self.add('Vibrato','Swing vibrato (native)',1260,500)
        for v in self.voices:
            self.connect(v.velocity_amp,self.vib_lfo)
        self.connect(self.vib_lfo,self.vib_mod)
        self.connect(self.vib_mod,0)
        for prefix,module in (('lfo',self.vib_lfo),('mod',self.vib_mod)):
            # Expliciet op unity; geen verborgen volumecorrectie op basis van 1 meting.
            vol_ctl = self.lookup(module,'Volume')
            self.vib_ctl[prefix+'_volume'] = vol_ctl
            self.set_ctl(module,vol_ctl,256)
            self.vib_ctl[prefix+'_amplitude'] = self.lookup(module,'Amplitude')
            if prefix == 'mod':
                # SunVox's exp-regeling heeft bij deze lage vibratodiepte
                # veel kleinere stappen dan de standaard lineaire regeling.
                self.vib_ctl['mod_exponential'] = self.lookup(module,'Exponential amplitude')
                self.set_ctl(module,self.vib_ctl['mod_exponential'],1)
            self.vib_ctl[prefix+'_frequency'] = self.lookup(module,'Frequency','Freq')
            unit = self.lookup(module,'Frequency unit','Frequency unit (Hz/64)')
            self.vib_ctl[prefix+'_unit'] = unit
            # De stand 0 van de SunVox Frequency unit-controller is Hz/64.
            self.set_ctl(module,unit,0)
            self.set_ctl(module,self.vib_ctl[prefix+'_amplitude'],0)
            self.set_ctl(module,self.vib_ctl[prefix+'_frequency'],
                         64* (self.lfo_rate if prefix=='lfo' else 5.0))

    def _create_chorus(self):
        """Stereo chorus: two independent modulated short delays in parallel.

        The original voice bus ALWAYS feeds the output directly. Both effects
        send wet-only signals through hard-panned amplifiers, and start at 0.
        This keeps the 0.9.13 dry patch intact when CC60=0.
        """
        sources = ([self.vib_mod] if self.pitch_lfo_mode == 'native' else
                   [v.velocity_amp for v in self.voices])
        for side,delay,rate,phase,pan in (
            ('left',570,8,0,0), ('right',790,11,128,256)):
            flanger=self.add('Flanger',f'Chorus {side} wet',1430,440 if side=='left' else 620)
            panner=self.add('Amplifier',f'Chorus {side} pan',1570,440 if side=='left' else 620)
            for source in sources:
                self.connect(source,flanger)
            self.connect(flanger,panner)
            self.connect(panner,0)
            self.set_ctl(panner,self.lookup(panner,'Balance'),pan)
            for name,value in (('Dry',0),('Wet',0),('Feedback',0),
                               ('Delay',delay),('Response',64),
                               ('LFO freq',rate),('LFO amp',175),
                               ('LFO waveform',1),('Set LFO phase',phase),
                               ('LFO freq unit',0)):
                self.set_ctl(flanger,self.lookup(flanger,name),value)
            self.chorus.append(flanger)
            self.chorus_ctl.append(self.lookup(flanger,'Wet'))

    def _update_chorus(self,dt):
        # Avoid audible steps when the physical CC60 knob moves quickly.
        wet=round(self._chorus_smoothed.update(172*max(0.,min(1.,self.chorus_mix+0.35*self._patch_fx_offsets[14])),dt))
        if wet!=self._last_chorus_wet:
            for module,ctl in zip(self.chorus,self.chorus_ctl):
                self.set_ctl(module,ctl,wet)
            self._last_chorus_wet=wet

    def _create_spatial_fx(self):
        """Parallelle wet-only sends, droge route en chorus niet gewijzigd.

        Echo en Reverb zijn native SunVox DSP modules, zonder extra Python-
        audiobuffers. Mix start op nul voor compatibiliteit met 0.10.2.
        """
        self.delay_mix = 0.0
        self.reverb_mix = 0.0
        self.delay_smoothed = SmoothParameter(tau=.10)
        self.reverb_smoothed = SmoothParameter(tau=.10)
        self.last_delay_wet = None
        self.last_reverb_wet = None
        sources = ([self.vib_mod] if self.pitch_lfo_mode == 'native' else
                   [v.velocity_amp for v in self.voices])
        self.delay_module = self.add('Echo', 'Preset delay wet', 1720, 690)
        self.reverb_module = self.add('Reverb', 'Preset reverb wet', 1720, 850)
        for source in sources:
            self.connect(source, self.delay_module)
            self.connect(source, self.reverb_module)
        self.connect(self.delay_module, 0)
        self.connect(self.reverb_module, 0)
        self.delay_wet_ctl = self.lookup(self.delay_module, 'Wet')
        self.delay_feedback_ctl=self.lookup(self.delay_module,'Feedback')
        self.delay_feedback_smoothed=SmoothParameter(value=105,tau=.16)
        self.last_delay_feedback=None
        self.reverb_wet_ctl = self.lookup(self.reverb_module, 'Wet')
        for name,value in (('Dry',0),('Wet',0),('Feedback',105),
                           ('Delay',135),('Delay unit',0),('Filter',1),('F.freq',4200)):
            self.set_ctl(self.delay_module,self.lookup(self.delay_module,name),value)
        for name,value in (('Dry',0),('Wet',0),('Feedback',172),
                           ('Damp',146),('Stereo width',220),('Room size',55)):
            self.set_ctl(self.reverb_module,self.lookup(self.reverb_module,name),value)

    def set_output_gain_db(self, db):
        """Software gain after all synth effects. Not a preset/MIDI control."""
        db = float(db)
        if not math.isfinite(db) or not -6.0 <= db <= 9.0:
            raise ValueError('Software outputgain moet tussen -6 en +9 dB liggen')
        self.output_gain_db = round(db * 2.0) / 2.0
        return f'Software outputgain {self.output_gain_db:+.1f} dB'

    def _update_output_gain(self, elapsed):
        # SunVox Amplifier Volume has unity=256 and max=1024.
        # Smooth in dB to avoid clicks when the GUI slider moves quickly.
        db = self._output_gain_smoothed.update(max(-6.,min(9.,self.output_gain_db)), elapsed)
        raw = round(256.0 * 10.0 ** (db / 20.0))
        if raw != self._last_output_volume:
            self.set_ctl(self.output_amp, self.output_volume_ctl, raw)
            self._last_output_volume = raw

    def _update_spatial_fx(self, elapsed):
        delay = round(self.delay_smoothed.update(max(0.,min(1.,self.delay_mix+0.4*self._patch_fx_offsets[12])) * 150, elapsed))
        reverb = round(self.reverb_smoothed.update(max(0.,min(1.,self.reverb_mix+0.4*self._patch_fx_offsets[13])) * 170, elapsed))
        # Hard feedback limit prevents runaway echoes; damping is updated at
        # control rate, not via audio resets.  No output-gain modulation.
        feedback=int(round(self.delay_feedback_smoothed.update(
            max(25.,min(180.,105.+65.*self._patch_fx_offsets[15])),elapsed)))
        if feedback!=self.last_delay_feedback:
            self.set_ctl(self.delay_module,self.delay_feedback_ctl,feedback)
            self.last_delay_feedback=feedback
        if delay != self.last_delay_wet:
            self.set_ctl(self.delay_module,self.delay_wet_ctl,delay)
            self.last_delay_wet = delay
        if reverb != self.last_reverb_wet:
            self.set_ctl(self.reverb_module,self.reverb_wet_ctl,reverb)
            self.last_reverb_wet = reverb

    def _velocity_gain(self, velocity):
        """Velocity ranges 1..127, with true off (constant level) at CC58=0."""
        return (max(1,min(127,velocity))/127.0)**(1.6*self.velocity_sensitivity)

    def _glide_offset(self, v, now):
        if v.glide_hold is not None:
            return v.glide_hold
        if v.glide_seconds <= 0:
            return 0.0
        progress=clamp((now-v.glide_started)/v.glide_seconds,0.0,1.0)
        if progress>=1.0:
            v.glide_seconds=0.0
            return 0.0
        # Linear in semitones (log frequency), no SET_PITCH during slide.
        return v.glide_from*(1.0-progress)

    def _update_native_vibrato(self,dt):
        if self.vib_lfo is None:
            return
        raw_lfo=self._lfo_amp_smoothed.update(self.lfo_pitch*VIBRATO_MAX_NATIVE_AMP,dt)
        # Exponentiële amplitude volgt ongeveer kwadratisch de controller.
        # De wortel houdt de gehoorde vibratodiepte vrijwel lineair over CC1.
        raw_mod=self._mod_amp_smoothed.update(
            MOD_EXP_NATIVE_AMP*math.sqrt(clamp(self.mod_wheel,0.,1.)),dt)
        for tag,module,value in (('lfo_amp',self.vib_lfo,raw_lfo),
                                 ('mod_amp',self.vib_mod,raw_mod)):
            value=round(value)
            if self._last_vibrato_native[tag] != value:
                key='lfo_amplitude' if tag=='lfo_amp' else 'mod_amplitude'
                self.set_ctl(module,self.vib_ctl[key],value)
                self._last_vibrato_native[tag]=value
        freq=round(self._effective_lfo_rate*64)
        if self._last_vibrato_native['lfo_freq'] != freq:
            self.set_ctl(self.vib_lfo,self.vib_ctl['lfo_frequency'],freq)
            self._last_vibrato_native['lfo_freq']=freq

    def _update_amp_envelopes(self):
        for v in self.voices:
            for key in ('attack','decay','release'):
                self.set_ctl(v.adsr,v.ctls['amp_'+key],self.amp[key]*1000)
            ctl=v.ctls['amp_sustain']
            self.set_ctl(v.adsr,ctl,ctl[1]+self.amp['sustain']*(ctl[2]-ctl[1]))

    def _update_osc_levels(self):
        for v in self.voices:
            for j in (1,2):
                wave=WAVEFORMS[self.wave_selection[j]][1]
                base=(self.osc1_level if j==1 else self.osc2_level)
                if not self.source_enabled[f'osc{j}']:base=0.0
                self.set_ctl(v.a1 if j==1 else v.a2, v.ctls[f'vol{j}'],
                             v.ctls[f'unity{j}']*.36*base*WAVE_TRIMS[wave])
            self.set_ctl(v.sub,v.ctls['subwave'],5)
            self.set_ctl(v.sub_gain,v.ctls['subvol'],v.ctls['subunity']*.16*self.sub_level*int(self.source_enabled['sub']))
            self.set_ctl(v.noise_gain,v.ctls['noisevol'],v.ctls['noiseunity']*.12*self.noise_level*int(self.source_enabled['noise']))

    def _update_all_waveforms(self):
        for v in self.voices:
            for j in (1,2):
                self.set_ctl(v.o1 if j==1 else v.o2,v.ctls[f'wave{j}'],
                             WAVEFORMS[self.wave_selection[j]][0])

    def waveform_mismatches(self):
        """Lees ALLE acht hoofdoscillatoren. Geen gecachete GUI-waarde."""
        wrong=[]
        for v in self.voices:
            for j,mod in ((1,v.o1),(2,v.o2)):
                ctl=v.ctls[f'wave{j}']
                expected=WAVEFORMS[self.wave_selection[j]][0]
                actual=int(self.slot.get_module_ctl_value(mod,ctl[0],0))
                if actual!=expected:
                    wrong.append((v.index+1,j,mod,ctl,expected,actual))
        return wrong

    def ensure_waveforms(self, timeout=.65, strict=True, retry_interval=.075):
        """Herhaal onbevestigde SunVox writes totdat readback overeenkomt.

        Alleen voor start/test: kan maximaal `timeout` blokkeren. De gewone
        control-loop gebruikt aparte NIET-blokkerende periodieke audits.
        """
        deadline=time.monotonic()+max(0,timeout)
        last_retry=float('-inf')
        while True:
            wrong=self.waveform_mismatches()
            if not wrong:return True
            now=time.monotonic()
            if now >= deadline:
                detail=', '.join(f'V{voice}/OSC{osc}: verwacht {wanted}, gelezen {actual}'
                                 for voice,osc,_,_,wanted,actual in wrong)
                if strict:
                    raise RuntimeError('SunVox golfvorm kon niet worden bevestigd: '+detail)
                return False
            if now-last_retry >= retry_interval:
                for _voice,_osc,mod,ctl,wanted,_actual in wrong:
                    self.set_ctl(mod,ctl,wanted)
                last_retry=now
            time.sleep(min(.015,max(0,deadline-now)))

    def _audit_waveforms_nonblocking(self,now):
        """Correctie van late writes, zonder te wachten in MIDI-eventloop."""
        if now < self._waveform_next_audit:return
        wrong=self.waveform_mismatches()
        self._waveform_next_audit=now+(.15 if wrong else .75)
        for _voice,_osc,mod,ctl,wanted,_actual in wrong:
            self.set_ctl(mod,ctl,wanted)

    def _update_resonance(self):
        for v in self.voices:
            ctl=v.ctls['resonance']
            self.set_ctl(v.filt,ctl,ctl[1]+self.resonance_frac**1.5*(ctl[2]-ctl[1]))

    def _send(self,track,note,vel,module):
        return send_checked(self.slot,track,note+1,vel,module+1,0,0)

    def _off_track(self,track,module=None):
        # Module EXPLICIET: SET_PITCH gebruikt op dezelfde track het adres van
        # de Generator. Een impliciete NoteOff zou daardoor de router missen.
        return send_checked(self.slot,track,NOTECMD.NOTE_OFF,0,
                            module+1 if module is not None else 0,0,0)

    @staticmethod
    def _native_pitch(midi_note):
        """MIDI-conforme absolute pitch: MIDI 69=A4=440Hz, noot 36=C2.

        Vorige versie gebruikte 30720 - 256*MIDI: één octaaf te hoog.
        Deze versie gebruikt de officieel gedocumenteerde Hz->Pitch-formule.
        """
        return sunvox_pitch_from_hz(midi_frequency(midi_note))

    def _send_live_pitch(self, v, osc, expressed_pitch):
        """Stem een aangehouden Generator-noot zonder hoorbare fase-reset.

        SET_PITCH herinitialiseert bij snelle herhaling de Generator-fase en
        veroorzaakt daarmee tikken (vooral bij SIN). Daarom uitsluitend één
        absolute SET_PITCH direct na een nieuwe Note ON / golfvorm-retrigger.
        Live pitchbend, OSC finetune, semitone-tuning en events-vibrato lopen
        vervolgens via SunVox-effecten 05 (bend up) / 06 (bend down). Deze
        effecten zijn relatief aan de ingeschakelde basisnoot, hebben een
        resolutie van 256 eenheden per semitoon en bewaren de oscillatorfase.

        Voor de sub is -12 semitonen onderdeel van de basisstemming; de
        pitchbend erbovenop is gelijk aan de hoofdoscillatoren.
        """
        if v.note is None:
            return
        if osc == 1:
            mod, track = v.o1, voice_track(v.index, "osc1")
        elif osc == 2:
            mod, track = v.o2, voice_track(v.index, "osc2")
        else:
            # 0.12.15: Sub and noise share this MultiSynth. All SET_PITCH and
            # 05/06 pitch-bend events MUST target their common router, not the
            # sub Generator: the latter steals the virtual track focus and
            # silently kills the noise voice. In the router, both sound.
            mod, track = v.sub_router, voice_track(v.index, "sub_noise")

        base_offset = -12.0 if osc == 3 else 0.0
        tuning = (self.osc_tuning[osc]['semitones'] + self.osc_tuning[osc]['cents']/100
                  if osc in (1, 2) else 0.0)
        wave_extra = (self.wave_pitch_offsets[WAVEFORMS[self.wave_selection[osc]][1]]
                      if osc in (1, 2) else 0.0)
        if v.last_pitch[osc] is None:
            # 0.10.2: initialiseer met de VOLLEDIGE basispitch, inclusief
            # de oscillator-tuning. Anders moet vlak na NOTE_ON nog een 05/06
            # effect voor de vaste tuning verwerkt worden. Bij een drukke
            # filter/ADSR/PWM patch kan dit eerste effect verdwijnen, waardoor
            # sommige stemmen vast blijven hangen op de ongetunede toonhoogte.
            # SET_PITCH wordt slechts één keer verstuurd, vóór de glide.
            base_relative = base_offset + tuning + v.glide_from
            base_pitch = self._native_pitch(v.note + base_relative +
                                            self.pitch_calibration_semitones + wave_extra)
            send_checked(self.slot, track, NOTECMD.SET_PITCH, 129, mod + 1, 0, base_pitch)
            v.pitch_base[osc] = round(base_relative * 256)
            v.last_pitch[osc] = v.pitch_base[osc]

        quantized = round(expressed_pitch * 256)
        if v.last_pitch[osc] == quantized:
            return
        relative_units = quantized - v.pitch_base[osc]
        effect = 0x05 if relative_units >= 0 else 0x06
        send_checked(self.slot, track, 0, 0, mod + 1, effect, abs(relative_units))
        v.last_pitch[osc] = quantized

    def swing_ui_state(self):
        """Kleine statusupdate voor het optionele debugvenster."""
        return {'bend':round(self.pitch_bend,5),
                'bend_semitones':round(self.pitch_bend*self.bend_range,3),
                'modwheel':round(self.mod_wheel,5),
                'mod_vibrato_cents':round(40*self.mod_wheel,2) if self.pitch_lfo_mode=='events' else None,
                'mod_native_amplitude': self._last_vibrato_native['mod_amp'] if self.pitch_lfo_mode=='native' else None,
                'pitch_lfo_mode':self.pitch_lfo_mode,
                'active_notes':sorted(self.active_notes),
                'aftertouch':round(self.channel_pressure,3)}

    def _stop_generators(self,v):
        # Audio blijft klinken gedurende de AMP-release. Op het einde
        # stoppen we de drie notenrouters; sub én noise delen de derde router.
        for role,module in (("osc1",v.r1),("osc2",v.r2),
                            ("sub_noise",v.sub_router)):
            self._off_track(voice_track(v.index,role),module)

    def _stop_voice(self,v):
        self._stop_generators(v)
        self._off_track(voice_track(v.index,"amp_gate"),v.adsr)
        v.note=None;v.released=None
        v.last_pitch={1:None,2:None,3:None}
        v.pitch_base={1:None,2:None,3:None}
        v.filter_env=Envelope(**self.fenv)
        v.amp_env_mod=Envelope(**self.amp)
        v.glide_from=0.0;v.glide_seconds=0.0;v.glide_hold=None;v.pressure=0.0
        v.smoothed_velocity=None;v.last_velocity_native=None
        v.patch_pitch_smooth={1:0.,2:0.}
        v.patch_last_levels={1:None,2:None};v.patch_last_resonance=None

    def _portamento_source(self, now):
        """Return the *audible* pitch of the last voice, not its target note.

        Especially important when a note is retriggered before its preceding
        glide finished. Released notes retain the pitch at key-up; an old
        release tail is not allowed to start a new glide seconds later.
        """
        previous = self._previous_voice
        if self.portamento_seconds <= 0:
            return None
        if previous is not None and previous.note is not None:
            if previous.released is None or now-previous.released <= 1.25:
                return previous.note + self._glide_offset(previous,now)
        # Keep the last audible key-up pitch, even after SunVox has reclaimed
        # the released voice. A quick non-legato C3-C4 still gets a glide.
        if (self._previous_released_at is not None and
                self._previous_pitch is not None and
                now-self._previous_released_at<=1.25):
            return self._previous_pitch
        return None

    def note_on(self,note,velocity):
        if not (0<=note<=126) or velocity<=0:return
        now=time.monotonic()
        self._audit_waveforms_nonblocking(now)
        # Capture BEFORE a repeated note steals/resets its old voice.
        source_pitch=self._portamento_source(now)
        if note in self.active_notes:
            v=self.voices[self.active_notes.pop(note)]
            self._stop_voice(v)
        else:
            free=[v for v in self.voices if v.note is None]
            if free: v=free[0]
            else:
                # Release tails krijgen voorrang om te worden gestolen.
                released=[v for v in self.voices if v.released is not None]
                v=min(released or self.voices,key=lambda x:x.started)
                # A released tail can share the same MIDI pitch with a NEW
                # held voice.  Only unregister the note if THIS voice owns the
                # mapping.  Otherwise the later key-up would never reach its
                # voice (stuck note after rapidly played chords).
                if self.active_notes.get(v.note) == v.index:
                    self.active_notes.pop(v.note,None)
                self._stop_voice(v)
        v.last_pitch={1:None,2:None,3:None}
        v.pitch_base={1:None,2:None,3:None}
        v.patch_pitch_smooth={1:0.,2:0.}
        v.patch_last_levels={1:None,2:None};v.patch_last_resonance=None
        # Fixed native Note ON velocity: the AFTER-ADSR amplifier implements a
        # single predictable velocity curve, rather than double-scaling it.
        v.note=note;v.velocity=max(1,min(127,int(velocity)))
        v.started=now;v.released=None
        v.pressure=self.poly_pressure.get(note,0.0)
        v.smoothed_velocity=self._velocity_gain(v.velocity)
        self.set_ctl(v.velocity_amp,v.ctls['velocity_vol'],
                     v.ctls['velocity_unity']*v.smoothed_velocity)
        v.last_velocity_native=round(v.ctls['velocity_unity']*v.smoothed_velocity)
        v.glide_hold=None
        v.glide_from=float(source_pitch-note) if source_pitch is not None else 0.0
        v.glide_started=now
        # Equal glide speed per semitone. A full octave takes CC59 seconds;
        # retriggering halfway through does not restart a full-duration ramp.
        v.glide_seconds=(self.portamento_seconds*abs(v.glide_from)/12.0
                         if abs(v.glide_from)>.005 else 0.0)
        self._previous_note=note
        self._previous_voice=v
        self._previous_pitch=None
        self._previous_released_at=None
        v.filter_env=Envelope(**self.fenv);v.filter_env.on(now)
        v.amp_env_mod=Envelope(**self.amp);v.amp_env_mod.on(now)
        v.patch_mod_env=Envelope(**self.patch_mod_env_settings);v.patch_mod_env.on(now)
        self.active_notes[note]=v.index
        self._send(voice_track(v.index,"osc1"),note,127,v.r1)
        self._send(voice_track(v.index,"osc2"),note,127,v.r2)
        self._send(voice_track(v.index,"sub_noise"),note,127,v.sub_router)
        self._send(voice_track(v.index,"amp_gate"),note,127,v.adsr)
        self.tick(now,force=True)

    def note_off(self,note):
        idx=self.active_notes.pop(note,None)
        if idx is None:return
        v=self.voices[idx]
        self.poly_pressure.pop(note,None)
        now=time.monotonic()
        v.filter_env.off(now)
        v.amp_env_mod.off(now)
        v.patch_mod_env.off(now)
        # Do not let a released tail keep sliding behind the new note.
        v.glide_hold=self._glide_offset(v,now)
        v.glide_seconds=0.0
        v.released=now
        if self._previous_voice is v:
            self._previous_pitch=note+v.glide_hold
            self._previous_released_at=now
        # Generator blijft spelen gedurende de ADSR release-tijd.
        # Alleen AMP gate ontvangt nu Note OFF.
        self._off_track(voice_track(v.index,"amp_gate"),v.adsr)

    def all_notes_off(self):
        for v in self.voices:self._stop_voice(v)
        self.active_notes.clear()
        self._previous_note=None
        self._previous_voice=None
        self._previous_pitch=None
        self._previous_released_at=None
        self.poly_pressure.clear()
        self.channel_pressure=0.0

    def panic(self):
        """Echte noodstop: actieve stemmen én ALLE SunVox-DSP-effectbuffers.

        CLEAN_SYNTHS (SunVox note command 130) wist de buffers van alle
        modules, inclusief Echo, Reverb en Chorus. De modulatieparameters,
        presetinstellingen, master en software-outputgain blijven bewaard.
        Deze opdracht mag NIET bij gewone BANK/presetwisselingen worden gebruikt.
        """
        self.all_notes_off()
        rc=self.slot.send_event(0, NOTECMD.CLEAN_SYNTHS, 0, 0, 0, 0)
        if rc is not None and rc<0:
            raise RuntimeError(f'SunVox CLEAN_SYNTHS mislukt: {rc}')
        return 'PANIC — stemmen en effectbuffers gewist'

    def handle_swing(self,msg):
        if msg.type=='note_on' and msg.velocity>0:
            self.note_on(msg.note,msg.velocity)
        elif msg.type=='note_off' or (msg.type=='note_on' and msg.velocity==0):
            self.note_off(msg.note)
        elif msg.type=='pitchwheel':
            value=max(-8192,min(8191,int(msg.pitch)))
            self.pitch_bend=value/(8192.0 if value<0 else 8191.0)
            self.tick(force=True)
        elif msg.type=='control_change' and msg.control==1:
            self.mod_wheel=clamp(msg.value/127.0,0.0,1.0)
            self.tick(force=True)
        elif msg.type in ('aftertouch','channel_pressure'):
            self.channel_pressure=clamp(msg.value/127.0,0.0,1.0)
            self.tick(force=True)
        elif msg.type=='polytouch':
            self.poly_pressure[msg.note]=clamp(msg.value/127.0,0.0,1.0)
            if msg.note in self.active_notes:
                self.voices[self.active_notes[msg.note]].pressure=self.poly_pressure[msg.note]
            self.tick(force=True)

    @staticmethod
    def _pitch_parts(semitones):
        """Splits de totale toonhoogte in integer transpose en fine +/-0.5 semitoon.

        MultiSynth Finetune gebruikt 256 eenheden per semitoon.
        """
        coarse=math.floor(semitones+0.5)
        fine=round((semitones-coarse)*256)
        return coarse,fine

    def load_mod_matrix(self, data):
        """Replace routes atomically; restore any previous temporary modulation."""
        had=self.mod_matrix.has_routes()
        self.mod_matrix.load(data)
        if had and not self.mod_matrix.has_routes():
            self._patch_fx_offsets=[0.]*16
            self._update_osc_levels()
            self._update_resonance()
            for voice in self.voices:
                voice.patch_last_levels={1:None,2:None}
                voice.patch_last_resonance=None
                voice.patch_last_sub=None;voice.patch_last_noise=None
        self.tick(force=True)

    def load_mod_groups(self, groups):
        self.mod_matrix.load_groups(groups)
        self.tick(force=True)

    def _patch_sources(self, v, now, lfo):
        """One normalized vector per playing voice. Keytrack is bipolar C4-centered."""
        env=v.filter_env.value(now) if v.note is not None else 0.0
        pressure=max(self.channel_pressure,v.pressure)
        velocity=v.velocity/127.0 if v.note is not None else 0.0
        key=max(-1.,min(1.,(v.note-60)/24.)) if v.note is not None else 0.
        gate=float(v.note is not None and v.released is None)
        age=max(0.,now-v.started) if v.note is not None else 0.
        # Separate LFO2 (slower), per-note amplitude contour, trigger, S&H.
        lfo2=math.sin(2*math.pi*(self._lfo2_phase + .125))
        amp_env=v.amp_env_mod.value(now) if v.note is not None else 0.
        sample_hold=(math.sin((int(now*2.0)+v.index*17+11)*78.233)*43758.5453)%2-1
        mod_env=v.patch_mod_env.value(now) if v.note is not None else 0.
        lfo3=math.sin(2*math.pi*(self._lfo3_phase+.29))
        def rnd(index):
            phase=math.sin((index+v.index*19+13)*78.233)*43758.5453
            return 2*(phase-math.floor(phase))-1
        # Continuous cosine interpolation: no sudden jumps at sample boundaries.
        u=now*1.3;step=math.floor(u);t=u-step;t=t*t*(3-2*t)
        random_smooth=rnd(step)*(1-t)+rnd(step+1)*t
        ramp=min(1.,age/max(.05,self.patch_ramp_seconds)) if gate else 0.
        return (lfo,env,velocity,pressure,self.mod_wheel,key,gate,1.,
                lfo2,amp_env,mod_env,lfo3,random_smooth,
                ramp,float(gate and age<.12),sample_hold)

    def _apply_patch_levels(self,v,offsets):
        # New layer D destinations: SUB and NOISE amplitudes (relative).
        for kind,index,unit,base,enabled,module in (
            ('sub',8,'subunity',self.sub_level,self.source_enabled['sub'],v.sub_gain),
            ('noise',9,'noiseunity',self.noise_level,self.source_enabled['noise'],v.noise_gain)):
            ctl=v.ctls[kind+'vol']
            gain=max(0.,min(1.5,1+.5*offsets[index]))
            native=round(v.ctls[unit]*(.16 if kind=='sub' else .12)*base*gain*int(enabled))
            native=int(clamp(native,ctl[1],ctl[2]))
            last='patch_last_sub' if kind=='sub' else 'patch_last_noise'
            if getattr(v,last)!=native:
                self.set_ctl(module,ctl,native)
                setattr(v,last,native)
        for j in (1,2):
            ctl=v.ctls[f'vol{j}']
            enabled=self.source_enabled[f'osc{j}']
            base=self.osc1_level if j==1 else self.osc2_level
            wave=WAVEFORMS[self.wave_selection[j]][1]
            # Relative level modulation, cannot unmute an intentionally muted OSC.
            gain=max(0.,min(1.5,1+.50*offsets[5+j]))
            native=round(v.ctls[f'unity{j}']*.36*base*WAVE_TRIMS[wave]*gain*int(enabled))
            native=int(clamp(native,ctl[1],ctl[2]))
            if v.patch_last_levels[j]!=native:
                self.set_ctl(v.a1 if j==1 else v.a2,ctl,native)
                v.patch_last_levels[j]=native

    def tick(self,now=None,force=False):
        now=time.monotonic() if now is None else now
        if not force and self._last_tick is not None and now-self._last_tick<1/TICK_HZ:
            return
        dt=0 if self._last_tick is None else max(0,now-self._last_tick)
        self._last_tick=now
        self._audit_waveforms_nonblocking(now)
        self._lfo_phase=(self._lfo_phase+self._effective_lfo_rate*dt)%1
        self._lfo2_phase=(self._lfo2_phase+self._effective_lfo_rate*0.5*dt)%1
        self._lfo3_phase=(self._lfo3_phase+self._effective_lfo_rate*.27*dt)%1
        self._mod_phase=(self._mod_phase+5.0*dt)%1
        lfo=math.sin(2*math.pi*self._lfo_phase)
        mod_lfo=math.sin(2*math.pi*self._mod_phase)
        bend=self.pitch_bend*self.bend_range
        vibrato=(0.40*self.mod_wheel*mod_lfo if self.pitch_lfo_mode=='events' else 0.0)
        pitch_lfo=(0.50*self.lfo_pitch*lfo if self.pitch_lfo_mode=='events' else 0.0)
        patch_active=self.mod_matrix.has_routes()
        if patch_active:
            voices=[v for v in self.voices if v.note is not None]
            if voices:
                values=[self.mod_matrix.offsets(self._patch_sources(v,now,lfo)) for v in voices]
                self._patch_fx_offsets=[sum(x[i] for x in values)/len(values) for i in range(16)]
            else:self._patch_fx_offsets=[0.]*16
        else:self._patch_fx_offsets=[0.]*16
        # 2 octaves up/down, globally applied across LFO1/2/3.  Smooth and
        # clamp to prevent feedback oscillations or control-rate aliasing.
        target_rate=max(.05,min(14.,self.lfo_rate*2**(2*self._patch_fx_offsets[11])))
        self._effective_lfo_rate=self._matrix_lfo_rate_smoothed.update(target_rate,dt)
        if not patch_active:
            # An ordinary MIDImix LFO speed change must remain immediate.
            self._matrix_lfo_rate_smoothed.value=target_rate
            self._effective_lfo_rate=target_rate
        if self.pitch_lfo_mode=='native':
            self._update_native_vibrato(dt)
        self._update_chorus(dt)
        self._update_spatial_fx(dt)
        self._update_output_gain(dt)
        if self._matrix_was_active and not patch_active:
            self._update_osc_levels();self._update_resonance()
            for voice in self.voices:
                voice.patch_last_sub=None;voice.patch_last_noise=None
                voice.patch_last_levels={1:None,2:None}
        self._matrix_was_active=patch_active
        widths=self.pwm.advance(now)
        if self.pwm_tick_trace:self.pwm_tick_trace({'rate_hz':self.pwm.rate,'depth':self.pwm.depth})
        for v in self.voices:
            offsets=(self.mod_matrix.offsets(self._patch_sources(v,now,lfo))
                     if patch_active else [0.0]*16)
            if patch_active:
                self._apply_patch_levels(v,offsets)
                # Resonance is a per-voice SunVox filter parameter.
                res=max(0.,min(1.,self.resonance_frac+0.25*offsets[5]))
                rctl=v.ctls['resonance']
                resonance_value=round(rctl[1]+res**1.5*(rctl[2]-rctl[1]))
                if resonance_value!=v.patch_last_resonance:
                    self.set_ctl(v.filt,rctl,resonance_value)
                    v.patch_last_resonance=resonance_value
            elif v.patch_last_resonance is not None:
                v.patch_last_resonance=None
                v.patch_last_levels={1:None,2:None}
            if v.note is not None:
                target=self._velocity_gain(v.velocity)
                if v.smoothed_velocity is None:
                    v.smoothed_velocity=target
                elif dt>0:
                    v.smoothed_velocity += (target-v.smoothed_velocity)*(1-math.exp(-dt/VELOCITY_SMOOTH_SECONDS))
                value=round(v.ctls['velocity_unity']*v.smoothed_velocity)
                if value!=v.last_velocity_native:
                    self.set_ctl(v.velocity_amp,v.ctls['velocity_vol'],value)
                    v.last_velocity_native=value
            glide=self._glide_offset(v,now) if v.note is not None else 0.0
            if v.note is not None and v.released is not None and now-v.released>=self.amp['release']+.08:
                self._stop_generators(v)
                v.note=None;v.released=None
            for j in (1,2):
                ctl=v.ctls[f'duty{j}'];mod=v.o1 if j==1 else v.o2
                if self.wave_selection[j]==3:
                    pw=max(.08,min(.92,widths[j]+.18*offsets[j+1])) if patch_active else widths[j]
                    native=round(ctl[1]+pw*(ctl[2]-ctl[1]))
                    if native!=v.last_duty[j]:
                        self.set_ctl(mod,ctl,native)
                        v.last_duty[j]=native
                        if self.pwm_trace and v.index==0:
                            self.pwm_trace({'osc':j,'native_duty_written':native,
                                            'effective_width':widths[j],
                                            'pwm_phase':self.pwm.phase,
                                            'rate_hz':self.pwm.rate,'depth':self.pwm.depth})
                # Pitch is één som; één absoluut Generator SET_PITCH-event.
                tuning=self.osc_tuning[j]
                # Bounded +/-25 cent modulation; smooth to avoid abrupt bends.
                desired=.25*offsets[j-1]
                if dt>0:
                    alpha=1-math.exp(-dt/.065)
                    v.patch_pitch_smooth[j]+=alpha*(desired-v.patch_pitch_smooth[j])
                elif v.last_pitch[j] is None:
                    v.patch_pitch_smooth[j]=desired
                expressed=(tuning['semitones']+tuning['cents']/100
                           +bend+pitch_lfo+vibrato+glide+v.patch_pitch_smooth[j])
                self._send_live_pitch(v,j,expressed)
            # Ook sub wordt direct naar een octaaf lager getuned.
            self._send_live_pitch(v,3,-12+bend+pitch_lfo+vibrato+glide)
            if v.note is not None:
                env=v.filter_env.value(now)
                pressure=max(self.channel_pressure,v.pressure)
                octaves=(self.keytrack*(v.note-60)/12 +
                         2*(self.filter_env_amount+0.4*offsets[10])*env +
                         self.lfo_filter*lfo + 1.5*pressure + 2.0*offsets[4])
                freq=self.cutoff_hz*2**octaves
            else:freq=self.cutoff_hz
            ctl=v.ctls['cutoff']
            # Afvlakking bij handmatige cutoff-, envelope- en LFO-updates.
            if v.smoothed_cutoff is None:
                v.smoothed_cutoff=freq
            elif dt>0:
                alpha=1-math.exp(-dt/FILTER_SMOOTH_SECONDS)
                v.smoothed_cutoff += alpha*(freq-v.smoothed_cutoff)
                if abs(v.smoothed_cutoff-freq)<.4:
                    v.smoothed_cutoff=freq
            value=int(clamp(round(v.smoothed_cutoff),ctl[1],ctl[2]))
            if value!=v.last_cutoff:
                self.set_ctl(v.filt,ctl,value)
                v.last_cutoff=value

    def set_waveform_index(self,osc,index):
        """Directe 4-keuzen golfschakelaar; één note_on kiest de juiste golf."""
        if osc not in (1,2) or index not in range(4):
            raise ValueError('Ongeldige oscillator/golfvorm')
        changed=index!=self.wave_selection[osc]
        self.wave_selection[osc]=index
        # Ook bij dezelfde selectie opnieuw zetten: noodzakelijk wanneer
        # SunVox init-/preset-events nog niet verwerkt zijn.
        self._update_all_waveforms()
        if changed:
            self._update_osc_levels()
            for v in self.voices:
                if v.note is not None:
                    role="osc1" if osc==1 else "osc2"
                    tr=voice_track(v.index,role)
                    module=v.r1 if osc==1 else v.r2
                    self._off_track(tr,module)
                    self._send(tr,v.note,127,module)
                    v.last_pitch[osc]=None  # nieuwe Generator-noot opnieuw stemmen
                    v.pitch_base[osc]=None
        self.tick(force=True)
        return f'OSC{osc} golfvorm {WAVEFORMS[index][1]}'

    def set_source_enabled(self,source,enabled):
        """Mute onafhankelijk van volumefader, zonder de faderwaarde te verliezen."""
        if source not in self.source_enabled:
            raise ValueError('Onbekende audiobron')
        self.source_enabled[source]=bool(enabled)
        self._update_osc_levels()
        return f'{source.upper()} {"aan" if enabled else "uit"}'

    def set_parameter(self,target,raw):
        p=clamp(raw/127.0,0,1)
        if target=='performance.velocity':
            self.velocity_sensitivity=p
            self.tick(force=True)
            return f'Velocity gevoeligheid {p:.0%}'
        if target=='performance.portamento':
            self.portamento_seconds=0.0 if raw<=2 else 0.02*50**p
            return f'Portamento {self.portamento_seconds:.3f} s'
        if target=='effects.chorus':
            self.chorus_mix=p
            self.tick(force=True)
            return f'Chorus mix {p:.0%}'
        if target=='effects.delay':
            self.delay_mix=p
            self.tick(force=True)
            return f'Delay mix {p:.0%}'
        if target=='effects.reverb':
            self.reverb_mix=p
            self.tick(force=True)
            return f'Reverb mix {p:.0%}'
        if target=='master.level':
            vol=round(MASTER_MAX*p);self.slot.volume(vol);return f'Master {vol}/256'
        if target=='filter.cutoff':
            self.cutoff_hz=80*(14000/80)**p
            self.tick(force=True);return f'Filter cutoff {self.cutoff_hz:.0f} Hz'
        if target=='filter.resonance':
            self.resonance_frac=p;self._update_resonance();return f'Resonantie {p:.0%}'
        if target.startswith('osc') and (target.endswith('.semitones') or target.endswith('.finetune')):
            j=int(target[3]);field='semitones' if target.endswith('semitones') else 'cents'
            size=24 if field=='semitones' else 100
            bipolar=(raw-64)/(64 if raw<=64 else 63)
            value=round(size*bipolar)
            self.osc_tuning[j][field]=value
            self.tick(force=True)
            return f'OSC{j} {field} {value:+d}'
        if target in ('osc1.waveform','osc2.waveform'):
            j=int(target[3]);choice=choose_wave_index(raw,self.wave_selection[j])
            return self.set_waveform_index(j,choice)
        if target in ('osc1.level','osc2.level','sub.level','noise.level'):
            if target=='osc1.level':self.osc1_level=p
            elif target=='osc2.level':self.osc2_level=p
            elif target=='sub.level':self.sub_level=p
            else:self.noise_level=p
            self._update_osc_levels()
            for v in self.voices:
                v.patch_last_levels={1:None,2:None}
                v.patch_last_sub=None;v.patch_last_noise=None
            return f'{target} {p:.0%}'
        if target.endswith('.pulse_width'):
            j=int(target[3]);self.pwm.set_width(j,.1+.8*p)
            self.tick(force=True);return f'OSC{j} PW {self.pwm.width[j]:.0%}'
        if target=='pwm.depth':self.pwm.depth=.35*p;self.tick(force=True);return f'PWM ±{self.pwm.depth:.0%}'
        if target=='pwm.rate':self.pwm.rate=.1*(50**p);return f'PWM {self.pwm.rate:.2f}Hz'
        if target.startswith('amp.'):
            key=target.split('.')[1]
            self.amp[key]=p if key=='sustain' else env_seconds(raw,3 if key=='release' else 2)
            self._update_amp_envelopes()
            for v in self.voices:
                v.amp_env_mod.attack=self.amp['attack'];v.amp_env_mod.decay=self.amp['decay']
                v.amp_env_mod.sustain=self.amp['sustain'];v.amp_env_mod.release=self.amp['release']
            return f'AMP {key} {self.amp[key]:.3f}'
        if target.startswith('filter.'):
            key=target.split('.')[1]
            if key in self.fenv:
                self.fenv[key]=p if key=='sustain' else env_seconds(raw,3 if key=='release' else 2)
                for v in self.voices:
                    v.filter_env.attack=self.fenv['attack'];v.filter_env.decay=self.fenv['decay']
                    v.filter_env.sustain=self.fenv['sustain'];v.filter_env.release=self.fenv['release']
                return f'Filter ADSR {key} {self.fenv[key]:.3f}'
            if key=='env_amount':self.filter_env_amount=p;return f'Filter ENV {p:.0%}'
            if key=='keytrack':self.keytrack=p;return f'Keytrack {p:.0%}'
        if target=='lfo.rate':self.lfo_rate=.05*(200**p);return f'LFO {self.lfo_rate:.2f}Hz'
        if target.startswith('mod_env.'):
            key=target.split('.')[1]
            if key not in self.patch_mod_env_settings:raise ValueError(target)
            val=p if key=='sustain' else env_seconds(raw,3 if key=='release' else 2)
            self.patch_mod_env_settings[key]=val
            for v in self.voices:
                setattr(v.patch_mod_env,key,val)
            return f'Mod ENV {key} {val:.3f}'
        if target=='mod_env.ramp':
            self.patch_ramp_seconds=.08+4*p
            return f'Note ramp {self.patch_ramp_seconds:.2f}s'
        if target=='lfo.pitch_depth':
            self.lfo_pitch=p
            return f'LFO pitch {p:.0%} (native vibrato)' if self.pitch_lfo_mode=='native' else f'LFO pitch ±{50*p:.0f}cent (events)'
        if target=='lfo.filter_depth':self.lfo_filter=p;return f'LFO filter {p:.0%}'
        raise ValueError(f'Onbekend target: {target}')

    def waveform_readback(self):
        """Vergelijk de *gevraagde* en de echt teruggelezen Generator-golfvorm."""
        return [{
            'voice':v.index+1,
            'osc1_requested':WAVEFORMS[self.wave_selection[1]][0],
            'osc1_actual':self.slot.get_module_ctl_value(v.o1,v.ctls['wave1'][0],0),
            'osc2_requested':WAVEFORMS[self.wave_selection[2]][0],
            'osc2_actual':self.slot.get_module_ctl_value(v.o2,v.ctls['wave2'][0],0),
            'sub_actual':self.slot.get_module_ctl_value(v.sub,v.ctls['subwave'][0],0),
        } for v in self.voices]

    def vibrato_volume_readback(self):
        if self.vib_lfo is None: return None
        return {tag:self.slot.get_module_ctl_value(mod,self.vib_ctl[tag+'_volume'][0],0)
                for tag,mod in (('lfo',self.vib_lfo),('mod',self.vib_mod))}

    def snapshot(self):
        # Alleen momentopname; SunVox kan enkele updates later verwerken.
        readback=[]
        for v in self.voices:
            def get(mod,ctl):
                return self.slot.get_module_ctl_value(mod,ctl[0],0)
            readback.append({
                'voice':v.index+1,'note':v.note,
                'cutoff_native':get(v.filt,v.ctls['cutoff']),
                'resonance_native':get(v.filt,v.ctls['resonance']),
                'wave1_native':get(v.o1,v.ctls['wave1']),
                'wave2_native':get(v.o2,v.ctls['wave2']),
                'duty1_native':get(v.o1,v.ctls['duty1']),
                'duty2_native':get(v.o2,v.ctls['duty2']),
                'amp_attack_ms':get(v.adsr,v.ctls['amp_attack']),
                'amp_release_ms':get(v.adsr,v.ctls['amp_release']),
                'filter_env_level':round(v.filter_env.value(time.monotonic()),4),
            })
        return {'version':'0.12.15','voices':VOICES,'sunvox_readback':readback,
                'active_notes':dict(self.active_notes),
                'waveforms':{str(k):WAVEFORMS[v][1] for k,v in self.wave_selection.items()},
                'tuning':self.osc_tuning,'source_enabled':dict(self.source_enabled),
                'osc_levels':{'osc1':self.osc1_level,'osc2':self.osc2_level},
                'sub_level':self.sub_level,'noise_level':self.noise_level,
                'amp_adsr':dict(self.amp),'filter_adsr':dict(self.fenv),
                'filter_cutoff':self.cutoff_hz,'filter_resonance':self.resonance_frac,
                'filter_env_amount':self.filter_env_amount,'keytrack':self.keytrack,
                'output_gain_db':self.output_gain_db,
                'mod_matrix':self.mod_matrix.dump(),
                'mod_env':dict(self.patch_mod_env_settings),'ramp_seconds':self.patch_ramp_seconds,
                'effective_lfo_rate':self._effective_lfo_rate,
                'delay_feedback':self.last_delay_feedback,
                'performance':{'velocity_sensitivity':self.velocity_sensitivity,
                               'portamento_seconds':self.portamento_seconds,
                               'aftertouch':self.channel_pressure,
                               'chorus_mix':self.chorus_mix,
                               'delay_mix':self.delay_mix,'reverb_mix':self.reverb_mix},
                'lfo':{'rate_hz':self.lfo_rate,'pitch_depth':self.lfo_pitch,'filter_depth':self.lfo_filter},
                'pwm':{'width':self.pwm.width,'rate_hz':self.pwm.rate,'depth':self.pwm.depth},
                'dc_blocker':self.dc_blocker_enabled,
                'pitch_target':self.pitch_target,
                'pitch_calibration_semitones':self.pitch_calibration_semitones,
                'wave_pitch_offsets':dict(self.wave_pitch_offsets),
                'waveform_checks':self.waveform_readback(),
                'native_vibrato_volume':self.vibrato_volume_readback(),
                'pitch_lfo_mode':self.pitch_lfo_mode,
                'native_vibrato':dict(self._last_vibrato_native) if self.pitch_lfo_mode=='native' else None,
                'swing':self.swing_ui_state()}
