"""Vaste MIDImix-indeling van SynthRig 0.9.3, zonder bankwissels.

Knoppen 1..8 in de MUTE-rij kiezen de oscillatorgolfvorm.
De eerste vier REC ARM knoppen schakelen de vier audio-bronnen aan/uit.
SOLO (note 27) is Panic. 2/5/... zijn MUTE-knoppen in solo-mode.
"""
from __future__ import annotations
import json
from pathlib import Path

DEFAULT_LAYOUT=Path(__file__).resolve().parents[1] / 'config' / 'midimix_091.json'
KNOB_CC=((16,20,24,28,46,50,54,58),
         (17,21,25,29,47,51,55,59),
         (18,22,26,30,48,52,56,60))
FADER_CC=(19,23,27,31,49,53,57,61,62)
VALID_CC={cc for row in KNOB_CC for cc in row} | set(FADER_CC)
SOURCES=('osc1','osc2','sub','noise')

class FixedControls:
    def __init__(self,path=DEFAULT_LAYOUT):
        data=json.loads(Path(path).read_text(encoding='utf8'))
        self.name=data['layout']
        self.mappings={int(k):v for k,v in data['controls'].items()}
        if not self.mappings.keys() <= VALID_CC:
            raise ValueError('Layout bevat onbestaande MIDImix CC')
        targets=[v['target'] for v in self.mappings.values()]
        if len(targets)!=len(set(targets)):
            raise ValueError('Eenzelfde doel is meerdere keren toegewezen')
        self.factory_wave_notes=tuple(map(int,data['wave_notes']))
        self.wave_notes={int(n):i for i,n in enumerate(self.factory_wave_notes)}
        self.wave_notes.update({int(n):i for i,n in enumerate(data.get('mute_notes_solo_layer',[]))})
        self.source_notes={int(n):s for n,s in zip(data['source_toggle_notes'],SOURCES)}
        self.reserved=set(map(int,data['reserved_rec_notes']))
        self.bank_notes=set(map(int,data['bank_notes']))
        self.panic_note=int(data['panic_note'])
        self.last_physical={}
        self.target_raw={}
        self.pickup=set()      # bij herstelde softwarewaarden / toekomstige presets
        self.pickup_band=3

    def labels(self):
        return {str(cc):s.get('label',s['target']) for cc,s in self.mappings.items()}

    def arm_pickup(self,targets=None):
        """Bij toekomstige preset-loads voorkomen dat de faders verspringen."""
        self.pickup={cc for cc,s in self.mappings.items()
                     if targets is None or s['target'] in targets}

    def resolve(self,cc,raw):
        cc=int(cc);raw=max(0,min(127,int(raw)))
        spec=self.mappings.get(cc)
        prev=self.last_physical.get(cc)
        self.last_physical[cc]=raw
        if spec is None:
            return None,'vrij'
        target=spec['target']
        if cc in self.pickup:
            expected=self.target_raw.get(target)
            if expected is not None and abs(raw-expected)>self.pickup_band and not (
                 prev is not None and min(prev,raw)<=expected<=max(prev,raw)):
                return None,f'pickup {spec["label"]}: beweeg naar {expected}/127'
            self.pickup.discard(cc)
        self.target_raw[target]=raw
        return target,spec['label']

    def on_note(self,note,rig):
        """Alleen aanroepen bij note_on met velocity > 0.

        Retourneert statusbericht of None; wisselt nooit van pagina.
        """
        note=int(note)
        if note in self.wave_notes:
            idx=self.wave_notes[note]
            osc=1 if idx<4 else 2
            wave=idx%4
            return rig.set_waveform_index(osc,wave)
        if note in self.source_notes:
            source=self.source_notes[note]
            return rig.set_source_enabled(source,not rig.source_enabled[source])
        if note==self.panic_note:
            rig.all_notes_off()
            return 'PANIC — alle noten uit'
        if note in self.bank_notes:
            return 'BANK-knoppen zijn gereserveerd voor presets (geen pagina’s)'
        if note in self.reserved:
            return 'Gereserveerde REC ARM-knop'
        return None

    def button_state(self,rig):
        """Persistente selectie voor de optionele MIDI-debugmonitor."""
        return {
            'wave1':rig.wave_selection[1],
            'wave2':rig.wave_selection[2],
            'enabled':dict(rig.source_enabled)
        }
