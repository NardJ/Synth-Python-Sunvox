"""0.12.11: previous real-DSP regression suite + new two destination A/B checks."""
from pathlib import Path
import json
from .offline0129 import run as previous_run
from .offline01211 import run as new_destinations

def run(output_dir='recordings',save_wav=True,wave_offsets=None,pitch_calibration=-12.,pitch_lfo_mode='native'):
    previous=previous_run(output_dir=output_dir,save_wav=save_wav,
                          wave_offsets=wave_offsets,pitch_calibration=pitch_calibration,
                          pitch_lfo_mode=pitch_lfo_mode)
    new=new_destinations(output_dir=output_dir,pitch_lfo_mode=pitch_lfo_mode)
    summary={name:previous['summary'].get(name,0)+new['summary'].get(name,0)
             for name in ('PASS','FAIL')}
    result={'version':'0.12.15','mode':pitch_lfo_mode,'summary':summary,
            'old_audio_checks':previous['summary'],'new_destinations':new['summary']}
    dest=Path(output_dir);dest.mkdir(parents=True,exist_ok=True)
    (dest/'summary_01215.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
    print(f'SynthRig 0.12.15 offline {pitch_lfo_mode}: {summary}',flush=True)
    return result
