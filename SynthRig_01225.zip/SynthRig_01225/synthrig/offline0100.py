"""SynthRig 0.10.0 native SunVox offline-audiotest (geen ALSA, PipeWire of MIDI).

SunVox draait in USER_AUDIO_CALLBACK | FLOAT32 | ONE_THREAD. Alle modulatie
van de SynthRig-engine wordt met een virtuele klok op 80 Hz aangestuurd.
De tests gebruiken de ECHTE vierstemmige engine, niet een losse testoscillator.
"""
from __future__ import annotations

import ctypes
import json
import math
from pathlib import Path
import time as realtime
from types import SimpleNamespace
import wave

RATE = 44100
CHANNELS = 2
CHUNK = 512
NOTE = 60
TARGET = 440.0 * 2 ** ((NOTE - 69) / 12)
WAVES = ("SIN", "TRI", "SAW", "PULSE")


def estimate_pitch(x, rate=RATE, low=105, high=1050):
    """Sterkste FFT-piek met parabolische interpolatie; géén doel-frequentie-bias.

    Daardoor wordt bijvoorbeeld een foutieve TRI van 523 Hz NIET voor 262 Hz
    aangezien. De grondtoon moet voor deze vier geselecteerde golfvormen
    de sterkste piek in het onderzoeksbereik zijn.
    """
    import numpy as np
    x = np.asarray(x, dtype=np.float64)
    if len(x) < 4096 or np.max(np.abs(x)) < .0001:
        return None
    x = x - np.mean(x)
    n = len(x)
    win = np.hanning(n)
    spec = np.abs(np.fft.rfft(x * win))
    freq = np.fft.rfftfreq(n, 1/rate)
    good = np.where((freq >= low) & (freq <= high))[0]
    p = int(good[np.argmax(spec[good])])
    # Verfijning in log spectrale magnitude; begrens tot één bin.
    if 1 <= p < len(spec)-1:
        a,b,c = np.log(np.maximum(spec[p-1:p+2],1e-12))
        den = a - 2*b + c
        delta = max(-1.,min(1.,.5*(a-c)/den)) if abs(den)>1e-10 else 0.
    else:
        delta = 0.
    return float((p+delta)*rate/n)


def rms(x):
    import numpy as np
    return float(np.sqrt(np.mean(np.asarray(x,dtype=np.float64)**2)))


def spectral_high_ratio(x, rate=RATE):
    """Energie > 1500 Hz / energie 100..1500 Hz (voor filterdiagnose)."""
    import numpy as np
    x=np.asarray(x,dtype=np.float64)
    s=np.abs(np.fft.rfft((x-np.mean(x))*np.hanning(len(x))))**2
    f=np.fft.rfftfreq(len(x),1/rate)
    return float(s[(f>=1500)&(f<10000)].sum()/max(1e-14,s[(f>=100)&(f<1500)].sum()))


class OfflineAudio:
    """Stuurt echte SunVox-samples uit en maakt tijd voor Python-LFO reproduceerbaar."""
    def __init__(self, rig, dll, rate=RATE):
        self.rig=rig
        self.dll=dll
        self.rate=rate
        self.clock=realtime.monotonic()
        self._time_module=None
        self._original_time=None

    def __enter__(self):
        # Een eigen time-proxy in alléén engine09, geen globale monkeypatch.
        from . import engine09
        self._time_module=engine09
        self._original_time=engine09.time
        engine09.time=SimpleNamespace(monotonic=lambda:self.clock,
                                      sleep=realtime.sleep)
        return self

    def __exit__(self, *_):
        self._time_module.time=self._original_time

    def render(self, seconds):
        import numpy as np
        remaining=round(seconds*self.rate)
        chunks=[]
        while remaining:
            n=min(CHUNK,remaining)
            self.rig.tick(now=self.clock)
            arr=(ctypes.c_float*(n*CHANNELS))()
            result=self.dll.audio_callback(arr,n,0,self.dll.get_ticks())
            if result < 0:
                raise RuntimeError(f'SunVox offline callback mislukt: {result}')
            chunks.append(np.ctypeslib.as_array(arr).copy().reshape(n,CHANNELS))
            self.clock+=n/self.rate
            remaining-=n
        return np.concatenate(chunks) if chunks else np.zeros((0,CHANNELS),dtype='float32')


class Report:
    def __init__(self):
        self.checks=[]
        self.audio=[]

    def check(self, name, ok, **measured):
        entry={'check':name,'status':'PASS' if ok else 'FAIL',**measured}
        self.checks.append(entry)
        print(f"  {entry['status']:4} {name}" + (
            f" | {measured.get('actual_hz',0):.2f} Hz" if 'actual_hz' in measured else ''),flush=True)
        return ok

    def summary(self):
        return {'PASS':sum(x['status']=='PASS' for x in self.checks),
                'FAIL':sum(x['status']=='FAIL' for x in self.checks)}


def apply_baseline(rig, osc=1, waveform=0):
    rig.all_notes_off()
    params={
        'master.level':100, 'osc1.level':100 if osc==1 else 0,
        'osc2.level':100 if osc==2 else 0, 'sub.level':0,'noise.level':0,
        'osc1.semitones':64,'osc2.semitones':64,
        'osc1.finetune':64,'osc2.finetune':64,
        'amp.attack':0,'amp.decay':0,'amp.sustain':127,'amp.release':0,
        'filter.cutoff':127,'filter.resonance':0,'filter.env_amount':0,
        'filter.keytrack':0,'lfo.pitch_depth':0,'lfo.filter_depth':0,
        'pwm.depth':0,
    }
    for key,val in params.items():rig.set_parameter(key,val)
    for source in ('osc1','osc2','sub','noise'):
        rig.set_source_enabled(source,source==f'osc{osc}')
    rig.pitch_bend=0
    rig.mod_wheel=0
    rig.set_waveform_index(osc,waveform)
    rig.tick(force=True)


def output_wav(path, audio):
    import numpy as np
    pcm=np.round(np.clip(audio,-1,1)*32767).astype('<i2')
    with wave.open(str(path),'wb') as wf:
        wf.setnchannels(CHANNELS)
        wf.setsampwidth(2)
        wf.setframerate(RATE)
        wf.writeframes(pcm.tobytes())


def perform(rig, dll, out_dir, save_wav=True):
    """Voert uitgebreide offline-reeks uit op de volledige native DSP-chain."""
    import numpy as np
    from .quality099 import mute_voice
    from .engine09 import midi_frequency
    report=Report()
    out_dir=Path(out_dir)
    out_dir.mkdir(parents=True,exist_ok=True)
    with OfflineAudio(rig,dll) as driver:
        # Init-events eerst door SunVox laten uitvoeren; readback daarna testen.
        driver.render(.20)
        print('GOLFTEST: 2 oscillatoren x 4 stemmen x 4 golfvormen',flush=True)
        for osc in (1,2):
            for voice_index in range(4):
                for wave_idx,wave_name in enumerate(WAVES):
                    apply_baseline(rig,osc,wave_idx)
                    driver.render(.045)
                    for j in range(voice_index):
                        rig.note_on(36+j,90)
                        mute_voice(rig,rig.voices[j])
                    rig.note_on(NOTE,100)
                    driver.render(.075)
                    audio=driver.render(.37)
                    report.audio.append(audio)
                    waveform_data=rig.waveform_readback()[voice_index]
                    readback=waveform_data[f'osc{osc}_actual']
                    expected=(5,0,1,2)[wave_idx]
                    name=f'osc{osc}_voice{voice_index+1}_{wave_name}'
                    report.check(name+'_readback',readback==expected,
                                 expected_wave=expected,actual_wave=readback)
                    mono=audio[round(.07*RATE):,0]
                    freq=estimate_pitch(mono)
                    cents=1200*math.log2(freq/TARGET) if freq and freq>0 else None
                    report.check(name+'_frequency',cents is not None and abs(cents)<20,
                                 expected_hz=round(TARGET,3),actual_hz=round(freq,3) if freq else None,
                                 cents=round(cents,2) if cents is not None else None,
                                 rms=round(rms(mono),6))
                    report.check(name+'_audio',rms(mono)>.004,
                                 rms=round(rms(mono),6))
                    rig.all_notes_off()
                    driver.render(.03)

        print('PITCH BEND: C4, +2, -2 en neutraal',flush=True)
        apply_baseline(rig,1,0)
        rig.note_on(NOTE,100)
        for semitones in (0,2,-2,0):
            rig.pitch_bend=semitones/rig.bend_range
            rig.tick(force=True)
            driver.render(.12)
            data=driver.render(.35)
            report.audio.append(data)
            freq=estimate_pitch(data[round(.06*RATE):,0])
            expected=TARGET*2**(semitones/12)
            cents=1200*math.log2(freq/expected) if freq else None
            report.check(f'pitchbend_{semitones:+d}',cents is not None and abs(cents)<20,
                         expected_hz=round(expected,3),actual_hz=round(freq,3) if freq else None,
                         cents=round(cents,2) if cents is not None else None)
        rig.all_notes_off()

        # Regressie 0.10.0: de oude 80 Hz SET_PITCH-aansturing gaf
        # afzonderlijke sample-sprongen van ~0.06 bij een zuivere sinus,
        # terwijl een constante sinus alleen ~0.004 verandert per sample.
        # Meet daarom de ECHTE overgangssamples, niet alleen de eindfrequentie.
        print('CONTINUOUS PITCH: 8 SIN/TRI sweeps (OSC1/2, bend/fine)',flush=True)
        for osc in (1, 2):
            for waveform in (0, 1):  # SIN/TRI laten kliks zichtbaar onderscheiden
                for mode in ('bend', 'finetune'):
                    apply_baseline(rig, osc, waveform)
                    driver.render(.20)
                    rig.note_on(NOTE, 100)
                    driver.render(.23)
                    baseline = driver.render(.20)[:, 0]
                    baseline_step = float(np.max(np.abs(np.diff(baseline))))
                    parts = []
                    # 80 wijzigingen over 0.8 sec, zowel negatief als positief,
                    # inclusief het nulpunt. Via de ECHTE MIDI-/CC-codepaden.
                    for k in range(81):
                        if mode == 'bend':
                            pitch = round(-8192 + k * (8191 + 8192) / 80)
                            rig.handle_swing(SimpleNamespace(type='pitchwheel',pitch=pitch))
                        else:
                            rig.set_parameter(f'osc{osc}.finetune',round(k*127/80))
                        parts.append(driver.render(.01))
                    sweep = np.concatenate(parts)
                    report.audio.append(sweep)
                    measured_step = float(np.max(np.abs(np.diff(sweep[:, 0]))))
                    threshold = max(.012, 3.0*baseline_step)
                    tag = f'continuous_osc{osc}_{WAVES[waveform]}_{mode}'
                    report.check(tag + '_no_clicks',measured_step < threshold,
                                 max_step=round(measured_step,6),
                                 steady_step=round(baseline_step,6),
                                 threshold=round(threshold,6))
                    # Op het eind moet de toonhoogte ook correct zijn, niet
                    # alleen de golfvorm mooi/zonder kliks.
                    driver.render(.13)
                    held = driver.render(.31)
                    expected = TARGET * 2**((2 if mode == 'bend' else 1)/12)
                    measured = estimate_pitch(held[:,0])
                    cents = 1200*math.log2(measured/expected) if measured else None
                    report.check(tag + '_final_pitch', cents is not None and abs(cents)<20,
                                 expected_hz=round(expected,3),
                                 actual_hz=round(measured,3) if measured else None)
                    if mode == 'bend':
                        rig.handle_swing(SimpleNamespace(type='pitchwheel',pitch=0))
                    else:
                        rig.set_parameter(f'osc{osc}.finetune',64)
                    driver.render(.13)
                    center = driver.render(.30)
                    returned = estimate_pitch(center[:,0])
                    cents0 = 1200*math.log2(returned/TARGET) if returned else None
                    report.check(tag + '_center_pitch',cents0 is not None and abs(cents0)<20,
                                 expected_hz=round(TARGET,3),
                                 actual_hz=round(returned,3) if returned else None)
                    rig.all_notes_off()
                    driver.render(.30)

        print('WAVE SWITCH: wissel tijdens aangehouden noot',flush=True)
        apply_baseline(rig,1,0)
        rig.note_on(NOTE,100)
        driver.render(.12)
        for idx,name in ((1,'TRI'),(2,'SAW'),(3,'PULSE'),(0,'SIN')):
            rig.set_waveform_index(1,idx)
            driver.render(.11)
            data=driver.render(.35)
            report.audio.append(data)
            freq=estimate_pitch(data[round(.06*RATE):,0])
            cents=1200*math.log2(freq/TARGET) if freq else None
            report.check('held_switch_'+name,cents is not None and abs(cents)<20,
                         expected_hz=round(TARGET,3),actual_hz=round(freq,3) if freq else None,
                         cents=round(cents,2) if cents is not None else None)
        rig.all_notes_off()

        print('POLYFONIE: vier onafhankelijke C3/E3/G3/B3-noten',flush=True)
        apply_baseline(rig,1,0)
        for note in (48,52,55,59):rig.note_on(note,100)
        driver.render(.20)
        poly=driver.render(.7)
        report.audio.append(poly)
        mono=poly[round(.1*RATE):,0]
        fft=np.abs(np.fft.rfft(mono*np.hanning(len(mono))))
        freq=np.fft.rfftfreq(len(mono),1/RATE)
        for note in (48,52,55,59):
            target=440*2**((note-69)/12)
            ix=np.where(np.abs(freq-target)<3.0)[0]
            signal=float(np.max(fft[ix])) if len(ix) else 0
            local=np.where((freq>target+7)&(freq<target+17))[0]
            floor=float(np.max(fft[local])) if len(local) else 1e-9
            report.check(f'poly_midi{note}',signal>max(2.5*floor,.1),
                         expected_hz=round(target,3),spectral_peak=round(signal,3),
                         local_background=round(floor,3))
        rig.all_notes_off()

        print('AMP ADSR: attack en release; FILTER: hoog/laag',flush=True)
        driver.render(.45)  # vorige polyfonie-ADSR volledig vrijgeven
        apply_baseline(rig,1,0)
        rig.set_parameter('amp.attack',90)
        rig.set_parameter('amp.release',95)
        driver.render(.15)  # eerst ADSR-parameters verwerken, daarna nieuwe NoteON
        rig.note_on(NOTE,100)
        attack=driver.render(1.0)
        report.audio.append(attack)
        early=rms(attack[round(.04*RATE):round(.14*RATE),0])
        late=rms(attack[round(.75*RATE):round(.95*RATE),0])
        report.check('adsr_attack',late>early*2.0 and late>.004,
                     rms_early=round(early,6),rms_late=round(late,6))
        rig.note_off(NOTE)
        release=driver.render(2.0)
        report.audio.append(release)
        beginning=rms(release[round(.05*RATE):round(.25*RATE),0])
        ending=rms(release[round(1.75*RATE):round(1.95*RATE),0])
        report.check('adsr_release',beginning>ending*4 and beginning>.003,
                     rms_begin=round(beginning,6),rms_end=round(ending,6))
        rig.all_notes_off()
        driver.render(.55)  # native ADSR en effectbuffers volledig laten uitdoven

        apply_baseline(rig,1,2)  # SAW met veel harmonischen
        rig.note_on(NOTE,100)
        driver.render(.20)
        high=driver.render(.40)
        report.audio.append(high)
        rig.set_parameter('filter.cutoff',0)  # 80 Hz, ruim beneden C4
        driver.render(1.8)  # native filter-afvlakking uit laten werken; eerder te snel gemeten
        low=driver.render(.40)
        report.audio.append(low)
        h=spectral_high_ratio(high[:,0]); l=spectral_high_ratio(low[:,0])
        report.check('filter_cutoff_brightness',h>l*2.0,
                     high_cut_ratio=round(h,5),low_cut_ratio=round(l,5),
                     settling_seconds=1.8)
        rig.all_notes_off()
        # Regressie 0.10.0: bij modulatie via Swing-CC1 veranderde de
        # native Vibrato amplitude in slechts 17 stappen (0..16). Dat gaf
        # 0.022+ sample-discontinuiteit bij geleidelijke SIN CC1-sweeps.
        # Test nu fysieke trackpadbewegingen: stijgend, sprong en snelle
        # afwisseling; OSC1/OSC2 en SIN/TRI via het echte DSP-signaal.
        print('CONTINUOUS MODULATION: 2 OSC x 2 waves x 3 CC1 bewegingen',flush=True)
        for osc in (1,2):
            for waveform in (0,1):
                for motion in ('ramp','step','oscillate'):
                    apply_baseline(rig,osc,waveform)
                    rig.handle_swing(SimpleNamespace(type='control_change',control=1,value=0))
                    driver.render(.24)
                    rig.note_on(NOTE,110)
                    driver.render(.60)
                    steady=driver.render(.20)[:,0]
                    baseline_step=float(np.max(np.abs(np.diff(steady))))
                    segments=[]
                    for k in range(120):
                        val=(round(k*127/119) if motion=='ramp' else
                             127 if motion=='step' else (127 if k%2 else 0))
                        rig.handle_swing(SimpleNamespace(
                            type='control_change',control=1,value=val))
                        segments.append(driver.render(.01))
                    sweep=np.concatenate(segments)
                    report.audio.append(sweep)
                    max_step=float(np.max(np.abs(np.diff(sweep[:,0]))))
                    # Limits zijn bewust strenger dan de gemeten 0.9.12:
                    # 5.3x bij een SIN-ramp en 14x bij snel heen-en-weer.
                    ratio=max_step/max(baseline_step,1e-9)
                    limit={'ramp':2.5,'step':4.0,'oscillate':6.5}[motion]
                    report.check(f'mod_osc{osc}_{WAVES[waveform]}_{motion}_no_clicks',
                                 ratio<limit, max_step=round(max_step,6),
                                 steady_step=round(baseline_step,6),
                                 jump_ratio=round(ratio,3),max_ratio=limit)
                    rig.all_notes_off()
                    rig.handle_swing(SimpleNamespace(type='control_change',control=1,value=0))
                    driver.render(.45)

        # Controleer dat het verbeteren van de amplitude-resolutie de
        # muzikale vibratodiepte niet heeft weggenomen of verdubbeld.
        # Het signaal wordt geanalyseerd via Hilbert/FFT, zonder scipy.
        print('MOD DEPTH: 0 / 64 / 127 (5 Hz)',flush=True)
        def vibrato_depth_cents(pcm):
            x=np.asarray(pcm,dtype=np.float64)
            n=len(x)
            spectrum=np.fft.fft(x)
            h=np.zeros(n)
            h[0]=1.
            if n%2==0:
                h[1:n//2]=2.;h[n//2]=1.
            else:
                h[1:(n+1)//2]=2.
            phase=np.unwrap(np.angle(np.fft.ifft(spectrum*h)))
            t=np.arange(0,n,20)/RATE
            theta=phase[::20]
            model=np.column_stack((np.ones(len(t)),t,
                                    np.sin(2*np.pi*5*t),np.cos(2*np.pi*5*t)))
            coef=np.linalg.lstsq(model,theta,rcond=None)[0]
            df=5*float(np.hypot(coef[2],coef[3]))
            return 1200*math.log2(1+df/TARGET)
        apply_baseline(rig,1,0)
        rig.note_on(NOTE,110)
        driver.render(.5)
        depth_ranges=(((0,0,4),(64,25,47),(127,51,80))
                      if rig.pitch_lfo_mode=='native' else
                      ((0,0,4),(64,14,27),(127,32,47)))
        for cc,low,high in depth_ranges:
            rig.handle_swing(SimpleNamespace(type='control_change',control=1,value=cc))
            driver.render(.60)
            data=driver.render(.8)
            report.audio.append(data)
            depth=vibrato_depth_cents(data[:,0])
            report.check(f'mod_cc{cc}_depth',low<=depth<=high,
                         cents_peak=round(depth,2),min_cents=low,max_cents=high)
        rig.all_notes_off()
        rig.handle_swing(SimpleNamespace(type='control_change',control=1,value=0))
        print('0.10.0 PERFORMANCE: echte velocity, aftertouch, stereo chorus, glide',flush=True)
        # Velocity: fixed Generator/ADSR note velocity; per-voice output gain is
        # solely responsible for the chosen dynamic range.
        apply_baseline(rig,1,0)
        rig.set_parameter('performance.velocity',127)
        driver.render(.25)
        velocities={}
        for velocity in (24,64,120):
            rig.note_on(NOTE,velocity)
            driver.render(.28)
            audio=driver.render(.28)
            report.audio.append(audio)
            velocities[velocity]=rms(audio[:,0])
            rig.note_off(NOTE)
            driver.render(.43)
        report.check('velocity_dynamics',velocities[120]>velocities[64]*1.8 and
                     velocities[64]>velocities[24]*2.0,
                     low=round(velocities[24],6),mid=round(velocities[64],6),
                     high=round(velocities[120],6))
        rig.set_parameter('performance.velocity',0)
        same=[]
        for velocity in (24,120):
            rig.note_on(NOTE,velocity)
            driver.render(.28)
            audio=driver.render(.28)
            same.append(rms(audio[:,0]))
            rig.note_off(NOTE)
            driver.render(.43)
        report.check('velocity_sensitivity_zero_equal_volume',
                     abs(same[0]-same[1])/max(same)<.02,
                     quiet=round(same[0],6),loud=round(same[1],6))
        rig.all_notes_off(); driver.render(.4)

        # Aftertouch is polyphonic when supported by the keyboard; channel
        # pressure opens all active voices. Verify native filter movement AND
        # acoustic brightness on a harmonic-rich waveform.
        apply_baseline(rig,1,2)
        rig.set_parameter('filter.cutoff',52)
        rig.note_on(NOTE,120)
        driver.render(1.5)
        before=driver.render(.4)
        low_cut=rig.voices[rig.active_notes[NOTE]].last_cutoff
        rig.handle_swing(SimpleNamespace(type='aftertouch',value=127))
        driver.render(1.5)
        after=driver.render(.4)
        high_cut=rig.voices[rig.active_notes[NOTE]].last_cutoff
        before_h=spectral_high_ratio(before[:,0]);after_h=spectral_high_ratio(after[:,0])
        report.audio.append(before);report.audio.append(after)
        report.check('channel_aftertouch_opens_filter',high_cut>low_cut*2.0 and
                     after_h>before_h*2.5,
                     cutoff_before=low_cut,cutoff_after=high_cut,
                     harmonics_before=round(before_h,6),harmonics_after=round(after_h,6))
        rig.all_notes_off(); rig.handle_swing(SimpleNamespace(type='aftertouch',value=0))
        driver.render(.43)
        apply_baseline(rig,1,2)
        rig.set_parameter('filter.cutoff',52)
        for note in (60,64):rig.note_on(note,120)
        driver.render(.35)
        v60=rig.voices[rig.active_notes[60]]
        v64=rig.voices[rig.active_notes[64]]
        rig.handle_swing(SimpleNamespace(type='polytouch',note=60,value=127))
        driver.render(.35)
        report.check('poly_aftertouch_isolated_by_note',
                     v60.last_cutoff>v64.last_cutoff*2 and v64.pressure==0,
                     note60_cutoff=v60.last_cutoff,note64_cutoff=v64.last_cutoff)
        rig.all_notes_off(); driver.render(.45)

        # Dry connection remains unchanged; wet chorus is physically stereo.
        apply_baseline(rig,1,0)
        rig.set_parameter('effects.chorus',0)
        rig.note_on(NOTE,120)
        driver.render(.6)
        dry=driver.render(.50)
        rig.set_parameter('effects.chorus',127)
        driver.render(.6)
        wet=driver.render(.5)
        report.audio.append(dry);report.audio.append(wet)
        stereo_diff=rms(wet[:,0]-wet[:,1]);dry_diff=rms(dry[:,0]-dry[:,1])
        report.check('chorus_stereo_wet_effect',stereo_diff>.005 and dry_diff<.001,
                     dry_rms=round(rms(dry[:,0]),6),wet_rms=round(rms(wet[:,0]),6),
                     stereo_difference=round(stereo_diff,6))
        # Fast movements should be smoothed, not immediate 127-step gain jumps.
        steps=[]
        for cc in (0,127,0,127,0):
            rig.set_parameter('effects.chorus',cc)
            steps.append(driver.render(.19))
        motion=np.concatenate(steps)
        report.audio.append(motion)
        report.check('chorus_sweep_no_large_clicks',
                     float(np.max(np.abs(np.diff(motion[:,0]))))<.035,
                     max_sample_step=round(float(np.max(np.abs(np.diff(motion[:,0])))),6))
        rig.all_notes_off();rig.set_parameter('effects.chorus',0)
        driver.render(.5)

        # Portamento glides from the previous MIDI note to the new note, and
        # must not use repeated phase-resetting SET_PITCH commands.
        apply_baseline(rig,1,0)
        rig.set_parameter('performance.portamento',100)
        rig.note_on(60,120)
        driver.render(.3)
        rig.note_off(60)
        driver.render(.5)
        rig.note_on(72,120)
        glide=driver.render(.95)
        report.audio.append(glide)
        pitches=[estimate_pitch(glide[int(t*RATE):int((t+.16)*RATE),0],low=200,high=700)
                 for t in (.07,.22,.4,.7)]
        report.check('portamento_glides_to_target',
                     all(p is not None for p in pitches) and
                     290<pitches[0]<380 and pitches[0]<pitches[1]<pitches[2] and
                     abs(pitches[3]-midi_frequency(72))<8,
                     measured_hz=[round(p,2) if p else None for p in pitches],
                     glide_seconds=round(rig.portamento_seconds,3))
        click_step=float(np.max(np.abs(np.diff(glide[int(.08*RATE):int(.90*RATE),0]))))
        report.check('portamento_no_large_sample_jumps',click_step<.018,
                     max_sample_step=round(click_step,6))
        rig.all_notes_off();rig.set_parameter('performance.portamento',0)
        driver.render(.4)

        combined=np.concatenate(report.audio) if report.audio else np.zeros((0,CHANNELS),dtype=np.float32)
        peak=float(np.max(np.abs(combined))) if len(combined) else 0
        report.check('output_nonzero',rms(combined)>.001,rms=rms(combined))
        report.check('no_clipping',peak<.999,max_abs=round(peak,6))
        report.check('stereo_channels',CHANNELS==combined.shape[1],channels=combined.shape[1])

    summary=report.summary()
    version={'version':'0.10.0','sunvox_mode':'offline native float32 one-thread',
             'sample_rate':RATE, 'duration_seconds':round(len(combined)/RATE,2),
             'wave_offsets':rig.wave_pitch_offsets,
             'summary':summary,'checks':report.checks}
    (out_dir/'report.json').write_text(json.dumps(version,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    rows=[f'SynthRig 0.10.0 — native offline DSP\n',
          f'PASS: {summary["PASS"]}   FAIL: {summary["FAIL"]}',
          f'Audio: {version["duration_seconds"]} s / {RATE} Hz / stereo',
          '']
    rows.extend(f'{entry["status"]:4} {entry["check"]}: '+
                ', '.join(f'{k}={v}' for k,v in entry.items() if k not in ('check','status'))
                for entry in report.checks)
    (out_dir/'report.txt').write_text('\n'.join(rows)+'\n',encoding='utf-8')
    if save_wav:output_wav(out_dir/'offline_tests.wav',combined)
    print(f'\nOFFLINE SAMENVATTING: {summary["PASS"]} PASS, {summary["FAIL"]} FAIL; {out_dir}',flush=True)
    return version


def run(output_dir='recordings', save_wav=True, wave_offsets=None, pitch_calibration=-12.,
        pitch_lfo_mode='native'):
    from sunvox.api import Slot,init,deinit
    from sunvox.types import INIT_FLAG
    from .engine09 import SynthRig
    flags=int(INIT_FLAG.OFFLINE | INIT_FLAG.AUDIO_FLOAT32 |
              INIT_FLAG.ONE_THREAD | INIT_FLAG.NO_DEBUG_OUTPUT)
    version=init(None,RATE,CHANNELS,flags)
    if version<0:raise RuntimeError(f'SunVox offline init mislukt: {version}')
    try:
        with Slot() as slot:
            rig=SynthRig(slot,pitch_lfo_mode=pitch_lfo_mode,
                         wave_pitch_offsets=wave_offsets,
                         pitch_calibration_semitones=pitch_calibration,offline=True)
            if slot.play()<0:raise RuntimeError('SunVox slot kon niet starten')
            stamp=realtime.strftime('%Y%m%d_%H%M%S')
            return perform(rig,__import__('sunvox.dll',fromlist=['audio_callback']),
                           Path(output_dir)/f'offline_0100_{stamp}',save_wav=save_wav)
    finally:
        deinit()
