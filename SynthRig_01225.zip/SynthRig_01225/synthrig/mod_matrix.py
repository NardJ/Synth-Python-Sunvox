"""SynthRig 0.12.6 fixed-overlay two-layer APC matrix.

Each of the 64 pads has exactly FIVE states: OFF, AC, AD, BC, BD.
A/B select row source layer 1/2; C/D select column destination layer 1/2.
For backward compatibility with 0.12.5, a stored 0..127 integer is AC
with that depth. Other variants are encoded as 128*variant + depth. All
choices remain an 8x8 list of nullable integers in existing preset JSON.
The human-facing route names and colors are entirely independent of that
storage encoding.
"""
from __future__ import annotations

SOURCES = ('LFO','FILTER ENV','VELOCITY','AFTERTOUCH','MOD WHEEL','KEYTRACK','GATE','BIAS')
SOURCES_B = ('LFO 2','AMP ENV','MOD ENV','LFO 3','SMOOTH RANDOM',
             'NOTE RAMP','TRIGGER','SAMPLE & HOLD')
DESTINATIONS = ('OSC1 PITCH','OSC2 PITCH','OSC1 PWM','OSC2 PWM',
                'CUTOFF','RESONANCE','OSC1 LEVEL','OSC2 LEVEL')
DESTINATIONS_D = ('SUB LEVEL','NOISE LEVEL','ENV AMOUNT','LFO RATE',
                  'DELAY MIX','REVERB MIX','CHORUS MIX','DELAY FEEDBACK')
# Version 2 reuses six historically occupied coordinates with NEW meanings.
# An old preset without a layout marker is migrated by archiving, NOT by
# silently reinterpreting, affected routes. Old source data remains intact.
MATRIX_LAYOUT = 'v2'
LEGACY_SOURCES_B=('LFO 2','AMP ENV','VEL INVERSE','TOUCH INVERSE','MOD INVERSE',
                  'KEY INVERSE','TRIGGER','SAMPLE & HOLD')
LEGACY_DESTINATIONS_D=('SUB LEVEL','NOISE LEVEL','ENV AMOUNT','KEYTRACK AMOUNT',
                       'DELAY MIX','REVERB MIX','CHORUS MIX','OUTPUT LEVEL')
VARIANTS=('AC','AD','BC','BD')


def migrate_state_matrix(state):
    """Return (new state, archived routes), preserving unsupported old routes.

    Never silently reinterpret old modulation destinations as new ones.
    The old encoded coordinates and their semantic names are archived in
    mod_legacy_routes. The original JSON file is never overwritten here.
    """
    from copy import deepcopy
    migrated=deepcopy(state)
    if migrated.get('mod_matrix_layout') == MATRIX_LAYOUT:
        return migrated, []
    grid=validate_matrix(migrated.get('mod_matrix',blank_matrix()))
    archived=[]
    for row in range(8):
        for col in range(8):
            current=decode(grid[row][col])
            if current is None: continue
            variant, depth=current
            old_source=row+(8 if variant>=2 else 0)
            old_target=col+(8 if variant%2 else 0)
            if old_source in (10,11,12,13) or old_target in (11,15):
                src=(SOURCES if old_source<8 else LEGACY_SOURCES_B)[row]
                dst=(DESTINATIONS if old_target<8 else LEGACY_DESTINATIONS_D)[col]
                archived.append({'row':row+1,'col':col+1,'variant':VARIANTS[variant],
                                 'depth':depth,'source':src,'destination':dst})
                grid[row][col]=None
    migrated['mod_matrix']=grid
    migrated['mod_matrix_layout']=MATRIX_LAYOUT
    migrated['mod_legacy_routes']=list(migrated.get('mod_legacy_routes',[]))+archived
    old_groups=migrated.get('mod_groups')
    groups=validate_groups(old_groups) if old_groups is not None else legacy_groups(grid)
    for col in range(8):
        groups['rows'][col]=[r for r in groups['rows'][col] if grid[r][col] is not None]
    migrated['mod_groups']=groups
    return migrated, archived

DEFAULT_DEPTH=86


def decode(value):
    if value is None:return None
    if type(value) is not int or not 0<=value<=511:
        raise ValueError('Padroute moet None of een integer 0..511 zijn')
    return (value//128,value%128)


def encode(variant,depth=DEFAULT_DEPTH):
    if type(variant) is not int or not 0<=variant<4 or type(depth) is not int or not 0<=depth<=127:
        raise ValueError('Ongeldige matrixroute/diepte')
    return 128*variant+depth


def validate_matrix(data):
    if not isinstance(data,list) or len(data)!=8 or any(not isinstance(row,list) or len(row)!=8 for row in data):
        raise ValueError('Modulatiematrix moet 8x8 zijn')
    for row in data:
        for cell in row:decode(cell)
    return [list(row) for row in data]


def blank_matrix():return [[None]*8 for _ in range(8)]


def legacy_groups(matrix):
    """Auto-assign formerly connected 0.12.5 routes to their fader columns."""
    groups=validate_groups(None)
    for row in range(8):
        for col in range(8):
            if matrix[row][col] is not None:groups['rows'][col].append(row)
    return groups


def signed_depth(raw):
    return max(-1.,min(1.,(raw-64)/(64 if raw<64 else 63)))


def validate_groups(data):
    if data is None:
        return {'rows':[[] for _ in range(8)],'gains':[1.]*8}
    if not isinstance(data,dict) or set(data)!={'rows','gains'}:
        raise ValueError('Ongeldig APC fader-groeperingsformaat')
    rows=data['rows'];gains=data['gains']
    if not isinstance(rows,list) or len(rows)!=8 or not isinstance(gains,list) or len(gains)!=8:
        raise ValueError('Fadertoewijzing moet acht kolommen hebben')
    for assigned in rows:
        if (not isinstance(assigned,list) or len(assigned)>8 or
            any(type(n) is not int or not 0<=n<8 for n in assigned) or len(assigned)!=len(set(assigned))):
            raise ValueError('Faderrijen moeten unieke indexen 0..7 bevatten')
    if any(type(v) not in (int,float) or not 0<=v<=2 for v in gains):
        raise ValueError('Faderfactor moet 0..2 zijn')
    return {'rows':[list(a) for a in rows], 'gains':[float(g) for g in gains]}


class ModMatrix:
    def __init__(self):
        self.grid=blank_matrix()
        self.groups=validate_groups(None)
        self.revision=0
        self.load_epoch=0

    def load(self,data):
        self.grid=validate_matrix(data)
        self.revision+=1;self.load_epoch+=1

    def load_groups(self,data):
        groups=legacy_groups(self.grid) if data is None else validate_groups(data)
        # Legacy 0.12.5 presets have no assigned rows. New routes stay silent to faders
        # until a pad is selected; existing depths remain fully audible.
        self.groups=groups
        self.revision+=1;self.load_epoch+=1

    def dump(self):return [list(row) for row in self.grid]
    def dump_groups(self):return {'rows':[list(a) for a in self.groups['rows']],
                                  'gains':list(self.groups['gains'])}

    def route(self,row,col):return decode(self.grid[row][col])

    def cycle(self,row,col):
        """OFF→AC→AD→BC→BD→OFF, exactly one route per physical pad."""
        old=self.route(row,col)
        variant=0 if old is None else old[0]+1
        value=None if variant==4 else encode(variant, old[1] if old else DEFAULT_DEPTH)
        self.grid[row][col]=value
        if value is not None and row not in self.groups['rows'][col]:
            self.groups['rows'][col].append(row)
        elif value is None and row in self.groups['rows'][col]:
            self.groups['rows'][col].remove(row)
        self.revision+=1
        return value

    def toggle(self,row,col):
        """Legacy toggle API: AC on/off (used by existing offline tests)."""
        value=self.grid[row][col]
        self.grid[row][col]=encode(0,DEFAULT_DEPTH) if value is None else None
        if value is None and row not in self.groups['rows'][col]:
            self.groups['rows'][col].append(row)
        elif value is not None and row in self.groups['rows'][col]:
            self.groups['rows'][col].remove(row)
        self.revision+=1
        return self.grid[row][col]

    def clear(self,row,col):
        if self.grid[row][col] is None:return False
        self.grid[row][col]=None
        if row in self.groups['rows'][col]:self.groups['rows'][col].remove(row)
        self.revision+=1;return True

    def set_depth(self,row,col,raw):
        current=self.route(row,col)
        if current is None:return False
        value=encode(current[0],raw)
        if value==self.grid[row][col]:return False
        self.grid[row][col]=value;self.revision+=1;return True

    def toggle_assignment(self,col,row):
        selected=self.groups['rows'][col]
        if row in selected:selected.remove(row)
        else:selected.append(row)
        self.revision+=1
        return row in selected

    def adjust_gain(self,col,delta):
        old=self.groups['gains'][col]
        gain=round(max(0.,min(2.,old+delta)),5)
        if gain==old:return False
        self.groups['gains'][col]=gain;self.revision+=1;return True

    def has_routes(self):return any(v is not None for row in self.grid for v in row)

    def offsets(self,source_values):
        """Return 16 destination offsets; A/C legacy behavior preserved.

        Fader group gain affects assigned row/column routes, retaining the
        individual signed-depth ratios for all selected connections.
        """
        if len(source_values)==8:source_values=list(source_values)+[0.]*8  # oude offline-tests
        if len(source_values)!=16:raise ValueError('16 bronwaarden vereist')
        result=[0.]*16
        for row in range(8):
            for col,encoded in enumerate(self.grid[row]):
                decoded=decode(encoded)
                if decoded is None:continue
                variant,depth=decoded
                src_idx=row+(8 if variant>=2 else 0)
                dst_idx=col+(8 if variant%2 else 0)
                factor=self.groups['gains'][col] if row in self.groups['rows'][col] else 1.
                result[dst_idx]+=float(source_values[src_idx])*signed_depth(depth)*factor
        return [max(-1.,min(1.,v)) for v in result]
