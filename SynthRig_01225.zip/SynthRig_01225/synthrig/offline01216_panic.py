"""Echte offline SunVox-controle van presetstaarten en hard PANIC."""
from pathlib import Path
import json
import numpy as np
from .offline0102 import OfflineAudio,RATE,rms,apply_baseline


def run(output_dir='recordings',pitch_lfo_mode='native'):
    import sunvox.dll as dll
    from sunvox.api import Slot,init,deinit
    from sunvox.types import INIT_FLAG
    from .engine09 import SynthRig
    out=Path(output_dir);out.mkdir(parents=True,exist_ok=True)
    flags=int(INIT_FLAG.OFFLINE|INIT_FLAG.AUDIO_FLOAT32|INIT_FLAG.ONE_THREAD|INIT_FLAG.NO_DEBUG_OUTPUT)
    if init(None,RATE,2,flags)<0:raise RuntimeError('SunVox init failed')
    tests=[];segments=[]
    def record(name,passed,**info):
        tests.append({'check':name,'status':'PASS' if passed else 'FAIL',**info})
        print(tests[-1],flush=True)
    try:
        with Slot() as slot:
            rig=SynthRig(slot,pitch_lfo_mode=pitch_lfo_mode,offline=True)
            apply_baseline(rig,waveform=2)
            assert slot.play()>=0
            with OfflineAudio(rig,dll) as audio:
                rig.set_parameter('amp.attack',0)
                rig.set_parameter('amp.release',0)
                rig.set_parameter('effects.delay',127)
                rig.set_parameter('effects.reverb',110)
                audio.render(.65)
                rig.note_on(60,105)
                audio.render(.20)
                rig.note_off(60)
                before=audio.render(.15)
                # Normal BANK behavior: stop held notes only; DO NOT CLEAN DSP.
                rig.all_notes_off()
                normal_tail=audio.render(.28)
                record('preset_change_preserves_effect_tail',rms(normal_tail)>.00009,
                       before=rms(before),after=rms(normal_tail))
                segments.append(normal_tail)
                rig.panic()
                clean=audio.render(.14)
                record('panic_clears_delay_reverb_pcm',rms(clean)<.00007 and np.max(np.abs(clean))<.003,
                       after_rms=rms(clean),after_peak=float(np.max(np.abs(clean))))
                segments.append(clean)
                record('panic_clears_active_notes',not rig.active_notes and all(v.note is None for v in rig.voices))
                record('panic_preserves_fx_settings',rig.delay_mix>.95 and rig.reverb_mix>.8,
                       delay=rig.delay_mix,reverb=rig.reverb_mix)
                rig.note_on(64,90)
                resumed=audio.render(.19)
                record('note_after_panic_is_audible',rms(resumed)>.0002,level=rms(resumed))
                rig.note_off(64)
                segments.append(resumed)
                rig.panic()
                again=audio.render(.14)
                record('second_panic_clears_new_tail',rms(again)<.00007,
                       level=rms(again))
    finally:
        deinit()
    result={'version':'0.12.16','mode':pitch_lfo_mode,'summary':{'PASS':sum(t['status']=='PASS' for t in tests),'FAIL':sum(t['status']=='FAIL' for t in tests)},'checks':tests}
    (out/f'panic_{pitch_lfo_mode}.json').write_text(json.dumps(result,indent=2)+'\n')
    from .offline0102 import output_wav
    if segments:output_wav(out/f'panic_{pitch_lfo_mode}.wav',np.concatenate(segments))
    return result
