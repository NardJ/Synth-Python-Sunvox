"""Hardware-only LED diagnostic; does not launch SunVox or need a Swing."""
from __future__ import annotations
import time
from .fixed_controls import FixedControls
from .midimix_hw import MidiMixLEDs


def run_led_test(output, controls=None, pause=time.sleep, report=print):
    controls=controls or FixedControls()
    leds=MidiMixLEDs(output,controls)
    blank={'wave1':None,'wave2':None,'enabled':{}}
    try:
        for number in (1,8,16):
            report(f'MIDImix LED-proef: preset {number:02d} — {number} LEDs moeten branden')
            leds.show_preset(number,duration=1.)
            pause(1.05)
            leds.tick(blank)
            pause(.15)
        report('MIDImix LED-proef voltooid; alle gecontroleerde LEDs uit.')
    finally:
        leds.clear()


def run_hardware_test():
    import mido
    from .engine import find_midi_port
    names=mido.get_output_names()
    port=find_midi_port(names,'midi mix','midimix')
    if not port:
        raise RuntimeError('MIDImix MIDI-uitgang ontbreekt. Beschikbare uitgangen: '+str(names))
    print('MIDImix MIDI-uitgang:',port)
    print('SynthRig moet voor deze hardwaretest afgesloten zijn.')
    with mido.open_output(port) as output:
        run_led_test(output)
