"""Leesbare PWM-telemetrie, zonder oscillator of klok aan te passen."""
import math


def pwm_snapshot(rig):
    """Observatie zonder rig.pwm.advance() aan te roepen."""
    pwm = rig.pwm
    delta = pwm.depth * math.sin(2 * math.pi * pwm.phase)
    actual_width = {
        str(n): round(max(.1, min(.9, pwm.width[n] + delta)), 5)
        for n in (1, 2)
    }
    return {
        'phase': round(pwm.phase, 5),
        'rate_hz': round(pwm.rate, 4),
        'depth': round(pwm.depth, 5),
        'base_width': {str(n): round(pwm.width[n], 5) for n in (1, 2)},
        'effective_width': actual_width,
        'waveform': {str(n): rig.wave_selection[n] for n in (1, 2)},
    }
