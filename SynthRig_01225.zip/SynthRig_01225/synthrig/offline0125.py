"""Additional true 8x8 modulation tests using *real* offline SunVox PCM."""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from .offline0120 import run as previous_run
from .offline0102 import OfflineAudio,RATE,rms,apply_baseline,estimate_pitch,spectral_high_ratio
from .mod_matrix import blank_matrix


def patch_audio_checks(directory, mode):
    import sunvox.dll as dll
    from sunvox.api import Slot,init,deinit
    from sunvox.types import INIT_FLAG
    flags=int(INIT_FLAG.OFFLINE|INIT_FLAG.AUDIO_FLOAT32|INIT_FLAG.ONE_THREAD|INIT_FLAG.NO_DEBUG_OUTPUT)
    if init(None,RATE,2,flags)<0:raise RuntimeError('SunVox initialisatie mislukt')
    rows=[]
    def check(name,ok,**values):
        row={'check':name,'status':'PASS' if ok else 'FAIL',**values}
        print(row['status'],name,values,flush=True)
        rows.append(row)
    try:
        from .engine09 import SynthRig
        with Slot() as slot:
            rig=SynthRig(slot,pitch_lfo_mode=mode,offline=True)
            apply_baseline(rig)
            assert slot.play()>=0
            with OfflineAudio(rig,dll) as audio:
                audio.render(.25)
                rig.note_on(60,108)
                base=rms(audio.render(.25))
                matrix=blank_matrix();matrix[7][6]=127 # BIAS -> OSC1 amplitude
                rig.load_mod_matrix(matrix)
                boosted=rms(audio.render(.35))
                check('bias_to_osc1_volume_changes_real_pcm',boosted>base*1.18,
                      base_rms=round(base,6),modulated_rms=round(boosted,6))
                rig.load_mod_matrix(blank_matrix())
                restored=rms(audio.render(.35))
                check('removing_route_restores_original_volume',abs(restored-base)<base*.12,
                      base_rms=round(base,6),restored_rms=round(restored,6))
                rig.note_off(60);audio.render(.22)

                # Live filter modulation changes actual spectra, not only config fields.
                apply_baseline(rig,waveform=2);rig.set_parameter('filter.cutoff',70)
                rig.note_on(60,109);audio.render(.25)
                baseline=spectral_high_ratio(audio.render(.4)[:,0])
                matrix=blank_matrix();matrix[7][4]=127 # BIAS -> cutoff
                rig.load_mod_matrix(matrix);audio.render(.4)
                cutoff=spectral_high_ratio(audio.render(.4)[:,0])
                check('bias_to_filter_cutoff_changes_spectrum',baseline>0.001 and abs(cutoff-baseline)>baseline*.12,
                      baseline_ratio=round(baseline,7),high_ratio=round(cutoff,7))
                rig.note_off(60);audio.render(.25)

                # Phase-safe pitch modulation while holding note, approximately +25 cent.
                apply_baseline(rig);rig.set_waveform_index(1,0)
                rig.note_on(60,110)
                before=estimate_pitch(audio.render(.6)[:,0],low=240,high=290)
                matrix=blank_matrix();matrix[7][0]=127 # BIAS -> OSC1 pitch
                rig.load_mod_matrix(matrix)
                audio.render(.3)
                after=estimate_pitch(audio.render(.6)[:,0],low=240,high=290)
                cents=1200*np.log2(after/before) if before and after else 0
                check('bias_to_osc1_pitch_phase_safe_bend',before is not None and after is not None and 10<cents<40,
                      before_hz=round(before or 0,4),after_hz=round(after or 0,4),cents=round(float(cents),2))
                rig.note_off(60);audio.render(.25)
                rig.load_mod_matrix(blank_matrix())
                check('clearing_matrix_removes_all_routes',not rig.mod_matrix.has_routes())
                # Live LFO->pitch: continuous sine audio, no sample discontinuities.
                apply_baseline(rig,waveform=0)
                rig.set_parameter('lfo.rate',65)
                rig.note_on(60,105);audio.render(.25)
                steady=audio.render(.25)[:,0]
                matrix=blank_matrix();matrix[0][0]=103 # LFO -> OSC1 pitch
                rig.load_mod_matrix(matrix);audio.render(.25)
                moving=audio.render(.8)[:,0]
                stable_jump=float(np.max(np.abs(np.diff(steady))))
                moving_jump=float(np.max(np.abs(np.diff(moving))))
                check('lfo_to_pitch_no_large_sample_discontinuity',moving_jump < max(.012,stable_jump*3.0),
                      stable_max_sample_jump=round(stable_jump,7),moving_max_sample_jump=round(moving_jump,7))
                rig.note_off(60);audio.render(.22)
                rig.load_mod_matrix(blank_matrix())

                # OSC1 PWM is controlled on a PULSE wave, independently of CC52.
                apply_baseline(rig,waveform=3)
                rig.note_on(60,100);audio.render(.18)
                original_duty=rig.voices[0].last_duty[1]
                matrix=blank_matrix();matrix[7][2]=127 # BIAS -> PWM1
                rig.load_mod_matrix(matrix);audio.render(.15)
                new_duty=rig.voices[0].last_duty[1]
                check('bias_to_osc1_pwm_changes_sunvox_duty',original_duty is not None and
                      new_duty is not None and new_duty>original_duty,
                      original_duty=original_duty,new_duty=new_duty)
                rig.note_off(60);audio.render(.22)
                rig.load_mod_matrix(blank_matrix())

    finally:
        deinit()
    directory=Path(directory);directory.mkdir(parents=True,exist_ok=True)
    (directory/'mod_matrix_audio_checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf8')
    return {'PASS':sum(x['status']=='PASS' for x in rows),'FAIL':sum(x['status']=='FAIL' for x in rows)}


def run(output_dir='recordings',save_wav=True,wave_offsets=None,pitch_calibration=-12.,pitch_lfo_mode='native'):
    base=previous_run(output_dir=output_dir,save_wav=save_wav,wave_offsets=wave_offsets,
                      pitch_calibration=pitch_calibration,pitch_lfo_mode=pitch_lfo_mode)
    extra=patch_audio_checks(output_dir,pitch_lfo_mode)
    summary={k:base['summary'][k]+extra[k] for k in ('PASS','FAIL')}
    result={'version':'0.12.5','mode':pitch_lfo_mode,'summary':summary,
            'previous':base['summary'],'matrix':extra}
    (Path(output_dir)/'summary_0125.json').write_text(json.dumps(result,indent=2)+'\n')
    print('SYNTHRIG 0.12.5',summary,flush=True)
    return result
