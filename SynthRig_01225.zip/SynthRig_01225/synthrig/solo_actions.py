"""Short SOLO: hard PANIC and one-second preset count, atomically mirrored.

Long SOLO remains SAVE and is handled by the original release-gesture logic.
"""
from __future__ import annotations


def panic_and_show_active_preset(rig, apc, presets, leds=None, monitor=None, diagnostic=None):
    """Stop sound/effects and transport; show selected slot, never switch slots.

    Hardware LED MIDI messages precede the atomic GUI snapshot.  Without a
    selected slot there is no truthful preset number to show.  A failure in
    optional LED output must not prevent an actual PANIC.
    """
    if apc is not None:
        apc.set_playing(False)
        apc.router.panic()
    else:
        rig.panic()

    number = presets.selected + 1 if 0 <= presets.selected < presets.SLOT_COUNT else None
    if number is not None and leds is not None:
        try:
            leds.show_preset(number)
        except (OSError, IOError, RuntimeError) as exc:
            if diagnostic is not None:
                diagnostic(f'SOLO PANIC: LED-teller niet verzonden: {exc}')
        else:
            if diagnostic is not None:
                diagnostic(f'SOLO PANIC: preset {number:02d} gedurende 1s op 16 LEDs')
    elif number is None and diagnostic is not None:
        diagnostic('SOLO PANIC: geen preset geselecteerd; LED-teller overgeslagen')

    if monitor is not None:
        monitor.send_preset(presets.selection(),
                            led_snapshot=leds.display_snapshot() if leds is not None else None)
    return 'PANIC — stemmen en effecten uit' + (f'; preset {number:02d} getoond' if number and leds else '')
