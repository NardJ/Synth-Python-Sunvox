"""Gecontroleerde SunVox virtual-pattern tracks voor SynthRig 0.10.2.

0..15 zijn beschikbaar: vier stembanken met elk vier tracks.
Track 0 bevat uitsluitend de ADSR-gate: SunVox track 0 kan anders
bij stemhergebruik pitchbend-effects 05/06 onderdrukken. OSC1/OSC2/sub
hebben daarom de tracks 4..15; alle rollen blijven gescheiden.
De sub-router triggert zowel sub als noise (met afzonderlijke gain).
"""
from __future__ import annotations

MAX_EVENT_TRACKS = 16
MAX_VOICES = 4
TRACK_OFFSETS = {"amp_gate": 0, "osc1": 4, "osc2": 8, "sub_noise": 12}

def voice_track(voice_index: int, role: str) -> int:
    if not isinstance(voice_index, int) or not 0 <= voice_index < MAX_VOICES:
        raise ValueError(f"Ongeldig voice-index {voice_index!r}")
    if role not in TRACK_OFFSETS:
        raise ValueError(f"Onbekende SunVox-trackrol {role!r}")
    return voice_index + TRACK_OFFSETS[role]

def send_checked(slot, track: int, note: int, velocity=0, module=0, control=0, value=0):
    if not isinstance(track, int) or not 0 <= track < MAX_EVENT_TRACKS:
        raise ValueError(f"SunVox eventtrack {track!r} buiten bereik 0..15")
    rc = slot.send_event(track, note, velocity, module, control, value)
    if rc is not None and rc < 0:
        raise RuntimeError(f"SunVox send_event track={track}, note={note}, module={module}: {rc}")
    return rc
