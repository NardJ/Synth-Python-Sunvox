"""Side-by-side, screen-aware geometry for the optional MIDI monitors.

Pure layout calculation: no Tk, MIDI, or SunVox dependencies. The two
monitors share the same scale and top edge, never an independent guess
about where the window manager put the first monitor.
"""
from dataclasses import dataclass

LEFT_W, LEFT_H = 1170, 1065
RIGHT_W, RIGHT_H = 720, 1065


@dataclass(frozen=True)
class MonitorLayout:
    scale: float
    left_x: int
    right_x: int
    top_y: int
    left_w: int
    left_h: int
    right_w: int
    right_h: int
    gap: int
    zoom: float = 1.0


def monitor_layout(screen_width: int, screen_height: int, zoom: float = 1.0) -> MonitorLayout:
    """Keep both decorated windows visible, scaling as a pair when needed.

    Margins include allowance for desktop panels and window-manager frames.
    Positions are absolute (rather than auto-placing the first window).
    """
    if screen_width <= 0 or screen_height <= 0:
        raise ValueError('Screen dimensions must be positive')
    if not 0.5 <= zoom <= 1.0:
        raise ValueError('Zoom must be between 0.5 and 1.0')
    left = 8
    right = 20
    gap = 14
    top = 32
    bottom = 16
    titlebar = 35
    available_width = max(1, screen_width - left - right - gap)
    available_height = max(1, screen_height - top - bottom - titlebar)
    fit_scale = min(1.0, available_width / (LEFT_W + RIGHT_W), available_height / LEFT_H)
    scale = fit_scale * zoom
    lwidth = max(1, int(LEFT_W * scale))
    rwidth = max(1, int(RIGHT_W * scale))
    return MonitorLayout(
        scale=scale, left_x=left, right_x=left + lwidth + gap, top_y=top,
        left_w=lwidth, left_h=max(1,int(LEFT_H * scale)),
        right_w=rwidth, right_h=max(1,int(RIGHT_H * scale)), gap=gap, zoom=zoom,
    )
