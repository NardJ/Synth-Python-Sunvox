"""Read-only APC Mini Mk2 visual mirror for SynthRig 0.12.25.

Never opens MIDI ports or sends MIDI. Only shows the LED palette indexes
last commanded by the engine plus the last observed hardware fader positions.
The APC can be used normally if this window is closed.
"""
from __future__ import annotations

import tkinter as tk
from .scaled_canvas import ScaledCanvas
from .window_layout import monitor_layout
from .apc_labels import ROW_LABELS, COLUMN_LABELS, LABEL_FONT, validate_labels
from .sequence_lengths import SEQUENCE_LENGTHS

BG='#141920'
CASE='#222932'
OUTLINE='#485767'
TEXT='#e9eef5'
MUTED='#a3b1be'
CYAN='#62d0d0'
GREEN='#7fe1a6'
AMBER='#ffb75d'
TRACK='#111820'
PAD_OFF='#38434e'
# AKAI palette entries used by SynthRig 0.12.25, with approximate monitor colors.
PALETTE={0:PAD_OFF,1:'#536271',3:'#e6edf3',5:'#f45569',9:'#ffa951',
         13:'#ffdb6a',21:'#4edd82',37:'#27d7ed',45:'#718eff',49:'#bf8fff'}
COLS=('P1','P2','PW1','PW2','CUT','RES','LV1','LV2')
COLS_D=('SUB','NOISE','ENV','RATE','DEL','REV','CHO','FB')
TRACK_LABELS=('PATCH','SEQ','1–8','9–16','PLAY','SAVE','LOAD','PANIC')
W,H=720,1065
PAD_LEFT, PAD_TOP = 96, 195
PAD_STEP_X, PAD_STEP_Y = 64, 42
PAD_W, PAD_H = 50, 36
COL_LABEL_Y1, COL_LABEL_Y2 = 161, 178
COL_DEPTH_Y = 538
FADER_TOP, FADER_BOTTOM = 658, 775
FADER_XS = tuple(PAD_LEFT + PAD_W/2 + i*PAD_STEP_X for i in range(8)) + (649,)


class APCMonitor:
    def __init__(self,master,layout=None):
        self.master=master
        self.layout=layout if layout is not None else monitor_layout(
            master.winfo_screenwidth(),master.winfo_screenheight())
        self.window=tk.Toplevel(master)
        self.window.title('SynthRig 0.12.25 — APC mini Mk2 · LIVE LED-monitor')
        self.window.configure(bg=BG)
        L=self.layout
        self.window.geometry(f'{L.right_w}x{L.right_h}+{L.right_x}+{L.top_y}')
        self.window.resizable(False,False)
        self.window.protocol('WM_DELETE_WINDOW',self.window.withdraw)
        self.canvas=ScaledCanvas(self.window,scale=L.scale,width=L.right_w,
                                 height=L.right_h,bg=BG,highlightthickness=0)
        self.canvas.pack()
        self.pad_shapes=[]
        self.track_shapes=[]
        self.track_text=[]
        self.scene_shapes=[]
        self.scene_number_texts=[]
        self.fader_shapes=[]
        self.fader_text=[]
        self.fader_labels=[]
        self.row_text=[]
        self.col_text=[]
        self.col_depth_text=[]
        self.last_status_event=''
        self.event_clear_job=None
        self.draw_static()
        self.update_status({'connected':False})

    def txt(self,x,y,text,color=TEXT,size=10,anchor='center',weight='normal',justify='center'):
        return self.canvas.create_text(x,y,text=text,fill=color,
                   font=('DejaVu Sans',size,weight),anchor=anchor,justify=justify)

    def matrix_txt(self,x,y,text,anchor='center',color=MUTED):
        """Eight monospace cells at most, shared row and column font."""
        return self.canvas.create_text(x,y,text=text,fill=color,
                   font=(LABEL_FONT,8,'normal'),anchor=anchor,justify='right' if anchor=='e' else 'center')

    def _clear_event(self):
        self.event_clear_job=None
        self.canvas.itemconfigure(self.footer_event,text='')

    def _show_event(self,message):
        # Refresh only when the APC reports a NEW event; do not keep repeating
        # a stale SysEx message on each 20 Hz state snapshot.
        message=str(message or '').strip()
        if not message or message==self.last_status_event:
            return
        self.last_status_event=message
        self.canvas.itemconfigure(self.footer_event,text=message[:84])
        if self.event_clear_job is not None:
            self.window.after_cancel(self.event_clear_job)
        self.event_clear_job=self.window.after(6000,self._clear_event)

    def rect(self,x1,y1,x2,y2,fill=CASE,outline=OUTLINE,width=1,radius=0):
        if not radius:
            return self.canvas.create_rectangle(x1,y1,x2,y2,
                        fill=fill,outline=outline,width=width)
        points = [x1+radius,y1, x2-radius,y1, x2,y1,
                  x2,y1+radius, x2,y2-radius, x2,y2,
                  x2-radius,y2, x1+radius,y2, x1,y2,
                  x1,y2-radius, x1,y1+radius, x1,y1]
        return self.canvas.create_polygon(points,smooth=True,splinesteps=12,
                       fill=fill,outline=outline,width=width)

    def draw_static(self):
        c=self.canvas
        # Same styling and rounded 886px-high controller card as MIDImix.
        self.rect(18,20,W-18,886,CASE,'#3b4652',2,radius=22)
        self.txt(40,55,'AKAI  /  APC mini Mk2',CYAN,19,'w','bold')
        self.connection=self.txt(W-40,55,'SYNTHRIG 0.12.25',CYAN,10,'e','bold')
        c.create_line(40,83,W-40,83,fill=OUTLINE)
        self.mode_text=self.txt(40,105,'',TEXT,12,'w','bold')
        self.status_text=self.txt(40,126,'',MUTED,10,'w')
        self.mode_hint=self.txt(40,144,'',MUTED,9,'w')
        for r in range(8):
            y=PAD_TOP+(7-r)*PAD_STEP_Y
            # Mono cells, always right-justified beside the corresponding row.
            self.row_text.append((
                self.matrix_txt(79,y+PAD_H/2-8,'',anchor='e'),
                self.matrix_txt(79,y+PAD_H/2+8,'',anchor='e')))
            for col in range(8):
                x=PAD_LEFT+col*PAD_STEP_X
                self.pad_shapes.append((r*8+col,
                    c.create_rectangle(x,y,x+PAD_W,y+PAD_H,fill=PAD_OFF,outline='#657481',width=1)))
        self.scene_title=self.txt(647,129,'PATROON',MUTED,9,'center','bold')
        for i in range(8):
            y=PAD_TOP+i*PAD_STEP_Y+2
            block=self.rect(628,y,670,y+34,PAD_OFF,'#687785')
            self.scene_shapes.append(block)
            self.scene_number_texts.append(self.txt(649,y+17,f'{i+1}',TEXT,10,weight='bold'))
        for col in range(8):
            x=PAD_LEFT+col*PAD_STEP_X+PAD_W/2
            # Both destination-layer labels use the SAME 9-pt size as the row labels.
            self.col_text.append((
                self.matrix_txt(x,COL_LABEL_Y1,''),
                self.matrix_txt(x,COL_LABEL_Y2,'')))
            self.col_depth_text.append(self.txt(x,COL_DEPTH_Y,'',MUTED,9))
        # No helper sentence: headless / fixed-overlay display is self-explanatory.
        c.create_line(40,578,W-40,578,fill=OUTLINE)
        for col in range(8):
            x=PAD_LEFT+col*PAD_STEP_X
            block=self.rect(x,594,x+PAD_W,624,PAD_OFF,'#657481')
            self.track_shapes.append(block)
            self.track_text.append(self.txt(x+PAD_W/2,609,TRACK_LABELS[col],TEXT,8,weight='bold'))
        self.shift_shape=self.rect(627,594,670,624,PAD_OFF,'#657481')
        self.txt(649,609,'SHIFT',MUTED,8,weight='bold')
        # Fader acquisition status is displayed ONLY in the bottom status strip.
        for i,x in enumerate(FADER_XS):
            # Track top/bottom are identical to MIDImix in design coordinates.
            self.rect(x-7,FADER_TOP,x+7,FADER_BOTTOM,TRACK,'#485767',radius=4)
            thumb=self.rect(x-19,FADER_BOTTOM-6,x+19,FADER_BOTTOM+6,
                            '#7c8998','#d1deeb',radius=3)
            self.fader_shapes.append(thumb)
            self.fader_text.append(self.txt(x,827,'—',MUTED,9))
            self.fader_labels.append(self.txt(x,807,'M' if i==8 else str(i+1),MUTED,9))
        # Do not place MIDI/event messages in the controller drawing.
        c.create_line(40,850,W-40,850,fill=OUTLINE)
        self.seq_help=self.txt(40,869,'',MUTED,9,'w')
        # Extra information card follows the same vertical positioning as Swing.
        # No explanatory footer card: the LED grid is the interface.
        # The software display is a direct mirror of the APC LED state.
        # Color legend belongs in the manual and physical overlay, not here.
        # Unified, fixed bottom strip across the MIDImix and APC windows.
        c.create_line(28,1004,W-28,1004,fill=OUTLINE)
        self.footer_status=self.txt(34,1020,'APC niet aangesloten',MUTED,10,'w')
        self.footer_event=self.txt(34,1048,'',TEXT,9,'w')
        self.zoom_text=self.txt(W-34,1048,'90%',CYAN,9,'e')

    def set_zoom_label(self, zoom):
        self.canvas.itemconfigure(self.zoom_text,text=f'Zoom {zoom*100:.0f}%')

    def update_status(self,state):
        if not state.get('connected',False):
            self.canvas.itemconfigure(self.footer_status,text='● APC niet aangesloten',fill=MUTED)
            self.canvas.itemconfigure(self.mode_text,text='')
            self.canvas.itemconfigure(self.status_text,text='')
            self.canvas.itemconfigure(self.mode_hint,text='')
            self.canvas.itemconfigure(self.seq_help,text='')
            for _,item in self.pad_shapes:self.canvas.itemconfigure(item,fill=PAD_OFF)
            for item in self.scene_shapes+self.track_shapes:self.canvas.itemconfigure(item,fill=PAD_OFF)
            return
        c=self.canvas
        c.itemconfigure(self.connection,text='SYNTHRIG 0.12.25',fill=CYAN)
        mode=state.get('mode','patch')
        patch=mode=='patch'
        length=state.get('length',16)
        bank=state.get('bank',1)
        pending=state.get('pending_bank')
        choosing_length=not patch and state.get('shift',False)
        selection=f'P{bank:02d}'+(f' → P{pending:02d}' if isinstance(pending,int) else '')
        c.itemconfigure(self.mode_text,text='' if patch else f'SEQ · {selection} · LOOP {length} STAPPEN')
        c.itemconfigure(self.scene_title,text='BRON' if patch else 'LENGTE' if choosing_length else 'PATROON')
        for i,item in enumerate(self.scene_number_texts):
            text=(str(SEQUENCE_LENGTHS[i]) if i<len(SEQUENCE_LENGTHS) else '') if choosing_length else str(8-i if patch else i+1)
            c.itemconfigure(item,text=text)
        run='PLAY' if state.get('playing') else 'STOP'
        # Buttons and LED states already show PATCH/SEQ, selected row and pad
        # choices. Avoid redundant technical help on a future headless rig.
        sync=state.get('sync',{})
        external=state.get('clock')=='swing'
        bpm=sync.get('bpm') if external else state.get('bpm')
        tempo=f'{bpm:.1f} BPM' if isinstance(bpm,(float,int)) else 'tempo —'
        label='SWING' if external else 'INTERN'
        phase='CLOCK WEG' if external and sync.get('transport')=='lost' else run
        if external and state.get('playing') and sync.get('transport') in ('stopped','waiting'):
            phase='WACHT'
        if external and sync.get('input_error') is not None:phase='MIDI WEG'
        c.itemconfigure(self.status_text,
                        text=f'{phase} · {label} · {tempo} · stap {state.get("step",0):02d}/{length}',
                        fill=AMBER if phase in ('CLOCK WEG','MIDI WEG') else MUTED)
        c.itemconfigure(self.mode_hint,text='' if patch else
                        'SHIFT+pad: tie · SHIFT+rechts: 4/8/16',fill=CYAN if choosing_length else MUTED)
        c.itemconfigure(self.fader_labels[-1],text='M' if patch else 'TEMPO',fill=MUTED if patch or external else CYAN)
        c.itemconfigure(self.seq_help,text='' if patch else
                        'TEMPO via SWING · cyaan = aangehouden noot (tie)' if external else
                        'TEMPO rechts: omlaag = langzamer (60–180 BPM)')
        pads=state.get('pads',[])
        if isinstance(pads,list) and len(pads)==64:
            for note,item in self.pad_shapes:
                col=PALETTE.get(pads[note],CYAN)
                c.itemconfigure(item,fill=col,outline='#b9ecfa' if pads[note] not in (0,1) else '#657481')
        track=state.get('track_leds',[])
        if isinstance(track,list) and len(track)==8:
            for i,item in enumerate(self.track_shapes):
                saved=i==5 and state.get('save_confirmed',False) and track[i]
                c.itemconfigure(item,fill=GREEN if saved else '#e94f69' if track[i] else PAD_OFF,
                                  outline='#d3f9fc' if track[i] else '#657481')
        c.itemconfigure(self.track_text[5],text='OK' if state.get('save_confirmed') else 'SAVE',
                        fill=BG if state.get('save_confirmed') else TEXT)
        c.itemconfigure(self.shift_shape,fill='#718eff' if state.get('shift',False) else PAD_OFF)
        scenes=state.get('scene_leds',[])
        if isinstance(scenes,list) and len(scenes)==8:
            for i,item in enumerate(self.scene_shapes):
                queued=not patch and not choosing_length and pending==i+1
                c.itemconfigure(item,fill=(AMBER if queued else '#44b772') if scenes[i] else PAD_OFF,
                                  outline='#ffe7bc' if scenes[i] else '#687785')
        columns=state.get('columns',[])
        lanes=state.get('lanes',[])
        # Two fixed labels per column, exactly aligned above the physical pad grid.
        # Short 9-point layer names preserve space for the printed-overlay design.
        for i,(line1,line2) in enumerate(self.col_text):
            if patch:
                factor=(columns[i].get('factor',1.) if len(columns)==8 else 1.)
                c.itemconfigure(line1,text=COLUMN_LABELS[i][0],fill=CYAN)
                c.itemconfigure(line2,text=COLUMN_LABELS[i][1])
                c.itemconfigure(self.col_depth_text[i],text=f'×{factor:.2f}')
            else:
                step=(state.get('page',1)-1)*8+i+1
                c.itemconfigure(line1,text=f'STAP {step}',fill=CYAN if step<=length else '#657380')
                c.itemconfigure(line2,text='')
                c.itemconfigure(self.col_depth_text[i],text='')
        if not patch and len(lanes)==8:
            for i,(line1,line2) in enumerate(self.row_text):
                c.itemconfigure(line1,text=f'{lanes[i]}',fill=CYAN)
                c.itemconfigure(line2,text='',fill=CYAN)
        else:
            sources=state.get('sources',[])
            sources_b=state.get('sources_b',[])
            selected=state.get('selected_source',0)
            for i,(line1,line2) in enumerate(self.row_text):
                a=(sources[i] if len(sources)==8 else str(i+1))
                b=(sources_b[i] if len(sources_b)==8 else '—')
                color=CYAN if i==selected else MUTED
                c.itemconfigure(line1,text=ROW_LABELS[i][0],fill=color)
                c.itemconfigure(line2,text=ROW_LABELS[i][1],fill=color)
        faders=state.get('faders',[])
        intro=state.get('fader_intro_status','unavailable')
        known=sum(type(v) is int and 0<=v<=127 for v in faders) if isinstance(faders,list) else 0
        details={'received':'SysEx bij opstarten', 'waiting':'wacht op SysEx-antwoord',
                 'failed':'verzoek mislukt', 'no_response':'geen SysEx-antwoord',
                 'unavailable':'geen APC-outputpoort'}.get(intro,'via MIDI')
        info=(f'● APC verbonden  ·  {mode.upper()}  ·  Faders {known}/9  ·  {details}')
        c.itemconfigure(self.footer_status,text=info,fill=GREEN if known==9 else MUTED)
        self._show_event(state.get('last_action'))

        if isinstance(faders,list) and len(faders)==9:
            for i,raw in enumerate(faders):
                item=self.fader_shapes[i]
                if type(raw) is int and 0<=raw<=127:
                    x=FADER_XS[i]
                    yy=FADER_BOTTOM - (FADER_BOTTOM-FADER_TOP)*raw/127
                    # Move the rounded grip as a complete polygon, not a rectangle.
                    points=[x-16,yy-6, x+16,yy-6, x+19,yy-6,
                            x+19,yy-3, x+19,yy+3, x+19,yy+6,
                            x+16,yy+6, x-16,yy+6, x-19,yy+6,
                            x-19,yy+3, x-19,yy-3, x-19,yy-6]
                    c.coords(item,*points)
                    c.itemconfigure(self.fader_text[i],text=str(raw),fill=CYAN)
                else:
                    c.itemconfigure(self.fader_text[i],text='—',fill=MUTED)
        if not patch:
            c.itemconfigure(self.fader_text[-1],
                            text='SWING' if external else f'{state.get("bpm",120):.1f} BPM',
                            fill=MUTED if external else CYAN)
        # All events live in the fixed bottom strip; no duplicate within pad card.
