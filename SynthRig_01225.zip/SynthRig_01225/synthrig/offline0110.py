"""Native SunVox 0.11 checks: legacy 0.10.2 and native preset, delay, reverb checks.

Requires wheel containing SunVox DSP. No MIDI device or sound card required.
"""
from __future__ import annotations
import json
import math
from pathlib import Path
import time
from .offline0102 import OfflineAudio, RATE, rms, output_wav
from .presets import PresetManager
from .fixed_controls import FixedControls
from .offline0102 import run as legacy_run


def run_additions(base,mode,save_wav=True):
    import numpy as np
    from sunvox.api import Slot,init,deinit
    from sunvox.types import INIT_FLAG
    from .engine09 import SynthRig
    from .session_state import apply_state, default_state
    import sunvox.dll as dll
    base=Path(base);base.mkdir(parents=True,exist_ok=True)
    controls=FixedControls()
    presets=PresetManager(controls,path=base/'no_user_presets')
    results=[];audio=[]
    def check(name,ok,**observed):
        print(('PASS' if ok else 'FAIL'),name,observed,flush=True)
        results.append({'name':name,'status':'PASS' if ok else 'FAIL',**observed})
    flags=int(INIT_FLAG.OFFLINE|INIT_FLAG.AUDIO_FLOAT32|
              INIT_FLAG.ONE_THREAD|INIT_FLAG.NO_DEBUG_OUTPUT)
    version=init(None,RATE,2,flags)
    if version<0:raise RuntimeError('SunVox DSP init mislukt')
    try:
        with Slot() as slot:
            rig=SynthRig(slot,pitch_lfo_mode=mode,offline=True)
            apply_state(rig,controls,default_state(controls))
            if slot.play()<0:raise RuntimeError('SunVox DSP slot.play mislukt')
            with OfflineAudio(rig,dll) as driver:
                driver.render(.35)
                check('preset_builtins_sixteen',len(presets.slots())==16,count=len(presets.slots()))
                for idx,(identifier,name,_) in enumerate((ident,name,state) for ident,name,state,_ in presets.slots()):
                    presets.load(identifier,rig)
                    driver.render(.16)
                    rig.note_on(60,87)
                    rig.note_on(64,90)
                    rig.note_on(67,91)
                    rig.note_on(72,92)
                    audio_on=driver.render(.5)
                    for n in (60,64,67,72):rig.note_off(n)
                    release=driver.render(.70)
                    peak=float(np.max(np.abs(np.concatenate((audio_on,release)))))
                    level=rms(audio_on)
                    check('preset_'+identifier+'_audio_and_headroom',
                          .0002<level and peak<.99,
                          name_preset=name,rms=round(level,5),peak=round(peak,5))
                    if idx in (0,3,4,7):audio.extend((audio_on,release))
                    driver.render(.9)
                # Strong audio effects in a short, clean percussive test.
                def transient(effect):
                    rig.all_notes_off()
                    rig.set_waveform_index(1,0)
                    for src in ('osc1','osc2','sub','noise'):
                        rig.set_source_enabled(src,src=='osc1')
                    for target,raw in (
                        ('master.level',87),('osc1.level',94),('osc2.level',0),
                        ('amp.attack',0),('amp.decay',0),('amp.sustain',0),
                        ('amp.release',0),('filter.cutoff',127),
                        ('filter.resonance',0),('filter.env_amount',0),
                        ('lfo.pitch_depth',0),('effects.chorus',0),
                        ('performance.portamento',0),('effects.delay',127 if effect=='delay' else 0),
                        ('effects.reverb',127 if effect=='reverb' else 0)):
                        rig.set_parameter(target,raw)
                    driver.render(1.6) # flush previous effect memories
                    rig.note_on(60,110)
                    head=driver.render(.12)
                    rig.note_off(60)
                    tail=driver.render(1.1)
                    audio.extend((head,tail))
                    return tail
                dry=transient('off')
                delay=transient('delay')
                reverb=transient('reverb')
                drytail=rms(dry[int(.18*RATE):])
                for name,tail in (('delay',delay),('reverb',reverb)):
                    wet=rms(tail[int(.18*RATE):])
                    check(name+'_audible_tail',wet>drytail*2 and wet>.00005,
                          dry_tail_rms=round(drytail,7),wet_tail_rms=round(wet,7))
                check('fx_control_ranges',0<=rig.last_delay_wet<=150 and 0<=rig.last_reverb_wet<=170,
                      delay=rig.last_delay_wet,reverb=rig.last_reverb_wet)
                # A/B restores exact previous state including FX and arms pickup
                rig.set_parameter('effects.delay',39)
                old=__import__('synthrig.session_state',fromlist=['capture_state']).capture_state(rig,controls)
                print(presets.load('5',rig))
                check('preset_soft_takeover',len(controls.pickup)==len(controls.mappings),pickup_count=len(controls.pickup))
                print(presets.compare(rig))
                check('ab_restores_old_delay',abs(rig.delay_mix*127-old['fx']['delay'])<=1,
                      wet=round(rig.delay_mix*127),expected=old['fx']['delay'])
                print(presets.compare(rig))
                check('ab_restores_preset_reverb',round(rig.reverb_mix*127)==72,
                      reverb=round(rig.reverb_mix*127))
    finally:
        deinit()
    summary={'PASS':sum(x['status']=='PASS' for x in results),
             'FAIL':sum(x['status']=='FAIL' for x in results)}
    result={'version':'0.11.1','mode':mode,'summary':summary,'checks':results}
    (base/'extras.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
    if save_wav and audio:output_wav(base/'extras.wav',np.concatenate(audio))
    return result


def run(output_dir='recordings',save_wav=True,wave_offsets=None,pitch_calibration=-12.,pitch_lfo_mode='native'):
    # Reuse unchanged detailed tests, now exercising the extended 0.11.1 engine.
    previous=legacy_run(output_dir=output_dir,save_wav=save_wav,
                        wave_offsets=wave_offsets,pitch_calibration=pitch_calibration,
                        pitch_lfo_mode=pitch_lfo_mode)
    base=Path(output_dir)/('offline_0111_'+time.strftime('%Y%m%d_%H%M%S'))
    addon=run_additions(base,pitch_lfo_mode,save_wav)
    summary={k:previous['summary'][k]+addon['summary'][k] for k in ('PASS','FAIL')}
    result={'version':'0.11.1','mode':pitch_lfo_mode,'summary':summary,
            'previous_checks':previous['summary'],'new_checks':addon['summary'],
            'additional_report':str(base/'extras.json')}
    (base/'summary.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
    print('SYNTHRIG 0.11.1 SAMENVATTING',summary,flush=True)
    return result
