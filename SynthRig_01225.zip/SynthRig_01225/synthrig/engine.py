"""SynthRig SunVox-engine: MIDI- en GUI-onafhankelijk.

0.8.1 behoudt de bewezen 0.7-notenrouting, filters, golfvormtrims en stemmen.
Alle SunVox-aanroepen vinden plaats op dezelfde main/event-loop-thread.
"""
from __future__ import annotations

import time
import math
from sunvox.api import NOTECMD
from .pwm import PWM

MAX_VOICES = 8
WAVEFORMS = ((5, "SIN"), (0, "TRI"), (1, "SAW"), (2, "PULSE"))
WAVE_HYSTERESIS = 2
WAVE_TRIMS = {"SIN": 1.00, "TRI": 1.25, "SAW": 1.55, "PULSE": 0.80}
MIX_HEADROOM = 0.65
MASTER_START = 128  # voorzichtig opstartniveau; oude maximum
MASTER_MAX = 256    # 0..256 is het officiële SunVox slot-volume bereik
PWM_HZ = 80.0       # Besturingsfrequentie; SunVox zelf berekent alle audio.


def choose_wave_index(raw, previous=None):
    raw = int(clamp(raw, 0, 127))
    candidate = raw // 32
    if previous is None or candidate == previous:
        return candidate
    if candidate == previous + 1 and raw < candidate * 32 + WAVE_HYSTERESIS:
        return previous
    if candidate == previous - 1 and raw >= previous * 32 - WAVE_HYSTERESIS:
        return previous
    return candidate

# Maak geen aannames over SunVox-controllernummers: zoek ze op naam op.
def controller(slot, module, *possible_names):
    count = slot.get_number_of_module_ctls(module)
    if count < 0:
        raise RuntimeError(f"Kon controllers voor module {module} niet ophalen: {count}")
    names = []
    for number in range(count):
        raw_name = slot.get_module_ctl_name(module, number)
        name = (raw_name.decode("utf-8", errors="replace")
                if isinstance(raw_name, bytes) else str(raw_name))
        names.append(name)
        if name.strip().casefold() in {x.casefold() for x in possible_names}:
            low = slot.get_module_ctl_min(module, number, 0)
            high = slot.get_module_ctl_max(module, number, 0)
            if high <= low:
                raise RuntimeError(f"Ongeldig bereik voor {name}: {low}..{high}")
            return number, low, high
    raise RuntimeError(
        f"Controller {possible_names} ontbreekt in module {module}. "
        f"Beschikbaar: {names}"
    )


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def find_midi_port(names, *markers):
    for name in names:
        low = name.casefold()
        if any(marker in low for marker in markers):
            return name
    return None


def display_controller(slot, module, *possible_names):
    """(nr, min_raw, max_raw, display_offset) voor Bipolaire controls.

    SunVox kan 0..256 intern opslaan en -128..+128 tonen.
    Daarom hier nooit blind een negatieve MIDI-waarde naar scaled=0 sturen.
    """
    number, low, high = controller(slot, module, *possible_names)
    offset = slot.get_module_ctl_offset(module, number)
    if low + offset > 0 or high + offset < 0:
        raise RuntimeError(f"Neutrale 0 ontbreekt bij {possible_names}: "
                           f"raw={low}..{high}, offset={offset}")
    return number, low, high, offset


class SynthRig:
    """8 stemmen via twee notenrouters (16 SunVox-tracks)."""

    def __init__(self, slot, mappings, diagnose=False, retrigger_wave=True,
                 dc_blocker=False):
        self.slot = slot
        self.mappings = mappings
        self.pwm = PWM()
        self._pwm_last_sent = {1: None, 2: None}
        self._pwm_last_tick = 0.0
        self.pwm_trace = None  # optionele callback: werkelijke Duty cycle writes
        self.pwm_tick_trace = None  # optionele callback: elke uitgevoerde PWM tick
        self.diagnose = diagnose
        self.retrigger_wave = retrigger_wave
        self.dc_blocker_enabled = bool(dc_blocker)
        self.verify_pending = {}  # (module, ctl) -> (cc, verwacht, controleren_na)
        self.osc1 = slot.new_module("Generator", "OSC1", 250, 300, 0)
        self.osc2 = slot.new_module("Generator", "OSC2", 250, 700, 0)
        # MultiSynth stuurt NOOT- en PITCH-events door, geen audio.
        # Hiermee kunnen OSC1 en OSC2 verschillende tonen spelen.
        self.note_router1 = slot.new_module("MultiSynth", "OSC1 notes", 70, 300, 0)
        self.note_router2 = slot.new_module("MultiSynth", "OSC2 notes", 70, 700, 0)
        # Een echte audiomixer: de oscillatorvolume-faders sturen niet meer
        # de Generator zelf aan, maar een aparte versterker in het audiopad.
        self.amp1 = slot.new_module("Amplifier", "OSC1 gain", 450, 300, 0)
        self.amp2 = slot.new_module("Amplifier", "OSC2 gain", 450, 700, 0)
        self.filt = slot.new_module("Filter", "LPF", 700, 500, 0)
        # Native SunVox DC-blockers PER OSCILLATOR, vóór Gain/Mixer/Filter.
        # In een A/B-test slaan we deze per oscillator over (geen downstream blocker).
        self.dc_blocker1 = (slot.new_module("DC Blocker", "OSC1 DC clean", 365, 300, 0)
                            if self.dc_blocker_enabled else None)
        self.dc_blocker2 = (slot.new_module("DC Blocker", "OSC2 DC clean", 365, 700, 0)
                            if self.dc_blocker_enabled else None)
        self.dc_blockers = (self.dc_blocker1, self.dc_blocker2)
        modules = [self.osc1, self.osc2, self.note_router1, self.note_router2,
                   self.amp1, self.amp2, self.filt]
        modules.extend(mod for mod in self.dc_blockers if mod is not None)
        if min(modules) < 0:
            raise RuntimeError("SunVox-modules konden niet worden aangemaakt")

        # NOTE-routing: MultiSynth1 -> OSC1; MultiSynth2 -> OSC2.
        # AUDIO-routing met DC: OSC -> DC Blocker -> Amp -> gezamenlijke Filter.
        # AUDIO-routing zonder DC (referentietest): OSC -> Amp -> Filter.
        routes = [
            (self.note_router1, self.osc1),
            (self.note_router2, self.osc2),
            (self.amp1, self.filt),
            (self.amp2, self.filt),
            (self.filt, 0),
        ]
        for osc, dc, amp in ((self.osc1, self.dc_blocker1, self.amp1),
                             (self.osc2, self.dc_blocker2, self.amp2)):
            if self.dc_blocker_enabled:
                routes.extend(((osc, dc), (dc, amp)))
            else:
                routes.append((osc, amp))
        self.audio_routes = tuple(routes)
        for src, target in routes:
            result = slot.connect_module(src, target)
            if result is not None and result < 0:
                raise RuntimeError(f"SunVox connect_module({src},{target}) fout {result}")
        slot.volume(MASTER_START)
        slot.set_event_t(1, 0)

        self.cutoff = controller(slot, self.filt, "Frequency", "Freq")
        self.resonance = controller(slot, self.filt, "Resonance")
        # De filtermodus wordt expliciet gezet: geen onbedoelde bypass,
        # dry/wet-stand of lage-kwaliteitmodus. Dit zijn gedocumenteerde
        # SunVox-Filter-controls; ontbreekt er een, dan stoppen we met een
        # duidelijke fout in plaats van te doen alsof resonantie werkt.
        self.filter_type = controller(slot, self.filt, "Type")
        self.filter_mix = controller(slot, self.filt, "Mix")
        self.filter_mode = controller(slot, self.filt, "Mode")
        self.rolloff = controller(slot, self.filt, "Roll-off", "Roll off", "Rolloff")
        self.filter_response = controller(slot, self.filt, "Response")
        self.set_ctl(self.filt, self.filter_type, 0)       # Low-pass
        self.set_ctl(self.filt, self.filter_mix, 256)     # 100% gefilterd
        self.set_ctl(self.filt, self.filter_mode, 0)      # HQ stereo
        self.set_ctl(self.filt, self.rolloff, 1)          # 24 dB/oct
        self.set_ctl(self.filt, self.filter_response, 1)  # Snelle response
        self.wave1 = controller(slot, self.osc1, "Waveform", "Type")
        self.wave2 = controller(slot, self.osc2, "Waveform", "Type")
        self.duty1 = controller(slot, self.osc1, "Duty cycle", "Duty Cycle")
        self.duty2 = controller(slot, self.osc2, "Duty cycle", "Duty Cycle")
        # 'square' met duty 50% is de PULSE-basisvorm; PWM volgt later.
        self.set_ctl(self.osc1, self.duty1,
                     (self.duty1[1] + self.duty1[2]) / 2)
        self.set_ctl(self.osc2, self.duty2,
                     (self.duty2[1] + self.duty2[2]) / 2)
        self.volume1 = controller(slot, self.amp1, "Volume")
        self.volume2 = controller(slot, self.amp2, "Volume")
        # Deze twee controls kunnen een display-offset hebben (bijv.
        # intern 0..256, getoond -128..+128). Corrigeer daarvoor.
        self.transpose1 = display_controller(slot, self.note_router1, "Transpose")
        self.transpose2 = display_controller(slot, self.note_router2, "Transpose")
        self.finetune1 = display_controller(slot, self.note_router1, "Finetune", "Fine tune")
        self.finetune2 = display_controller(slot, self.note_router2, "Finetune", "Fine tune")
        # Standaardsterkte van een nieuwe Amplifier (typisch unity gain).
        # Niet het maximale versterkingsbereik als 100% gebruiken!
        self.amp1_unity = slot.get_module_ctl_value(self.amp1, self.volume1[0], 0)
        self.amp2_unity = slot.get_module_ctl_value(self.amp2, self.volume2[0], 0)
        if self.amp1_unity <= 0 or self.amp2_unity <= 0:
            raise RuntimeError("Kan standaardversterking van Amplifier niet vaststellen")

        self.active_notes = {}  # note -> voice index 0..7
        self.active_velocities = {}  # note -> SunVox velocity, nodig voor retrigger
        self.free_voices = set(range(MAX_VOICES))
        self.last_cc = {}
        self.osc1_level = 0.8
        self.osc2_level = 0.8
        self.wave_selection = {1: 2, 2: 3}  # begin: OSC1=SAW; OSC2=PULSE
        self.vco_mix = 0.0  # Begin met alleen OSC1: CC52/53 direct hoorbaar
        self.osc_tuning = {
            1: {"semitones": 0, "cents": 0},
            2: {"semitones": 0, "cents": 0},
        }

        self.set_ctl(self.osc1, self.wave1, WAVEFORMS[2][0])  # SAW
        self.set_ctl(self.osc2, self.wave2, WAVEFORMS[3][0])  # PULSE
        # Filter ver genoeg open voor een hoorbaar golfvormverschil.
        self.set_ctl(self.filt, self.cutoff,
                     clamp(8000, self.cutoff[1], self.cutoff[2]))
        self.set_ctl(self.filt, self.resonance, self.resonance[1])
        self.apply_osc_levels()
        self.apply_tuning(1)
        self.apply_tuning(2)
        self.wave_values = {1: WAVEFORMS[2][0], 2: WAVEFORMS[3][0]}

        print("\nGevonden SunVox-controllers:")
        for title, ctl in (("Cutoff", self.cutoff),
                           ("Resonantie", self.resonance),
                           ("OSC1 waveform", self.wave1),
                           ("OSC2 waveform", self.wave2),
                           ("OSC1 AMP volume", self.volume1),
                           ("OSC2 AMP volume", self.volume2),
                           ("Filtertype", self.filter_type),
                           ("Filter wet", self.filter_mix),
                           ("Filter response", self.filter_response),
                           ("Filter rolloff", self.rolloff)):
            print(f"  {title:<16} ctl={ctl[0]} bereik={ctl[1]}..{ctl[2]}")
        print(f"  Gain bij 100%: OSC1={self.amp1_unity}, OSC2={self.amp2_unity}")
        print("  Notenrouting: MIDI -> MultiSynth1/2 -> Generator1/2")
        print("  Audiorouting: OSC1 -> Amp1 -> Filter <- Amp2 <- OSC2")
        print(f"  DC Blockers PER OSC, vóór mixer/filter: {'AAN' if self.dc_blocker_enabled else 'UIT'}")
        if self.dc_blocker_enabled:
            print("  Route: OSC1 → DC1 → Amp1 → Filter → Output")
            print("         OSC2 → DC2 → Amp2 → Filter → Output")
        else:
            print("  Route: OSC1/OSC2 → Amp1/Amp2 → Filter → Output (A/B-referentie)")
        print("  Filter: low-pass, HQ, 24dB/octaaf, 100% wet")
        print("  Beginbalans: 100% OSC1 / 0% OSC2")
        print("  Voor resonantie: zet CC16 rond 55-70/127 en verander CC17.")
        print("  Voor golfvormen: zet CC61 op 0 voor OSC1 of 127 voor OSC2.")
        print("  CC52/56: 0..31 SIN | 32..63 TRI | 64..95 SAW | 96..127 PULSE")
        print("  Golfvormselectie heeft 2 MIDI-stappen hysterese bij de grenzen.")
        print(f"  Statische trims: {WAVE_TRIMS}; headroom {MIX_HEADROOM:.0%}")
        print("  PWM-blok: CC28=PW1, CC46=PW2, CC29=snelheid, CC47=diepte (voorlopig).")
        print(f"  Master: CC62 0..{MASTER_MAX}; opstartwaarde {MASTER_START}. Let op oversturing bij hoge waarden.")
        print("  Duty cycle wordt alleen gemoduleerd zolang PULSE geselecteerd is.")
        print("  REC ARM/MUTE/BANK blijven vrij.")
        print("  Golfvormwissel herstart alleen de actieve stem van die oscillator.")
        print("  Stemming: CC50/51 voor OSC1, CC54/55 voor OSC2.")
        print("  Middenstand (MIDI 64) = 0; ±24 semitones, ±100 cent.")
        print("  Bij een stemmingswissel worden actieve noten op die oscillator herstart.")

    def set_ctl(self, module, ctl, value):
        number, low, high = ctl
        native_value = int(clamp(round(value), low, high))
        result = self.slot.set_module_ctl_value(module, number, native_value, 0)
        if result is not None and result < 0:
            raise RuntimeError(f"SunVox controller {number}: fout {result}")
        return native_value

    def apply_tuning(self, osc_number):
        """Transponeer *note events* via een afzonderlijke MultiSynth.

        Dit vermijdt de ambiguïteit van het instellen van de modulemetadata
        (set_module_relnote) op een Generator die al noten speelt.
        """
        mod = self.note_router1 if osc_number == 1 else self.note_router2
        semictl = self.transpose1 if osc_number == 1 else self.transpose2
        finectl = self.finetune1 if osc_number == 1 else self.finetune2
        tuning = self.osc_tuning[osc_number]
        semitones = int(tuning["semitones"])
        fine_units = round(tuning["cents"] * 256 / 100)
        self.set_display_ctl(mod, semictl, semitones)
        self.set_display_ctl(mod, finectl, fine_units)
        if self.diagnose:
            actual_s = self.get_display_ctl(mod, semictl)
            actual_f = self.get_display_ctl(mod, finectl)
            status = "OK" if (actual_s, actual_f) == (semitones, fine_units) else "AFWIJKEND"
            print(f"  MultiSynth OSC{osc_number}: transpose={actual_s:+d}, "
                  f"fine={actual_f:+d}/256 [{status}]")
        return semitones, fine_units

    def set_display_ctl(self, module, ctl, displayed):
        """Zet een control inclusief eventuele SunVox-display-offset."""
        number, raw_min, raw_max, offset = ctl
        raw = round(displayed - offset)
        raw = int(clamp(raw, raw_min, raw_max))
        result = self.slot.set_module_ctl_value(module, number, raw, 0)
        if result is not None and result < 0:
            raise RuntimeError(f"SunVox display-ctl {number}: fout {result}")
        return raw + offset

    def get_display_ctl(self, module, ctl):
        number, _, _, offset = ctl
        return self.slot.get_module_ctl_value(module, number, 0) + offset

    def apply_osc_levels(self):
        """Onafhankelijke faders + OSC-mix + vaste golfvormtrim.

        De Amplifiers verwerken deze gain; de Generator volumes blijven
        onveranderd. Headroom voorkomt dat de som snel overstuurt.
        """
        w1 = WAVEFORMS[self.wave_selection[1]][1]
        w2 = WAVEFORMS[self.wave_selection[2]][1]
        v1 = round(self.amp1_unity * MIX_HEADROOM * self.osc1_level *
                   (1.0 - self.vco_mix) * WAVE_TRIMS[w1])
        v2 = round(self.amp2_unity * MIX_HEADROOM * self.osc2_level *
                   self.vco_mix * WAVE_TRIMS[w2])
        actual1 = self.set_ctl(self.amp1, self.volume1, v1)
        actual2 = self.set_ctl(self.amp2, self.volume2, v2)
        return actual1, actual2

    def select_wave(self, oscillator, wave_index):
        """Stel de golfvorm en bijbehorende gain atomair vanuit de eventloop in."""
        assert oscillator in (1, 2)
        assert 0 <= wave_index < 4
        module, ctl = ((self.osc1, self.wave1) if oscillator == 1
                       else (self.osc2, self.wave2))
        value, name = WAVEFORMS[wave_index]
        changed = self.wave_selection[oscillator] != wave_index
        if changed:
            actual = self.set_ctl(module, ctl, value)
            self.wave_values[oscillator] = actual
            self.wave_selection[oscillator] = wave_index
            self.apply_osc_levels()
            self.schedule_verify(52 if oscillator == 1 else 56,
                                 module, ctl, actual)
            self.retrigger_oscillator(oscillator)
        return name, WAVE_TRIMS[name], changed

    def note_on(self, note, velocity):
        if not 0 <= note <= 126:
            return
        previous = self.active_notes.pop(note, None)
        self.active_velocities.pop(note, None)
        if previous is not None:
            self.stop_voice(previous)
            self.free_voices.add(previous)
        if not self.free_voices:
            print("Geen vrije stem (maximaal 8)")
            return
        voice = min(self.free_voices)
        self.free_voices.remove(voice)
        self.active_notes[note] = voice
        sv_velocity = max(1, min(129, round(velocity * 129 / 127)))
        self.active_velocities[note] = sv_velocity
        # 16 eventtracks: 0..7 MultiSynth1, 8..15 MultiSynth2.
        # MultiSynth past transpose/fine aan en stuurt door naar de Generator.
        self.slot.send_event(voice, note + 1, sv_velocity,
                             self.note_router1 + 1, 0, 0)
        self.slot.send_event(voice + MAX_VOICES, note + 1, sv_velocity,
                             self.note_router2 + 1, 0, 0)

    def retrigger_oscillator(self, oscillator):
        """Stuur een nieuwe Note ON door de MultiSynth bij een wijziging.

        Alleen de betreffende oscillator wordt herstart; de andere blijft
        onaangeroerd. Dit voorkomt dat men pas na een nieuwe toets iets hoort.
        """
        if not self.retrigger_wave:
            return
        for note, voice in self.active_notes.items():
            track = voice if oscillator == 1 else voice + MAX_VOICES
            mod = self.note_router1 if oscillator == 1 else self.note_router2
            velocity = self.active_velocities.get(note, 100)
            self.slot.send_event(track, NOTECMD.NOTE_OFF, 0, 0, 0, 0)
            self.slot.send_event(track, note + 1, velocity, mod + 1, 0, 0)

    def schedule_verify(self, cc, mod, ctl, expected):
        if self.diagnose:
            self.verify_pending[(mod, ctl[0])] = (cc, expected, time.monotonic() + 0.12)

    def check_verifications(self):
        if not self.verify_pending:
            return
        now = time.monotonic()
        for key, (cc, expected, due) in list(self.verify_pending.items()):
            if now < due:
                continue
            actual = self.slot.get_module_ctl_value(key[0], key[1], 0)
            result = 'OK' if actual == expected else 'AFWIJKEND'
            print(f'  SunVox controle CC{cc}: gevraagd={expected}, gelezen={actual} [{result}]')
            del self.verify_pending[key]

    def stop_voice(self, voice):
        # Note-offs lopen over dezelfde tracks als de MultiSynth Note-ons.
        self.slot.send_event(voice, NOTECMD.NOTE_OFF, 0, 0, 0, 0)
        self.slot.send_event(voice + MAX_VOICES,
                             NOTECMD.NOTE_OFF, 0, 0, 0, 0)

    def note_off(self, note):
        voice = self.active_notes.pop(note, None)
        self.active_velocities.pop(note, None)
        if voice is not None:
            self.stop_voice(voice)
            self.free_voices.add(voice)

    def all_notes_off(self):
        for voice in self.active_notes.values():
            self.stop_voice(voice)
        self.active_notes.clear()
        self.active_velocities.clear()
        self.free_voices = set(range(MAX_VOICES))

    def handle_swing(self, message):
        if message.type == "note_on" and message.velocity > 0:
            self.note_on(message.note, message.velocity)
        elif message.type == "note_off" or (
                message.type == "note_on" and message.velocity == 0):
            self.note_off(message.note)

    def _duty_native(self, osc, width):
        """Width percentage (0..1) -> native SunVox Duty cycle 0..256 o.i.d."""
        ctl = self.duty1 if osc == 1 else self.duty2
        _, low, high = ctl
        # Geen verborgen aanname dat het native bereik exact 0..256 is.
        return round(low + clamp(width, 0.0, 1.0) * (high - low))

    def tick_pwm(self, now=None, force=False):
        """Controlefrequentie ~80 Hz; geen Python-audio/DSP.

        Deze methode wordt uitsluitend vanuit de bestaande eventloop geroepen.
        PWM is voorlopig een controle-rate LFO, geen audio-rate modulatie.
        """
        now = time.monotonic() if now is None else now
        if not force and now - self._pwm_last_tick < (1.0 / PWM_HZ):
            return
        self._pwm_last_tick = now
        if self.pwm_tick_trace is not None:
            self.pwm_tick_trace({'rate_hz': round(self.pwm.rate, 5), 'depth': round(self.pwm.depth, 5)})
        widths = self.pwm.advance(now)
        for osc in (1, 2):
            if WAVEFORMS[self.wave_selection[osc]][1] != "PULSE":
                self._pwm_last_sent[osc] = None
                continue
            native = self._duty_native(osc, widths[osc])
            if native == self._pwm_last_sent[osc]:
                continue
            mod = self.osc1 if osc == 1 else self.osc2
            ctl = self.duty1 if osc == 1 else self.duty2
            actual = self.set_ctl(mod, ctl, native)
            self._pwm_last_sent[osc] = actual
            if self.pwm_trace is not None:
                self.pwm_trace({
                    "osc": osc, "native_duty_written": actual,
                    "effective_width": round(widths[osc], 6),
                    "pwm_phase": round(self.pwm.phase, 6),
                    "rate_hz": round(self.pwm.rate, 6),
                    "depth": round(self.pwm.depth, 6),
                    "force": bool(force),
                })

    def set_parameter(self, target, raw):
        """Fysieke CC -> logische parameter -> engine, zonder CC-specifieke DSP-code.

        Een andere CC-indeling kan in config/controls.json worden gemaakt.
        Geeft de beschrijving voor debugmonitor terug.
        """
        position = raw / 127.0
        if target == "filter.cutoff":
            lo, hi = max(80, self.cutoff[1]), min(14000, self.cutoff[2])
            if hi <= lo:
                raise RuntimeError("Geen bruikbaar cutoff-bereik in SunVox")
            actual = self.set_ctl(self.filt, self.cutoff, lo * (hi / lo) ** position)
            return f"Cutoff {actual} Hz"
        if target == "filter.resonance":
            value = self.resonance[1] + position ** 1.5 * (self.resonance[2] - self.resonance[1])
            actual = self.set_ctl(self.filt, self.resonance, value)
            current_cutoff = self.slot.get_module_ctl_value(self.filt, self.cutoff[0], 0)
            return f"Resonantie {actual} (cutoff {current_cutoff} Hz)"
        if target in ("osc1.semitones", "osc1.finetune", "osc2.semitones", "osc2.finetune"):
            osc = 1 if target.startswith("osc1") else 2
            field = "semitones" if target.endswith("semitones") else "cents"
            delta = 24 if field == "semitones" else 100
            bipolar = (raw - 64) / (64.0 if raw <= 64 else 63.0)
            value = round(delta * bipolar)
            if self.osc_tuning[osc][field] != value:
                self.osc_tuning[osc][field] = value
                self.apply_tuning(osc)
                self.retrigger_oscillator(osc)
            unit = 'st' if field == 'semitones' else 'cent'
            return f"OSC{osc} {field}: {value:+d} {unit}"
        if target in ("osc1.waveform", "osc2.waveform"):
            osc = 1 if target.startswith("osc1") else 2
            wave_idx = choose_wave_index(raw, self.wave_selection[osc])
            name, trim, changed = self.select_wave(osc, wave_idx)
            self.tick_pwm(force=True)
            return f"OSC{osc} golfvorm {name} (trim {trim:.2f}x){' [nieuw]' if changed else ''}"
        if target in ("osc1.level", "osc2.level", "osc.mix"):
            if target == "osc1.level":
                self.osc1_level = position
            elif target == "osc2.level":
                self.osc2_level = position
            else:
                self.vco_mix = position
            a, b = self.apply_osc_levels()
            return f"OSC1/OSC2 levels {a}/{b} (mix {self.vco_mix:.0%})"
        if target == "master.level":
            actual = round(MASTER_MAX * position)
            self.slot.volume(actual)
            return f"Master {actual}/{MASTER_MAX}"
        if target in ("osc1.pulse_width", "osc2.pulse_width"):
            osc = 1 if target.startswith("osc1") else 2
            self.pwm.set_width(osc, 0.10 + 0.80 * position)
            self.tick_pwm(force=True)
            return f"OSC{osc} Pulse Width {self.pwm.width[osc]*100:.0f}%" + (
                " (alleen hoorbaar bij PULSE)" if self.wave_selection[osc] != 3 else "")
        if target == "pwm.depth":
            self.pwm.depth = 0.35 * position
            self.tick_pwm(force=True)
            return f"PWM diepte ±{self.pwm.depth*100:.1f} procentpunt"
        if target == "pwm.rate":
            self.pwm.rate = 0.1 * (5.0 / 0.1) ** position
            self.tick_pwm(force=True)
            return f"PWM rate {self.pwm.rate:.2f} Hz"
        raise ValueError(f"Onbekende synthparameter {target!r}")

    def handle_midimix(self, message):
        if message.type != "control_change":
            return None
        cc, raw = message.control, message.value
        spec = self.mappings.get(cc)
        if spec is None or self.last_cc.get(cc) == raw:
            return None
        self.last_cc[cc] = raw
        label = self.set_parameter(spec["target"], raw)
        print(f"MIDImix CC{cc}={raw:3d} -> {label}")
        return label

