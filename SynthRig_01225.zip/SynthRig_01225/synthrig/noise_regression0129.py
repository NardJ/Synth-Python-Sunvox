"""Standalone offline noise/sub playback test for shared SunVox note routing."""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from sunvox.api import Slot, init, deinit
from sunvox.types import INIT_FLAG
import sunvox.dll as dll
from .engine09 import SynthRig
from .mod_matrix import blank_matrix, encode
from .offline0102 import OfflineAudio, rms, estimate_pitch, output_wav

RATE=44100

def run(output_dir='recordings/noise', pitch_lfo_mode='native', save_wav=True):
    flags=int(INIT_FLAG.OFFLINE|INIT_FLAG.AUDIO_FLOAT32|INIT_FLAG.ONE_THREAD|INIT_FLAG.NO_DEBUG_OUTPUT)
    rc=init(None,RATE,2,flags)
    if rc<0:raise RuntimeError(f'SunVox offline init failed: {rc}')
    steps=[];record=[]
    def check(name,ok,**metrics):
        steps.append({'check':name,'status':'PASS' if ok else 'FAIL',**metrics})
    try:
        with Slot() as slot:
            rig=SynthRig(slot,pitch_lfo_mode=pitch_lfo_mode,offline=True)
            assert slot.play()>=0
            with OfflineAudio(rig,dll) as ren:
                rig.all_notes_off()
                rig.load_mod_matrix(blank_matrix())
                params={'master.level':105, 'osc1.level':0,'osc2.level':0,
                        'sub.level':100,'noise.level':100,'amp.attack':0,
                        'amp.decay':0,'amp.sustain':127,'amp.release':0,
                        'filter.cutoff':127,'filter.resonance':0,'filter.env_amount':0,
                        'effects.delay':0,'effects.reverb':0,'effects.chorus':0}
                for key,val in params.items():rig.set_parameter(key,val)
                rig.set_output_gain_db(0)
                for source in ('osc1','osc2','sub','noise'):
                    rig.set_source_enabled(source,source in ('sub','noise'))
                rig.tick(force=True);ren.render(.17)
                rig.note_on(60,110);ren.render(.16)
                rig.set_source_enabled('noise',False)
                sub=ren.render(.20);record.append(sub)
                rig.set_source_enabled('noise',True)
                rig.set_source_enabled('sub',False)
                noise=ren.render(.20);record.append(noise)
                rig.set_source_enabled('sub',True)
                both=ren.render(.20);record.append(both)
                sr,nr,br=rms(sub),rms(noise),rms(both)
                check('sub_alone_audible',sr>.001, rms=sr)
                check('noise_alone_audible',nr>.001, rms=nr)
                check('sub_and_noise_simultaneous',br>max(sr,nr)*1.04,sub_rms=sr,noise_rms=nr,both_rms=br)
                check('sub_pitch_still_C2',abs((estimate_pitch(sub[:,0],low=40,high=180) or 0)-65.41)<1.0)
                rig.set_source_enabled('sub',False)
                unmod=ren.render(.20)
                matrix=blank_matrix();matrix[7][1]=encode(1,127) # BIAS -> NOISE LEVEL on AD
                rig.load_mod_matrix(matrix)
                ren.render(.08)
                mod=ren.render(.22);record.append(mod)
                mod_ratio=rms(mod)/max(rms(unmod),1e-15)
                check('noise_matrix_route_changes_audio',mod_ratio>1.07,ratio=mod_ratio)
                rig.load_mod_matrix(blank_matrix());ren.render(.08)
                rig.set_source_enabled('sub',True)
                rig.pitch_bend=1.;rig.tick(force=True);ren.render(.1)
                up=ren.render(.22);record.append(up)
                hz=estimate_pitch(up[:,0],low=40,high=180)
                # Noise is broadband and masks pitch detection; isolate sub for pitch check.
                rig.set_source_enabled('noise',False);ren.render(.1)
                up_sub=ren.render(.20)
                sub_hz=estimate_pitch(up_sub[:,0],low=40,high=180)
                check('sub_pitchbend_plus_two_semitones',sub_hz is not None and abs(sub_hz-73.42)<1.0,frequency_hz=sub_hz)
                rig.set_source_enabled('noise',True);rig.pitch_bend=0.;rig.tick(force=True)
                ren.render(.05)
                rig.note_off(60)
                ren.render(.18)
                tail=ren.render(.26)
                check('noise_and_sub_stop_after_release',rms(tail)<.00015,tail_rms=rms(tail))
                # Four voices can enter and exit without a stuck noise voice.
                for n in (60,64,67,72):rig.note_on(n,100)
                chord=ren.render(.24);record.append(chord)
                for n in (60,64,67,72):rig.note_off(n)
                ren.render(.25)
                quiet=ren.render(.25)
                check('four_voice_noise_polyphony_and_release',rms(chord)>.002 and rms(quiet)<.00015,
                      chord_rms=rms(chord),after_rms=rms(quiet))
    finally:deinit()
    folder=Path(output_dir);folder.mkdir(parents=True,exist_ok=True)
    result={'version':'0.12.9','mode':pitch_lfo_mode,'checks':steps,
            'summary':{'PASS':sum(x['status']=='PASS' for x in steps),'FAIL':sum(x['status']=='FAIL' for x in steps)}}
    (folder/f'noise_regression_{pitch_lfo_mode}.json').write_text(json.dumps(result,indent=2)+'\n')
    if save_wav:
        output_wav(folder/f'noise_regression_{pitch_lfo_mode}.wav',np.concatenate(record,axis=0))
    print(f"NOISE TEST {pitch_lfo_mode}: {result['summary']}",flush=True)
    for x in steps:print(x,flush=True)
    return result
