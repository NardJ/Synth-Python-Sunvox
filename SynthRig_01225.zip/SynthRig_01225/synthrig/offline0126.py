"""Real native SunVox regression tests for fixed two-layer APC patch routing."""
from __future__ import annotations
from pathlib import Path
import json
import numpy as np
from .offline0125 import run as previous_run
from .offline0102 import OfflineAudio,RATE,rms,apply_baseline,estimate_pitch
from .mod_matrix import blank_matrix,encode


def patch_layer_audio_checks(folder,mode):
    import sunvox.dll as dll
    from sunvox.api import Slot,init,deinit
    from sunvox.types import INIT_FLAG
    flags=int(INIT_FLAG.OFFLINE|INIT_FLAG.AUDIO_FLOAT32|INIT_FLAG.ONE_THREAD|INIT_FLAG.NO_DEBUG_OUTPUT)
    if init(None,RATE,2,flags)<0:raise RuntimeError('SunVox audio offline kon niet starten')
    results=[]
    def check(name,ok,**values):
        results.append({'check':name,'status':'PASS' if ok else 'FAIL',**values})
        print(('PASS' if ok else 'FAIL'),name,values,flush=True)
    try:
        from .engine09 import SynthRig
        with Slot() as slot:
            rig=SynthRig(slot,pitch_lfo_mode=mode,offline=True)
            apply_baseline(rig,waveform=2)
            rig.set_source_enabled('sub',True)
            rig.set_parameter('sub.level',85)
            assert slot.play()>=0
            with OfflineAudio(rig,dll) as audio:
                audio.render(.2);rig.note_on(60,95);audio.render(.3)
                base=rms(audio.render(.35))
                # AD: A=BIAS, D=SUB level, route at row 7 col 0.
                matrix=blank_matrix();matrix[7][0]=encode(1,127)
                rig.load_mod_matrix(matrix)
                gain=rms(audio.render(.45))
                check('AD_bias_to_sub_changes_real_audio',gain>base*1.01,
                      base_rms=round(base,7),modified_rms=round(gain,7))
                rig.load_mod_matrix(blank_matrix());audio.render(.25)
                after=rms(audio.render(.30))
                check('AD_off_restores_baseline',abs(after-base)<base*.15,
                      restored_rms=round(after,7))
                # AD: BIAS -> DELAY MIX, with long enough time for wet tail.
                rig.note_off(60);audio.render(.4)
                rig.set_parameter('effects.delay',0)
                matrix=blank_matrix();matrix[7][4]=encode(1,127)
                rig.load_mod_matrix(matrix)
                rig.note_on(60,100);audio.render(.25)
                rig.note_off(60);audio.render(.08)
                tail=rms(audio.render(.34))
                check('AD_bias_to_delay_produces_wet_tail',tail>.00005,tail_rms=round(tail,7))
                rig.load_mod_matrix(blank_matrix());audio.render(.4)
                # BC: second source LFO2 -> first-layer pitch on OSC1.
                apply_baseline(rig,waveform=0)
                rig.note_on(60,110);audio.render(.2)
                matrix=blank_matrix();matrix[0][0]=encode(2,111)
                rig.load_mod_matrix(matrix);moving=audio.render(.55)[:,0]
                v=rig.voices[0]
                check('BC_lfo2_to_pitch_writes_phase_safe_pitch',len(moving)>1000 and
                      abs(v.patch_pitch_smooth[1])>.00001,
                      smooth_pitch=round(v.patch_pitch_smooth[1],6))
                rig.note_off(60);audio.render(.4)
                # BD: second-source triggered pulse => second-layer reverb.
                matrix=blank_matrix();matrix[6][5]=encode(3,127)
                rig.load_mod_matrix(matrix)
                rig.note_on(60,105);audio.render(.09)
                check('BD_trigger_to_reverb_controls_wet',rig.last_reverb_wet is not None and rig.last_reverb_wet>0,
                      reverb_wet=rig.last_reverb_wet)
                rig.note_off(60);audio.render(.3)
                rig.load_mod_matrix(blank_matrix())
                check('all_routes_clear',not rig.mod_matrix.has_routes())
    finally:deinit()
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    (folder/'patch_layers_audio.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf8')
    return {key:sum(item['status']==key for item in results) for key in ('PASS','FAIL')}


def run(output_dir='recordings',save_wav=True,wave_offsets=None,pitch_calibration=-12.,pitch_lfo_mode='native'):
    base=previous_run(output_dir=output_dir,save_wav=save_wav,wave_offsets=wave_offsets,
                      pitch_calibration=pitch_calibration,pitch_lfo_mode=pitch_lfo_mode)
    extra=patch_layer_audio_checks(output_dir,pitch_lfo_mode)
    result={'version':'0.12.6','mode':pitch_lfo_mode,
            'summary':{k:base['summary'][k]+extra[k] for k in ('PASS','FAIL')},
            'previous':base['summary'],'layers':extra}
    (Path(output_dir)/'summary_0126.json').write_text(json.dumps(result,indent=2)+'\n')
    print('SynthRig 0.12.6 offline:',result['summary'],flush=True)
    return result
