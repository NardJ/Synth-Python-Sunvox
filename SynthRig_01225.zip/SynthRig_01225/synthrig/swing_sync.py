"""SWING input clock observer and 24-PPQN transport. No MIDI/audio imports.

Wire counters record only received messages, never local APC commands. Clock
may arrive while stopped; it measures tempo but must not start playback.
"""
from collections import Counter, deque
from dataclasses import dataclass
import json
import os
from pathlib import Path
import time

PPQN = 24
CLOCKS_PER_STEP = 6
CLOCK_TIMEOUT = .75


def read_swing_messages(port, rig, sync, apc=None, now=None):
    """A vanished MIDI endpoint must not take the other controllers down."""
    if sync.input_error is not None:
        return []
    try:
        return list(port.iter_pending())
    except (OSError, RuntimeError, ValueError) as exc:
        now = time.monotonic() if now is None else now
        if apc is not None:
            apc.router.clear('swing')
            if apc.clock == 'swing':
                apc.set_playing(False, now)
        else:
            for note in list(sync.held_notes):
                rig.note_off(note)
        sync.held_notes.clear()
        sync.input_error = str(exc)[:160]
        sync.running = False
        sync.lost = True
        sync.position = 0
        sync.counts['input_errors'] += 1
        sync._event('input_disconnected', now)
        return []


def handle_swing_input(message, rig, sync, apc=None, now=None):
    """Live input path, shared by the launcher and integration tests."""
    now = time.monotonic() if now is None else now
    if apc is not None:
        apc.swing_clock(message, now)
    else:
        _release_if_lost(rig, sync, now)
        sync.feed(message, now)
    if apc is not None and message.type in ('note_on', 'note_off'):
        if message.type == 'note_on' and message.velocity > 0:
            apc.router.on('swing', message.note, message.velocity)
        else:
            apc.router.off('swing', message.note)
    else:
        rig.handle_swing(message)


def _release_if_lost(rig, sync, now):
    if sync.check_timeout(now):
        for note in list(sync.held_notes):
            rig.note_off(note)
        sync.held_notes.clear()


def tick_swing_input(rig, sync, apc=None, now=None):
    """Idle watchdog also works with no APC connected."""
    now = time.monotonic() if now is None else now
    if apc is not None:
        apc.tick(now)
    else:
        _release_if_lost(rig, sync, now)


@dataclass(frozen=True)
class SyncEvent:
    kind: str
    tick: int | None = None


class SwingSync:
    def __init__(self, port=None, timeout=CLOCK_TIMEOUT):
        if not .3 <= timeout <= 5:
            raise ValueError('Clock-timeout moet tussen 0.3 en 5 seconden liggen')
        self.port = port
        self.timeout = float(timeout)
        self.running = False
        self.lost = False
        self.position = 0  # index of NEXT clock, zero = first step downbeat
        self.last_clock = None
        self.run_clock = None
        self.armed_at = None
        self.bpm = None
        self.clock_times = deque(maxlen=25)
        self.counts = Counter()
        self.held_notes = set()
        self.events = deque(maxlen=32)
        self.last_transport = None
        self.input_error = None

    def _event(self, kind, now):
        self.events.append({'event': kind, 'time_monotonic': now,
                            'next_tick': self.position})

    def arm(self, now, *, reset=True):
        if reset:
            self.position = 0
        self.running = True
        self.lost = False
        self.armed_at = now
        self.run_clock = None
        # A pause is not a slow clock interval. Keep the last estimate for the
        # first gate, then measure the resumed stream from fresh timestamps.
        self.clock_times.clear()

    def feed(self, message, now=None):
        now = time.monotonic() if now is None else now
        kind = message.type
        if kind in ('note_on', 'note_off'):
            down = kind == 'note_on' and message.velocity > 0
            self.counts['note_on' if down else 'note_off'] += 1
            if down:
                self.held_notes.add(message.note)
            else:
                self.held_notes.discard(message.note)
            return None
        if kind not in ('start', 'stop', 'continue', 'clock'):
            return None
        self.counts[kind] += 1
        if kind == 'clock':
            if self.last_clock is not None and now - self.last_clock > self.timeout:
                self.clock_times.clear()
                self.bpm = None
            self.last_clock = now
            self.clock_times.append(now)
            if len(self.clock_times) >= 7:
                span = now - self.clock_times[0]
                if span > 0:
                    bpm = 60 * (len(self.clock_times) - 1) / (PPQN * span)
                    self.bpm = bpm if 10 <= bpm <= 500 else None
            if self.running:
                self.run_clock = now
                tick = self.position
                self.position += 1
                return SyncEvent(kind, tick)
            return SyncEvent(kind)
        self.last_transport = kind
        self._event(kind, now)
        if kind == 'start':
            self.arm(now)
        elif kind == 'stop':
            self.running = False  # keep the cursor for MIDI Continue
        elif self.lost:
            # After a lost clock the phase is unknown. Require a fresh START.
            self._event('continue_ignored_after_timeout', now)
            return None
        elif not self.running:
            self.arm(now, reset=False)
        return SyncEvent(kind)

    def check_timeout(self, now=None):
        now = time.monotonic() if now is None else now
        reference = self.run_clock if self.run_clock is not None else self.armed_at
        if self.running and reference is not None and now - reference >= self.timeout:
            self.running = False
            self.lost = True
            self.position = 0
            self.counts['timeouts'] += 1
            self._event('clock_lost', now)
            return True
        return False

    def snapshot(self, now=None):
        now = time.monotonic() if now is None else now
        age = None if self.last_clock is None else max(0, now - self.last_clock)
        receiving = age is not None and age < self.timeout and self.input_error is None
        state = ('lost' if self.lost else 'waiting' if self.running and self.run_clock is None
                 else 'playing' if self.running else 'stopped')
        return {'transport': state, 'last_transport': self.last_transport,
                'input_error': self.input_error,
                'clock_receiving': receiving,
                'clock_age_ms': round(age * 1000) if age is not None else None,
                'bpm': round(self.bpm, 1) if receiving and self.bpm else None,
                'ppqn': PPQN, 'clocks_per_step': CLOCKS_PER_STEP,
                'next_tick': self.position, 'timeout_seconds': self.timeout,
                'counts': {k: self.counts[k] for k in
                           ('clock', 'start', 'continue', 'stop', 'timeouts', 'input_errors', 'note_on', 'note_off')},
                'held_notes': sorted(self.held_notes)}

    def save_report(self, path, *, clock_source, now=None):
        """Small atomic report, independent of audio recording and GUI."""
        data = {'format': 'SynthRig SWING sync 1', 'version': '0.12.25',
                'input_port': self.port, 'apc_clock_source': clock_source,
                'sync': self.snapshot(now), 'recent_events': list(self.events)}
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name('.' + path.name + '.tmp')
        try:
            temporary.write_text(json.dumps(data, indent=2) + '\n', encoding='utf8')
            os.replace(temporary, path)
        finally:
            temporary.unlink(missing_ok=True)
        return path
