"""Small Canvas adapter for responsive MIDI-monitor visualizations.

Geometry remains expressed in the original 1170x1065 / 720x1035
coordinate systems; both initial shapes and live update coords are scaled.
"""
import tkinter as tk


class ScaledCanvas(tk.Canvas):
    def __init__(self, master, *, scale=1.0, **kwargs):
        self.ui_scale = float(scale)
        super().__init__(master, **kwargs)
        self._base_fonts = {}
        self._base_linewidths = {}

    def _points(self, args):
        if len(args) == 1 and isinstance(args[0], (tuple, list)):
            args = args[0]
        return tuple(float(v) * self.ui_scale for v in args)

    def _line_options(self, kw):
        if 'width' in kw and isinstance(kw['width'], (int, float)):
            kw['width'] = max(1, kw['width'] * self.ui_scale)
        return kw

    def _remember_width(self, item, width):
        if isinstance(width, (int, float)):
            self._base_linewidths[item] = float(width)
        return item

    def create_line(self, *args, **kw):
        width = kw.get('width')
        item = super().create_line(*self._points(args), **self._line_options(kw))
        return self._remember_width(item, width)

    def create_rectangle(self, *args, **kw):
        width = kw.get('width')
        item = super().create_rectangle(*self._points(args), **self._line_options(kw))
        return self._remember_width(item, width)

    def create_oval(self, *args, **kw):
        width = kw.get('width')
        item = super().create_oval(*self._points(args), **self._line_options(kw))
        return self._remember_width(item, width)

    def create_polygon(self, *args, **kw):
        width = kw.get('width')
        item = super().create_polygon(*self._points(args), **self._line_options(kw))
        return self._remember_width(item, width)

    def create_text(self, *args, **kw):
        font = kw.get('font')
        base = font if isinstance(font, (tuple, list)) and len(font) >= 2 and isinstance(font[1], int) else None
        if base:
            kw['font'] = (base[0], max(6,round(base[1]*self.ui_scale)), *base[2:])
        if 'width' in kw and isinstance(kw['width'], (int,float)):
            kw['width'] *= self.ui_scale
        item = super().create_text(*self._points(args), **kw)
        if base:
            self._base_fonts[item] = base
        return item

    def create_window(self, *args, **kw):
        if 'width' in kw and isinstance(kw['width'], (int,float)):
            kw['width'] *= self.ui_scale
        if 'height' in kw and isinstance(kw['height'], (int,float)):
            kw['height'] *= self.ui_scale
        return super().create_window(*self._points(args), **kw)

    def coords(self, tag_or_id, *args):
        if args:
            return super().coords(tag_or_id, *self._points(args))
        return super().coords(tag_or_id)

    def set_scale(self, new_scale):
        """Resize existing shapes and text while preserving live item IDs."""
        new_scale = float(new_scale)
        if new_scale <= 0:
            raise ValueError('Invalid UI scale')
        ratio = new_scale / self.ui_scale
        super().scale('all', 0, 0, ratio, ratio)
        self.ui_scale = new_scale
        for item, base in self._base_fonts.items():
            self.itemconfigure(item, font=(base[0], max(6,round(base[1]*new_scale)), *base[2:]))
        for item, width in self._base_linewidths.items():
            self.itemconfigure(item, width=max(1,width*new_scale))
