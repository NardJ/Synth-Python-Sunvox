"""0.12.9 legacy quality suite kept byte-for-byte in offline0127; new audit separate."""
from pathlib import Path
import json
from .offline0127 import run as previous_run

def run(**kwargs):
    result=previous_run(**kwargs)
    result['version']='0.12.9'
    output_dir=Path(kwargs.get('output_dir','recordings'))
    output_dir.mkdir(parents=True,exist_ok=True)
    (output_dir/'summary_0129.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
    return result
