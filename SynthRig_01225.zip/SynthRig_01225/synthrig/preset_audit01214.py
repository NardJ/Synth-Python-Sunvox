"""Echte SunVox PCM-beluisternotities voor 16 matrix-fabriekspresets.

De A/B-meting is een indikatie, GEEN blinde luisterstudie. De fases en de
amplitude-envelop verlopen in de tijd; we vergelijken daarom stabiele RMS-
en spectrale kenmerken en noemen een route niet automatisch hoorbaar.
"""
from __future__ import annotations
from pathlib import Path
import json
from .offline0102 import OfflineAudio, RATE, rms, output_wav, spectral_high_ratio
from .presets import PresetManager, factory_route_summary, FACTORY_SOUND_GUIDE
from .session_state import apply_state
from .mod_matrix import blank_matrix
from .fixed_controls import FixedControls


def run(output_dir='recordings', pitch_lfo_mode='native', save_wav=True):
    import numpy as np
    from sunvox.api import Slot, init, deinit
    from sunvox.types import INIT_FLAG
    from .engine09 import SynthRig
    import sunvox.dll as dll
    out=Path(output_dir);out.mkdir(parents=True,exist_ok=True)
    flags=int(INIT_FLAG.OFFLINE|INIT_FLAG.AUDIO_FLOAT32|INIT_FLAG.ONE_THREAD|INIT_FLAG.NO_DEBUG_OUTPUT)
    if init(None,RATE,2,flags)<0:raise RuntimeError('SunVox OFFLINE init mislukt')
    controls=FixedControls()
    presets=PresetManager(controls,out/'_empty_user_presets')
    checks=[];clips=[];entries=[]
    def check(label,ok,**metrics):
        data={'check':label,'status':'PASS' if ok else 'FAIL',**metrics}
        checks.append(data);print(data['status'],label,flush=True)
    try:
        with Slot() as slot:
            rig=SynthRig(slot,offline=True,pitch_lfo_mode=pitch_lfo_mode)
            assert slot.play()>=0
            with OfflineAudio(rig,dll) as driver:
                driver.render(.30)
                items=presets.slots()
                check('16_fabriekspresets',len(items)==16,count=len(items))
                variants=set()
                for idx,(identifier,name,state,_) in enumerate(items,1):
                    matrix=state['mod_matrix']
                    routes=factory_route_summary(idx)
                    variants.update(r['variant'] for r in routes)
                    check(f'patch_{idx:02d}_routes_present',2<=len(routes)<=3 and
                          sum(v is not None for row in matrix for v in row)==len(routes) and
                          all(r['depth']!=64 for r in routes),routes=len(routes))
                    # All factory states are applied through the real engine, not mocked controllers.
                    apply_state(rig,controls,state,pickup=True)
                    rig.all_notes_off()
                    driver.render(.85)
                    rig.note_on(60,112)
                    onset=driver.render(.14)
                    melody=driver.render(.76)
                    rig.note_off(60)
                    tail=driver.render(.55)
                    # Four-voice chord checks clipping for this SAME factory sound.
                    driver.render(.45)
                    for n in (48,52,55,60):rig.note_on(n,90)
                    chord=driver.render(.60)
                    for n in (48,52,55,60):rig.note_off(n)
                    chord_tail=driver.render(.55)
                    peak=float(np.max(np.abs(np.concatenate([melody,tail,chord,chord_tail]))))
                    melody_rms=rms(melody);chord_rms=rms(chord)
                    check(f'patch_{idx:02d}_pcm_four_voices',melody_rms>.0007 and
                          chord_rms>.0007 and peak<.99,
                          single_rms=round(melody_rms,5),chord_rms=round(chord_rms,5),
                          max_peak=round(peak,5))
                    if save_wav:
                        clips.extend((onset,melody,tail,chord,chord_tail,np.zeros((round(.15*RATE),2),dtype='float32')))
                    # Unmodulated dry counterpart with otherwise identical patch and FX.
                    rig.all_notes_off()
                    rig.load_mod_matrix(blank_matrix())
                    driver.render(1.2)  # let transient FX from last chord dissipate
                    rig.note_on(60,112)
                    driver.render(.14)
                    bare=driver.render(.76)
                    rig.note_off(60)
                    driver.render(.42)
                    bare_rms=rms(bare)
                    hot_ratio=spectral_high_ratio(melody.mean(axis=1))
                    bare_ratio=spectral_high_ratio(bare.mean(axis=1))
                    rel_rms=abs(melody_rms-bare_rms)/max(melody_rms,bare_rms,1.e-8)
                    rel_harm=abs(np.log((hot_ratio+1.e-9)/(bare_ratio+1.e-9)))
                    # Exploratory discriminator, no assertion that the user's ear hears it.
                    noticeable=(rel_rms>.06 or rel_harm>.13)
                    entries.append({'slot':idx,'preset':name,'character':FACTORY_SOUND_GUIDE[idx-1],
                        'routes':routes,'single_rms':round(melody_rms,6),
                        'chord_rms':round(chord_rms,6),'peak':round(peak,6),
                        'bare_rms':round(bare_rms,6),
                        'rms_difference_fraction':round(rel_rms,4),
                        'spectral_log_difference':round(rel_harm,4),
                        'modulation_feature_difference':bool(noticeable),
                        'note':'Feature-afwijking is een indicatie, geen gehoortest.'})
                check('vier_kleurcombinaties_in_bibliotheek',variants==set(('AC','AD','BC','BD')),
                      combinations=sorted(variants))
                # Expression-specific: static notes alone cannot judge these patches.
                import mido
                presets.load('3',rig)  # Bright Lead: AFTERTOUCH -> OSC1 PITCH
                rig.handle_swing(mido.Message('aftertouch',value=0))
                rig.all_notes_off();driver.render(.4)
                rig.note_on(60,108);driver.render(.30)
                v=rig.voices[rig.active_notes[60]]
                pitch0=float(v.patch_pitch_smooth[1])
                rig.handle_swing(mido.Message('aftertouch',value=112))
                driver.render(.35)
                pitch1=float(v.patch_pitch_smooth[1])
                check('bright_lead_aftertouch_pitch_reageert',pitch1>pitch0+.035,
                      no_pressure_semitones=round(pitch0,4),
                      pressure_semitones=round(pitch1,4))
                rig.handle_swing(mido.Message('aftertouch',value=0))
                rig.note_off(60);driver.render(.5)
                presets.load('2',rig)  # Deep Sub: KEYTRACK centred on C4
                rig.all_notes_off();driver.render(.25)
                rig.note_on(48,104);driver.render(.22)
                v=rig.voices[rig.active_notes[48]]
                offs=rig.mod_matrix.offsets(rig._patch_sources(v,driver.clock,0.5))
                check('deep_sub_keytrack_C3_active',abs(offs[4])>.03,
                      cutoff_offset=round(offs[4],4))
                rig.note_off(48);driver.render(.5)
                presets.load('15',rig)  # Octave Pulse: periodic LFO -> OSC2 PWM
                rig.all_notes_off();driver.render(.22)
                rig.note_on(60,110);driver.render(.15)
                v=rig.voices[rig.active_notes[60]]
                duty1=v.last_duty[2]
                driver.render(.33);duty2=v.last_duty[2]
                driver.render(.31);duty3=v.last_duty[2]
                check('octave_pulse_PWM2_beweegt',len({duty1,duty2,duty3})>=2,
                      pulse_width_values=[duty1,duty2,duty3])
                rig.note_off(60);driver.render(.5)
    finally:
        deinit()
    if save_wav and clips:
        output_wav(out/f'16_presets_{pitch_lfo_mode}.wav',np.concatenate(clips))
    summary={'PASS':sum(c['status']=='PASS' for c in checks),
             'FAIL':sum(c['status']=='FAIL' for c in checks),
             'measurable_feature_differences':sum(p['modulation_feature_difference'] for p in entries),
             'presets':len(entries)}
    report={'version':'0.12.15','mode':pitch_lfo_mode,'summary':summary,'checks':checks,
            'presets':entries,'limitations':[
              'Offline-test meet echt SunVox PCM, niet menselijke waardering.',
              'De A/B-passage speelt op verschillende tijdstippen, effecten en LFO-fase kunnen verschillen.',
              'Aftertouch en Mod Wheel kunnen pas tijdens een fysieke performance volledig worden beoordeeld.',
              'Output Gain hoger dan +0 dB kan bij extreme patches extra headroom kosten.',
            ]}
    (out/f'preset_audit_{pitch_lfo_mode}.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
    return report
