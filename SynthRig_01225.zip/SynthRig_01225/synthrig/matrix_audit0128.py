"""Exhaustive two-layer route verification using native SunVox DSP.

256 route/pad combinations per engine mode (64 pads * 4 choices).
A clean known test note is used per destination; a *controlled* modulation
source is injected one at a time. This isolates routing from source movement.
The PCM is genuinely rendered by the full SynthRig SunVox signal path.

Crucially, these are not 256 independent listening judgments. Controls that
are close to saturation, depend on filter/amp state, or change a quiet effect
may be reported INCONCLUSIVE. This file never silently changes them to PASS.
"""
from __future__ import annotations

from collections import Counter
import csv
import json
import math
from pathlib import Path

from .mod_matrix import (ModMatrix, blank_matrix, encode, SOURCES, SOURCES_B,
                         DESTINATIONS,DESTINATIONS_D,VARIANTS)
from .offline0102 import OfflineAudio, RATE, rms, estimate_pitch, spectral_high_ratio, apply_baseline

NAMES = tuple(DESTINATIONS) + tuple(DESTINATIONS_D)
SOURCE_NAMES = tuple(SOURCES) + tuple(SOURCES_B)


def _spectral_distance(first,second):
    """A/B difference of normalized spectral bands: insensitive to phase."""
    import numpy as np
    def feature(x):
        x=np.asarray(x[:,0],dtype='float64')
        x=x-np.mean(x)
        power=np.abs(np.fft.rfft(x*np.hanning(len(x))))**2
        f=np.fft.rfftfreq(len(x),1/RATE)
        bands=np.geomspace(70.,11500.,33)
        vals=np.array([power[(f>=lo)&(f<hi)].sum() for lo,hi in zip(bands[:-1],bands[1:])])
        return vals/(vals.sum()+1e-15)
    a,b=feature(first),feature(second)
    return float(np.abs(a-b).sum()/2)


def _audio_metrics(ref, test):
    import numpy as np
    a,b=rms(ref),rms(test)
    ratio=20*math.log10(max(b,1e-12)/max(a,1e-12))
    spectral=_spectral_distance(ref,test)
    peak=float(np.max(np.abs(test)))
    return {'baseline_rms':round(a,7), 'route_rms':round(b,7),
            'loudness_delta_db':round(ratio,3),
            'spectrum_distance':round(spectral,5),
            'peak':round(peak,6)}


def _target_snapshot(rig,index):
    v=next((v for v in rig.voices if v.note is not None),rig.voices[0])
    if index==0:return v.patch_pitch_smooth[1]
    if index==1:return v.patch_pitch_smooth[2]
    if index==2:return v.last_duty[1]
    if index==3:return v.last_duty[2]
    if index==4:return v.last_cutoff
    if index==5:return v.patch_last_resonance
    if index==6:return v.patch_last_levels[1]
    if index==7:return v.patch_last_levels[2]
    if index==8:return v.patch_last_sub
    if index==9:return v.patch_last_noise
    if index in (10,11):return v.last_cutoff
    if index==12:return rig.last_delay_wet
    if index==13:return rig.last_reverb_wet
    if index==14:return rig._last_chorus_wet
    if index==15:return rig._last_output_volume


def _setup(rig, destination):
    # Different *audio excitation* per target; do not claim a SIN PWM test.
    wave=3 if destination in (2,3) else 2
    apply_baseline(rig,waveform=wave)
    rig.set_waveform_index(2,wave)
    # Isolate the respective generator for amplitude destinations, otherwise
    # a quiet oscillator/noise component gets buried under the other three.
    target_source={6:'osc1',7:'osc2',8:'sub',9:'noise'}.get(destination)
    for source in ('osc1','osc2','sub','noise'):
        rig.set_source_enabled(source,target_source is None or source==target_source)
    rig.set_parameter('osc1.level',82)
    rig.set_parameter('osc2.level',77)
    rig.set_parameter('sub.level',62)
    rig.set_parameter('noise.level',43)
    rig.set_parameter('filter.cutoff',65 if destination in (4,5,10,11) else 92)
    rig.set_parameter('filter.resonance',48)
    rig.set_parameter('filter.env_amount',0)
    rig.set_parameter('filter.sustain',127)  # Sustained envelope gives a meaningful ENV AMOUNT test
    rig.set_parameter('filter.keytrack',0)
    rig.set_parameter('amp.attack',0)
    rig.set_parameter('amp.decay',0)
    rig.set_parameter('amp.sustain',127)
    rig.set_parameter('amp.release',0)
    rig.set_parameter('pwm.depth',0)
    rig.set_parameter('effects.delay',0)
    rig.set_parameter('effects.reverb',0)
    rig.set_parameter('effects.chorus',0)
    rig.set_output_gain_db(0)
    rig.tick(force=True)


def _source_checks(rig,clock):
    """Live (unforced) source sanity samples, not substitute for audio tests."""
    v=rig.voices[0]
    original=rig._patch_sources
    # Exercise each actual source with an appropriate representative input:
    # note above middle C (KEY), nonzero channel pressure, Mod Wheel and
    # an early note age (TRIGGER); restore the physical engine state afterward.
    previous=(v.note,v.started,rig.channel_pressure,rig.mod_wheel)
    rigs=[]
    try:
        v.note=72
        v.started=clock-.01
        rig.channel_pressure=.65
        rig.mod_wheel=.70
        for time_shift in (.02,.07,.10):
            now=clock+time_shift
            lfo=math.sin(2*math.pi*(rig._lfo_phase+.37*time_shift))
            rigs.append(original(v,now,lfo))
    finally:
        v.note,v.started,rig.channel_pressure,rig.mod_wheel=previous
    result=[]
    for i,label in enumerate(SOURCE_NAMES):
        values=[float(row[i]) for row in rigs]
        result.append({'source':label,'nonzero':any(abs(x)>1e-6 for x in values),
                       'values':[round(x,4) for x in values]})
    return result


def _probe_mode(folder,mode):
    import numpy as np
    import sunvox.dll as dll
    from sunvox.api import Slot,init,deinit
    from sunvox.types import INIT_FLAG
    from .engine09 import SynthRig

    flags=int(INIT_FLAG.OFFLINE|INIT_FLAG.AUDIO_FLOAT32|INIT_FLAG.ONE_THREAD|INIT_FLAG.NO_DEBUG_OUTPUT)
    if init(None,RATE,2,flags)<0:raise RuntimeError('Offline SunVox init mislukt')
    records=[];sources=None
    try:
        with Slot() as slot:
            rig=SynthRig(slot,pitch_lfo_mode=mode,offline=True)
            assert slot.play()>=0
            with OfflineAudio(rig,dll) as render:
                # One fresh sound patch per destination; prevents FX carry-over.
                # Every route is rendered and measured as actual SunVox audio.
                for dst in range(16):
                    _setup(rig,dst)
                    rig.load_mod_matrix(blank_matrix())
                    render.render(.10)
                    note=72 if dst==11 else 60
                    rig.note_on(note,104)
                    render.render(.19)
                    if sources is None:sources=_source_checks(rig,render.clock)
                    for src in range(16):
                        row=src%8;src_layer=int(src>=8)
                        col=dst%8;dst_layer=int(dst>=8)
                        variant=src_layer*2+dst_layer
                        matrix=blank_matrix()
                        matrix[row][col]=encode(variant,127)
                        m=ModMatrix();m.load(matrix)
                        probe=[0.]*16;probe[src]=1.
                        baseline=[0.]*16
                        expected=m.offsets(probe)
                        alt=m.offsets(baseline)
                        isolated=(expected[dst]>.99 and all(abs(v)<1e-12 for j,v in enumerate(expected) if j!=dst) and
                                  all(abs(v)<1e-12 for v in alt))
                        # Tests use a constant injected source to distinguish DSP routing
                        # from naturally varying LFO, velocity, pressure and envelopes.
                        rig._patch_sources=lambda v,now,lfo,p=probe:p
                        rig.load_mod_matrix(blank_matrix())
                        render.render(.17)
                        base=_target_snapshot(rig,dst)
                        ref=render.render(.16)
                        rig.load_mod_matrix(matrix)
                        render.render(.22)
                        target=_target_snapshot(rig,dst)
                        new=render.render(.16)
                        metrics=_audio_metrics(ref,new)
                        signal_written=(target is not None and (base is None or
                                        abs(float(target)-float(base))>1e-6))
                        # Explicit no-signal situation is NOT a successful audio test.
                        measurable=(abs(metrics['loudness_delta_db'])>=.28 or
                                    metrics['spectrum_distance']>=.018)
                        # Some effects are mainly audible after releasing the key;
                        # these get separate wet-tail tests below, not false positives.
                        status='FAIL' if not isolated or not signal_written else ('MEASURABLE' if measurable else 'INCONCLUSIVE')
                        records.append({
                            'pad_row':row+1,'pad_col':col+1,
                            'variant':VARIANTS[variant],
                            'source':SOURCE_NAMES[src],
                            'destination':NAMES[dst],
                            'router_isolated':bool(isolated),
                            'sunvox_control_changed':bool(signal_written),
                            'control_before':base,'control_after':target,
                            'audio_measurable':bool(measurable),
                            'status':status,**metrics})
                    rig.note_off(note)
                    render.render(.3)
                    print(f'  [{mode}] destination {dst+1}/16 {NAMES[dst]}: '+
                          ', '.join(f'{k}={v}' for k,v in Counter(x['status'] for x in records if x['destination']==NAMES[dst]).items()),
                          flush=True)
    finally:
        deinit()
    folder=Path(folder)
    folder.mkdir(parents=True,exist_ok=True)
    with (folder/f'matrix_audit_{mode}.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(records[0]));writer.writeheader();writer.writerows(records)
    (folder/f'matrix_audit_{mode}.json').write_text(json.dumps({'mode':mode,'sources':sources,'routes':records},indent=2)+'\n',encoding='utf8')
    return records,sources



def _stress_checks(mode):
    """Representative simultaneous-routing / signed-depth / click checks."""
    import numpy as np
    import sunvox.dll as dll
    from sunvox.api import Slot,init,deinit
    from sunvox.types import INIT_FLAG
    from .engine09 import SynthRig

    flags=int(INIT_FLAG.OFFLINE|INIT_FLAG.AUDIO_FLOAT32|INIT_FLAG.ONE_THREAD|INIT_FLAG.NO_DEBUG_OUTPUT)
    if init(None,RATE,2,flags)<0:raise RuntimeError('SunVox stress initialisatie mislukt')
    checks=[]
    def check(name,success,**values):
        checks.append({'check':name,'status':'PASS' if success else 'FAIL',**values})
    try:
        with Slot() as slot:
            rig=SynthRig(slot,pitch_lfo_mode=mode,offline=True)
            assert slot.play()>=0
            with OfflineAudio(rig,dll) as audio:
                _setup(rig,4)
                rig.note_on(60,107)
                audio.render(.18)
                vals=[0.]*16;vals[0]=1.;vals[5]=1.
                rig._patch_sources=lambda *_:vals
                baseline=rig.voices[0].last_cutoff
                m=blank_matrix();m[0][4]=encode(0,85);m[5][4]=encode(0,85)
                rig.load_mod_matrix(m);audio.render(.25)
                combined=rig.voices[0].last_cutoff
                sound=audio.render(.12)
                check('two_sources_same_cutoff_add',combined is not None and baseline is not None
                      and combined>baseline,baseline=baseline,both=combined)
                m[5][4]=None
                rig.load_mod_matrix(m);audio.render(.25)
                single=rig.voices[0].last_cutoff
                check('remove_one_route_preserves_other',single is not None and baseline<single<combined,
                      one=single,both=combined)
                m[5][4]=encode(0,27) # negative depth
                rig.load_mod_matrix(m);audio.render(.25)
                opposite=rig.voices[0].last_cutoff
                check('opposite_signed_depth_cancels',opposite is not None and opposite<single,
                      one=single,opposite=opposite)
                check('multi_route_audio_no_clipping',float(np.max(np.abs(sound)))<.99,
                      peak=round(float(np.max(np.abs(sound))),6))
                rig.note_off(60);rig.load_mod_matrix(blank_matrix());audio.render(.35)
                # True SIN during pitch modulation: 0 -> + -> - -> 0.
                apply_baseline(rig,waveform=0)
                rig._patch_sources=lambda *_:[0.,0.,0.,0.,0.,0.,0.,1.]+[0.]*8
                rig.note_on(60,100);audio.render(.16)
                steady=audio.render(.23)[:,0]
                m=blank_matrix();m[7][0]=encode(0,96)
                rig.load_mod_matrix(m);up=audio.render(.28)[:,0]
                m[7][0]=encode(0,31)
                rig.load_mod_matrix(m);down=audio.render(.28)[:,0]
                rig.load_mod_matrix(blank_matrix());normal=audio.render(.28)[:,0]
                stable_step=float(np.max(np.abs(np.diff(steady))))
                maximum_step=float(np.max(np.abs(np.diff(np.concatenate((up,down,normal))))))
                check('rapid_pitch_modulation_no_large_click',maximum_step<max(.014,stable_step*3.2),
                      sine_step=round(stable_step,7),transition_step=round(maximum_step,7))
                rig.note_off(60);audio.render(.30)
    finally:
        deinit()
    return checks

def run(output_dir='recordings',pitch_lfo_mode='native'):
    """One mode per run; run with --pitch-lfo-mode events for second mode."""
    folder=Path(output_dir)
    records,sources=_probe_mode(folder,pitch_lfo_mode)
    stress=_stress_checks(pitch_lfo_mode)
    (folder/f'matrix_stress_{pitch_lfo_mode}.json').write_text(json.dumps(stress,indent=2)+'\n',encoding='utf8')
    count=Counter(x['status'] for x in records)
    missing_sources=[s['source'] for s in sources if not s['nonzero']]
    results={'version':'0.12.8','mode':pitch_lfo_mode,
             'routes':len(records), 'source_checks':sources, 'sources_not_exercised':missing_sources,
             'stress_checks':stress,
             'summary':{'PASS':count['MEASURABLE'], 'WARN':count['INCONCLUSIVE'], 'FAIL':count['FAIL']+sum(x['status']=='FAIL' for x in stress)},
             'limitations':['Constant synthetic source stimulus isolates a route; natural movement and audio are separately assessed.',
                            'Spectral/RMS changes are a screen for audibility, not a human listening test.',
                            'Inconclusive PCM is not silently counted as PASS.',
                            'Some routings need dedicated note or FX-tail tests to yield an audible change.']}
    summary=(f"SynthRig 0.12.8 MATRIX AUDIT — {pitch_lfo_mode}\n"
             f"Routes: {len(records)}\nMeasured: {count['MEASURABLE']}\n"
             f"Inconclusive: {count['INCONCLUSIVE']}\nRouting/control FAIL: {count['FAIL']}\n"
             f"Source stimuli not exercised: {missing_sources}\n"
             f"Stress tests: {sum(x['status']=='PASS' for x in stress)}/{len(stress)} PASS\n"
             "This does not prove that each route is musically useful under every preset.\n")
    (folder/f'matrix_audit_{pitch_lfo_mode}.txt').write_text(summary,encoding='utf8')
    (folder/f'matrix_audit_summary_{pitch_lfo_mode}.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf8')
    print(summary,flush=True)
    return results
