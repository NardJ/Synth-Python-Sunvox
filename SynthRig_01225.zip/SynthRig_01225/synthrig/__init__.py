"""SynthRig 0.11.1 — SunVox, MIDI hardware, presets, state en debug gescheiden."""
