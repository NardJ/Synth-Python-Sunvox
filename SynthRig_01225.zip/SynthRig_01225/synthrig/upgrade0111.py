"""Non-destructive one-time upgrade from a sibling SynthRig_0110 installation.

Only copies defaults if destination does not exist. Never overwrites user files.
"""
from __future__ import annotations
from pathlib import Path
import shutil


def migrate_0110(new_root, previous_root, state_path, preset_dir,
                 *, do_state=True, do_presets=True):
    new_root=Path(new_root).resolve()
    previous_root=Path(previous_root).resolve()
    state_path=Path(state_path).resolve()
    preset_dir=Path(preset_dir).resolve()
    actions=[]
    # Only operate on the standard locations: don't touch an explicit custom path.
    if do_state and state_path==new_root/'state'/'last_session.json':
        src=previous_root/'state'/'last_session.json'
        if src.is_file() and not state_path.exists():
            state_path.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(src,state_path)
            actions.append(f'Sessie uit 0.11.0 overgenomen: {state_path.name}')
    if do_presets and preset_dir==new_root/'presets'/'user':
        src_dir=previous_root/'presets'/'user'
        if src_dir.is_dir():
            for src in sorted(src_dir.glob('*.json')):
                dest=preset_dir/src.name
                if not dest.exists():
                    preset_dir.mkdir(parents=True,exist_ok=True)
                    shutil.copy2(src,dest)
                    actions.append(f'Preset overgenomen: {src.name}')
    return actions
