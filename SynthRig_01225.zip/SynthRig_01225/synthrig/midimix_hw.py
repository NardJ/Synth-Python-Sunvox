"""MIDI-hardware feedback voor MIDImix. Los van SunVox en GUI.

De MIDImix gebruikt Note-On velocity > 0 voor LED AAN en Note-On
velocity 0 voor LED UIT; Note-Off zet zijn LEDs niet uit.
"""
from __future__ import annotations
import time


def describe_midi(msg):
    """Maak de echte inkomende MIDI-velden leesbaar voor diagnose."""
    typ = getattr(msg, 'type', '')
    ch = getattr(msg, 'channel', None)
    if typ in ('note_on','note_off'):
        note = getattr(msg,'note','?')
        vel = getattr(msg,'velocity','?')
        event = 'druk' if typ=='note_on' and isinstance(vel,int) and vel>0 else 'los'
        return f'{typ} ch={ch} note={note} velocity={vel} ({event})'
    if typ=='control_change':
        return f'control_change ch={ch} cc={msg.control} value={msg.value}'
    return str(msg)


def desired_leds(controls, state):
    """Gewenste fysieke LED-status uit de persistente synthstatus, niet de knopdruk."""
    states = {}
    waves = (state.get('wave1'),state.get('wave2'))
    wave_notes = [int(n) for n in controls.factory_wave_notes]
    for i,note in enumerate(wave_notes):
        states[note] = (waves[i//4] == i%4)
    for note,source in controls.source_notes.items():
        states[int(note)] = bool(state.get('enabled',{}).get(source,False))
    for note in controls.reserved:
        states[int(note)] = False
    return states


def sync_leds_for_button(leds, state, msg, solo_note=27):
    """Update physical LEDs for a normal button, never for SOLO itself.

    SOLO is handled explicitly by the gesture logic: short press may show a
    selected preset; when no slot is selected it is PANIC *without any LED
    writes*. In particular, a SOLO note_off must not force a 16-LED refresh.
    The GUI uses the same LED snapshot as the physical port.
    """
    if msg.type not in ('note_on','note_off'):
        return False
    if getattr(msg,'note',None)==solo_note:
        return False
    leds.sync(state,force=(msg.type=='note_off' or getattr(msg,'velocity',1)==0))
    return True


class MidiMixLEDs:
    def __init__(self,output,controls):
        self.output=output
        self.controls=controls
        self.last={}
        self._all_led_notes=set(int(x) for x in controls.factory_wave_notes)
        self._all_led_notes.update(int(n) for n in controls.source_notes)
        self._all_led_notes.update(int(n) for n in controls.reserved)
        self.preset_until=0.0
        self._overlay=False
        self.display_leds={}  # read-only mirror of commands actually sent
        self.revision=0
        self.preset_number=None

    def _write_led(self, note, on):
        from mido import Message
        self.output.send(Message('note_on',channel=0,note=int(note),
                                 velocity=127 if on else 0))
        self.display_leds[int(note)]=bool(on)
        self.revision+=1

    def display_snapshot(self):
        return {'notes':{str(k):v for k,v in self.display_leds.items()},
                'overlay':bool(self._overlay),
                'preset':self.preset_number if self._overlay else None,
                'revision':self.revision}

    def sync(self,state,force=False):
        if self._overlay and time.monotonic()<self.preset_until:
            return
        if self._overlay:
            self._overlay=False
            self.preset_number=None
            force=True
        wanted=desired_leds(self.controls,state)
        for note,on in sorted(wanted.items()):
            if force or self.last.get(note)!=on:
                # MIDImix verwacht NOTE ON, ook voor het uitschakelen van LED.
                self._write_led(note,on)
                self.last[note]=on

    def show_preset(self,number,duration=1.0):
        """Unary count on 8 amber MUTE + 8 red REC LEDs; restore after duration."""
        if not 1<=number<=16:raise ValueError('Presetnummer moet 1..16 zijn')
        ordered=tuple(self.controls.factory_wave_notes)+tuple(int(n) for n in (3,6,9,12,15,18,21,24))
        self.preset_until=time.monotonic()+duration
        self._overlay=True
        self.preset_number=number
        for idx,note in enumerate(ordered):
            on=idx<number
            self._write_led(note,on)
        # Hardware LEDs must resync from the synth once the temporary count expires.
        self.last.clear()

    def tick(self,state):
        if self._overlay and time.monotonic()>=self.preset_until:
            self.sync(state,force=True)

    def clear(self):
        # Explicitly clear ALL controlled LEDs, including those whose state was
        # temporarily masked by the preset count (which clears self.last).
        for note in sorted(self._all_led_notes):
            self._write_led(note,False)
        self.last.clear()
        self._overlay=False
        self.preset_number=None
