"""SunVox regression suite plus real-DSP APC sequencing and patch routing tests."""
from __future__ import annotations
from pathlib import Path
import json
import numpy as np
from .offline0113 import run as previous_run
from .offline0102 import OfflineAudio, RATE, rms, apply_baseline
from .apc_mk2 import APCminiMk2


def apc_audio_checks(directory, mode):
    import mido
    import sunvox.dll as dll
    from sunvox.api import Slot, init, deinit
    from sunvox.types import INIT_FLAG
    from .engine09 import SynthRig
    flags=int(INIT_FLAG.OFFLINE|INIT_FLAG.AUDIO_FLOAT32|INIT_FLAG.ONE_THREAD|INIT_FLAG.NO_DEBUG_OUTPUT)
    version=init(None,RATE,2,flags)
    if version<0:raise RuntimeError('SunVox offline init mislukt: '+str(version))
    results=[]
    def record(name,ok,**details):
        row={'check':name,'status':'PASS' if ok else 'FAIL',**details}
        print(row['status'],name,details,flush=True)
        results.append(row)
    try:
        with Slot() as slot:
            rig=SynthRig(slot,pitch_lfo_mode=mode,offline=True)
            apply_baseline(rig)
            assert slot.play()>=0
            with OfflineAudio(rig,dll) as audio:
                audio.render(.25)
                apc=APCminiMk2(None,rig,pattern_dir=Path(directory)/'patterns',logger=lambda _:None)
                apc.handle(mido.Message('note_on',note=101,velocity=127)) # seq
                apc.handle(mido.Message('note_on',note=0,velocity=127))   # C3 on step 1
                start=audio.clock
                apc.set_playing(True,start)
                apc.tick(start)
                active=rms(audio.render(.075))
                apc.tick(audio.clock)
                audio.render(.4)
                apc.set_playing(False,audio.clock)
                audio.render(.4)
                silent=rms(audio.render(.25))
                record('apc_pattern_makes_audio_then_stops',active>.0001 and silent<.00014,
                       on_rms=round(active,7),after_stop_rms=round(silent,7))
                # A Swing-held C3 must not be cancelled by APC gate expiry.
                apply_baseline(rig)
                apc.router.panic()
                apc.router.on('swing',60,95)
                audio.render(.15)
                apc.router.on('apc',60,110)
                apc.router.off('apc',60)
                sustained=rms(audio.render(.18))
                apc.router.off('swing',60)
                audio.render(.35)
                released=rms(audio.render(.2))
                record('apc_off_does_not_cancel_swing_key',sustained>.0001 and released<.00014,
                       held_rms=round(sustained,7),released_rms=round(released,7))
                # Patch pad creates a real modulation route, not an FX knob edit.
                apc.handle(mido.Message('note_on',note=100,velocity=127)) # patch
                apc.handle(mido.Message('note_on',note=60,velocity=127)) # BIAS -> cutoff
                record('apc_patch_true_routing',rig.mod_matrix.grid[7][4] is not None and
                       rig.reverb_mix == 0.0 and rig.filter_env_amount == 0.0,
                       route=rig.mod_matrix.grid[7][4])
                apc.close()
    finally:
        deinit()
    directory=Path(directory);directory.mkdir(parents=True,exist_ok=True)
    (directory/'apc_audio_checks.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf8')
    return {'PASS':sum(x['status']=='PASS' for x in results),
            'FAIL':sum(x['status']=='FAIL' for x in results)}


def run(output_dir='recordings',save_wav=True,wave_offsets=None,pitch_calibration=-12.,pitch_lfo_mode='native'):
    base=previous_run(output_dir=output_dir,save_wav=save_wav,wave_offsets=wave_offsets,
                      pitch_calibration=pitch_calibration,pitch_lfo_mode=pitch_lfo_mode)
    apc=apc_audio_checks(output_dir,pitch_lfo_mode)
    total={key:base['summary'][key]+apc[key] for key in ('PASS','FAIL')}
    result={'version':'0.12.5','mode':pitch_lfo_mode,'summary':total,'previous':base['summary'],'apc':apc}
    (Path(output_dir)/'summary_0120.json').write_text(json.dumps(result,indent=2)+'\n')
    print('SYNTHRIG 0.12.5 (oude suite)',total,flush=True)
    return result
