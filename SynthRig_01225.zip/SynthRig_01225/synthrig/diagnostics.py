"""Optionele observaties en reproduceerbaar PWM-testsignaal.

Geen DSP of audio in Python. SunVox blijft verantwoordelijk voor de audio.
"""
from __future__ import annotations
import platform
import sys
import time
from importlib import metadata
from .engine import WAVEFORMS, MAX_VOICES
from .pwm_observe import pwm_snapshot


def environment_snapshot(swing=None, midimix=None, sunvox_version=None):
    try:
        package = metadata.version('sunvox-dll-python')
    except metadata.PackageNotFoundError:
        package = 'onbekend'
    return {
        'python': sys.version.split()[0],
        'platform': platform.system(),
        'architecture': platform.machine(),
        'sunvox_python_package': package,
        'sunvox_version': str(sunvox_version) if sunvox_version is not None else None,
        'midi_swing': swing,
        'midi_midimix': midimix,
        'note': 'Audio wordt via monitor van Linux-output opgenomen; systeemgeluid kan ook meekomen.',
    }


def state_snapshot(rig):
    """Actuele logische toestand EN de werkelijk teruggelezen SunVox-controls."""
    get = rig.slot.get_module_ctl_value
    def value(mod, ctl):
        return int(get(mod, ctl[0], 0))
    return {
        'pwm': pwm_snapshot(rig),
        'osc': {
            str(i): {
                'waveform': WAVEFORMS[rig.wave_selection[i]][1],
                'volume_fraction': rig.osc1_level if i == 1 else rig.osc2_level,
                'tuning': rig.osc_tuning[i].copy(),
                'native_waveform': value(rig.osc1 if i == 1 else rig.osc2,
                                         rig.wave1 if i == 1 else rig.wave2),
                'native_duty': value(rig.osc1 if i == 1 else rig.osc2,
                                     rig.duty1 if i == 1 else rig.duty2),
                'native_amplifier_volume': value(rig.amp1 if i == 1 else rig.amp2,
                                                 rig.volume1 if i == 1 else rig.volume2),
                'native_tuning_semitones': int(rig.get_display_ctl(
                    rig.note_router1 if i == 1 else rig.note_router2,
                    rig.transpose1 if i == 1 else rig.transpose2)),
                'native_tuning_fine': int(rig.get_display_ctl(
                    rig.note_router1 if i == 1 else rig.note_router2,
                    rig.finetune1 if i == 1 else rig.finetune2)),
            } for i in (1, 2)
        },
        'filter': {
            'cutoff_native': value(rig.filt, rig.cutoff),
            'resonance_native': value(rig.filt, rig.resonance),
            'type': value(rig.filt, rig.filter_type),
            'wet': value(rig.filt, rig.filter_mix),
            'rolloff': value(rig.filt, rig.rolloff),
        },
        'mix_fraction_osc2': rig.vco_mix,
        'active_notes': sorted(rig.active_notes),
        'last_midi_cc': {str(k): v for k, v in sorted(rig.last_cc.items())},
        'mappings': {str(k): v['target'] for k, v in sorted(rig.mappings.items())},
        'dc_blocker_enabled': bool(getattr(rig, 'dc_blocker_enabled', False)),
        'max_voices': MAX_VOICES,
        'caution': 'Native SunVox-waarden zijn momentopnames, geen garanties voor de hoorbare audiowaarde.',
    }


def run_pwm_check(rig, recorder, duration_baseline=3.0, duration_pwm=7.0, duration_after=2.0):
    """Deterministische A/B test met één noot, zonder MIDI-controllerbewegingen.

    De functie verandert alleen parameters die een normale MIDI-CC ook kan wijzigen.
    Het gaat om een apart debugscenario, niet om de normale synthesizerinstellingen.
    """
    rig.set_parameter('osc1.waveform', 127)      # PULSE
    rig.set_parameter('osc2.waveform', 127)
    rig.set_parameter('osc1.level', 127)
    rig.set_parameter('osc2.level', 0)
    rig.set_parameter('osc.mix', 0)
    rig.set_parameter('osc1.pulse_width', 64)    # ~50%
    rig.set_parameter('osc2.pulse_width', 64)
    rig.set_parameter('filter.cutoff', 110)
    rig.set_parameter('filter.resonance', 0)
    rig.set_parameter('master.level', 65)         # gematigd niveau
    rig.set_parameter('pwm.rate', 68)             # ~0.8Hz
    rig.set_parameter('pwm.depth', 0)
    rig.pwm.phase = 0.0
    rig.pwm.last_time = None
    rig._pwm_last_tick = 0.0
    rig.tick_pwm(force=True)

    def stage(name, depth_raw, seconds):
        rig.set_parameter('pwm.depth', depth_raw)
        recorder.log('test_stage', {
            'name': name, 'depth_cc': depth_raw,
            'duration_seconds': seconds,
            'state': state_snapshot(rig),
        })
        print(f'  Testfase: {name} ({seconds:.1f}s)')
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            rig.tick_pwm()
            time.sleep(.002)

    try:
        rig.note_on(53, 90)  # F3, vaste velocity
        recorder.log('test_note_on', {'note': 53, 'velocity': 90})
        stage('basis_zonder_pwm', 0, duration_baseline)
        stage('pwm_aan', 80, duration_pwm)
        stage('pwm_weer_uit', 0, duration_after)
    finally:
        rig.all_notes_off()
        recorder.log('test_note_off', {'note': 53})


class ReadbackAudit:
    """Controleer na settling meerdere keren werkelijk opgeslagen controls.

    De API verwerkt set_module_ctl_value via een SunVox-event. Daardoor mag
    een directe readback nog een vorige waarde bevatten. We claimen nooit
    dat een overeenkomende waarde bewijst dat de DSP-audio al is verwerkt.
    Alleen vanuit main/eventloop-thread gebruiken (niet uit audiothread).
    """
    def __init__(self, rig, recorder, delays=(0., 0.15, 0.50)):
        self.rig = rig
        self.recorder = recorder
        self.delays = delays
        self.pending = []

    def _controls(self):
        r=self.rig
        return [
            ('osc1.waveform', r.osc1, r.wave1, WAVEFORMS[r.wave_selection[1]][0]),
            ('osc2.waveform', r.osc2, r.wave2, WAVEFORMS[r.wave_selection[2]][0]),
            ('osc1.duty', r.osc1, r.duty1, r._pwm_last_sent[1]),
            ('osc2.duty', r.osc2, r.duty2, r._pwm_last_sent[2]),
            ('filter.rolloff', r.filt, r.rolloff, 1),
        ]

    def schedule(self, reason='snapshot'):
        now=time.monotonic()
        # Expected values are frozen at scheduling; a subsequent MIDI action
        # can supersede them, and in that case this is tagged 'superseded'.
        expected=[(name, module, ctl[0], wanted) for name,module,ctl,wanted in self._controls()]
        self.recorder.log('readback_requested', {'reason': reason,
             'expected': {x[0]: x[3] for x in expected}})
        for delay in self.delays:
            self.pending.append((now+delay, reason, delay, expected))

    def poll(self):
        now=time.monotonic()
        for item in list(self.pending):
            due,reason,delay,expected=item
            if now < due: continue
            self.pending.remove(item)
            live={name:wanted for name,_,_,wanted in self._controls()}
            data=[]
            for name,module,ctl,wanted in expected:
                raw=int(self.rig.slot.get_module_ctl_value(module,ctl,0))
                displayed=int(self.rig.slot.get_module_ctl_value(module,ctl,2))
                superseded=live.get(name)!=wanted
                status=('superseded' if superseded else 'unknown' if wanted is None
                        else 'match' if raw == wanted else 'mismatch')
                data.append({'name':name,'requested_raw':wanted, 'read_raw':raw,
                             'read_display':displayed,'status':status})
            self.recorder.log('readback_audit', {
                'reason':reason,'delay_requested_s':delay,
                'delay_actual_s':round(now-(due-delay),4),'controls':data})


def run_pwm_onset_check(rig, recorder, seconds_pwm=8.0, seconds_off=2.0,
                        progress=None):
    """Een vaste F3 met PWM vanaf de Note ON; fase expliciet nul bij aanslag.

    De PWM-diepte verandert pas na 8 s, voor een referentieperiode zonder PWM.
    Retourneert met NOOT OFF, ook bij fout.
    """
    rig.set_parameter('osc1.waveform', 127)
    rig.set_parameter('osc2.waveform', 127)
    rig.set_parameter('osc1.level', 127)
    rig.set_parameter('osc2.level', 0)
    rig.set_parameter('osc.mix', 0)
    rig.set_parameter('osc1.pulse_width', 64)
    rig.set_parameter('osc2.pulse_width', 64)
    rig.set_parameter('filter.cutoff', 110)
    rig.set_parameter('filter.resonance', 0)
    rig.set_parameter('master.level', 65)
    rig.set_parameter('pwm.rate', 68)
    rig.set_parameter('pwm.depth', 80)
    # Vrijlopende fase uitschakelen voor dit reproduceerbare experiment.
    rig.pwm.phase=0.0
    rig.pwm.last_time=None
    rig._pwm_last_tick=0.0
    rig.tick_pwm(force=True)
    recorder.log('test_setup', {'scenario':'pwm_from_note_on',
                               'state': state_snapshot(rig)})
    try:
        recorder.log('test_stage', {'name':'pwm_vanaf_noot',
                                   'duration_seconds':seconds_pwm,
                                   'state':state_snapshot(rig)})
        rig.note_on(53,90)
        recorder.log('test_note_on', {'note':53,'velocity':90})
        if progress:progress('pwm_vanaf_noot')
        until=time.monotonic()+seconds_pwm
        while time.monotonic()<until:
            rig.tick_pwm()
            if progress:progress(None)
            time.sleep(.002)
        rig.set_parameter('pwm.depth',0)
        recorder.log('test_stage', {'name':'zelfde_noot_pwm_uit',
                                   'duration_seconds':seconds_off,
                                   'state':state_snapshot(rig)})
        if progress:progress('zelfde_noot_pwm_uit')
        until=time.monotonic()+seconds_off
        while time.monotonic()<until:
            rig.tick_pwm()
            if progress:progress(None)
            time.sleep(.002)
    finally:
        rig.all_notes_off()
        recorder.log('test_note_off', {'note':53})
