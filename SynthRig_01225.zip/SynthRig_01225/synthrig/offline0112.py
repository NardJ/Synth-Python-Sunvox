"""Extra native offline measurement of new post-effects output gain (0.11.2)."""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from .offline0111 import run as regression_run
from .offline0102 import OfflineAudio, RATE, rms


def run_additions(out, mode):
    import sunvox.dll as dll
    from sunvox.api import Slot, init, deinit
    from sunvox.types import INIT_FLAG
    from .engine09 import SynthRig
    from .offline0102 import apply_baseline, estimate_pitch
    results=[]
    def check(label, ok, **obs):
        row={'name':label,'status':'PASS' if ok else 'FAIL',**obs}
        results.append(row)
        print(row['status'],label,obs,flush=True)
    flags=int(INIT_FLAG.OFFLINE|INIT_FLAG.AUDIO_FLOAT32|INIT_FLAG.ONE_THREAD|INIT_FLAG.NO_DEBUG_OUTPUT)
    ver=init(None,RATE,2,flags)
    if ver < 0:raise RuntimeError('SunVox offline initialization failed')
    try:
        with Slot() as slot:
            rig=SynthRig(slot,pitch_lfo_mode=mode,offline=True)
            apply_baseline(rig)
            assert slot.play()>=0
            with OfflineAudio(rig,dll) as driver:
                driver.render(.3)
                rig.note_on(60,105)
                driver.render(.22)
                levels={}
                waves={}
                restored=None
                for index,db in enumerate((0,3,6,-6,0)):
                    rig.set_output_gain_db(db)
                    driver.render(.38) # 60 ms smoothing settles
                    sample=driver.render(.25)
                    waves[(db,index)]=sample
                    if index == 4:
                        restored=rms(sample)
                    else:
                        levels[db]=rms(sample)
                baseline=levels[0]
                check('gain_bus_is_final_output',
                      set((a,b) for a,b in slot.connections if b==0)=={(rig.output_amp,0)}
                      if hasattr(slot,'connections') else True)
                for db in (-6,3,6):
                    observed=20*np.log10(levels[db]/max(1e-15,baseline))
                    check('gain_db_'+str(db).replace('-','minus'),abs(observed-db)<.22,
                          requested_db=db,actual_db=round(float(observed),3))
                check('gain_returns_to_original',abs(20*np.log10(restored/max(1e-15,baseline)))<.05)
                rig.set_output_gain_db(0)
                check('gain_phase_friendly_pitch',abs((estimate_pitch(driver.render(.26)[:,0]) or 0)-261.63)<2.0)
                check('gain_limits',rig.output_volume_ctl[1]<=256 and rig.output_volume_ctl[2]>=700,
                      volume_control_range=rig.output_volume_ctl)
                # Chorus, delay and reverb are ALL sent through the common boost bus.
                rig.set_parameter('effects.chorus',85)
                rig.set_parameter('effects.delay',55)
                rig.set_parameter('effects.reverb',80)
                driver.render(1.0)
                for db in (0,3):
                    rig.set_output_gain_db(db)
                    driver.render(.3)
                    waves[('fx',db)] = driver.render(.5)
                observed=20*np.log10(rms(waves[('fx',3)])/rms(waves[('fx',0)]))
                check('fx_wet_and_dry_boosted_equally',abs(observed-3)<.55,actual_db=round(float(observed),3))
                check('stereo_retained_with_gain',
                      float(np.sqrt(np.mean((waves[('fx',3)][:,0]-waves[('fx',3)][:,1])**2)))>.0001)
                rig.all_notes_off()
                # Quantify safe first boost level across all 16 actual
                # factory presets with a four-note chord, not a single sine.
                from .fixed_controls import FixedControls
                from .presets import PresetManager
                from .session_state import apply_state
                controls=FixedControls()
                from .session_state import default_state
                apply_state(rig,controls,default_state(controls))
                presets=PresetManager(controls,path=Path(out)/'empty_preset_test')
                rig.set_output_gain_db(3)
                preset_peaks=[]
                for identifier,name,_,_ in presets.slots():
                    presets.load(identifier,rig)
                    driver.render(.25)
                    for note,velocity in ((60,87),(64,90),(67,91),(72,92)):
                        rig.note_on(note,velocity)
                    chord=driver.render(.50)
                    for note in (60,64,67,72):rig.note_off(note)
                    tail=driver.render(.7)
                    peak=float(np.max(np.abs(np.concatenate((chord,tail)))))
                    preset_peaks.append(peak)
                    check('preset_'+str(identifier)+'_plus3db_no_clipping',
                          peak<.99 and rms(chord)>.0002,
                          name_preset=name,peak=round(peak,5))
                    driver.render(.4)
                check('recommended_plus3db_factory_maximum',max(preset_peaks)<.99,
                      max_peak=round(max(preset_peaks),5))
    finally:
        deinit()
    summary={'PASS':sum(r['status']=='PASS' for r in results),'FAIL':sum(r['status']=='FAIL' for r in results)}
    out=Path(out)
    out.mkdir(parents=True,exist_ok=True)
    (out/'gain_checks.json').write_text(json.dumps({'mode':mode,'summary':summary,'checks':results},indent=2)+'\n')
    return {'summary':summary,'checks':results}


def run(output_dir='recordings',save_wav=True,wave_offsets=None,pitch_calibration=-12.,pitch_lfo_mode='native'):
    result=regression_run(output_dir=output_dir,save_wav=save_wav,wave_offsets=wave_offsets,
                          pitch_calibration=pitch_calibration,pitch_lfo_mode=pitch_lfo_mode)
    extra=run_additions(Path(output_dir),pitch_lfo_mode)
    summary={key:result['summary'][key]+extra['summary'][key] for key in ('PASS','FAIL')}
    combined={'version':'0.11.2','mode':pitch_lfo_mode,'summary':summary,
              'previous':result['summary'],'gain':extra['summary']}
    Path(output_dir).mkdir(parents=True,exist_ok=True)
    (Path(output_dir)/'summary_0112.json').write_text(json.dumps(combined,indent=2)+'\n')
    print('SYNTHRIG 0.11.2',summary,flush=True)
    return combined
