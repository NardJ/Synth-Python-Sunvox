"""SynthRig 0.11 - factory/user presets and a simple reversible A/B manager.

The sound parameter payload is the same validated session schema as 0.10.2,
with optional 0.11 FX values. We never overwrite a factory preset.
"""
from __future__ import annotations
import json
import os
import tempfile
import re
from copy import deepcopy
from pathlib import Path
from .session_state import capture_state, default_state, apply_state, DEFAULT_RAW
from .mod_matrix import (validate_matrix,blank_matrix,validate_groups,legacy_groups,
                         migrate_state_matrix,MATRIX_LAYOUT,encode,VARIANTS,SOURCES,SOURCES_B,
                         DESTINATIONS,DESTINATIONS_D)

PRESET_DIR = Path(__file__).resolve().parents[1] / 'presets' / 'user'

# 1-based factory selection; deliberately moderate output and distinct envelopes.
_FACTORY = (
 ('Analog Bass', {'osc1.level':99,'osc2.level':48,'sub.level':25,'noise.level':0,
    'filter.cutoff':49,'filter.resonance':23,'filter.env_amount':72,
    'amp.attack':0,'amp.decay':42,'amp.sustain':90,'amp.release':26,
    'filter.attack':0,'filter.decay':39,'filter.sustain':20,
    'effects.chorus':0}, (2,3), ('osc1','osc2','sub'), (0,0)),
 ('Deep Sub Bass', {'osc1.level':72,'osc2.level':0,'sub.level':90,'noise.level':0,
    'filter.cutoff':54,'filter.resonance':12,'filter.env_amount':15,
    'amp.attack':0,'amp.decay':44,'amp.sustain':112,'amp.release':24},
    (0,0), ('osc1','sub'), (0,0)),
 ('Bright Lead', {'osc1.level':94,'osc2.level':66,'sub.level':0,'noise.level':0,
    'filter.cutoff':98,'filter.resonance':25,'amp.attack':2,
    'amp.decay':47,'amp.sustain':110,'amp.release':27,
    'osc2.finetune':68,'performance.portamento':24,'effects.chorus':15},
    (2,3), ('osc1','osc2'), (16,5)),
 ('PWM Strings', {'osc1.level':86,'osc2.level':75,'sub.level':0,'noise.level':0,
    'filter.cutoff':87,'filter.resonance':15,'amp.attack':55,'amp.decay':49,
    'amp.sustain':98,'amp.release':73,'pwm.depth':64,'pwm.rate':34,
    'effects.chorus':66,'osc2.finetune':67},
    (3,3), ('osc1','osc2'), (0,28)),
 ('Soft Pad', {'osc1.level':76,'osc2.level':68,'sub.level':15,'noise.level':0,
    'filter.cutoff':75,'filter.resonance':13,'amp.attack':76,
    'amp.decay':60,'amp.sustain':95,'amp.release':89,
    'filter.env_amount':28,'lfo.filter_depth':18,'effects.chorus':76},
    (1,0), ('osc1','osc2','sub'), (12,72)),
 ('Glass Keys', {'osc1.level':80,'osc2.level':54,'sub.level':0,'noise.level':0,
    'filter.cutoff':115,'filter.resonance':8,'amp.attack':0,
    'amp.decay':52,'amp.sustain':24,'amp.release':53,
    'effects.chorus':20,'performance.velocity':112},
    (0,1), ('osc1','osc2'), (44,34)),
 ('Noise Sweep', {'osc1.level':65,'osc2.level':0,'sub.level':0,'noise.level':37,
    'filter.cutoff':66,'filter.resonance':53,'filter.env_amount':95,
    'filter.attack':66,'filter.decay':83,'amp.attack':37,
    'amp.decay':66,'amp.sustain':83,'amp.release':70,
    'effects.chorus':18},
    (2,0), ('osc1','noise'), (16,49)),
 ('Vintage Brass', {'osc1.level':84,'osc2.level':77,'sub.level':0,'noise.level':0,
    'filter.cutoff':74,'filter.resonance':22,'filter.env_amount':79,
    'filter.attack':12,'filter.decay':55,'filter.sustain':45,
    'amp.attack':20,'amp.decay':48,'amp.sustain':104,'amp.release':35,
    'osc2.finetune':66,'effects.chorus':24},
    (2,2), ('osc1','osc2'), (8,12)),
 ('Detuned Saw Lead', {'osc1.level':83,'osc2.level':80,'sub.level':0,'noise.level':0,
    'osc1.finetune':62,'osc2.finetune':67,'filter.cutoff':92,'filter.resonance':17,
    'amp.attack':5,'amp.decay':45,'amp.sustain':105,'amp.release':38,
    'effects.chorus':19}, (2,2), ('osc1','osc2'), (17,19)),
 ('Warm Poly', {'osc1.level':74,'osc2.level':70,'sub.level':8,'noise.level':0,
    'osc1.finetune':63,'osc2.finetune':66,'filter.cutoff':71,'filter.resonance':10,
    'amp.attack':26,'amp.decay':52,'amp.sustain':95,'amp.release':67,
    'effects.chorus':32}, (2,1), ('osc1','osc2','sub'), (0,36)),
 ('Plucked Square', {'osc1.level':89,'osc2.level':18,'sub.level':0,'noise.level':0,
    'filter.cutoff':83,'filter.resonance':9,'amp.attack':0,'amp.decay':22,
    'amp.sustain':0,'amp.release':32,'filter.env_amount':46},
    (3,0), ('osc1','osc2'), (39,24)),
 ('Dream Bell', {'osc1.level':73,'osc2.level':42,'sub.level':0,'noise.level':0,
    'osc2.semitones':76,'filter.cutoff':112,'filter.resonance':15,
    'amp.attack':1,'amp.decay':71,'amp.sustain':19,'amp.release':85,
    'effects.chorus':16}, (0,1), ('osc1','osc2'), (34,62)),
 ('Resonant Sweep', {'osc1.level':75,'osc2.level':60,'sub.level':0,'noise.level':10,
    'filter.cutoff':47,'filter.resonance':60,'filter.env_amount':98,
    'filter.attack':59,'filter.decay':80,'amp.attack':42,
    'amp.sustain':75,'amp.release':69}, (2,3), ('osc1','osc2','noise'), (0,48)),
 ('Slow Motion Pad', {'osc1.level':62,'osc2.level':60,'sub.level':12,'noise.level':0,
    'filter.cutoff':78,'filter.resonance':12,'amp.attack':82,
    'amp.decay':78,'amp.sustain':87,'amp.release':94,
    'lfo.filter_depth':12,'effects.chorus':64}, (1,2), ('osc1','osc2','sub'), (21,70)),
 ('Octave Pulse', {'osc1.level':82,'osc2.level':52,'sub.level':0,'noise.level':0,
    'osc2.semitones':76,'filter.cutoff':100,'filter.resonance':9,
    'amp.attack':0,'amp.decay':51,'amp.sustain':93,'amp.release':34,
    'effects.chorus':10}, (3,3), ('osc1','osc2'), (12,15)),
 ('Vintage Organ', {'osc1.level':76,'osc2.level':53,'sub.level':14,'noise.level':0,
    'osc2.semitones':76,'filter.cutoff':113,'filter.resonance':0,
    'amp.attack':2,'amp.decay':0,'amp.sustain':120,'amp.release':40,
    'effects.chorus':22}, (3,0), ('osc1','osc2','sub'), (0,25)),

)


# 0.12.14 — Zestien muzikaal ontworpen fabriekspatches.  Alleen de factory
# definitie verandert; bestaande user slot_XX.json bestanden blijven leidend.
# Route = (rij 0..7, kolom 0..7, variant AC/AD/BC/BD, diepte 0..127).
# 64 is nul, 0/127 zijn maximum negatieve/positieve modulatie.
# Kies doorgaans subtiele dieptes voor pitch, resonance en feedback.
FACTORY_MATRIX_ROUTES = (
    ((1,4,'AC',100),(2,6,'AC',78)),                               # Analog Bass
    ((2,0,'BD',88),(5,4,'AC',76)),                                # Deep Sub Bass
    ((3,0,'AC',86),(4,4,'AC',91),(7,6,'AD',76)),                 # Bright Lead
    ((0,2,'AC',102),(0,3,'BC',97),(2,4,'BC',83)),                # PWM Strings
    ((0,4,'BC',84),(4,0,'BC',75),(2,5,'AD',77)),                 # Soft Pad
    ((1,7,'BC',90),(2,4,'AC',78),(1,4,'AD',78)),                 # Glass Keys
    ((1,1,'AD',105),(3,4,'BC',88),(7,5,'BC',71)),                # Noise Sweep
    ((1,4,'AC',99),(2,0,'BC',77),(3,4,'AC',77)),                 # Vintage Brass
    ((0,1,'AC',83),(4,4,'AC',95)),                               # Detuned Saw Lead
    ((0,4,'BC',82),(3,6,'AD',85),(5,4,'AC',71)),                 # Warm Poly
    ((2,2,'BC',99),(2,4,'AC',84)),                               # Plucked Square
    ((7,1,'BC',73),(5,4,'BD',78)),                               # Dream Bell
    ((3,5,'BC',78),(1,4,'AC',103),(6,1,'AD',77)),                # Resonant Sweep
    ((4,4,'BC',83),(0,5,'BD',79),(2,6,'BC',78)),                 # Slow Motion Pad
    ((0,3,'AC',98),(2,7,'AC',82),(6,4,'BC',77)),                 # Octave Pulse
    ((5,4,'AC',77),(4,6,'AD',85),(3,6,'BC',77)),                 # Vintage Organ
)

FACTORY_SOUND_GUIDE = (
    'Percussieve SAW-bas: filter-envelope plus velocity op oscillatorniveau',
    'Diepe sinusbas: mod-envelope op sub en keytracking op filter',
    'Expressieve lead: aftertouch-pitch, modwheel-filter en chorusbias',
    'Twee PULSE-oscillatoren: verschillende LFOs op de pulsbreedte',
    'Langzame pad: LFO2-filter, soepele random pitch, velocity-reverb',
    'Dynamische keys: AMP-envelope op OSC2 en filter/echoexpressie',
    'Effectklank: filter-envelope op noise, LFO3-filter en S&H-resonantie',
    'Brass: filter-envelope plus korte pitch-envelope en aftertouch',
    'Analoge detune-lead: kleine toonhoogtebeweging en modwheel-cutoff',
    'Poly-pad: LFO2-filter, aftertouch-chorus en keytracking',
    'Pluck: mod-envelope op pulsewidth en velocity op cutoff',
    'Belachtige toon: kleine S&H-detune met opbouwende delaymix',
    'Filter sweep met LFO3-resonantie, noise-trigger en envelope',
    'Trage pad met smooth-random-filter en bewegende reverb',
    'Octaaf-pulse: PWM, velocity op oscillatorniveau en trigger-filter',
    'Organ: keytracking, chorus op modwheel en zachte tremolo',
)

def factory_route_summary(slot):
    """Aangegeven fabrieksroutes voor documentatie en A/B-audiotests."""
    result=[]
    for row,col,variant,depth in FACTORY_MATRIX_ROUTES[slot-1]:
        source=(SOURCES if variant[0]=='A' else SOURCES_B)[row]
        target=(DESTINATIONS if variant[1]=='C' else DESTINATIONS_D)[col]
        result.append(dict(row=row+1,col=col+1,variant=variant,source=source,
                           destination=target,depth=depth))
    return result

def factory_presets(controls):
    base=default_state(controls)
    result=[]
    for index,(name,overrides,waves,enabled,fx) in enumerate(_FACTORY):
        state=deepcopy(base)
        for key,raw in overrides.items():
            if key not in state['raw']:
                raise ValueError(f'Factory preset {name}: onbekende control {key}')
            state['raw'][key]=raw
        state['raw']['master.level']=95
        state['waveforms']={'1':waves[0],'2':waves[1]}
        state['enabled']={src:src in enabled for src in ('osc1','osc2','sub','noise')}
        state['fx']={'delay':fx[0],'reverb':fx[1]}
        # De matrix staat los van de MIDImix-basisstanden: een preset bevat
        # beide.  Een pad heeft maximaal EEN actieve route (keuze A).
        grid=blank_matrix()
        for row,col,variant,depth in FACTORY_MATRIX_ROUTES[index]:
            if grid[row][col] is not None:
                raise ValueError(f'Dubbele route op fysiek pad {row+1},{col+1}')
            grid[row][col]=encode(VARIANTS.index(variant),depth)
        state['mod_matrix']=grid
        state['mod_groups']=legacy_groups(grid)
        state['mod_matrix_layout']=MATRIX_LAYOUT
        result.append((name,state))
    return result


def validate_preset(data,controls):
    """Strictly validate shape/range and layout before applying to DSP."""
    current=default_state(controls)
    if not isinstance(data,dict) or data.get('schema')!=1:
        raise ValueError('Onbekend presetformaat')
    layout=data.get('layout_targets')
    if not isinstance(layout,dict) or any(current['layout_targets'].get(cc)!=target
                                           for cc,target in layout.items()):
        raise ValueError('Preset hoort bij een andere MIDI-mapping')
    raw=data.get('raw')
    optional={'effects.delay','effects.reverb'}
    if not isinstance(raw,dict) or set(raw)-set(current['raw']) or set(current['raw'])-set(raw)-optional or not all(
        type(v)==int and 0<=v<=127 for v in raw.values()):
        raise ValueError('Preset bevat ongeldige controllerstanden')
    wave=data.get('waveforms')
    if not isinstance(wave,dict) or set(wave)!={'1','2'} or not all(type(v)==int and 0<=v<=3 for v in wave.values()):
        raise ValueError('Ongeldige golfvorm')
    enabled=data.get('enabled')
    if not isinstance(enabled,dict) or set(enabled)!={'osc1','osc2','sub','noise'} or not all(type(v)==bool for v in enabled.values()):
        raise ValueError('Ongeldige bronstatus')
    fx=data.get('fx',{'delay':0,'reverb':0})
    if not isinstance(fx,dict) or set(fx)!={'delay','reverb'} or not all(type(v)==int and 0<=v<=127 for v in fx.values()):
        raise ValueError('Ongeldige effectstanden')
    valid, archived=migrate_state_matrix(data)
    valid['fx']=dict(fx)
    if archived:
        print(f'WAARSCHUWING: preset heeft {len(archived)} oude matrixroutes; '
              'niet hergebruikt, gearchiveerd in mod_legacy_routes.')
    valid['mod_matrix']=validate_matrix(data.get('mod_matrix',blank_matrix()))
    valid['mod_groups']=(validate_groups(data['mod_groups']) if 'mod_groups' in data
                         else legacy_groups(valid['mod_matrix']))
    valid['raw']={**current['raw'],**raw}
    for effect in ('delay','reverb'):
        if 'effects.'+effect not in raw:
            valid['raw']['effects.'+effect]=fx[effect]
    valid['layout_targets']=current['layout_targets']
    return valid


class PresetManager:
    def __init__(self,controls,path=PRESET_DIR):
        self.controls=controls
        self.path=Path(path)
        self.selected=-1
        self.before=None
        self.loaded=None
        self.compare_b=True

    SLOT_COUNT=16

    def _slot_path(self,number):
        if not 1<=number<=self.SLOT_COUNT:raise ValueError('Presetslot moet 1..16 zijn')
        return self.path/f'slot_{number:02d}.json'

    def slots(self):
        result=[]
        for number,(factory_name,factory_state) in enumerate(factory_presets(self.controls),1):
            name=factory_name; state=deepcopy(factory_state); user=False
            dest=self._slot_path(number)
            if dest.exists():
                try:
                    stored=json.loads(dest.read_text(encoding='utf8'))
                    state=validate_preset(stored['state'],self.controls)
                    name=str(stored.get('name',factory_name))[:80]
                    user=True
                except (ValueError,KeyError,OSError,TypeError) as exc:
                    print(f'WAARSCHUWING: preset-slot {number} ongeldig, fabrieksklank gebruikt: {exc}')
            result.append((str(number),name,state,user))
        return result

    def all(self):
        items=[(ident,name,state) for ident,name,state,_ in self.slots()]
        if self.path.exists():
            for f in sorted(self.path.glob('*.json')):
                if re.fullmatch(r'slot_\d\d',f.stem):continue
                try:
                    data=json.loads(f.read_text(encoding='utf8'))
                    state=validate_preset(data['state'],self.controls)
                    name=str(data['name'])
                    if not (1<=len(name)<=80):raise ValueError('Naam ongeldig')
                    items.append((f.stem,name,state))
                except (KeyError,ValueError,OSError,TypeError) as exc:
                    print(f'WAARSCHUWING: preset {f.name} overgeslagen: {exc}')
        return items

    def listings(self):
        return [(identifier,name) for identifier,name,_ in self.all()]

    def selection(self):
        if not 0<=self.selected<self.SLOT_COUNT:
            return {'slot':None,'name':'Sessiestand (geen preset gekozen)','user':False}
        _,name,_,user=self.slots()[self.selected]
        return {'slot':self.selected+1,'name':name,'user':user}

    def load(self,reference,rig):
        items=self.all()
        found=next(((idx,item) for idx,item in enumerate(items) if
                    str(reference).lower() in (item[0].lower(),item[1].lower())),None)
        if found is None:raise ValueError('Preset niet gevonden: '+str(reference))
        idx,(identifier,name,state)=found
        candidate=validate_preset(state,self.controls)
        self.before=capture_state(rig,self.controls)
        rig.all_notes_off()
        apply_state(rig,self.controls,candidate,pickup=True)
        self.loaded=deepcopy(candidate)
        self.selected=idx if idx<self.SLOT_COUNT else -1
        self.compare_b=True
        return f'Preset {identifier}: {name} geladen (A/B: p compare)'

    def step(self,direction,rig):
        index=(self.selected+direction)%self.SLOT_COUNT if self.selected>=0 else (0 if direction>0 else self.SLOT_COUNT-1)
        return self.load(str(index+1),rig)

    def save_slot(self,rig):
        if not 0<=self.selected<self.SLOT_COUNT:
            raise ValueError('Kies eerst met BANK LEFT/RIGHT een van de 16 slots')
        number=self.selected+1
        _,name,_,_=self.slots()[self.selected]
        state=validate_preset(capture_state(rig,self.controls),self.controls)
        payload={'format':'SynthRig slot 1','slot':number,'name':name,'state':state}
        self.path.mkdir(parents=True,exist_ok=True)
        dest=self._slot_path(number)
        # Atomic replacement; factory preset is always kept in Python.
        with tempfile.NamedTemporaryFile('w',encoding='utf8',dir=self.path,
                                         prefix='.slot_',suffix='.tmp',delete=False) as f:
            tmp=Path(f.name)
            try:
                json.dump(payload,f,ensure_ascii=False,indent=2)
                f.write('\n');f.flush();os.fsync(f.fileno())
            except BaseException:
                tmp.unlink(missing_ok=True)
                raise
        os.replace(tmp,dest)
        self.loaded=deepcopy(state)
        return f'Preset-slot {number:02d} opgeslagen: {name} ({dest.name})'

    def restore_factory(self,number,rig):
        number=int(number)
        dest=self._slot_path(number)
        if dest.exists():dest.unlink()
        return self.load(str(number),rig)

    def compare(self,rig):
        if self.before is None or self.loaded is None:
            raise ValueError('Laad eerst een preset voor A/B')
        current=capture_state(rig,self.controls)
        rig.all_notes_off()
        if self.compare_b:
            self.loaded=current  # capture user tweaks of B
            apply_state(rig,self.controls,self.before,pickup=True)
            self.compare_b=False
            return 'A: vorige patch'
        self.before=current  # capture user tweaks of A
        apply_state(rig,self.controls,self.loaded,pickup=True)
        self.compare_b=True
        return 'B: geladen preset'

    def save(self,name,rig):
        name=name.strip()
        if not 1<=len(name)<=80 or not re.fullmatch(r'[\w\- ]+',name,flags=re.UNICODE):
            raise ValueError('Presetnaam: 1-80 letters, cijfers, spaties, - of _')
        slug=re.sub(r'[^a-z0-9_-]+','-',name.lower()).strip('-')
        if not slug:
            raise ValueError('Naam bevat geen bruikbare bestandsnaam')
        if re.fullmatch(r'slot_\d\d',slug):
            raise ValueError('Naam slot_XX is gereserveerd voor fysieke presets')
        self.path.mkdir(parents=True,exist_ok=True)
        dest=self.path/(slug+'.json')
        if dest.exists():raise FileExistsError(f'Preset bestaat al: {dest.name}. Gebruik een andere naam.')
        data={'format':'SynthRig preset 1','name':name,'state':validate_preset(capture_state(rig,self.controls),self.controls)}
        # x mode makes overwriting an existing user preset impossible
        with dest.open('x',encoding='utf8') as f:
            json.dump(data,f,ensure_ascii=False,indent=2)
            f.write('\n')
        return f'Opgeslagen: {name} ({dest})'
