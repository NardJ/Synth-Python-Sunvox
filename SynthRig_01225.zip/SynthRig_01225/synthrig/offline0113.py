"""0.11.3: existing full SunVox suite + new chord/voice-reuse audio tests."""
from __future__ import annotations
from pathlib import Path
import json
import numpy as np
from .offline0112 import run as previous_run
from .offline0102 import OfflineAudio, RATE, rms, apply_baseline


def chord_release_checks(output_dir,mode):
    import sunvox.dll as dll
    from sunvox.api import Slot,init,deinit
    from sunvox.types import INIT_FLAG
    from .engine09 import SynthRig
    flags=int(INIT_FLAG.OFFLINE|INIT_FLAG.AUDIO_FLOAT32|INIT_FLAG.ONE_THREAD|INIT_FLAG.NO_DEBUG_OUTPUT)
    version=init(None,RATE,2,flags)
    if version<0:raise RuntimeError(f'SunVox offline init failed: {version}')
    rows=[]
    try:
        with Slot() as slot:
            rig=SynthRig(slot,pitch_lfo_mode=mode,offline=True)
            apply_baseline(rig)
            rig.set_parameter('amp.release',22) # short, non-zero tail
            assert slot.play()>=0
            with OfflineAudio(rig,dll) as audio:
                audio.render(.3)
                for held in (71,64):
                    rig.all_notes_off()
                    audio.render(.3)
                    rig.note_on(held,95)
                    audio.render(.025)
                    rig.note_off(held)
                    audio.render(.025)
                    rig.note_on(held,95) # new same-note voice
                    audio.render(.025)
                    rig.note_on(60,95)
                    audio.render(.025)
                    rig.note_on(67,95)
                    audio.render(.025)
                    rig.note_on(69,95)   # triggers steal of released first voice
                    held_ok=held in rig.active_notes and rig.voices[rig.active_notes[held]].released is None
                    audio.render(.055)
                    active=rms(audio.render(.07))
                    rig.note_off(held)
                    for n in (60,67,69):rig.note_off(n)
                    audio.render(.4)
                    tail=rms(audio.render(.35))
                    no_orphans=all(v.note is None for v in rig.voices)
                    passed=bool(held_ok and no_orphans and active>.00015 and tail<.00012)
                    row={'test':f'no_stuck_note_after_steal_{held}','status':'PASS' if passed else 'FAIL',
                         'held_note_registered':bool(held_ok),'voices_released':bool(no_orphans),
                         'active_rms':round(active,7),'tail_rms':round(tail,7)}
                    rows.append(row)
                    print(row['status'],row['test'],row,flush=True)
    finally:
        deinit()
    output_dir=Path(output_dir)
    output_dir.mkdir(parents=True,exist_ok=True)
    (output_dir/'stuck_chord_checks.json').write_text(json.dumps({'mode':mode,'checks':rows},indent=2)+'\n')
    return {'PASS':sum(x['status']=='PASS' for x in rows),
            'FAIL':sum(x['status']=='FAIL' for x in rows)}


def run(output_dir='recordings',save_wav=True,wave_offsets=None,pitch_calibration=-12.,pitch_lfo_mode='native'):
    existing=previous_run(output_dir=output_dir,save_wav=save_wav,
                          wave_offsets=wave_offsets,pitch_calibration=pitch_calibration,
                          pitch_lfo_mode=pitch_lfo_mode)
    new=chord_release_checks(output_dir,pitch_lfo_mode)
    total={k:existing['summary'][k]+new[k] for k in ('PASS','FAIL')}
    result={'version':'0.11.3','mode':pitch_lfo_mode,'summary':total,
            'previous':existing['summary'],'stuck_note':new}
    (Path(output_dir)/'summary_0113.json').write_text(json.dumps(result,indent=2)+'\n')
    print('SYNTHRIG 0.11.3',total,flush=True)
    return result
