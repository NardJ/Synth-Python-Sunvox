"""SynthRig 0.9.13: reproduceerbare WAV-kwaliteitscheck op de echte 4-voice engine.

Alleen voor --qualitycheck. Rewire-output-taps vereisen SunVox lock/unlock.
Verandert geen patches of instellingen van de opgeslagen speelsessie.
"""
from __future__ import annotations
from contextlib import contextmanager
import time
from .engine09 import midi_frequency

WAVE_LABELS={5:'SIN',1:'SAW'}


def baseline(rig):
    rig.all_notes_off()
    for k,v in {
        'master.level':110,'osc1.level':105,'osc2.level':0,
        'sub.level':0,'noise.level':0,'osc1.semitones':64,'osc2.semitones':64,
        'osc1.finetune':64,'osc2.finetune':64,
        'filter.cutoff':127,'filter.resonance':0,'filter.env_amount':0,
        'filter.keytrack':0,'lfo.pitch_depth':0,'lfo.filter_depth':0,
        'pwm.depth':0,'amp.attack':0,'amp.decay':0,'amp.sustain':127,'amp.release':0,
    }.items():
        rig.set_parameter(k,v)
    for source in ('osc1','osc2','sub','noise'):
        rig.set_source_enabled(source,source=='osc1')
    rig.set_waveform_index(1,0)
    rig.set_waveform_index(2,0)
    # Niet vertrouwen op een eventwrite zonder hardware-readback.
    rig.ensure_waveforms(timeout=.8,strict=True)
    rig.pitch_bend=0
    rig.mod_wheel=0
    rig.tick(force=True)


def wave_readback(rig,voice=0,osc=1):
    v=rig.voices[voice]
    mod=v.o1 if osc==1 else v.o2
    ctl=v.ctls['wave1' if osc==1 else 'wave2']
    return rig.slot.get_module_ctl_value(mod,ctl[0],0)


def wait(rig,seconds):
    until=time.monotonic()+seconds
    while time.monotonic()<until:
        rig.tick()
        time.sleep(.004)


def emit(recorder, label, duration, **details):
    data={'label':label,'duration':duration,**details}
    print('QUALITY:',label,details,flush=True)
    if recorder and recorder.active:recorder.log('quality_step',data)


def original_gain(rig,v):
    return rig.slot.get_module_ctl_value(v.a1,v.ctls['vol1'][0],0)


def mute_voice(rig,v):
    rig.set_ctl(v.a1,v.ctls['vol1'],0)
    rig.set_ctl(v.a2,v.ctls['vol2'],0)
    rig.set_ctl(v.sub_gain,v.ctls['subvol'],0)
    rig.set_ctl(v.noise_gain,v.ctls['noisevol'],0)


@contextmanager
def rewire_output(slot,original_output,probe):
    """SunVox topology change with mandatory lock. Restore on exceptions.

    Only called in the dedicated qualitycheck process, after note stop, never
    in the normal live-performance event loop.
    """
    lock=getattr(slot,'lock',None) or getattr(slot,'lock_slot',None)
    unlock=getattr(slot,'unlock',None) or getattr(slot,'unlock_slot',None)
    if not (callable(lock) and callable(unlock) and
            callable(getattr(slot,'disconnect_module',None)) and
            callable(getattr(slot,'connect_module',None))):
        raise RuntimeError('De SunVox Python-wrapper biedt geen lock/unlock/disconnect_module. '
                           'Staged output-test overgeslagen; installeer compatibele SunVox Library.')
    def change(old,new):
        rc=slot.disconnect_module(*old)
        if rc is not None and rc<0:raise RuntimeError(f'disconnect {old} => {rc}')
        try:
            rc=slot.connect_module(*new)
            if rc is not None and rc<0:raise RuntimeError(f'connect {new} => {rc}')
        except Exception:
            # A failed tap must not leave the project disconnected from audio.
            slot.connect_module(*old)
            raise
    lock()
    try:
        change(original_output,(probe,0))
    finally:
        unlock()
    try:
        yield
    finally:
        lock()
        try:
            rc=slot.disconnect_module(probe,0)
            if rc is not None and rc<0:raise RuntimeError(f'tap disconnect {probe}: {rc}')
            rc=slot.connect_module(*original_output)
            if rc is not None and rc<0:raise RuntimeError(f'restore {original_output}: {rc}')
        finally:
            unlock()


def qualitycheck(rig,recorder=None):
    """MIDI-onafhankelijke meting: golfvorm, per-voice, tap-chain, ADSR, poly.

    Analyzer checks time-aligned PCM afterwards; no success claim here.
    """
    print('\nQUALITYCHECK 0.9.13 — vier stemmen, golfvorm, signaalroute en ADSR.',flush=True)
    print('Zet je luidsprekers LAAG; een losse Generator-tap kan luider klinken.',flush=True)
    print('Gebruik --record voor het meetrapport. Geen MIDI-hardware nodig.',flush=True)
    baseline(rig)
    try:
        wait(rig,.4)
        # De hoogste voice wordt gealloceerd door eerdere noten vast te houden,
        # maar hun audiogains worden tijdens de volgende meting op 0 gezet.
        # Daarmee zijn de vier werkelijke stemketens individueel bereikbaar.
        for i in range(4):
            baseline(rig)
            dummy=[48+j for j in range(i)]
            for note in dummy:
                rig.note_on(note,96)
                idx=rig.active_notes[note]
                mute_voice(rig,rig.voices[idx])
            rig.note_on(60,105)
            actual=rig.active_notes[60]
            assert actual==i,(actual,i)
            wait(rig,.15)
            emit(recorder,f'voice{i+1}_sin',1.30,kind='voice',voice=i+1,
                 waveform_expected=5,waveform_readback=wave_readback(rig,i),
                 expected_hz=midi_frequency(60),note=60)
            wait(rig,1.30)
            rig.all_notes_off()
            wait(rig,.18)
        # Dezelfde controle voor OSC2: vier afzonderlijke Generator-modules,
        # zonder dat OSC1 of voorafgaande dummy-stemmen meetellen in de WAV.
        for i in range(4):
            baseline(rig)
            rig.set_source_enabled('osc1',False)
            rig.set_parameter('osc2.level',105)
            rig.set_source_enabled('osc2',True)
            for j in range(i):
                note=48+j
                rig.note_on(note,96)
                mute_voice(rig,rig.voices[rig.active_notes[note]])
            rig.note_on(60,105)
            assert rig.active_notes[60]==i
            wait(rig,.15)
            emit(recorder,f'voice{i+1}_osc2_sin',1.30,kind='voice',voice=i+1,osc=2,
                 waveform_expected=5,waveform_readback=wave_readback(rig,i,2),
                 expected_hz=midi_frequency(60),note=60)
            wait(rig,1.30)
            rig.all_notes_off();wait(rig,.18)
        # Controleer dat de golfvorm ook na een Note On kan omschakelen.
        baseline(rig)
        rig.note_on(60,105)
        wait(rig,.15)
        rig.set_waveform_index(1,2)  # SAW while note is held; retriggers OSC1 only.
        wait(rig,.18)
        emit(recorder,'wave_switch_saw',1.30,kind='wave_switch',voice=1,
             waveform_expected=1,waveform_readback=wave_readback(rig),
             expected_hz=midi_frequency(60),note=60)
        wait(rig,1.30)
        rig.set_waveform_index(1,0)
        wait(rig,.18)
        emit(recorder,'wave_switch_back_sin',1.30,kind='wave_switch',voice=1,
             waveform_expected=5,waveform_readback=wave_readback(rig),
             expected_hz=midi_frequency(60),note=60)
        wait(rig,1.30)
        rig.all_notes_off()
        wait(rig,.25)
        # Bij natieve vibrato is dit één echte signaalroute; we luisteren
        # telkens rechtstreeks naar een andere module-uitgang.
        baseline(rig)
        v=rig.voices[0]
        stages=[('generator',v.o1)]
        if v.dc1 is not None:stages.append(('dc_blocker',v.dc1))
        stages.extend([('osc_gain',v.a1),('filter',v.filt),('amp_adsr',v.adsr)])
        full=(rig.output_amp,0)  # 0.11.2: probe after the common post-FX output bus
        stage_ok=True
        for stage,module in stages:
            try:
                rig.all_notes_off()
                with rewire_output(rig.slot,full,module):
                    rig.note_on(60,105)
                    wait(rig,.23)
                    emit(recorder,'stage_'+stage,1.30,kind='stage',stage=stage,
                         voice=1,waveform_expected=5,waveform_readback=wave_readback(rig),
                         expected_hz=midi_frequency(60),note=60)
                    wait(rig,1.30)
                    rig.all_notes_off()
                wait(rig,.15)
            except RuntimeError as exc:
                stage_ok=False
                print('WAARSCHUWING: stage-tap niet beschikbaar:',exc,flush=True)
                if recorder and recorder.active:recorder.log('quality_warning',{'stage':stage,'detail':str(exc)})
                break
        baseline(rig)
        rig.note_on(60,105)
        wait(rig,.23)
        emit(recorder,'stage_full_chain',1.30,kind='stage',stage='full_chain',voice=1,
             expected_hz=midi_frequency(60),waveform_expected=5,
             waveform_readback=wave_readback(rig),note=60)
        wait(rig,1.30)
        rig.all_notes_off();wait(rig,.30)
        # AMP ADSR audit: attack langzaam vs direct, release langzaam vs kort.
        baseline(rig)
        rig.set_parameter('amp.attack',90)
        rig.set_parameter('amp.sustain',127)
        rig.note_on(60,105)
        emit(recorder,'adsr_attack_slow',1.70,kind='adsr_attack',voice=1)
        wait(rig,1.70)
        rig.all_notes_off();wait(rig,.25)
        baseline(rig)
        rig.set_parameter('amp.release',85)
        rig.note_on(60,105)
        emit(recorder,'adsr_release_hold',1.00,kind='adsr_hold',voice=1)
        wait(rig,1.00)
        rig.note_off(60)
        emit(recorder,'adsr_release_tail',2.40,kind='adsr_release',voice=1)
        wait(rig,2.40)
        rig.all_notes_off();wait(rig,.25)
        # Eén versus vier tegelijk; dient tevens als clipping/headroomcheck.
        baseline(rig)
        rig.note_on(60,100)
        wait(rig,.20)
        emit(recorder,'poly_one',1.30,kind='poly',voices=1)
        wait(rig,1.30)
        rig.all_notes_off();wait(rig,.22)
        for n in (60,64,67,72):rig.note_on(n,100)
        wait(rig,.20)
        emit(recorder,'poly_four',1.30,kind='poly',voices=4)
        wait(rig,1.30)
    finally:
        rig.all_notes_off()
        print('QUALITYCHECK klaar; analyserapport wordt na het stoppen van de opname gemaakt.',flush=True)


def wavecheck(rig,recorder=None):
    """Acht reproduceerbare toonfasen: SIN TRI SAW PULSE x OSC1 OSC2.

    Neemt een aparte WAV op; dit is de beslissende audiokalibratietest.
    De TRI-pitchcorrectie is gemeten en blijft als regressiecontrole actief.
    """
    from .engine import WAVEFORMS
    print('WAVECHECK 0.9.13 — SIN, TRI, SAW en PULSE, beide oscillatoren.',flush=True)
    print('Zet je luidsprekers LAAG. Geen MIDI-hardware nodig.',flush=True)
    try:
        for osc in (1,2):
            for index,(_native,name) in enumerate(WAVEFORMS):
                baseline(rig)
                rig.set_parameter('osc1.level',105)
                rig.set_parameter('osc2.level',105)
                rig.set_source_enabled('osc1',osc==1)
                rig.set_source_enabled('osc2',osc==2)
                rig.set_waveform_index(osc,index)
                rig.ensure_waveforms(timeout=.8,strict=True)
                rig.note_on(60,110)
                wait(rig,.23)
                emit(recorder,f'wave_osc{osc}_{name.lower()}',1.40,
                     kind='wave_calibration',osc=osc,voice=1,
                     waveform_expected=_native,
                     waveform_readback=wave_readback(rig,0,osc),
                     pitch_base_semis=rig.pitch_calibration_semitones,
                     pitch_extra_semis=rig.wave_pitch_offsets[name],
                     expected_hz=midi_frequency(60),note=60)
                wait(rig,1.40)
                rig.all_notes_off()
                wait(rig,.18)
    finally:
        rig.all_notes_off()
        print('WAVECHECK klaar. Meetrapport verschijnt na WAV-opname.',flush=True)
