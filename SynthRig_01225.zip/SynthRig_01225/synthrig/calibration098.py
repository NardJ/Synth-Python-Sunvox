"""SynthRig 0.9.8: onafhankelijke SunVox Generator kalibratie.

Géén beweringen over audiokwaliteit vóór meting op echte installatie.
Generator direct -> Output of Generator -> Vibrato(amplitude=0) -> Output.
"""
from __future__ import annotations
import time
import math
from sunvox.api import NOTECMD
from .engine import controller
from .engine09 import midi_frequency, sunvox_pitch_from_hz
from .tracks098 import send_checked


def tonecheck(slot, rig, recorder=None):
    rig.all_notes_off()
    slot.set_event_t(1,0)
    direct=slot.new_module('Generator','CAL Direct Generator',1420,200,0)
    through=slot.new_module('Generator','CAL FX Generator',1420,450,0)
    effect=slot.new_module('Vibrato','CAL Vibrato unity A=0',1600,450,0)
    for mod in (direct,through,effect):
        if mod < 0:raise RuntimeError('SunVox kalibratiemodule ontbreekt')
    for a,b in ((direct,0),(through,effect),(effect,0)):
        rc=slot.connect_module(a,b)
        if rc is not None and rc<0:raise RuntimeError(f'Kalibratieroute {a}->{b}: {rc}')
    def setctl(mod,ctl,value):
        number,lo,hi=ctl
        v=max(lo,min(hi,int(round(value))))
        rc=slot.set_module_ctl_value(mod,number,v,0)
        if rc is not None and rc<0:raise RuntimeError(f'Kalibratiecontroller error {rc}')
    ctl_direct=controller(slot,direct,'Waveform')
    ctl_fx=controller(slot,through,'Waveform')
    setctl(effect,controller(slot,effect,'Volume'),256)
    setctl(effect,controller(slot,effect,'Amplitude'),0)
    setctl(effect,controller(slot,effect,'Frequency unit'),0)
    setctl(effect,controller(slot,effect,'Frequency','Freq'),320)
    slot.volume(192)

    def wait(t):
        deadline=time.monotonic()+t
        while time.monotonic()<deadline:
            rig.tick()
            time.sleep(.003)

    def phase(label, wave, with_fx, use_pitch, pitch_offset=0):
        mod=through if with_fx else direct
        ctl=ctl_fx if with_fx else ctl_direct
        track=1 if with_fx else 0
        # Wacht tot SunVox een controller-write kan verwerken; directe
        # readback onmiddellijk na write kan nog de vorige waarde tonen.
        setctl(mod,ctl,wave)
        read=None
        for attempt in range(15):
            wait(.02)
            read=slot.get_module_ctl_value(mod,ctl[0],0)
            if read==wave:
                break
        if read!=wave:
            print(f'WAARSCHUWING: waveform requested {wave}, readback {read} (niet bevestigd)',flush=True)
        hz=midi_frequency(60+pitch_offset)
        if recorder and recorder.active:
            recorder.log('tonecheck_step',{'label':label,'duration':1.3,
                'waveform_requested':wave,'waveform_readback':read,
                'send_pitch':use_pitch,'pitch_offset':pitch_offset,
                'requested_hz':hz if use_pitch else None,
                'effect_chain':with_fx, 'event_track':track,
                'readback_confirmed':read==wave})
        print(f'TONECHECK {label}: Waveform={read} (gevraagd {wave}), '
              f'FX={with_fx}, SET_PITCH={use_pitch}, Hz doel={hz:.2f}',flush=True)
        send_checked(slot,track,61,115,mod+1,0,0)
        if use_pitch:
            # Zonder synth-calibratie! We testen expliciet de kale Generator-respons.
            p=sunvox_pitch_from_hz(hz)
            send_checked(slot,track,NOTECMD.SET_PITCH,129,mod+1,0,p)
        wait(1.3)
        send_checked(slot,track,NOTECMD.NOTE_OFF,0,mod+1,0,0)
        wait(.25)

    print('TONECHECK: geheel onafhankelijke SunVox Generator, géén filter of ADSR.',flush=True)
    print('Direct SIN versus SAW en SIN via Vibrato (amplitude 0).',flush=True)
    print('Luidsprekervolume LAAG! Andere systeemgeluiden tijdens opname UIT.',flush=True)
    wait(.3)
    try:
        phase('1 Direct SIN NoteOn',5,False,False)
        phase('2 Direct SIN SET_PITCH 261Hz',5,False,True)
        phase('3 Direct SIN SET_PITCH 130Hz',5,False,True,-12)
        phase('4 Direct SAW SET_PITCH 261Hz',1,False,True)
        phase('5 Vibrato SIN A0 SET_PITCH 261Hz',5,True,True)
    finally:
        send_checked(slot,0,NOTECMD.NOTE_OFF,0,direct+1,0,0)
        send_checked(slot,1,NOTECMD.NOTE_OFF,0,through+1,0,0)
        rig.all_notes_off()
