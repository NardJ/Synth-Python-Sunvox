"""0.12.11: in-place A/B PCM checks for LFO RATE and DELAY FEEDBACK.

Both configurations are rendered in the SAME SunVox slot.  Switching slots
is not a valid A/B test with the global native audio_callback.
"""
from pathlib import Path
import json
import numpy as np
from .offline0102 import OfflineAudio,RATE,rms,apply_baseline
from .mod_matrix import blank_matrix,encode


def run(output_dir='recordings',pitch_lfo_mode='native'):
    import sunvox.dll as dll
    from sunvox.api import Slot,init,deinit
    from sunvox.types import INIT_FLAG
    from .engine09 import SynthRig
    flags=int(INIT_FLAG.OFFLINE|INIT_FLAG.AUDIO_FLOAT32|INIT_FLAG.ONE_THREAD|INIT_FLAG.NO_DEBUG_OUTPUT)
    if init(None,RATE,2,flags)<0: raise RuntimeError('SunVox init mislukt')
    rows=[]
    def check(name,ok,**metrics):
        item={'check':name,'status':'PASS' if ok else 'FAIL',**metrics}
        rows.append(item);print(item['status'],name,metrics,flush=True)
    try:
        with Slot() as slot:
            rig=SynthRig(slot,pitch_lfo_mode=pitch_lfo_mode,offline=True)
            apply_baseline(rig,waveform=2)
            assert slot.play()>=0
            with OfflineAudio(rig,dll) as render:
                # Dry SAW + animated filter: changing LFO rate must change PCM.
                rig.set_parameter('filter.cutoff',58)
                rig.set_parameter('lfo.rate',80)
                rig.set_parameter('lfo.filter_depth',127)
                rig.note_on(60,105)
                render.render(.18)
                base=render.render(.40)
                base_rate=rig._effective_lfo_rate
                matrix=blank_matrix();matrix[7][3]=encode(1,127)
                rig.load_mod_matrix(matrix)
                render.render(.15)
                mod=render.render(.40)
                mod_rate=rig._effective_lfo_rate
                difference=float(np.mean(np.abs(base-mod)))
                check('lfo_rate_modulates_real_pcm',mod_rate>base_rate*1.5 and difference>.003,
                      base_hz=round(base_rate,3),routed_hz=round(mod_rate,3),
                      pcm_mean_abs_delta=round(difference,6))
                rig.note_off(60);render.render(.32)
                rig.load_mod_matrix(blank_matrix());render.render(.3)
                # Two identical note/echo passages in a single DSP slot.
                apply_baseline(rig,waveform=2)
                rig.set_parameter('amp.attack',0)
                rig.set_parameter('amp.release',0)
                rig.set_parameter('effects.delay',127)
                rig.set_ctl(rig.delay_module,rig.lookup(rig.delay_module,'Delay'),75)
                render.render(.80)
                rig.note_on(60,100);render.render(.18)
                baseline_feedback=rig.last_delay_feedback
                rig.note_off(60);render.render(.10)
                baseline_tail=render.render(.55)
                render.render(.60) # quiet between comparisons
                matrix=blank_matrix();matrix[7][7]=encode(1,127)
                rig.load_mod_matrix(matrix)
                rig.note_on(60,100);render.render(.28)
                routed_feedback=rig.last_delay_feedback
                rig.note_off(60);render.render(.10)
                modulated_tail=render.render(.55)
                delta=float(np.mean(np.abs(baseline_tail-modulated_tail)))
                check('feedback_modulates_real_echo',routed_feedback>baseline_feedback+20 and delta>.0004,
                      feedback_before=baseline_feedback,feedback_after=routed_feedback,
                      baseline_tail_rms=round(rms(baseline_tail),6),
                      routed_tail_rms=round(rms(modulated_tail),6),
                      tail_pcm_mean_abs_delta=round(delta,6))
                check('no_clipping_new_routes',float(np.max(np.abs(mod)))<.999 and float(np.max(np.abs(modulated_tail)))<.999,
                      rate_peak=round(float(np.max(np.abs(mod))),5),
                      feedback_peak=round(float(np.max(np.abs(modulated_tail))),5))
    finally:
        deinit()
    out=Path(output_dir);out.mkdir(parents=True,exist_ok=True)
    summary={k:sum(c['status']==k for c in rows) for k in ('PASS','FAIL')}
    payload={'version':'0.12.14','mode':pitch_lfo_mode,'summary':summary,'checks':rows}
    (out/f'new_destinations_{pitch_lfo_mode}.json').write_text(json.dumps(payload,indent=2)+'\n',encoding='utf8')
    return payload
