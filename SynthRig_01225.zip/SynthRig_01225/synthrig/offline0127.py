"""SynthRig 0.12.7: unchanged SunVox audio regression after UI label move."""
from pathlib import Path
import json
from .offline0126 import run as previous_run

def run(**kwargs):
    result=previous_run(**kwargs)
    result['version']='0.12.7'
    output_dir=Path(kwargs.get('output_dir','recordings'))
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir/'summary_0127.json').write_text(json.dumps(result, indent=2)+'\n',encoding='utf8')
    return result
