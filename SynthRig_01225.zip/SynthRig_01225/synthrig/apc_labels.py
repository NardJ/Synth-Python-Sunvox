"""Fixed, print-ready two-layer APC Mini Mk2 patch labels (v0.12.13).

Each layer label is <= 8 MONOSPACED CHARACTER CELLS.  Index 0 is the
bottom source row (LFO1); index 7 is the top source row (BIAS).  This file
is presentation-only; original engine source/destination IDs stay intact.
"""
from .mod_matrix import SOURCES, SOURCES_B, DESTINATIONS, DESTINATIONS_D

# Row labels (bottom to top); each tuple is (layer A, layer B).
ROW_LABELS=(
    ('LFO1',    'LFO2'),
    ('FLT ENV', 'AMP ENV'),
    ('VELOCITY','MOD ENV'),
    ('AFTTOUCH','LFO3'),
    ('MODWHL',  'SMOOTH R'),
    ('KEYTRACK','NOTE RMP'),
    ('GATE',    'TRIGGER'),
    ('BIAS',    'S&HOLD'),
)
# Column labels (left to right); each tuple is (layer C, layer D).
COLUMN_LABELS=(
    ('O1 PITCH','SUB LVL'),
    ('O2 PITCH','NOISE LV'),
    ('O1 PWM',  'ENV AMT'),
    ('O2 PWM',  'LFO RATE'),
    ('CUTOFF',  'DLY MIX'),
    ('RESON',   'REV MIX'),
    ('O1 LEVEL','CHO MIX'),
    ('O2 LEVEL','DLY FDBK'),
)
MAX_LABEL_CELLS=8
LABEL_FONT='DejaVu Sans Mono'

def validate_labels():
    assert len(ROW_LABELS)==len(SOURCES)==len(SOURCES_B)==8
    assert len(COLUMN_LABELS)==len(DESTINATIONS)==len(DESTINATIONS_D)==8
    for pairs in (ROW_LABELS,COLUMN_LABELS):
        for pair in pairs:
            assert len(pair)==2
            for label in pair:
                assert label and len(label)<=MAX_LABEL_CELLS, repr(label)
                assert label.isascii() and '\n' not in label and '\t' not in label
    return True

validate_labels()
