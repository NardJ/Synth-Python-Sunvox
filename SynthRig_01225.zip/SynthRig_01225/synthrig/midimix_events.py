"""Production MIDImix BANK event handler, separately integration-testable.

The main loop MUST call this on BANK Note On. LED feedback is a user-visible
controller contract, not merely a helper-only unit-test detail.
"""
from __future__ import annotations


def handle_bank_press(msg, controls, presets, rig, leds=None, monitor=None,
                      mark_changed=None, diagnostic=None):
    """Handle genuine MIDI bank PRESS. Return selected preset text or None.

    Note-off and note-on velocity zero are release events and must not switch.
    Failure to open a MIDI output is not allowed to disable preset loading.
    A failed LED send must be reported, never reported as confirmed success.
    """
    if (getattr(msg, 'channel', 0) != 0 or
            getattr(msg, 'type', None) != 'note_on' or
            getattr(msg, 'velocity', 0) <= 0 or
            getattr(msg, 'note', None) not in controls.bank_notes):
        return None
    direction = -1 if msg.note == 25 else 1
    result = presets.step(direction, rig)
    if mark_changed is not None:
        mark_changed()
    number = presets.selected + 1
    if leds is None:
        if diagnostic is not None:
            diagnostic(f'PRESET {number:02d}: geladen, maar MIDImix LED-uitgang ontbreekt')
    else:
        try:
            leds.show_preset(number)
        except (OSError, IOError, RuntimeError) as exc:
            if diagnostic is not None:
                diagnostic(f'PRESET {number:02d}: geladen, LED-teller NIET verzonden: {exc}')
        else:
            if diagnostic is not None:
                diagnostic(f'PRESET {number:02d}: 16 LED-opdrachten verzonden; herstel na 1 s')
    if monitor is not None:
        # Atomair preset + hardware-LED snapshot in één UDP-datagram.
        # De vorige versie stuurde de presetmelding VOOR show_preset en
        # vertrouwde op een los, later GUI-bericht. Daardoor was een
        # interface-event mogelijk zonder bijbehorende LED-telling.
        monitor.send_preset(presets.selection(),
                            led_snapshot=leds.display_snapshot() if leds is not None else None)
        monitor.send_values({str(cc):controls.target_raw.get(spec['target'],64)
                             for cc,spec in controls.mappings.items()})
    return result
