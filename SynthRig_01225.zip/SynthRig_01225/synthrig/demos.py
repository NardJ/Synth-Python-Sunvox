"""Optionele diagnostische demonstraties; geen invloed op normaal spelen."""
import time
import mido
from .engine import WAVEFORMS, clamp

POLL_INTERVAL = 0.002

def resonance_demo(rig):
    """A/B-proef met vaste instellingen, zonder fysieke CC-bediening."""
    print("\nRESONANTIE A/B TEST — mastervolume eerst laag instellen!")
    rig.slot.volume(65)
    rig.vco_mix = 0.0
    rig.osc1_level = 0.75
    rig.apply_osc_levels()
    rig.select_wave(1, 2)  # Zaagtand inclusief golfvormtrim
    freq = rig.set_ctl(rig.filt, rig.cutoff, 900)
    rig.note_on(48, 90)
    try:
        for title, amount in (("A: laag", rig.resonance[1]),
                              ("B: hoog", rig.resonance[2])):
            actual = rig.set_ctl(rig.filt, rig.resonance, amount)
            time.sleep(0.12)
            measured = rig.slot.get_module_ctl_value(rig.filt, rig.resonance[0], 0)
            print(f"  {title}: cutoff={freq} Hz, resonantie={actual} "
                  f"(gelezen {measured}); luister 3 seconden")
            time.sleep(3)
    finally:
        rig.all_notes_off()
    print("A/B-test afgelopen. Als A en B identiek klinken, stuur de console-output.")



def prepare_resonance_midi_demo(rig):
    """Exact dezelfde audioinstellingen als de geslaagde automatische A/B-test.

    We veranderen de gewone synthesizer NIET; deze instellingen gelden
    uitsluitend zolang --resonance-midi-demo draait.
    """
    rig.slot.volume(65)        # Voorzichtig uitgangsniveau
    rig.vco_mix = 0.0          # Alleen OSC1
    rig.osc1_level = 0.75
    rig.apply_osc_levels()
    rig.select_wave(1, 2)  # Zaagtand inclusief golfvormtrim
    freq = rig.set_ctl(rig.filt, rig.cutoff, 900)
    rig.set_ctl(rig.filt, rig.resonance, rig.resonance[1])
    rig.last_cc.pop(17, None)
    return freq


def resonance_midi_demo(rig, midimix_port, monitor=None):
    """Speelt een constante C3 terwijl de fysieke MIDImix CC17 stuurt.

    Dit test CC17 met PRECIES de signaalketen van --resonance-demo.
    Andere MIDImix-CC's veranderen de klank niet tijdens deze proef.
    """
    freq = prepare_resonance_midi_demo(rig)
    print("\nRESONANTIE MIDI-TEST — zet de externe geluidssterkte laag")
    print("Vaste C3 met OSC1 zaagtand, cutoff=900 Hz, OSC2 uit, master=65/128")
    print("Beweeg alleen MIDImix CC17 (de TWEEDE draaiknop van links).")
    print("Alle andere CC's worden alleen getoond in de debuginterface.")
    print("Ctrl+C stopt de C3-noot en de test.\n")
    rig.note_on(48, 90)
    try:
        with mido.open_input(midimix_port) as midi_in:
            while True:
                for msg in midi_in.iter_pending():
                    if msg.type == "control_change" and msg.control == 17:
                        label = rig.handle_midimix(msg)
                        actual = rig.slot.get_module_ctl_value(
                            rig.filt, rig.resonance[0], 0)
                        print(f"  MIDI={msg.value:3d}/127 | filter res={actual} | "
                              f"cutoff={freq} Hz")
                        if monitor is not None:
                            monitor.send(msg, label)
                    elif monitor is not None:
                        monitor.send(msg, "Resonantietest: alleen CC17 actief")
                rig.check_verifications()
                time.sleep(POLL_INTERVAL)
    except KeyboardInterrupt:
        print("\nResonantie-MIDI-test gestopt.")
    finally:
        rig.all_notes_off()


def wave_demo(rig):
    """Automatische vergelijkingsproef met vaste C3 voor SIN/TRI/SAW/PULSE."""
    print("\nGOLFVORM A/B-TEST — begin met laag extern volume!")
    rig.slot.volume(65)
    rig.vco_mix = 0.0
    rig.osc1_level = 0.75
    rig.apply_osc_levels()
    rig.set_ctl(rig.filt, rig.cutoff,
                clamp(9000, rig.cutoff[1], rig.cutoff[2]))
    rig.set_ctl(rig.filt, rig.resonance, rig.resonance[1])
    try:
        for idx in range(len(WAVEFORMS)):
            name, trim, _ = rig.select_wave(1, idx)
            rig.note_on(48, 90)
            print(f"  OSC1 {name:5s} trim {trim:.2f}x — luister 2.5 seconde")
            time.sleep(2.5)
            rig.note_off(48)
            time.sleep(0.2)
    finally:
        rig.all_notes_off()
    print("Golftest gereed; stel eventueel WAVE_TRIMS bovenaan bij.")




def pwm_demo(rig):
    """Vergelijk handmatige pulse-width met automatische PWM op vaste C3."""
    print("\nPWM-DEMO — externe geluidssterkte eerst laag zetten!")
    rig.slot.volume(65)
    rig.vco_mix = 0.0
    rig.osc1_level = 0.75
    rig.apply_osc_levels()
    rig.set_ctl(rig.filt, rig.cutoff, clamp(8000, rig.cutoff[1], rig.cutoff[2]))
    rig.set_ctl(rig.filt, rig.resonance, rig.resonance[1])
    rig.select_wave(1, 3)  # PULSE
    rig.pwm.set_width(1, .5)
    rig.pwm.rate = 1.1
    rig.note_on(48, 95)
    try:
        for title, width, depth, seconds in (
            ("PULSE 50%, geen PWM", .50, .0, 2.5),
            ("PULSE 25%, geen PWM", .25, .0, 2.5),
            ("PULSE 50% + PWM ±20% bij 1.1 Hz", .50, .20, 5.0),
        ):
            rig.pwm.set_width(1, width)
            rig.pwm.depth = depth
            print(f"  {title}")
            end = time.monotonic() + seconds
            while time.monotonic() < end:
                rig.tick_pwm()
                time.sleep(.005)
    finally:
        rig.all_notes_off()
