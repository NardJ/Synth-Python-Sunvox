"""Optionele realtime audio- en diagnoseopname van de Linux-output.

Neemt het monitor-signaal van de standaard PulseAudio/PipeWire-audiosink op.
SynthRig/SunVox blijven ongewijzigd; dit bestand hoeft niet te worden
geïmporteerd of geïnstalleerd voor normaal gebruik.

WAARSCHUWING: dit neemt de *gehele* systeemuitgang op en is niet geschikt
wanneer SunVox rechtstreeks naar een ALSA-apparaat buiten Pulse/PipeWire gaat.
"""
from __future__ import annotations

from array import array
from datetime import datetime
import json
import csv
import math
import zipfile
from pathlib import Path
import shutil
import subprocess
import threading
import time
import wave


SAMPLE_RATE = 44100
CHANNELS = 2
BYTES_PER_SAMPLE = 2
CHUNK_FRAMES = 4096


class RecordingError(RuntimeError):
    pass


def find_monitor_source():
    """Zoek de monitor van de actuele standaard-audiouitgang."""
    if shutil.which('pactl') is None or shutil.which('parec') is None:
        raise RecordingError(
            'pactl/parec ontbreken. Installeer met: '
            'sudo apt install pulseaudio-utils'
        )
    try:
        result = subprocess.run(
            ['pactl', 'get-default-sink'], capture_output=True, text=True,
            timeout=3, check=True,
        )
        sink = result.stdout.strip()
        sources = subprocess.run(
            ['pactl', 'list', 'short', 'sources'], capture_output=True,
            text=True, timeout=3, check=True,
        ).stdout
    except (subprocess.SubprocessError, OSError) as exc:
        raise RecordingError(f'Kan de audio-monitor niet vinden: {exc}') from exc
    if not sink:
        raise RecordingError('Geen standaard audiosink ingesteld')
    monitor = sink + '.monitor'
    source_names = [line.split('\t')[1] for line in sources.splitlines()
                    if '\t' in line and len(line.split('\t')) >= 2]
    if monitor not in source_names:
        raise RecordingError(
            f'Monitor {monitor!r} bestaat niet. Beschikbaar: {source_names}. '
            'Gebruik zo nodig --record-source.'
        )
    return monitor


class AudioDebugRecorder:
    """Een opname is een WAV plus een tijdlog van MIDI en PWM.

    De SunVox-eventloop schrijft alleen kleine JSON-regels en raakt het
    audioproces niet. Een aparte thread leest PCM en schrijft de WAV.
    """

    def __init__(self, directory='recordings', source=None, *, capture_command=None, bundle=True):
        self.directory = Path(directory)
        self.source = source
        self.capture_command = capture_command  # alleen tests/diagnose
        self.bundle = bundle
        self.active = False
        self.started_at = None
        self.wav_path = None
        self.events_path = None
        self.summary_path = None
        self.process = None
        self.reader = None
        self._events = None
        self._wav_error = None
        self._frames = 0
        self._clip_peak = 0
        self._energy = {}
        self._bytes = 0
        self._windows = {}
        self._capture_first_chunk_elapsed = None
        self._stderr_file = None
        self.stderr_path = None
        self.csv_path = None
        self.bundle_path = None
        self.metadata = {}
        self._event_counts = {}
        self._events_since_flush = 0

    def start(self, metadata=None):
        if self.active:
            return False
        cmd = self.capture_command
        source = self.source
        if cmd is None:
            source = source or find_monitor_source()
            if shutil.which('parec') is None:
                raise RecordingError('parec ontbreekt: sudo apt install pulseaudio-utils')
            cmd = [
                'parec', f'--device={source}', '--raw', '--format=s16le',
                f'--rate={SAMPLE_RATE}', f'--channels={CHANNELS}',
                '--latency-msec=50',
            ]
        self.directory.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
        basename = self.directory / f'synthrig_{stamp}'
        self.wav_path = basename.with_suffix('.wav')
        self.events_path = basename.with_suffix('.jsonl')
        self.summary_path = basename.with_name(basename.name + '_summary.json')
        self.csv_path = basename.with_name(basename.name + '_audio_windows.csv')
        self.stderr_path = basename.with_name(basename.name + '_capture_stderr.txt')
        self.bundle_path = basename.with_suffix('.zip')
        self.metadata = metadata or {}
        self._frames = 0
        self._clip_peak = 0
        self._energy = {}
        self._bytes = 0
        self._wav_error = None
        self._windows = {}
        self._event_counts = {}
        self._events_since_flush = 0
        self._capture_first_chunk_elapsed = None
        try:
            self._stderr_file = self.stderr_path.open('wb')
            self.process = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=self._stderr_file,
                bufsize=0,
            )
            self._events = self.events_path.open('w', encoding='utf-8')
        except (OSError, PermissionError) as exc:
            if self._stderr_file is not None:
                self._stderr_file.close()
                self._stderr_file = None
            if self.process is not None and self.process.poll() is None:
                self.process.terminate()
            raise RecordingError(f'Kan opname niet starten: {exc}') from exc
        self.started_at = time.monotonic()
        self.active = True
        self.log('record_start', {'audio_source': source or 'test-input', 'rate': SAMPLE_RATE, 'metadata': self.metadata})
        self.reader = threading.Thread(target=self._read_audio, daemon=True, name='SunVoxAudioRecorder')
        self.reader.start()
        print(f'\n● OPNAME GESTART: {self.wav_path}')
        print(f'  Events/PWM-log: {self.events_path}')
        if source:
            print(f'  Audio-bron: {source}')
        return True

    def _read_audio(self):
        try:
            with wave.open(str(self.wav_path), 'wb') as output:
                output.setnchannels(CHANNELS)
                output.setsampwidth(BYTES_PER_SAMPLE)
                output.setframerate(SAMPLE_RATE)
                while True:
                    block = self.process.stdout.read(CHUNK_FRAMES * CHANNELS * BYTES_PER_SAMPLE)
                    if not block:
                        break
                    block = block[:len(block) // (CHANNELS * BYTES_PER_SAMPLE) * (CHANNELS * BYTES_PER_SAMPLE)]
                    if not block:
                        continue
                    output.writeframesraw(block)
                    nframes = len(block) // (CHANNELS * BYTES_PER_SAMPLE)
                    if self._capture_first_chunk_elapsed is None:
                        self._capture_first_chunk_elapsed = time.monotonic() - self.started_at
                    samples = array('h')
                    samples.frombytes(block)
                    import sys
                    if sys.byteorder != 'little':
                        samples.byteswap()
                    # Analyse van ongeveer 5.5k stereo-samples/s:
                    # laag genoeg voor een Pi 3, maar geen sample-perfecte clippingdetectie.
                    for sample_index in range(0, len(samples), 16):
                        frame_index = self._frames + sample_index // CHANNELS
                        window = frame_index * 10 // SAMPLE_RATE  # 100ms
                        val = int(samples[sample_index])
                        stats = self._windows.setdefault(window, [0, 0, 0, 0, 0])
                        stats[0] += 1
                        stats[1] += val
                        stats[2] += val * val
                        stats[3] = max(stats[3], abs(val))
                        if abs(val) >= 32760:
                            stats[4] += 1
                        self._clip_peak = max(self._clip_peak, stats[3])
                    sec = self._frames // SAMPLE_RATE
                    bins = self._energy.setdefault(sec, [0, 0, 0])
                    for val in samples[::16]:
                        value = int(val)
                        bins[0] += 1
                        bins[1] += value * value
                        bins[2] = max(bins[2], abs(value))
                    self._frames += nframes
                    self._bytes += len(block)
        except Exception as exc:
            self._wav_error = str(exc)

    def log(self, event, data=None):
        """Aanroepen vanuit *de main-eventloop* (niet vanuit audiothread)."""
        if not self.active or self._events is None:
            return
        self._event_counts[event] = self._event_counts.get(event, 0) + 1
        self._events.write(json.dumps({
            't': round(time.monotonic() - self.started_at, 6),
            'event': event, 'data': data if data is not None else {},
        }, ensure_ascii=False) + '\n')
        self._events_since_flush += 1
        if self._events_since_flush >= 100:
            self._events.flush()
            self._events_since_flush = 0

    def stop(self):
        if not self.active:
            return None
        self.log('record_stop')
        self.active = False
        if self.process is not None and self.process.poll() is None:
            self.process.terminate()
        if self.reader is not None:
            self.reader.join(timeout=3)
        if self.process is not None and self.process.poll() is None:
            self.process.kill()
        if self.process is not None:
            try:
                self.process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait()
        if self.reader is not None and self.reader.is_alive():
            self.reader.join(timeout=2)
        if self.process is not None and self.process.stdout is not None:
            self.process.stdout.close()
        if self._stderr_file is not None:
            self._stderr_file.close()
            self._stderr_file = None
        duration_wall = time.monotonic() - self.started_at
        if self._events:
            self._events.close()
            self._events = None
        seconds = round(self._frames / SAMPLE_RATE, 3)
        energies = {}
        for sec, (count, energy, peak) in sorted(self._energy.items()):
            energies[str(sec)] = {
                'rms_dbfs_approx': (round(20 * __import__('math').log10((energy / count) ** .5 / 32768), 1)
                                     if count and energy else None),
                'peak_dbfs_approx': (round(20 * __import__('math').log10(peak / 32768), 1)
                                      if peak else None),
            }
        with self.csv_path.open('w', newline='', encoding='utf-8') as f:
            w = csv.writer(f)
            w.writerow(['t_s', 'samples_approx', 'rms_dbfs_approx',
                        'peak_dbfs_approx', 'dc_offset_approx', 'clip_samples_approx'])
            for tenth, (count, total, square, peak, clipped) in sorted(self._windows.items()):
                rms = 20 * math.log10(math.sqrt(square / count) / 32768) if count and square else None
                peak_db = 20 * math.log10(peak / 32768) if peak else None
                w.writerow([round(tenth / 10, 3), count,
                            round(rms, 2) if rms is not None else '',
                            round(peak_db, 2) if peak_db is not None else '',
                            round(total / count / 32768, 7) if count else '', clipped])
        approx_dc_max = max((abs(total / count / 32768)
                             for count, total, sq, peak, clips in self._windows.values() if count), default=0)
        clip_count = sum(stats[4] for stats in self._windows.values())
        summary = {
            'wav': str(self.wav_path),
            'events': str(self.events_path),
            'audio_windows_csv': str(self.csv_path),
            'capture_stderr': str(self.stderr_path),
            'metadata': self.metadata,
            'event_counts': self._event_counts,
            'audio_first_pcm_read_t_approx': self._capture_first_chunk_elapsed,
            'approx_max_abs_dc_offset': round(approx_dc_max, 7),
            'approx_clipped_samples': clip_count,
            'audio_alignment_note': 'MIDI/PWM en WAV zijn niet sample-precies gesynchroniseerd. PCM-read-tijd is geen betrouwbare fysieke audio-onset.',
            'recorded_audio_seconds': seconds,
            'wall_seconds': round(duration_wall, 3),
            'sample_rate': SAMPLE_RATE,
            'channels': CHANNELS,
            'peak_sample_approx': self._clip_peak,
            'rms_by_second': energies,
            'capture_error': self._wav_error,
            'note': 'Opname van Linux-output-monitor, niet van een interne SunVox-bus. Kan andere systeemgeluiden bevatten.'
        }
        self.summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
        if self.bundle:
            try:
                with zipfile.ZipFile(self.bundle_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=1) as z:
                    for path in (self.wav_path, self.events_path, self.csv_path,
                                 self.summary_path, self.stderr_path):
                        if path.exists():
                            z.write(path, arcname=path.name)
                summary['bundle'] = str(self.bundle_path)
                self.summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
            except Exception as exc:
                print(f'  Kon ZIP niet maken: {exc}')
        print(f'\n■ OPNAME GESTOPT — {seconds:.1f} s audio')
        print(f'  WAV:     {self.wav_path}')
        print(f'  MIDI:    {self.events_path}')
        print(f'  Niveaus: {self.summary_path}')
        print(f'  100ms analyse: {self.csv_path}')
        if self.bundle and self.bundle_path.exists():
            print(f'  DEEL DIT BESTAND: {self.bundle_path}')
        if self._wav_error:
            print(f'  WAARSCHUWING bij WAV-opname: {self._wav_error}')
        if self._frames < SAMPLE_RATE / 2:
            print('  WAARSCHUWING: weinig audio ontvangen; controleer monitor/soundserver.')
        if self._clip_peak == 0:
            print('  WAARSCHUWING: opname is stil; SunVox gebruikt mogelijk directe ALSA-uitvoer.')
        return summary
