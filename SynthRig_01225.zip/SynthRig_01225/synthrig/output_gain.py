"""Global (non-preset) output gain stored separately from the MIDI session."""
from __future__ import annotations
import json
import math
import os
from pathlib import Path

DEFAULT_GAIN_FILE = Path(__file__).resolve().parents[1] / 'state' / 'output_gain.json'
MIN_DB, MAX_DB = -6.0, 9.0


def valid_gain(value):
    if type(value) not in (int, float) or not math.isfinite(value) or not MIN_DB <= value <= MAX_DB:
        raise ValueError('Outputgain moet -6 tot +9 dB zijn')
    return round(float(value)*2)/2


def load_gain(path=DEFAULT_GAIN_FILE):
    try:
        data=json.loads(Path(path).read_text(encoding='utf8'))
        if data.get('schema') != 1:
            raise ValueError('Onbekend outputgainformaat')
        return valid_gain(data['db'])
    except FileNotFoundError:
        return 0.0
    except (OSError,ValueError,KeyError,TypeError,AttributeError) as exc:
        print(f'WAARSCHUWING: ongeldige outputgain ({path}): {exc}; start op 0 dB')
        return 0.0


def save_gain(path, db):
    db=valid_gain(db)
    path=Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name('.'+path.name+'.tmp')
    try:
        with tmp.open('w',encoding='utf8') as fh:
            json.dump({'schema':1,'db':db},fh,indent=2)
            fh.write('\n')
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp,path)
    finally:
        if tmp.exists():tmp.unlink()
    return path
