"""Pure control-rate LFO voor pulse width; genereert GEEN audio.

De SunVox Generator maakt de oscillator; Python verandert alleen Duty cycle.
Bij 0 depth wordt de handmatige breedte gerespecteerd.
"""
from __future__ import annotations
from math import sin, pi


def clamp(value, lo, hi):
    return max(lo, min(hi, value))


class PWM:
    def __init__(self):
        self.width = {1: 0.50, 2: 0.50}  # basis duty als 0..1
        self.depth = 0.0                 # 0..0.35, in percentagepunten
        self.rate = 0.8                  # Hz
        self.phase = 0.0
        self.last_time = None

    def set_width(self, osc: int, fraction: float):
        if osc not in (1, 2):
            raise ValueError("osc moet 1 of 2 zijn")
        self.width[osc] = clamp(fraction, 0.10, 0.90)

    def advance(self, now: float):
        if self.last_time is None:
            self.last_time = now
        else:
            dt = max(0.0, now - self.last_time)
            self.last_time = now
            self.phase = (self.phase + dt * self.rate) % 1.0
        delta = self.depth * sin(2.0 * pi * self.phase)
        return {osc: clamp(base + delta, 0.10, 0.90)
                for osc, base in self.width.items()}
