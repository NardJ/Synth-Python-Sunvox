"""Optionele debugmonitor: geheel los Python-proces en UDP localhost.

Verwijder deze module, en de synthesizer werkt zonder --debug-ui.
"""
import json
import socket
import subprocess
import sys
from pathlib import Path


class OptionalMidiMixDebug:
    def __init__(self, mappings_path):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(('127.0.0.1', 0))
        self.sock.setblocking(False)
        probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        probe.bind(('127.0.0.1', 0))
        self.port = probe.getsockname()[1]
        probe.close()
        self.target = ('127.0.0.1', self.port)
        script = Path(__file__).resolve().parent.parent / 'midimix_debug.py'
        if not script.exists():
            self.sock.close()
            raise FileNotFoundError(f'Debuginterface ontbreekt: {script}')
        self.process = subprocess.Popen([
            sys.executable, str(script), '--port', str(self.port),
            '--mappings', str(Path(mappings_path).resolve()),
        ])
        print('MIDImix-debuginterface gestart (los proces).')

    def send(self, message, applied=None):
        if self.process.poll() is not None:
            return
        payload = {'kind': 'midi', 'message': message.dict(), 'applied': applied}
        try:
            self.sock.sendto(json.dumps(payload).encode('utf-8'), self.target)
        except OSError:
            pass

    def send_page(self, page_name, assignments):
        if self.process.poll() is None:
            self.sock.sendto(json.dumps({"kind":"page", "name":page_name, "assignments":assignments}).encode("utf8"), self.target)

    def send_state(self, state):
        """Stuur geselecteerde golfvormen en bron-aan/uit naar los monitorproces."""
        if self.process.poll() is None:
            try:
                self.sock.sendto(json.dumps({'kind':'buttons','state':state}).encode('utf8'),self.target)
            except OSError:
                pass

    def send_swing(self, state, message=None):
        """Swing-waarden en MIDI-event voor de losse read-only debug-GUI."""
        if self.process.poll() is None:
            payload={'kind':'swing','state':state}
            if message is not None:
                payload['message']=message.dict()
            try:
                self.sock.sendto(json.dumps(payload).encode('utf8'),self.target)
            except OSError:
                pass

    def send_preset(self, info, led_snapshot=None):
        if self.process.poll() is None:
            try:
                payload={'kind':'preset','info':info}
                if led_snapshot is not None:
                    payload['leds']=led_snapshot  # daadwerkelijk verzonden MIDI-leds
                self.sock.sendto(json.dumps(payload).encode('utf8'),self.target)
            except OSError:
                pass

    def send_sync(self, status):
        if self.process.poll() is None:
            try:
                self.sock.sendto(json.dumps({'kind':'sync','status':status}).encode('utf8'),self.target)
            except OSError:
                pass

    def send_values(self,cc_values):
        """Werk de virtuele parameterstanden in het venster bij, ook zonder SEND ALL."""
        if self.process.poll() is None:
            try:
                self.sock.sendto(json.dumps({'kind':'values','values':cc_values}).encode('utf8'),self.target)
            except OSError:
                pass

    def send_apc_status(self, status):
        if self.process.poll() is None:
            try:
                self.sock.sendto(json.dumps({'kind':'apc', 'status':status}).encode('utf8'),self.target)
            except OSError:
                pass

    def send_midimix_leds(self, snapshot):
        """Single source of truth: states of ACTUALLY SENT MIDImix LEDs."""
        if self.process.poll() is None:
            try:
                self.sock.sendto(json.dumps({'kind':'midimix_leds',
                                            'status':snapshot}).encode('utf8'),self.target)
            except OSError:
                pass

    def send_output_gain(self, db):
        if self.process.poll() is None:
            try:
                self.sock.sendto(json.dumps({'kind':'output_gain', 'db':db}).encode('utf8'), self.target)
            except OSError:
                pass

    def poll_commands(self):
        """Only gain messages from the GUI's known local UDP endpoint."""
        commands = []
        if self.process.poll() is not None:
            return commands
        for _ in range(32):
            try:
                packet, address = self.sock.recvfrom(512)
            except BlockingIOError:
                break
            except OSError:
                break
            if address != self.target:
                continue
            try:
                payload=json.loads(packet.decode('utf8'))
                if payload.get('kind') != 'set_output_gain':
                    continue
                value = payload.get('db')
                if type(value) not in (int,float) or not -6 <= value <= 9:
                    continue
                commands.append(float(value))
            except (ValueError,UnicodeDecodeError,TypeError,AttributeError):
                continue
        return commands

    def close(self):
        self.sock.close()
        if self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=1.0)
            except subprocess.TimeoutExpired:
                self.process.kill()
