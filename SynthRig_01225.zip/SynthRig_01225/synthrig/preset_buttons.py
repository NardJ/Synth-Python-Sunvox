"""Deterministic SOLO-button gesture detection (no MIDI device required)."""
from __future__ import annotations

class SoloSaveButton:
    def __init__(self,threshold=1.5):
        self.threshold=float(threshold)
        self.down_at=None

    def feed(self,msg,now):
        if getattr(msg,'type',None) not in ('note_on','note_off') or getattr(msg,'note',None)!=27:
            return None
        down=(msg.type=='note_on' and getattr(msg,'velocity',0)>0)
        if down:
            if self.down_at is None:self.down_at=now
            return None
        if self.down_at is None:return None  # ignore orphan release
        duration=max(0,now-self.down_at)
        self.down_at=None
        return 'save' if duration>=self.threshold else 'panic'
