"""SynthRig 0.9.3: persistente synthinstellingen, nooit een hardware-uitlezing.

Schrijf atomair, zodat afbreken tijdens opslaan geen onvolledig JSON-bestand oplevert.
"""
from __future__ import annotations
import json
import os
from .mod_matrix import (blank_matrix, validate_matrix, validate_groups,legacy_groups,
                         migrate_state_matrix,MATRIX_LAYOUT)
from pathlib import Path

DEFAULT_RAW = {
    'filter.cutoff':78,'filter.resonance':18,'master.level':110,
    'osc1.level':102,'osc2.level':102,'sub.level':0,'noise.level':0,
    'amp.attack':20,'amp.decay':44,'amp.sustain':90,'amp.release':40,
    'filter.attack':18,'filter.decay':48,'filter.sustain':20,'filter.release':40,
    'filter.env_amount':0,'filter.keytrack':0,
    'lfo.rate':65,'lfo.pitch_depth':0,'lfo.filter_depth':0,
    'pwm.depth':0,'pwm.rate':68,
    'osc1.pulse_width':64,'osc2.pulse_width':64,
    'osc1.semitones':64,'osc2.semitones':64,
    'osc1.finetune':64,'osc2.finetune':64,
    'performance.velocity':89,'performance.portamento':0,'effects.chorus':0,
    'effects.delay':0,'effects.reverb':0,
}
DEFAULT_STATE_PATH = Path(__file__).resolve().parents[1] / 'state' / 'last_session.json'


def default_state(controls):
    return {'schema':1,'layout_targets':{str(cc):spec['target'] for cc,spec in controls.mappings.items()},
            'raw':{target:DEFAULT_RAW.get(target,64) for target in
                   (spec['target'] for spec in controls.mappings.values())},
            'waveforms':{'1':2,'2':3},
            'enabled':{'osc1':True,'osc2':True,'sub':True,'noise':True},
            'fx':{'delay':0,'reverb':0},
            'mod_matrix':blank_matrix(),'mod_groups':validate_groups(None),
            'mod_matrix_layout':MATRIX_LAYOUT,'mod_legacy_routes':[]}


def load_state(path, controls):
    path=Path(path)
    if not path.exists(): return None
    try:
        data=json.loads(path.read_text(encoding='utf8'))
        if data.get('schema')!=1:raise ValueError('Onbekende stateversie')
        current=default_state(controls)
        saved_layout=data.get('layout_targets',{})
        additions={'performance.velocity','performance.portamento','effects.chorus',
                   'effects.delay','effects.reverb'}
        if not isinstance(saved_layout,dict) or any(
            current['layout_targets'].get(cc)!=target for cc,target in saved_layout.items()):
            raise ValueError('Opgeslagen MIDImix-layout wijkt af')
        expected={spec['target'] for spec in controls.mappings.values()}
        raw=data['raw']
        if not isinstance(raw,dict) or set(raw)-expected or expected-set(raw)-additions or not all(
            type(value)==int and 0<=value<=127 for value in raw.values()):
            raise ValueError('Onvolledige of ongeldige controllerstanden')
        # Upgrade 0.9.13 without losing oscillator/filter/ADSR positions.
        data['raw']={**current['raw'],**raw}
        data['layout_targets']=current['layout_targets']
        wave=data['waveforms']; enabled=data['enabled']
        if set(wave)!={'1','2'} or not all(type(i)==int and i in range(4) for i in wave.values()):
            raise ValueError('Ongeldige golfvormen')
        if set(enabled)!={'osc1','osc2','sub','noise'} or not all(type(v)==bool for v in enabled.values()):
            raise ValueError('Ongeldige bronstatus')
        fx=data.get('fx',{'delay':0,'reverb':0})
        if not isinstance(fx,dict) or set(fx)!={'delay','reverb'} or not all(
            type(x)==int and 0<=x<=127 for x in fx.values()):
            raise ValueError('Ongeldige delay/reverb sessiestand')
        data['fx']=fx
        data, archived = migrate_state_matrix(data)
        data['mod_matrix']=validate_matrix(data.get('mod_matrix',blank_matrix()))
        data['mod_groups']=(validate_groups(data['mod_groups']) if 'mod_groups' in data
                            else legacy_groups(data['mod_matrix']))
        if archived:
            print(f'WAARSCHUWING: {len(archived)} oude matrixroutes gedeactiveerd en gearchiveerd '
                  'in mod_legacy_routes; vorige sessiebestand is ongemoeid gelaten.')
        # Pre-0.11.1: FX were saved separately; populate newly mapped knobs.
        for key in ('delay','reverb'):
            if 'effects.'+key not in raw:
                data['raw']['effects.'+key]=fx[key]
        return data
    except (OSError, ValueError, KeyError, TypeError, AttributeError) as exc:
        print(f'WAARSCHUWING: sessiestand niet geladen ({path}): {exc}')
        return None


def apply_state(rig,controls,state,*,pickup=False):
    """Pas alle parameters toe. Alleen geaccepteerde MIDI-CCs veranderen target_raw."""
    for target,raw in state['raw'].items():
        rig.set_parameter(target,raw)
    for k,index in state['waveforms'].items():
        rig.set_waveform_index(int(k),index)
    for source,enabled in state['enabled'].items():
        rig.set_source_enabled(source,enabled)
    for effect,raw in state.get('fx',{'delay':0,'reverb':0}).items():
        rig.set_parameter('effects.'+effect,raw)
    rig._mod_legacy_routes=list(state.get('mod_legacy_routes',[]))
    rig.load_mod_matrix(state.get('mod_matrix',blank_matrix()))
    rig.load_mod_groups(state.get('mod_groups'))
    controls.target_raw=dict(state['raw'])
    for effect,raw in state.get('fx',{}).items():
        if 'effects.'+effect in controls.target_raw:
            controls.target_raw['effects.'+effect]=raw
    controls.last_physical.clear()
    controls.pickup.clear()
    if pickup: controls.arm_pickup()


def capture_state(rig,controls):
    state=default_state(controls)
    state['raw']={spec['target']:controls.target_raw[spec['target']]
                  for spec in controls.mappings.values()}
    # Direct terminal FX edits must also show up at CC47/48.
    state['raw']['effects.delay']=max(0,min(127,round(rig.delay_mix*127)))
    state['raw']['effects.reverb']=max(0,min(127,round(rig.reverb_mix*127)))
    state['waveforms']={str(k):v for k,v in rig.wave_selection.items()}
    state['enabled']=dict(rig.source_enabled)
    state['mod_matrix']=rig.mod_matrix.dump()
    state['mod_matrix_layout']=MATRIX_LAYOUT
    state['mod_legacy_routes']=list(getattr(rig,'_mod_legacy_routes',[]))
    state['mod_groups']=rig.mod_matrix.dump_groups()
    state['fx']={'delay':max(0,min(127,round(rig.delay_mix*127))),
                 'reverb':max(0,min(127,round(rig.reverb_mix*127)))}
    return state


def save_state(path, rig, controls):
    path=Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload=json.dumps(capture_state(rig,controls),indent=2,ensure_ascii=False)+'\n'
    tmp=path.with_name('.'+path.name+'.tmp')
    try:
        with open(tmp,'w',encoding='utf8') as fh:
            fh.write(payload)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp,path)
    finally:
        if tmp.exists():tmp.unlink()
    return path
