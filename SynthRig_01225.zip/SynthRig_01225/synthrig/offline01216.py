"""0.12.16: full legacy audio tests + automatic hard PANIC tail tests."""
from pathlib import Path
import json
from .offline01211_full import run as previous_run
from .offline01216_panic import run as panic_run


def run(output_dir='recordings',save_wav=True,wave_offsets=None,pitch_calibration=-12.,pitch_lfo_mode='native'):
    previous=previous_run(output_dir=output_dir,save_wav=save_wav,
                          wave_offsets=wave_offsets,pitch_calibration=pitch_calibration,
                          pitch_lfo_mode=pitch_lfo_mode)
    panic=panic_run(output_dir=output_dir,pitch_lfo_mode=pitch_lfo_mode)
    total={k:previous['summary'].get(k,0)+panic['summary'].get(k,0) for k in ('PASS','FAIL')}
    report={'version':'0.12.16','mode':pitch_lfo_mode,'summary':total,
            'previous_audio':previous['summary'],'panic':panic['summary']}
    dest=Path(output_dir);dest.mkdir(parents=True,exist_ok=True)
    (dest/f'summary_01216_{pitch_lfo_mode}.json').write_text(json.dumps(report,indent=2)+'\n')
    print(f'SynthRig 0.12.16 {pitch_lfo_mode}: {total}',flush=True)
    return report
