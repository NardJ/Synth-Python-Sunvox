"""Laad fysieke CC-toewijzingen uit config/controls.json.

Geen enkele UI-component is nodig om dit bestand te gebruiken.
"""
from __future__ import annotations
import json
from pathlib import Path

DEFAULT_CONFIG = Path(__file__).resolve().parent.parent / "config" / "controls.json"
ALLOWED_TARGETS = ['filter.cutoff', 'filter.resonance', 'master.level', 'osc.mix', 'osc1.finetune', 'osc1.level', 'osc1.pulse_width', 'osc1.semitones', 'osc1.waveform', 'osc2.finetune', 'osc2.level', 'osc2.pulse_width', 'osc2.semitones', 'osc2.waveform', 'pwm.depth', 'pwm.rate']


def load_mappings(path=DEFAULT_CONFIG):
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    mappings = {}
    for key, spec in data.items():
        try:
            cc = int(key)
        except ValueError:
            raise ValueError(f"Ongeldig CC-nummer {key!r}") from None
        if not (0 <= cc <= 127):
            raise ValueError(f"MIDI CC buiten bereik: {cc}")
        target = spec.get("target")
        if target not in ALLOWED_TARGETS:
            raise ValueError(f"Onbekende target {target!r} bij CC{cc}")
        mappings[cc] = {"target": target, "label": spec.get("label", target)}
    if len(set(x["target"] for x in mappings.values())) != len(mappings):
        raise ValueError("Dezelfde synthparameter komt op meerdere CC's voor")
    return mappings
