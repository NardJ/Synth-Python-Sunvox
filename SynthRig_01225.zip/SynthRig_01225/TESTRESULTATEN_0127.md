# SynthRig 0.12.7 — testresultaten

- **194/194 Python-regressietests geslaagd**, inclusief twee nieuwe checks op het plaatsen van kolomheaders boven de matrix en blijvende faderuitlijning.
- **239/239 echte SunVox-audiocontroles (native)** geslaagd.
- **239/239 echte SunVox-audiocontroles (events)** geslaagd.
- De APC-monitor is onder een virtueel Linux-display gerenderd; de labels staan boven de bovenste padrij, zonder overlap met de instructieregel of pads.
- De hardware-MIDI-bediening en de nieuwe GUI-labelpositie zijn nog niet samen op de fysieke APC van de gebruiker getest.

Het betreft een **GUI-only update** van 0.12.6; de SunVox-engine en APC event-routing zijn ongemoeid gebleven. De audiotests zijn volledige regressies, geen nieuwe auditieve beoordeling van alle 256 theoretische routes.
