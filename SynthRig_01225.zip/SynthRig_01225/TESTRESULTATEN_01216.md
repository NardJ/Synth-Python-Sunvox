# SynthRig 0.12.16 — testresultaten

| Controle | Native | Events |
|---|---:|---:|
| SunVox volledige offline suite inclusief PANIC | 248/248 | 248/248 |
| PANIC extra DSP-audio (onderdeel van bovenstaande) | 6/6 | 6/6 |
| Matrixroutering | 256/256 | 256/256 |
| Matrixroute met audioverandering | 254/256 | 254/256 |
| Matrix akoestisch onbeslist | 2 | 2 |

- Python-regressies: 238/238 (incl. 5 nieuwe controls). 
- Tkinter LED-mirroring virtueel Linux-display: geslaagd.
- Hard PANIC tijdens reverb+delay: eerste gerenderde blok na de commandopdracht exact nul (`RMS=0`, `peak=0`), daarna klinkt nieuwe noot weer.
- BANK wisselt zonder DSP-clean; eerder begonnen effecten blijven uitklinken.
- Fysieke MIDI-controllers niet beschikbaar in deze testomgeving. Handmatige rigtest blijft noodzakelijk.

De bestaande twee akoestisch onbesliste gevallen zijn envelope→delay-feedback; dit zijn geen routingfouten.
