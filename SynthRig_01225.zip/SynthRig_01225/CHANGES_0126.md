# SynthRig 0.12.6 — testrelease voor een headless patchpanel

- Vijf LED-toestanden per pad: uit, AC/groen, AD/blauw, BC/oranje, BD/paars.
- Elk pad bevat hoogstens één route; geen ingewikkelde combinaties van twee
  gelijktijdige verbindingen op hetzelfde pad.
- Vaste bron- en bestemmingslabels voor laag 1/2; zie `PATCH_MATRIX_0126.md`.
- 16 modulatiebronnen en 16 bestemmingen met echte audio-implementatie.
- APC-faders per kolom met opgeslagen groepstoewijzingen en relatieve
  gezamenlijke diepte. SCENE toont de groepen na een faderbeweging één seconde.
- SHIFT-knop zichtbaar in het APC-monitorvenster. SHIFT+pad wist direct.
- MIDI SysEx-uitlezing, MIDImix SEND ALL, sequencer, 16 klankpresets en
  SynthRig 0.11.3-stemverdeler behouden.
- Oude 0.12.5-presetverbindingen worden behouden als groene AC-routes.
- Een wijziging van een preset leest nieuwe groepsinstellingen in en overschrijft
  nooit de presets in de oude projectmap.

**Testrelease:** de twee-laags bronnamen en bestemmingnamen zijn voorlopige
kandidaten voor de toekomstige print-overlays. Beoordeel die voordat de
geprinte bedieningspanelen ontworpen worden.
