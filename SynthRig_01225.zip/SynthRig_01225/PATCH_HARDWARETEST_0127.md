# SynthRig 0.12.7 — praktische PATCH-test

De kolomlabels staan nu **boven** de 8×8-pads; de bronlabels blijven links.
De audiomatrix, MIDImix, Swing, APC-mapping en sequencer zijn verder ongewijzigd.

## Vooraf

- Start `python synthrig_0127.py --debug-ui --midi-log`.
- Kies tijdelijk een klank met OSC1 **SAW**, OSC2/sub/noise bij voorkeur uit,
  een vrij open filter, korte Attack/Release, gematigd volume.
- Noteer welke klank/preset je gebruikt. **Bewaar de testwijzigingen niet
  in een bestaand gebruikersslot** als je dat wilt behouden.
- Wis voor de genoemde testposities oude verbindingen met **SHIFT+pad**.
- Zorg dat PATCH actief is. De nieuwe tweede-laagfuncties zijn nog voorlopig.

## Test A — de vier kleuren en vier echte routes

Gebruik de onderste rij (**LFO / LFO 2**) en kolom 5 (**CUTOFF / DELAY**).
Houd tijdens de CUTOFF-proeven een noot aan; bij DELAY speel je ook korte
noten en luister je na het loslaten.

| Druk | LED | Route | Wat je hoort of controleert |
|---|---|---|---|
| 1 | groen | LFO → CUTOFF | Filter beweegt met MIDImix-LFO-tempo |
| 2 | blauw | LFO → DELAY | Delaymix wordt gemoduleerd; luister naar echo's |
| 3 | oranje | LFO 2 → CUTOFF | Langzamere filterbeweging dan bij groen |
| 4 | paars | LFO 2 → DELAY | Langzamer wisselende delaymix |
| 5 | uit | geen route | Klank keert naar basisinstelling terug |

**Let op:** effecten bij DELAY kunnen subtiel zijn afhankelijk van de preset,
notenlengte en het delayniveau. Een nauwelijks hoorbare DELAY-route is niet
op zichzelf een fout. De vier kleuren en routing moeten wel overeenkomen
met het APC-venster.

## Test B — twee bronnen in dezelfde kolom

1. Zet **onderste rij, kolom 5** op groen (LFO → CUTOFF).
2. Zet **rij 6 vanaf onder, kolom 5** op groen (KEYTRACK → CUTOFF).
3. Speel lage en hoge noten en luister naar verschil in filtering, mét LFO.
4. Beweeg APC-**fader 5** een beetje. De groene SCENE-lampjes van beide
   rijen moeten gedurende ongeveer **1 seconde na de laatste beweging**
   actief zijn.
5. Druk in die periode op een SCENE-knop om de betreffende rij uit de
   fadergroep te halen. De **verbinding zelf** moet blijven bestaan.
6. Beweeg fader 5 opnieuw. Alleen de nog toegewezen route verandert nu mee.

De fader verandert de groepsversterking **relatief**. De diepte van de twee
routes wordt niet samengevoegd of overschreven. Een fader kan de routemix
in zijn kolom maximaal 2× versterken; hij is geen absolute MIDImix-cutoff.

## Test C — twee onafhankelijke kolomfaders

- Zet bijvoorbeeld **LFO → OSC1 PITCH** aan: onderste rij, kolom 1, groen.
- Laat ook **LFO → CUTOFF** actief: onderste rij, kolom 5, groen.
- Beweeg APC-fader 1: vibratodiepte verandert, terwijl de instelling van
  fader 5 behouden blijft. Beweeg fader 5 en luister naar de filterbeweging.
- Let bij snelle bewegingen op plopjes, pitchsprongen en clipping.

## Test D — preset en SEQ bewaren

- Sla de testpatch onder een **nieuwe naam** op in de SynthRig-terminal:
  `p save PATCHTEST0127`.
- Wis een route via SHIFT+pad; laad dan `p load PATCHTEST0127`.
- Controleer of kleur, route en fadergroep terugkomen.
- Wissel even naar SEQ en weer naar PATCH. Bestaande sequencerpatronen
  mogen niet veranderen; de PATCH-routes moeten behouden blijven.

## Wat ik van je wil terughoren

1. Zijn **groen/blauw/oranje/paars** op de fysieke APC goed herkenbaar?
2. Is **vijfmaal op dezelfde pad drukken** prettig of te omslachtig?
3. Is de **SCENE-selectie van één seconde** voldoende, of te kort?
4. Zijn er hoorbare **plopjes, vastlopende noten of grote volumesprongen**?
5. Welke combinaties van de tweede laag klinken nuttig, welke niet?

Als iets misgaat: maak met `r` + Enter een diagnoseopname in de terminal,
herhaal de fout, stop met opnieuw `r` + Enter en upload de diagnose-ZIP.
Beschrijf welke pads/SCENE/fader je gebruikte. Maak geen definitieve overlay
voordat de bron- en bestemmingskeuze is vastgesteld.
