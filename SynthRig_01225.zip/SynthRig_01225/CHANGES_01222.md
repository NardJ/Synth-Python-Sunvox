# SynthRig 0.12.22 — APC-looplengte

- Looplengte 4, 8 of 16 stappen per APC-patroon. Interne clock en SWING-clock gebruiken dezelfde gekozen grens.
- SEQ + APC-SHIFT + bovenste drie rechter scene-knoppen selecteren direct 4/8/16. De lengtekeuze verandert geen patroonbank en stopt het transport niet.
- Tijdens SHIFT toont de GUI LENGTE met 4/8/16; hardware-LEDs en virtuele LEDs geven dezelfde geselecteerde lengte aan. Loslaten herstelt de patroonbankweergave.
- Zichtbare LOOP-header, juiste stapnoemer in beide monitoren en gedimde kolomlabels/opgeslagen noten buiten de loop.
- SAVE bewaart het nieuwe optionele `length`-veld. Het opslagrooster blijft 8 lanes × 16 stappen, zonder dataverlies bij inkorten. Oudere patroonbestanden zonder veld krijgen lengte 16.
- Bij inkorten buiten de huidige afspeelpositie: alleen APC-gate loslaten, volgende stap begint bij 1; tempo en MIDI-clockfase blijven doorlopen. Een gedeelde SWING-noot blijft beschermd.
- Nieuwe startfile `synthrig_01222.py`; overname van sessie, presets, patronen en outputgain geeft 0.12.21 prioriteit en overschrijft geen aanwezige bestanden.
- Nieuwe tests voor lussen, controllergebaren, leds, opslag, compatibiliteit, live wisselen en GUI/UDP. Geen nieuwe dependencies of wijzigingen in SunVox-DSP, ADSR-geometrie of fabriekspresets.
