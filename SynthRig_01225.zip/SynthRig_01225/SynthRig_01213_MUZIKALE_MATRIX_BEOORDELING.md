# SynthRig 0.12.13 — muzikale beoordeling van 256 modulatieverbindingen

**Beoordeling, geen gebruiksstatistiek.** Deze 256 routes zijn stuk voor stuk muzikaal ingeschat met de concrete 0.12.12 bron- en bestemmingsnamen als uitgangspunt. Dit is nadrukkelijk **niet** een nieuwe audio-audit of 256 afzonderlijke luistertests. Eerdere tests bevestigden de routing en veel audioresponsen, niet de artistieke frequentie van gebruik.

## Uitkomst

| Mogelijke toepassing | Aantal routes |
|---|---:|
| Breed muzikaal inzetbaar | 103 |
| Situationeel / patchafhankelijk | 112 |
| Niche, vaak redundant of met extra risico | 41 |
| **Totaal** | **256** |

### Behouden vs schrappen van kruislagen

| Routegroep | Breed inzetbaar | Situationeel | Niche | Totaal |
|---|---:|---:|---:|---:|
| AC + BD (houden bij versimpeling) | 53 | 52 | 23 | 128 |
| AD + BC (kwijt bij versimpeling) | 50 | 60 | 18 | 128 |

Dat er 50 breed inzetbare kruislaagverbindingen zouden verdwijnen, pleit tegen het beperken tot AC+BD. De exacte aantallen zijn een **beredeneerde ontwerpinschatting**, niet uit patches verzamelde statistiek.

## Scores

- **Veelzijdig (3):** meerdere klassieke sounddesign- of live-expressietoepassingen, mits de patch de betrokken oscillator/effect werkelijk gebruikt.
- **Situationeel (2):** muzikaal nuttig in een passend programma, maar geen dagelijkse standaardverbinding.
- **Niche (1):** vooral effectklanken, overbodig bij bestaande basisregeling, of extra voorzichtigheid nodig bij snelle veranderingen/feedback.

De rangschikking is bedoeld om de **fixed-overlay** te beoordelen, niet om routes automatisch te verbieden. Voor alle 256 beoordelingen, voorwaarden en verklaringen: `SynthRig_01213_routebeoordeling_256.csv` / `.xlsx`.

## Concrete voorbeelden

- **Essentieel kruislaag:** AFTERTOUCH → REVERB MIX (AD); MOD ENV → CUTOFF (BC); LFO 3 → OSC1 PWM (BC).
- **Voorwaardelijk:** LFO → OSC1 PWM werkt alleen muzikaal als OSC1 een pulsgolf speelt; LFO → LFO RATE kan self-modulatie zijn.
- **Vaak redundant:** KEYTRACK → OSC1 PITCH (toonhoogte is al gekoppeld aan MIDI-noot); BIAS → OSC1 LEVEL (constante offset).
- **Risicovol:** TRIGGER → OSC1 PITCH (abrupte toonhoogtesprong); S&HOLD → DELAY FEEDBACK (plotse feedbackwisselingen).

## Advies

1. **Behoud AC, AD, BC en BD**: alleen AC+BD zou 50 breed bruikbare kruislagen uitsluiten zonder hardware te besparen.
2. **Behoud optie A**: één actieve route per pad. De limiet van 64 gelijktijdige routes is een veel begrijpelijkere beperking dan een bron-/bestemmingsverbod.
3. **Beoordeel vooral BIAS, GATE en TRIGGER**: zij leveren relatief veel nicheverbindingen op en concurreren voor schaarse vaste rijlabels. Niet automatisch verwijderen: BIAS is handig voor statische doelen zonder fysieke knob, GATE/TRIGGER voor percussie.
4. **Waarschuw bij pitchstappen en feedback**, en toon duidelijk dat PWM alleen een pulsgolf beïnvloedt. Niet elke route is in iedere preset hoorbaar.
5. **Maak eerst enkele presetfamilies** (bass, pad, lead, percussion, experimental) en kijk welke routes in de praktijk worden gebruikt voordat we de overlay definitief vastleggen.

## Vergelijking met bestaande synths

- Arturia PolyBrute ondersteunt cross-routing van meerdere bronnen naar dezelfde bestemming en kent onafhankelijke dieptes: https://support.arturia.com/hc/en-us/articles/4405748080914-PolyBrute-Modulation-Matrix
- Novation Summit ondersteunt o.a. LFO Rate, oscillator pitch/shape, noise level en FX-feedback als bestemmingen: https://novationmusic.com/products/summit
- ASM Hydrasynth heeft veel bronnen/bestemmingen maar een beperkt aantal tegelijk toewijsbare routes: https://www.asmhydrasynth.com/hydrasynth-specifications.html

*Broncodereferentie: SynthRig 0.12.12 `synthrig/mod_matrix.py`; muzikale rubricering door de assistent. Geen empirisch prevalentieonderzoek.*
