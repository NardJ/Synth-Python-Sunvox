# SynthRig 0.12.16 — LED-spiegeling en hard PANIC

## MIDImix-fysieke en virtuele LEDs
- Een BANK LEFT/RIGHT-druk laat de 1..16 preset-LED-teller tegelijk zien op de echte MIDImix en in het debugvenster.
- Het debugvenster ontvangt de status **van de daadwerkelijk verzonden MIDI-LED-opdrachten**. Er is dus geen tweede teller die afwijkend kan lopen.
- De voorheen bewaarde golfvorm- en bron-LEDs komen na 1 seconde op beide plekken terug. Bij herhaalde BANK-drukken begint de seconde opnieuw.
- Bij afwezigheid van een MIDI-output blijft de GUI normale synthstatus tonen, zonder te pretenderen dat fysieke feedback is verzonden.

## PANIC
- Kort SOLO/PANIC op MIDImix en PANIC op APC geven beide een **SunVox CLEAN_SYNTHS**-event.
- Dat stopt alle actieve noten en wist de DSP-buffers van de effectmodules (Echo, Reverb, Chorus).
- De APC-sequencer en de notenadministratie stoppen; presets, master en effectinstellingen blijven behouden.
- BANK LEFT/RIGHT gebruikt uitdrukkelijk geen CLEAN_SYNTHS: normale echo- en galmstaarten mogen uitklinken.
- PANIC is een noodstop. Een zeer abrupte stop kan een korte schakeltransiënt geven; er is geen op audio-rate gecontroleerde microfade ingebouwd.

## Testdekking
- 238/238 Python-regressies.
- 248/248 SunVox-audiocontroles in beide modi, inclusief 6 PANIC-audiotests.
- 256/256 routings per audiomodus; 254/256 per modus meetbaar en 2 akoestisch onbeslist.
- Virtuele Tk/Canvas-test onder Xvfb: preset 11, fysieke LED-toestanden, terugkeer, ongewijzigde statusweergave.

De echte hardware-MIDImix/APC blijft ter plekke te controleren.
