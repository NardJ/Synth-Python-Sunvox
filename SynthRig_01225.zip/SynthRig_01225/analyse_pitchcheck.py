#!/usr/bin/env python3
"""Controleer de audio van SynthRig 0.9.6 --pitchcheck --record.

Pure standaardbibliotheek; geschatte toonhoogte via positieve nuldoorgangen.
Geschikt voor de automatische SOLO-SINUS-test, niet voor volle akkoorden.
De WAV is een Linux-output-monitor, dus eventuele andere audio kan verstoren.
"""
from __future__ import annotations
import argparse
from array import array
import io
import json
import math
from pathlib import Path
from statistics import median
import sys
import wave
import zipfile

WINDOWS = {
    'Normaal 1':(.67,1.05),
    '+2 semitonen':(1.67,2.05),
    '-2 semitonen':(2.67,3.05),
    'Normaal 2':(3.67,4.05),
    'Vibrato':(4.67,5.95),
    'Vibrato uit':(6.67,7.05),
}


def read_wav(path):
    path=Path(path)
    if path.suffix.lower()=='.zip':
        with zipfile.ZipFile(path) as z:
            names=[n for n in z.namelist() if n.lower().endswith('.wav')]
            if len(names)!=1:
                raise ValueError(f'Verwacht 1 WAV in ZIP, gevonden {len(names)}')
            content=z.read(names[0])
            return read_audio(io.BytesIO(content))
    return read_audio(path)


def read_audio(source):
    with wave.open(str(source) if isinstance(source,Path) else source,'rb') as f:
        channels=f.getnchannels();width=f.getsampwidth();rate=f.getframerate()
        if width!=2:
            raise ValueError(f'Alleen 16-bit PCM ondersteund; breedte={width}')
        data=f.readframes(f.getnframes())
    all_samples=array('h')
    all_samples.frombytes(data)
    if sys.byteorder!='little':all_samples.byteswap()
    return rate,list(all_samples[::channels])


def window_stats(samples,rate,begin,end):
    samples=samples[max(0,int(begin*rate)):min(len(samples),int(end*rate))]
    if len(samples)<1000:
        return {'frequency_hz':None,'rms_dbfs':None,'crossings':0}
    rms=math.sqrt(sum(float(v)**2 for v in samples)/len(samples))/32768
    # De synth-test is een zuivere SIN. Kruisingen met lineaire interpolatie;
    # mediaan is minder gevoelig voor incidenteel audioartefact.
    dc=sum(samples)/len(samples)
    crossing=[]
    for i in range(1,len(samples)):
        a=samples[i-1]-dc;b=samples[i]-dc
        if a<0<=b and b!=a:
            crossing.append((i-1)+(-a)/(b-a))
    frequencies=[]
    for a,b in zip(crossing,crossing[1:]):
        freq=rate/(b-a)
        if 45<=freq<=2000:
            frequencies.append(freq)
    return {'frequency_hz':round(median(frequencies),2) if len(frequencies)>8 else None,
            'rms_dbfs':round(20*math.log10(rms),2) if rms>0 else None,
            'crossings':len(crossing),
            'freq_spread_hz':round(max(frequencies)-min(frequencies),2) if len(frequencies)>8 else None}


def report(path):
    rate,samples=read_wav(path)
    print('SynthRig 0.9.6 pitchcheck-analyse')
    print(f'Audio: {len(samples)/rate:.2f}s, {rate} Hz (kanaal links)')
    results={k:window_stats(samples,rate,*times) for k,times in WINDOWS.items()}
    for k,v in results.items():
        hz=v['frequency_hz'];rms=v['rms_dbfs']
        print(f'{k:14}  pitch={hz if hz is not None else "--"!s:>8} Hz'
              f'  RMS={rms if rms is not None else "stil"} dBFS')
    f0=results['Normaal 1']['frequency_hz']
    if f0 is not None:
        print(f'Absolute grondtoon: {f0:.2f} Hz (MIDI-noot 60: verwacht circa 261.63 Hz)')
        if abs(1200*math.log2(f0/261.625565))>35:
            print('WAARSCHUWING: grondtoon wijkt meer dan 35 cent af; controleer tuning en spectrum.')
    success=f0 is not None and results['+2 semitonen']['frequency_hz'] is not None and results['-2 semitonen']['frequency_hz'] is not None
    if success:
        up=12*math.log2(results['+2 semitonen']['frequency_hz']/f0)
        down=12*math.log2(results['-2 semitonen']['frequency_hz']/f0)
        reset=results['Normaal 2']['frequency_hz']
        print(f'Gemeten verandering omhoog: {up:+.2f} halve tonen (verwacht +2)')
        print(f'Gemeten verandering omlaag:  {down:+.2f} halve tonen (verwacht -2)')
        if reset:
            print(f'Terug naar normaal:         {12*math.log2(reset/f0):+.2f} halve tonen (verwacht 0)')
        if abs(up-2)>.3 or abs(down+2)>.3:
            print('WAARSCHUWING: pitchverandering wijkt aanzienlijk af. Upload de diagnose-ZIP.')
        else:
            print('Pitchbend-verhouding komt overeen met ±2 halve tonen.')
    else:
        print('NIET BEOORDEELBAAR: onvoldoende betrouwbare sine-tonen. Kan stille opname of vervorming zijn.')
    print('Opmerking: de audio kan van andere programma’s komen; visuele/luistercontrole blijft nodig.')
    return results


def main():
    p=argparse.ArgumentParser(description='Meet de frequenties van SynthRig 0.9.6 pitchcheck-WAV/ZIP')
    p.add_argument('bestand',help='Diagnose ZIP of WAV (van --pitchcheck --record)')
    args=p.parse_args()
    report(args.bestand)

if __name__=='__main__':main()
