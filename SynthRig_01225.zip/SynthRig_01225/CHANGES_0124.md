# SynthRig 0.12.4 — fysieke faderstanden via MIDI

- APC Mini Mk2: verstuurt na openen van de Control-MIDI-poort de officiële AKAI Introduction SysEx (softwareversie 0.12.4).
- Verwerkt uitsluitend het officiële Introduction Reply-formaat met **negen fysieke faderwaarden**. Controle op fabrikant, model, berichttype en lengte.
- Het APC-monitorvenster toont alle negen faders bij opstarten en meldt ontvangst, ontbrekend antwoord of ontbrekende uitgangspoort.
- Een fader-CC die na het verzoek binnenkomt blijft leidend boven het moment waarop het antwoord wordt verwerkt.
- SysEx-waarden veranderen **geen** sequencer-BPM, nootmapping, presetwaarden of geluidsparameters; faders blijven pas actief bij fysieke bediening.
- MIDImix: druk op **SEND ALL** om alle 24 knopwaarden en 9 faderwaarden door te geven. De debugmonitor toont hoeveel van 33 fysieke standen bekend zijn.
- Bij opstarten wordt MIDImix-soft-takeover altijd ingeschakeld, zodat SEND ALL geen abrupte wijzigingen in de klank veroorzaakt.
- Presets, sequencer, effecten en DSP-engine zijn inhoudelijk niet gewijzigd.

**Beperking:** de SysEx-respons is getest met simulaties; de daadwerkelijke hardware-antwoordfunctie moet op de aangesloten APC bevestigd worden.
