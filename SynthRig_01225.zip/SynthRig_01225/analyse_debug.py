#!/usr/bin/env python3
"""Analyseert een enkele SynthRig opname-ZIP zonder extra pip-pakketten.

python analyse_debug.py recordings/synthrig_....zip
Kan ook de losse _summary.json als argument krijgen.
"""
from __future__ import annotations
import argparse
import csv
import io
import json
import math
from pathlib import Path
import statistics
import zipfile


def percentile(a, percent):
    if not a:
        return None
    a = sorted(a)
    return a[min(len(a)-1, round((len(a)-1)*percent/100))]


def summarize(summary, events, windows):
    ticks = [e['t'] for e in events if e['event'] == 'pwm_tick']
    # De optionele recorder start tijdens een reeds lopende synth; eerste
    # loopafstand vanaf t=0 wordt niet als PWM jitter beschouwd.
    gaps = [round((b-a)*1000, 4) for a, b in zip(ticks, ticks[1:]) if b >= a]
    writes = [e for e in events if e['event'] == 'pwm_written']
    errors = [e for e in events if e['event'] in ('event_loop_delay','exception')]
    markers = [e for e in events if e['event'] in ('manual_marker', 'test_stage')]
    audits = [e for e in events if e['event'] == 'readback_audit']
    mismatch = []
    for audit in audits:
        if audit.get('data',{}).get('delay_requested_s',0) < .15: continue
        for control in audit.get('data',{}).get('controls',[]):
            if control.get('status') == 'mismatch':
                mismatch.append((audit['t'], control['name'], control['requested_raw'], control['read_raw']))

    def average_rms(start,end):
        vals = [float(w['rms_dbfs_approx']) for w in windows
                if w['rms_dbfs_approx'] and start <= float(w['t_s']) < end]
        # gemiddeld dB is slechts een grove visualisatie, geen energetisch totaal
        return round(statistics.mean(vals),2) if vals else None
    dcs = [abs(float(w['dc_offset_approx'])) for w in windows if w['dc_offset_approx']]
    report = [
        'SynthRig 0.8.5 — analyse van debugopname',
        '=' * 48,
        f"Audio: {summary.get('recorded_audio_seconds')} seconden, {summary.get('sample_rate')} Hz",
        f"Per-osc DC-blockers (vóór filter): {'AAN' if summary.get('metadata',{}).get('dc_blocker_enabled') else 'UIT'}",
        f"Uitgestelde SunVox-readbacks: {len(audits)}, mismatches vanaf 150ms: {len(mismatch)}", 
        f"PWM-ticks: {len(ticks)}; daadwerkelijke SunVox Duty Cycle-writes: {len(writes)}",
        f"PWM-timing (interval tick): mediaan={round(statistics.median(gaps),2) if gaps else 'n.v.t.'} ms, p95={round(percentile(gaps,95),2) if gaps else 'n.v.t.'} ms, max={round(max(gaps),2) if gaps else 'n.v.t.'} ms",
        f"Eventloopvertragingen (>18ms): {len([e for e in errors if e['event']=='event_loop_delay'])}",
        f"RMS opname 0-2s (gem. dB): {average_rms(0,2)} dBFS",
        f"RMS opname 2-5s (gem. dB): {average_rms(2,5)} dBFS",
        f"Grootste |DC| per 100ms (benadering): {max(dcs,default=0):.5f}",
        f"Clips in bemonsterde data (benadering): {summary.get('approx_clipped_samples',0)}",
        f"Handmatige markers / testfasen: {len(markers)}",
        f"Audio-opnamefout: {summary.get('capture_error') or 'geen gemeld'}",
        '',
        'Let op: events en audio zijn NIET sample-precies gesynchroniseerd.',
        'Een Duty-write is niet hetzelfde als een PWM-tick: dezelfde native waarde kan meerdere ticks achtereen gelijk blijven.',
        'Audio RMS en DC zijn benaderd uit bemonsterde PCM; foutieve audio-routing kan een stille WAV opleveren.',
    ]
    for stamp,name,expected,actual in mismatch[:10]:
        report.append(f'Readbackverschil @{stamp:.3f}s: {name} gevraagd={expected}, gelezen={actual}')
    for marker in markers:
        report.append(f"Marker @{marker['t']:.3f}s: {marker['event']} {marker.get('data',{}).get('name','')}")
    return '\n'.join(report)


def load(path):
    if path.suffix.lower() == '.zip':
        with zipfile.ZipFile(path) as z:
            names = z.namelist()
            def find(suffix):
                matches=[n for n in names if n.endswith(suffix)]
                if not matches: raise FileNotFoundError(f'{suffix} ontbreekt in {path}')
                return matches[0]
            summary = json.loads(z.read(find('_summary.json')))
            events = [json.loads(line) for line in z.read(find('.jsonl')).decode().splitlines() if line.strip()]
            windows = list(csv.DictReader(io.StringIO(z.read(find('_audio_windows.csv')).decode())))
    else:
        summary = json.loads(path.read_text())
        events_path = path.parent / Path(summary['events']).name
        windows_path = path.parent / Path(summary['audio_windows_csv']).name
        events = [json.loads(line) for line in events_path.read_text().splitlines() if line.strip()]
        with windows_path.open() as f:
            windows = list(csv.DictReader(f))
    return summary, events, windows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('opname', type=Path, help='Opname-ZIP of _summary.json')
    args=parser.parse_args()
    summary, events, windows = load(args.opname)
    print(summarize(summary,events,windows))

if __name__ == '__main__':
    main()
