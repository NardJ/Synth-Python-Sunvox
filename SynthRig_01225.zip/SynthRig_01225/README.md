# SynthRig 0.12.25

Python/SunVox-synthesizer voor Behringer SWING, AKAI MIDImix en APC mini Mk2 op Linux.

## Nieuw: live patronen wisselen zonder stoppen

Tijdens afspelen in SEQ kun je met de acht kleine knoppen rechts naast het APC-rooster het volgende patroon kiezen. Het huidige patroon speelt zijn 4-, 8- of 16-stapsloop af. Op de volgende loopgrens begint het gekozen patroon bij stap 1, terwijl PLAY en de clock actief blijven.

- De knop van het huidige patroon blijft branden.
- De gekozen volgende patroonplaats knippert fysiek. In het venster knippert die knop amber en staat bijvoorbeeld **P01 → P02**.
- Op de overgang wordt de nieuwe knop de vaste actieve indicatie en verdwijnt de voorselectie.
- Kies je vóór de overgang nog een andere plaats, dan geldt de laatste geldige keuze.
- Druk op de knop van het huidige patroon om de voorselectie te wissen en het huidige patroon te laten herhalen.
- STOP, PANIC en afsluiten wissen de voorselectie. Er volgt na opnieuw starten geen oude onverwachte keuze.

Zonder afspelen wordt een gekozen patroon direct geladen, zoals voorheen. Een voorbereid patroon wordt vóór de overgang gelezen en gevalideerd; op de loopgrens vindt geen bestandslezing plaats.

## Tempo en noten tijdens performance

Bij live wisselen blijft de huidige BPM behouden, ook als het volgende patroon met een ander intern tempo was opgeslagen. Zo veroorzaakt een patroonkeuze geen temposprong. De rechter APC-fader blijft het live interne tempo regelen. Bij SWING-clock blijft de SWING het tempo bepalen.

Als je een patroon kiest terwijl de sequencer stilstaat, wordt het opgeslagen interne tempo wel geladen. Een selectie vóór de eerste clockpuls zet de gereedstaande patroonplaats meteen klaar.

Elke patroonplaats gebruikt zijn eigen looplengte, noten, velocity en ties. Op een patroonovergang krijgen de noten van het nieuwe patroon een eigen aanslag. Ties worden binnen het patroon behandeld; oude APC-gates worden op de overgang losgelaten. Release en effecten mogen natuurlijk uitklinken. De NoteRouter houdt SWING-noten beschermd. De overgang voert geen PANIC uit.

Kleine vertragingen van de interne polling schuiven de volgende stappen niet meer telkens op: de bestaande tijdlijn blijft het uitgangspunt. Na een echte lange stall worden gemiste stappen nog steeds overgeslagen in plaats van als een snelle notenreeks ingehaald.

## Praktisch spelen

Bereid maximaal acht patronen voor en bewaar ze elk met **TRACK 6 — SAVE**. In SEQ kies je de patroonplaatsen met de acht kleine knoppen **rechts naast** het rooster, van boven naar beneden, **zonder SHIFT**.

1. Kies patroon 1 en druk **TRACK 5 — PLAY**.
2. Druk tijdens afspelen op de tweede rechterknop. Patroon 2 knippert; patroon 1 speelt door.
3. Na het einde van de loop begint patroon 2 op stap 1.
4. Kies daarna bijvoorbeeld 1, 3 of 4 om verder te spelen. Je kunt zo live een vorm maken zoals 1 → 2 → 1 → 3 → 4.

Er staat steeds één volgende keuze klaar; de laatste knop vóór de overgang vervangt de vorige voorselectie. Een lege patroonplaats levert een leeg patroon op, terwijl de clock blijft lopen. Een onleesbare keuze verandert het actieve patroon en een eerdere geldige voorselectie niet.

**SAVE bewaart het actieve patroon, niet de knipperende volgende plaats.** Live bewerkingen worden niet automatisch opgeslagen door een wissel. De gewone LOAD-knop herlaadt het actieve patroon direct en wist een voorselectie.

## Installeren en starten

Sla je huidige APC-patroon in 0.12.24 eerst op met TRACK 6 — SAVE. Pak de nieuwe map uit naast `SynthRig_01224`. Opgeslagen sessie, gebruikerspresets, APC-patronen en outputgain worden eerst daaruit overgenomen, alleen waar nog geen nieuw bestand bestaat.

```bash
cd ~/Synth/Python-sunvox/SynthRig_01225
source ../.venv/bin/activate
python synthrig_01225.py --debug-ui --apc-clock internal
```

Voor een losse APC-performance staat de SWING op STOP. Voor externe clock kun je `--apc-clock swing` blijven gebruiken; SWING STOP en PAUSE/PLAY bedienen dan het mastertransport.

## Behouden bediening

TRACK 2 = SEQ; TRACK 3/4 = zichtbare pagina 1–8 / 9–16; TRACK 5 = PLAY/STOP; TRACK 6 = SAVE met bevestigingslicht; TRACK 7 = LOAD; TRACK 8 = PANIC. SHIFT + bovenste drie rechterknoppen kiest loop 4/8/16; SHIFT + pad maakt een tie. Padbewerkingen blijven hun rijtoon voorluisteren. ADSR, presetbediening, matrix en soft takeover blijven beschikbaar.

## Tests en bestanden

```bash
python -m unittest discover -s tests -q
python tests/audio_live_patterns_probe_01225.py
PYTHONPATH=.:tests xvfb-run -a python tests/gui_udp_live_patterns_probe_01225.py --capture
```

Zie `APC_LIVE_PERFORMANCE_01225.md`, `CHANGES_01225.md`, `TESTRESULTATEN_01225.md` en de echte testschermafdruk `GUI_LIVE_PATTERN_01225.png`. Native audio is zonder geluidskaart gemeten; de GUI/MIDI-keten is gesimuleerd getest. Fysieke controllers waren hier niet aangesloten. Geen nieuwe gebruikersdependencies.
