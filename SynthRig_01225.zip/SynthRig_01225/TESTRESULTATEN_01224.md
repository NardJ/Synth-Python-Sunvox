# Testresultaten SynthRig 0.12.24

| Controle | Resultaat |
|---|---|
| Volledige Python-regressiesuite | **350 tests geslaagd** |
| Gerichte echte SunVox-audio, ties | **16/16 cases geslaagd** in native/events-modus |
| Gerichte echte SunVox-audio, padpreview | **32/32 cases geslaagd** |
| Tied tegenover untied | Eén aanslag met continue audio tegenover twee aanslagen met gatepauze |
| Tempo bij audiometing | 60, 120 en 180 BPM gecontroleerd |
| Loopgrens in PCM | Volledig verbonden 4- en 16-stapsloops blijven over twee rondjes klinken met één aanslag; STOP geeft stilte na release |
| Unit-loopvarianten | 4/8/16, laatste-naar-eerste tie, ketens, externe-clockjitter en STOP/CONTINUE |
| Rust/pitch/live bewerking | Geen hangende gate na verwijderen buur, andere rijtoon of inkorten; native gate herstelt na engine-reset |
| Dubbele rijtoon / SWING | Geen voortijdige Note Off; geen verbinding tussen losse noten op verschillende rijen |
| Tie-invoer | SHIFT + tweede pad verandert alleen tie, niet beide aan/uit-stappen; geldige verbinding cyaan |
| Oud bestand en validatie | Ontbrekende ties = uit; ongeldige roosters afgewezen |
| SAVE | LED pas na atomaire vervanging, één seconde na afloop schrijfduur, herhaald drukken vernieuwt timer |
| SAVE-fout | Geen succeslicht, oude file intact, tijdelijke file opgeruimd en zichtbare foutmelding |
| Opslag | Ties, looplengte en BPM na SAVE/load behouden |
| Tempo | Rechterfader omlaag = 60 BPM; clockgrens behouden; SWING-tempo niet overschreven |
| Echte Tk/UDP | Cyaan-pad, TEMPO + BPM, fysieke LED-opdracht 105 en groen OK/succesverval gecontroleerd |
| Zoom | Nieuwe labels en hints passen bij 50%, 90% en 100%, zonder itemgroei |
| GUI-regressies | Preview, looplengte, SWING-sync, ADSR en SOLO geslaagd |
| Upgrade | 0.12.23 krijgt prioriteit; bestaande huidige bestanden blijven behouden |
| Bronvergelijking | Native DSP alleen versieteksten anders; ADSR, mapping, loopkeuzes en factory presets ongewijzigd |
| Aflevering | ZIP-integriteit, syntax en nieuwe tests/startfile uit afzonderlijk uitgepakte ZIP gecontroleerd |

## Meetbereik

Native audio is echte offline SunVox-PCM zonder MIDI-apparaat of geluidskaart. Een droge sinus-baseline met korte attack/release maakt gatepauzes en de loopnaad meetbaar. In de tiecases is de normale gatepauze afwezig en worden geen herhaalde Note Ons verzonden; de onverbonden controlegevallen behouden twee aanslagen. Andere presets gebruiken bij normaal spelen hun eigen ADSR en effecten. De volledige historische DSP-suite is niet opnieuw uitgevoerd.

De GUI-keten gebruikt echte Tk-canvassen en localhost-UDP, gesimuleerde MIDI en FakeSlot voor het engine-gatepad. Fysieke SWING, MIDImix en APC waren hier niet aangesloten. De SAVE-controle bevestigt verstuurde LED-opdrachten, geen hardware-uitlezing.

Logs staan in `reports_01224/`: `python_tests.log`, `audio_ties.log/json`, `audio_preview.log`, `gui_ties_save_tempo.log`, `gui_preview.log`, `gui_loop_length.log`, `gui_sync.log`, `gui_adsr.log`, `gui_solo_session.log` en `gui_solo_presets.log`. De echte Tk-schermafdruk is `GUI_TIES_SAVE_TEMPO_01224.png`.

Start voor deze functies `synthrig_01224.py`. Oudere startfiles en verslagen blijven historische referenties.
