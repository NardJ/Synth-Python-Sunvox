# 0.12.12 — vaste 7-posities matrixlabels

Volledige modulatienamen zijn intern behouden; alleen de overlay/debug-afkortingen zijn gewijzigd.

## Rijen (onder → boven)

| Rij | Laag A | Volledige bron | Laag B | Volledige bron |
|---|---|---|---|---|
| 1 | `LFO1` | LFO | `LFO2` | LFO 2 |
| 2 | `FLT ENV` | FILTER ENV | `AMP ENV` | AMP ENV |
| 3 | `VELOC` | VELOCITY | `MOD ENV` | MOD ENV |
| 4 | `TOUCH` | AFTERTOUCH | `LFO3` | LFO 3 |
| 5 | `MODWHL` | MOD WHEEL | `SMRAND` | SMOOTH RANDOM |
| 6 | `KEYTRK` | KEYTRACK | `NOTERMP` | NOTE RAMP |
| 7 | `GATE` | GATE | `TRIGGER` | TRIGGER |
| 8 | `BIAS` | BIAS | `S&HOLD` | SAMPLE & HOLD |

## Kolommen (links → rechts)

| Kolom | Laag C | Volledige bestemming | Laag D | Volledige bestemming |
|---|---|---|---|---|
| 1 | `O1PITCH` | OSC1 PITCH | `SUB LVL` | SUB LEVEL |
| 2 | `O2PITCH` | OSC2 PITCH | `NOISE` | NOISE LEVEL |
| 3 | `O1 PWM` | OSC1 PWM | `ENV AMT` | ENV AMOUNT |
| 4 | `O2 PWM` | OSC2 PWM | `LFO SPD` | LFO RATE |
| 5 | `CUTOFF` | CUTOFF | `DLY MIX` | DELAY MIX |
| 6 | `RESON` | RESONANCE | `REV MIX` | REVERB MIX |
| 7 | `O1 LVL` | OSC1 LEVEL | `CHO MIX` | CHORUS MIX |
| 8 | `O2 LVL` | OSC2 LEVEL | `DLY FB` | DELAY FEEDBACK |

Alle labels zijn maximaal 7 tekens en worden in een monospaced lettertype weergegeven. `O1PITCH`/`O2PITCH` betekent oscillator-**toonhoogte**, `PWM` pulsbreedtemodulatie, `LVL` niveau, `DLY FB` delay-feedback.
