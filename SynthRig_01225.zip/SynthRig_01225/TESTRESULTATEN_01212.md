# SynthRig 0.12.12 — verificatie

## Scope

Deze release is een GUI-/versiebeheerrelease: geen wijzigingen aan de werkelijke SunVox-DSP, APC-matrixroutelogica, MIDImix-knopmapping of APC-ledprotocol.

## Resultaat

| Controle | Uitkomst |
|---|---|
| Python-regressies | 212/212 PASS |
| Offline SunVox native DSP | 242/242 PASS |
| Offline SunVox events-DSP | 242/242 PASS |
| Monospaced 7-tekenslabels, 16 rijen + 16 kolommen | PASS (automatisch) |
| Uniforme status + event onderaan beide monitorvensters | PASS (broncode + virtuele Linux GUI) |
| Virtuele Linux-voorvertoning bij 1920×1100 | PASS |
| Upgradelijst: voorkeur voor 0.12.11 vóór oudere versies | Gecorrigeerd |
| Fysieke APC Mini/MIDImix/Swing | Niet opnieuw getest (vereist hardware) |

De audiocontroles komen overeen met het geërfde 0.12.11-testprogramma (239 bestaande SunVox-tests plus 3 nieuwe effecttesten). De audiotest heeft geen opname van fysieke MIDI-controllers nodig. Meer specifieke routemetingen staan in het rapport van 0.12.11; er is geen nieuwe complete matrixaudit uitgevoerd in deze uitsluitend visuele release.
