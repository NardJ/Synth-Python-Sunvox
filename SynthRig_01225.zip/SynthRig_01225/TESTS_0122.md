# SynthRig 0.12.2 — gecontroleerde wijzigingen

## Regressies
- **165/165** Python-unittests geslaagd; vijf nieuwe controles voor de gedeelde windowlayout en proportionele schaling.
- **226/226** offline SunVox-audiocontroles geslaagd in de native modus.
- **226/226** offline SunVox-audiocontroles geslaagd in de events-modus.
- De portamento-, polyfonie-, oscillator-, chorus-, delay-, reverb-, outputgain-, APC-sequencer- en vastgelopen-noten-regressies blijven groen.

## Virtuele Linux-GUI
Met `xvfb-run` en een Linux-windowmanager gecontroleerd op:

| Resolutie | Gezamenlijke schaal | Overlap? | Beide binnen scherm? |
| --- | ---: | --- | --- |
| 1935×1156 | 100% | Nee | Ja |
| 1600×900 | ca. 77% | Nee | Ja |
| 1366×768 | ca. 64% | Nee | Ja |

Ook live wijziging van MIDI-indicatoren, APC-padkleuren en faderstanden zonder verplaatste canvas-elementen getest. De outputgain-schuif blijft als echt bedienbaar Tk-widget aanwezig.

**Nog niet op fysieke hardware geverifieerd:** precieze titelbalk-/paneelruimte en eventuele afwijkende Cinnamon-schermschaling. Beide vensters blijven daarom gewoon met de muis verplaatsbaar.
