# Wijzigingen SynthRig 0.11.0

- **Basis:** SynthRig 0.10.2 met de al bevestigde portamento-trackreparatie.
- **Presetbibliotheek:** 8 code-gedefinieerde fabriekspresets voor bass, lead,
  strings, pad, keys, noise en brass.
- **Gebruikerspresets:** lossless JSON voor alle 31 toegekende regelaars,
  2 golfvormkeuzen, 4 source-switches en delay/reverb-wetmix.
- **Sessiecompatibiliteit:** bestaande schema-1-sessies zonder `fx` worden
  aangevuld met neutrale effectwaarden, zonder te resetten.
- **Presetselectie:** terminal (`p list/load/save/compare/next/prev`),
  MIDI BANK 25/26, en `--preset` bij starten.
- **Soft-takeover:** voor iedere preset-/A/B-wisseling opnieuw actief.
- **Delay:** echte SunVox Echo als wet-only bus; 100 ms mix-smoothing.
- **Reverb:** echte SunVox Reverb als wet-only bus; 100 ms mix-smoothing.
- **Dry path:** onveranderd; effecten starten uit om eerdere sessies
  akoestisch gelijk te houden als de effectmix op nul staat.
- **Versie/UI:** SynthRig 0.11.0 versus MIDI-mapping 1.0 expliciet gescheiden.
- **Tests:** 124 Python (waarvan 9 nieuwe preset-/effecttesten),
  187 native SunVox audiocontroles in beide modi (15 nieuw).

## Wat is bewust niet gewijzigd?

Alle fysieke MIDImix-CC-toewijzingen, OSC1/OSC2-bend en -fijntuning,
PWM, LFO, Swing-CC1 smoothing, vierstemmige voice assignment,
filter/amp envelopes, stereo chorus, pitchbend en portamento.
De APC Mini wordt pas in een latere versie toegevoegd.

## Bekende beperkingen

- Niveaus boven de gemeten presetstanden kunnen de polyfone mix oversturen.
- Geen nieuwe dedicated hardwareknop voor delay/reverb; gebruik terminal.
- Bij zeer snelle Swing-Modulation-bewegingen kan nog een lichte transient
  voorkomen (bekend sinds 0.9.13).
- Fabriekspresets zijn startklanken: muzikale voorkeuren vragen afstemming
  op jouw speakers, hoofdtelefoon en speelstijl.
