# SynthRig 0.12.5 — echte APC Mini Mk2 PATCH-matrix

## Wat doet een pad?

De **rij is de bron**, de **kolom is de bestemming**. Een brandende pad betekent:
**deze bron mag deze bestemming moduleren**. Meerdere verbindingen in dezelfde
rij en kolom kunnen tegelijk aan staan. De parameters van de MIDImix blijven
de basisinstellingen; de matrix voegt hier alleen tijdelijke beweging aan toe.

### Bronnen — van fysieke onderrij naar bovenrij

| Rij | Bron | Betekenis |
|---|---|---|
| 1 (onder) | LFO | heen-en-weer bewegende sinus met MIDImix LFO-snelheid |
| 2 | FILTER ENV | envelope per aangeslagen toets |
| 3 | VELOCITY | aanslagsterkte van die toets |
| 4 | AFTERTOUCH | druk op het keyboard |
| 5 | MOD WHEEL | Swing Modulation-trackpad (CC1) |
| 6 | KEYTRACK | lage/hoge noten leveren andere modulatie |
| 7 | GATE | 1 zolang de toets is ingedrukt |
| 8 (boven) | BIAS | constante waarde 1; bruikbaar als test of vaste offset |

### Bestemmingen — kolom 1 t/m 8

1. OSC1 pitch (tot ±25 cent)
2. OSC2 pitch (tot ±25 cent)
3. OSC1 PWM (alleen goed hoorbaar met PULSE)
4. OSC2 PWM (alleen goed hoorbaar met PULSE)
5. Filter cutoff (tot ±2 octaven)
6. Filterresonantie (tot ±25 procentpunten)
7. OSC1 volume (relatief tot zijn MIDImix-fader)
8. OSC2 volume (relatief tot zijn MIDImix-fader)

## Bediening

1. Druk op de onderste knop **PATCH**.
2. Druk op een pad om die verbinding **aan/uit** te zetten. Een nieuwe route
   begint met een veilige, positieve diepte van ongeveer 35%.
3. Druk rechts op de **scene-knop naast de gewenste rij** om die **bron** te kiezen.
   De bovenste rechter knop kiest de bovenste rij (BIAS), de onderste
   kiest de onderste rij (LFO). De gekozen bron staat blauw in de
   matrix; andere actieve routes zijn cyaan.
4. De **faders 1..8** veranderen nu uitsluitend de diepte van de gekozen bron
   naar de acht bestemmingen. Een niet-verbonden cel wordt niet door zijn
   fader ingeschakeld.
5. Omdat de faders fysieke standen hebben, gebruikt iedere route **soft takeover**:
   eerst langs de opgeslagen waarde bewegen. De fysieke standen zijn wel
   meteen zichtbaar via SysEx.

**Bipolaire diepte:** midden (64/127) is nul, links veroorzaakt negatieve
modulatie en rechts positieve modulatie. Dit heeft geen invloed op het
midden van de fysieke fader: voorheen opgeslagen presetwaarden worden niet
gewijzigd totdat je de fader echt beweegt en langs de softwarewaarde komt.

**Voorbeeld:** druk op het kruispunt van `LFO` (onderrij) en `CUTOFF`
(vijfde kolom). Houd een SAW-noot ingedrukt. Je hoort het filter bewegen.
Kies rechts de **onderste** scene-knop (LFO). Met fader 5 pas je nu de *sterkte*
van die beweging aan, zonder MIDImix Filter cutoff te veranderen.

**Bewaren:** routes worden opgeslagen in de normale SynthRig-sessie en in
klankpresets. Gebruik MIDImix BANK om een preset te kiezen, en **SOLO
minimaal 1,5 seconde** om het preset-slot inclusief matrix te bewaren.
De APC-knop SAVE/LOAD blijft het **SEQuencerpatroon** bewaren; dit zijn geen
PATCH-presetknoppen.

**De overige modus SEQ blijft aanwezig**, met 16 stappen, acht lanes en
acht patronen. Scene-knoppen kiezen daar weer de sequencerpatronen.

## Audioveiligheid

- De matrix grijpt in op de bestaande SunVox-stemmen; er is geen tweede
  audio-engine. Pitch gaat via de fasevaste SunVox 05/06-effecten.
- Snelle LFO's blijven Python-control-rate (~80 Hz). De pitchroute wordt
  begrensd en afgevlakt, maar speelgevoel bij extreme settings moet je op
  de echte hardware nog beluisteren.
- Resonantie, level en cutoff hebben begrensde modulatie; extreme combinaties
  kunnen nog steeds veel energie produceren. Begin met een matige master.
- Bestaande sessies en presets zonder `mod_matrix` krijgen een lege 8x8-matrix.

## Debugvenster

Het APC-venster toont de hele matrix, de geselecteerde bron, actuele
pad-LEDs, de fysieke stand van de negen faders en de opgeslagen diepte
per bestemming. Het programma toont de laatste LED-opdrachten, niet
teruggelezen LED-kleuren.
