# SynthRig 0.12.3 — APC-/MIDImix-vensters en zoom

- De APC Mini Mk2-monitor heeft nu afgeronde kader- en paneelhoeken zoals de MIDImix-monitor.
- Acht APC-faders zijn exact gecentreerd onder de acht overeenkomstige padkolommen; negende master is apart geplaatst.
- APC-fadertracks lopen op dezelfde ontwerpcoördinaten (y=658–775) als de MIDImix-fadertracks.
- De padmatrix is verticaal compacter, zodat de fadersectie gelijk uitlijnt.
- Ctrl + / Ctrl − / Ctrl 0 zoomt beide vensters samen in stappen, van 50% tot maximaal schermpassend.
- Fontgrootte, canvasvormen, gekoppelde Tk-schuif en live updates schalen mee.
- Preset-, sessie-, pattern- en outputgain-migratie controleert eerst de meest recente 0.12.2-map.
- Geen wijzigingen aan audio-DSP, MIDI-mapping, sequencerlogica of fysieke LED-commando’s.
- 169 Python-regressietests geslaagd; echte SunVox offline-audio opnieuw gecontroleerd.
