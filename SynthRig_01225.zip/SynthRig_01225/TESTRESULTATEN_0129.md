# Testresultaten SynthRig 0.12.9

De wheel van de gebruiker is gebruikt om echte SunVox PCM offline te renderen;
geen MIDI-controller of audioapparaat vereist.

| Controle | Native | Events |
|---|---:|---:|
| Volledige matrixaudit | 256/256 meetbaar | 256/256 meetbaar |
| Routering en controller | 256/256 juist | 256/256 juist |
| Aanvullende matrixtests | 5/5 PASS | 5/5 PASS |
| Bestaande SunVox-suite | 239/239 PASS | 239/239 PASS |
| Nieuwe sub/noise-audiotests | 8/8 PASS | 8/8 PASS |

Python-regressietests: **200/200 PASS**.

De audio-controles zijn deels overlappende testsets; de aantallen mogen
niet zonder meer als onafhankelijke unieke controles worden opgeteld.

Zie `MATRIX_AUDIT_0129.md` en `NOISE_TEST_0129.md`. De bijgeleverde
rapport-ZIP bevat de afzonderlijke CSV-, JSON- en WAV-resultaten.

De fysieke MIDImix, Swing en APC zijn in deze omgeving niet aangesloten;
hun hardwarewerking is niet opnieuw getest. De wijziging is beperkt tot
de noot-/pitchrouter van de gezamenlijke sub/noise-track.
