# SynthRig 0.12.6 — testresultaten

## Software en audiotests (uitgevoerd in deze sessie)

| Test | Resultaat |
|---|---|
| Python-regressies, inclusief 8 nieuwe 0.12.6-cases | 192/192 PASS |
| Native SunVox offline PCM | 239/239 PASS |
| Events SunVox offline PCM | 239/239 PASS |
| APC-monitor in virtuele Linux-desktop | Start en rendert succesvol |
| Fysieke APC Mini Mk2 in deze omgeving | Niet beschikbaar, hardwarecontrole nog nodig |

Bestaande audiocontroles uit 0.12.5 (233 per modus) en zes aanvullende
0.12.6-controles (onder meer AD Bias→SUB-volume, AD Bias→Delay, BC LFO2→Pitch
en BD Trigger→Reverb) zijn geslaagd. De oude tests omvatten waveform,
portamento, pitchbend, chorus, velocity, polyfonie, sequencer, vastlopende
noten en outputgain.

## Nieuwe functionele tests

- Pad doorloopt vijf toestanden en stuurt 4 RGB-kleuren; SHIFT+pad wist direct.
- Iedere positie heeft hoogstens één route.
- AC/AD/BC/BD leiden naar vier verschillende bron-/bestemmingsindices.
- Twee routes in dezelfde kolom kunnen met dezelfde fader gezamenlijk worden
  versterkt, zonder de opgeslagen individuele dieptes te veranderen.
- Tijdelijke SCENE-toewijzing na faderbeweging en terugkeer na 1 seconde.
- Oude 0.12.5-route wordt als AC geladen en de groepsindeling automatisch
  overgenomen.
- SEQ-mode, 16 stappen en patroonbediening blijven bruikbaar.

## Nog te controleren op de fysieke hardware

- Herkenbaarheid van groen, blauw, oranje en paars bij verschillende helderheid.
- Het tempo waarmee je de vijf toestanden wilt kunnen doorlopen.
- De tijd van één seconde voor het koppelen van SCENE-rijen tijdens het bewegen
  van de fader.
- Muzikale bruikbaarheid van de voorgestelde **tweede laag**. De namen zijn nog
  voorlopig en niet bedoeld voor een definitieve overlay.
- Snelle modulatieroutes met Sample & Hold en de nieuwe globale effectdoelen
  kunnen in extreme standen nog hoorbare transiënten/oversturing veroorzaken.

De tests tonen geen garantie tegen clipping bij alle mogelijke patches,
modulatiedieptes en vierstemmige combinaties.
