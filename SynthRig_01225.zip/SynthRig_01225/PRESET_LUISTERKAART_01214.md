# SynthRig 0.12.14 — luisterkaart voor 16 matrixpresets

De zestien **fabrieksposities** blijven genummerd 1–16. De basisgeluiden uit 0.12.13 zijn niet vervangen door willekeurige testgeluiden: ze kregen doelgericht gekozen modulatieverbindingen. Bestaande **eigen** `slot_XX.json`-presets worden nooit overschreven en hebben voorrang.

De APC-kleuren blijven groen=AC, blauw=AD, oranje=BC, paars=BD. Faders met groeperingen bepalen de gezamenlijke sterkte; de afzonderlijke routesterkte blijft opgeslagen.

| Slot | Fabriekspreset | Muzikale bedoeling | Luisterproef |
|---:|---|---|---|
| 01 | Analog Bass | Percussieve SAW-bas: filter-envelope plus velocity op oscillatorniveau | Speel C2–C3 staccato; luister naar filterattack en aanslagsterkte. |
| 02 | Deep Sub Bass | Diepe sinusbas: mod-envelope op sub en keytracking op filter | Speel C2 en daarna C4; toetsvolging verandert het filter. De sub blijft rond en diep. |
| 03 | Bright Lead | Expressieve lead: aftertouch-pitch, modwheel-filter en chorusbias | Houd C4 vast; druk harder (aftertouch) en beweeg het Modulation-trackpad. |
| 04 | PWM Strings | Twee PULSE-oscillatoren: verschillende LFOs op de pulsbreedte | Houd een drieklank 3 s vast; hoor twee onafhankelijk bewegende pulsbreedtes. |
| 05 | Soft Pad | Langzame pad: LFO2-filter, soepele random pitch, velocity-reverb | Houd C4 minstens 4 s vast; hoor zwevend filter, milde detune en ruimtelijkheid. |
| 06 | Glass Keys | Dynamische keys: AMP-envelope op OSC2 en filter/echoexpressie | Speel zacht en hard afwisselend; de aanslag en de korte effectuitklank kleuren de toon. |
| 07 | Noise Sweep | Effectklank: filter-envelope op noise, LFO3-filter en S&H-resonantie | Houd één toets 3 s vast; let op ruisaanzet, filterbeweging en resonantie. |
| 08 | Vintage Brass | Brass: filter-envelope plus korte pitch-envelope en aftertouch | Speel korte en lange noten; filter-envelope en korte pitchbeweging geven brassattack. |
| 09 | Detuned Saw Lead | Analoge detune-lead: kleine toonhoogtebeweging en modwheel-cutoff | Houd een leadnoot vast, beweeg MOD en luister naar cutoff naast de natuurlijke detune. |
| 10 | Warm Poly | Poly-pad: LFO2-filter, aftertouch-chorus en keytracking | Houd een akkoord vast, druk harder (aftertouch), vergelijk donker/licht en chorus. |
| 11 | Plucked Square | Pluck: mod-envelope op pulsewidth en velocity op cutoff | Speel korte noten met verschillende velocity; let op PWM en veranderend filter. |
| 12 | Dream Bell | Belachtige toon: kleine S&H-detune met opbouwende delaymix | Laat een korte noot los en luister naar de echo; de nootramp opent de delaymix. |
| 13 | Resonant Sweep | Filter sweep met LFO3-resonantie, noise-trigger en envelope | Houd C4 lang vast; resonantie en LFO3 veranderen het filter, met subtiele ruis. |
| 14 | Slow Motion Pad | Trage pad met smooth-random-filter en bewegende reverb | Houd een akkoord 4 s vast; random verandert filterkleur en LFO2 de galm. |
| 15 | Octave Pulse | Octaaf-pulse: PWM, velocity op oscillatorniveau en trigger-filter | Houd een noot aan en varieer velocity; LFO beweegt OSC2-pulsbreedte. |
| 16 | Vintage Organ | Organ: keytracking, chorus op modwheel en zachte tremolo | Houd een akkoord vast en beweeg de Modulation-trackpad voor extra chorus. |

## Precies welke matrixroutes staan aan?

Iedere rij is een fysiek APC-pad: bron (A/B), bestemming (C/D), diepte 0–127. **64 = nul**; hogere/lagere waarden veranderen richting en sterkte. Alle genoemde combinaties zijn verschillend per pad, nooit vier routes tegelijk op één pad.

### 01 — Analog Bass

- **AC** — FILTER ENV → CUTOFF, diepte **100**, pad rij 2, kolom 5
- **AC** — VELOCITY → OSC1 LEVEL, diepte **78**, pad rij 3, kolom 7

### 02 — Deep Sub Bass

- **BD** — MOD ENV → SUB LEVEL, diepte **88**, pad rij 3, kolom 1
- **AC** — KEYTRACK → CUTOFF, diepte **76**, pad rij 6, kolom 5

### 03 — Bright Lead

- **AC** — AFTERTOUCH → OSC1 PITCH, diepte **86**, pad rij 4, kolom 1
- **AC** — MOD WHEEL → CUTOFF, diepte **91**, pad rij 5, kolom 5
- **AD** — BIAS → CHORUS MIX, diepte **76**, pad rij 8, kolom 7

### 04 — PWM Strings

- **AC** — LFO → OSC1 PWM, diepte **102**, pad rij 1, kolom 3
- **BC** — LFO 2 → OSC2 PWM, diepte **97**, pad rij 1, kolom 4
- **BC** — MOD ENV → CUTOFF, diepte **83**, pad rij 3, kolom 5

### 05 — Soft Pad

- **BC** — LFO 2 → CUTOFF, diepte **84**, pad rij 1, kolom 5
- **BC** — SMOOTH RANDOM → OSC1 PITCH, diepte **75**, pad rij 5, kolom 1
- **AD** — VELOCITY → REVERB MIX, diepte **77**, pad rij 3, kolom 6

### 06 — Glass Keys

- **BC** — AMP ENV → OSC2 LEVEL, diepte **90**, pad rij 2, kolom 8
- **AC** — VELOCITY → CUTOFF, diepte **78**, pad rij 3, kolom 5
- **AD** — FILTER ENV → DELAY MIX, diepte **78**, pad rij 2, kolom 5

### 07 — Noise Sweep

- **AD** — FILTER ENV → NOISE LEVEL, diepte **105**, pad rij 2, kolom 2
- **BC** — LFO 3 → CUTOFF, diepte **88**, pad rij 4, kolom 5
- **BC** — SAMPLE & HOLD → RESONANCE, diepte **71**, pad rij 8, kolom 6

### 08 — Vintage Brass

- **AC** — FILTER ENV → CUTOFF, diepte **99**, pad rij 2, kolom 5
- **BC** — MOD ENV → OSC1 PITCH, diepte **77**, pad rij 3, kolom 1
- **AC** — AFTERTOUCH → CUTOFF, diepte **77**, pad rij 4, kolom 5

### 09 — Detuned Saw Lead

- **AC** — LFO → OSC2 PITCH, diepte **83**, pad rij 1, kolom 2
- **AC** — MOD WHEEL → CUTOFF, diepte **95**, pad rij 5, kolom 5

### 10 — Warm Poly

- **BC** — LFO 2 → CUTOFF, diepte **82**, pad rij 1, kolom 5
- **AD** — AFTERTOUCH → CHORUS MIX, diepte **85**, pad rij 4, kolom 7
- **AC** — KEYTRACK → CUTOFF, diepte **71**, pad rij 6, kolom 5

### 11 — Plucked Square

- **BC** — MOD ENV → OSC1 PWM, diepte **99**, pad rij 3, kolom 3
- **AC** — VELOCITY → CUTOFF, diepte **84**, pad rij 3, kolom 5

### 12 — Dream Bell

- **BC** — SAMPLE & HOLD → OSC2 PITCH, diepte **73**, pad rij 8, kolom 2
- **BD** — NOTE RAMP → DELAY MIX, diepte **78**, pad rij 6, kolom 5

### 13 — Resonant Sweep

- **BC** — LFO 3 → RESONANCE, diepte **78**, pad rij 4, kolom 6
- **AC** — FILTER ENV → CUTOFF, diepte **103**, pad rij 2, kolom 5
- **AD** — GATE → NOISE LEVEL, diepte **77**, pad rij 7, kolom 2

### 14 — Slow Motion Pad

- **BC** — SMOOTH RANDOM → CUTOFF, diepte **83**, pad rij 5, kolom 5
- **BD** — LFO 2 → REVERB MIX, diepte **79**, pad rij 1, kolom 6
- **BC** — MOD ENV → OSC1 LEVEL, diepte **78**, pad rij 3, kolom 7

### 15 — Octave Pulse

- **AC** — LFO → OSC2 PWM, diepte **98**, pad rij 1, kolom 4
- **AC** — VELOCITY → OSC2 LEVEL, diepte **82**, pad rij 3, kolom 8
- **BC** — TRIGGER → CUTOFF, diepte **77**, pad rij 7, kolom 5

### 16 — Vintage Organ

- **AC** — KEYTRACK → CUTOFF, diepte **77**, pad rij 6, kolom 5
- **AD** — MOD WHEEL → CHORUS MIX, diepte **85**, pad rij 5, kolom 7
- **BC** — LFO 3 → OSC1 LEVEL, diepte **77**, pad rij 4, kolom 7

## Testprotocol

1. Start `python synthrig_01214.py --debug-ui --midi-log` en verlaag de softwarematige Output Gain tot **0 dB** of **+3 dB** om oversturing tijdens luisteren te vermijden.
2. Kies presets met **BANK LEFT/RIGHT**, of typ `p load 1` enzovoort in de terminal. Let op: gebruikersslots zijn bewust behouden en kunnen daarom anders klinken dan de fabriekspatches.
3. Speel per preset de specifieke luisterproef hierboven. Vooral presets 3, 9, 10 en 16 hebben expliciete expressiebewegingen nodig.
4. Luister op een stereohoofdtelefoon wanneer chorus, delay of reverb betrokken is. Na presetwissel moeten APC-pads en faders de modulatieroutes tonen.
5. Zet bij twijfel kort `--preset-audit` in om de factory audit en audio-WAV zonder hardware te renderen; voor echt luisteren blijft je Swing belangrijk.

### Wat is objectief bevestigd?

De SunVox-offline-audit heeft **37/37** controles in native modus gehaald en alle 16 klanken met vier noten onder de digitale clippinggrens gehouden. De grootste piek was **0.570** (lineair, bij globale outputgain 0 dB).
Een gekozen RMS/spectrum-A/B-criterium detecteerde bij **12 van 16** klanken een duidelijke verandering. Bij vier klanken was die verandering in een enkele statische C4-test klein; dit is geen bewijs dat die modulaties niet werken. Gerichte tests voor Bright Lead-aftertouch, Deep Sub-keytracking en Octave Pulse-PWM zijn eveneens geslaagd.
Deze metingen zijn geen geblindeerde muzikale beoordeling. Het blijft zinvol om de presets op je eigen rig te beluisteren en later gericht te verfijnen.
