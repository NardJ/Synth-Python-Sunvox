# Wijzigingen 0.12.7

- Verplaatst de twee-laags kolomlabels (P1/SUB, enz.) in het APC-monitorvenster van onder naar **boven** het 8×8-padgrid.
- Past de verticale padrij-afstanden licht aan; controller-LED-mapping, padnummering, rijlabels, faderposities en audiomatrix zijn ongewijzigd.
- Voegt `PATCH_HARDWARETEST_0127.md` toe met concrete stappen voor kleur-, route-, fadergroep-, preset- en sequencerproeven.
- Migreert voorrangig huidige sessies, gebruikerspresets, APC-patronen en software-outputgain uit 0.12.6.
- Geen wijzigingen in SunVox-DSP of MIDI-eventlogica.
