> Historische handleiding uit een eerdere versie; voor de huidige offline-test zie [OFFLINE_TEST.md](OFFLINE_TEST.md).

# Golfvormcontrole 0.9.12

Zet luidsprekervolume laag en sluit andere audioprogramma’s.

```bash
cd ~/Synth/Python-sunvox/SynthRig_0912
source ../.venv/bin/activate
python synthrig_0912.py --wavecheck --record
```

De analyse controleert bij OSC1 en OSC2 vier golfvormen met een noot C4 (261.63 Hz). Het toont de wave-readback, de fundamentele frequentie, harmonischen en RMS per fase.

De TRI-offset is nu 0, bevestigd via 32 offline audiotests. De aanvullende controle op jouw Linux-computer blijft aanbevolen.

Daarna: `python synthrig_0912.py --qualitycheck --record`.
