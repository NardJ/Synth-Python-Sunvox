# APC Mini Mk2 — bron/bestemmingsindeling 0.12.11

Laag 1 blijft ongewijzigd. Laag 2 is een bewust vaste tweede keuze per fysieke rij en kolom. Dit is een werkende testindeling voor de toekomstige geprinte overlay, geen verplicht definitief ontwerp.

## Bronnen (rijen, van boven naar beneden)

| Rij op APC | Laag 1 | Laag 2 |
|---|---|---|
| 8 (boven) | BIAS | SAMPLE & HOLD |
| 7 | GATE | TRIGGER |
| 6 | KEYTRACK | NOTE RAMP |
| 5 | MOD WHEEL | SMOOTH RANDOM |
| 4 | AFTERTOUCH | LFO 3 |
| 3 | VELOCITY | MOD ENV |
| 2 | FILTER ENV | AMP ENV |
| 1 (onder) | LFO | LFO 2 |

De software gebruikt interne rijindex 0 voor de onderste rij. De hardware SCENE-knop staat rechtstreeks rechts van diezelfde fysieke bronrij.

## Bestemmingen (kolommen, van links naar rechts)

| Kolom | Laag 1 | Laag 2 |
|---|---|---|
| 1 | OSC1 PITCH | SUB LEVEL |
| 2 | OSC2 PITCH | NOISE LEVEL |
| 3 | OSC1 PWM | FILTER ENV AMOUNT |
| 4 | OSC2 PWM | LFO RATE |
| 5 | CUTOFF | DELAY MIX |
| 6 | RESONANCE | REVERB MIX |
| 7 | OSC1 LEVEL | CHORUS MIX |
| 8 | OSC2 LEVEL | DELAY FEEDBACK |

## Praktisch testen

1. Selecteer PATCH. Maak onderaan rij 1, kolom 5 een groene route (LFO → CUTOFF) en luister naar de bewegende filterklank.
2. Zet rij 4 (fysieke scene 4), kolom 5 op oranje om de zelfstandige LFO3 → CUTOFF te horen. Twee rijen kunnen dezelfde bestemming beïnvloeden.
3. Gebruik rij 8 (bovenste rij), kolom 4 als **blauwe** route BIAS → LFO RATE. Luister hoe de filtersweep sneller wordt wanneer de route actief is.
4. Zet voor echo de DELAY MIX op je MIDImix open. Kies rij 8, kolom 8 **blauw** voor BIAS → DELAY FEEDBACK. Luister na een korte toets naar meer herhalingen. Houd outputgain gematigd.
5. Houd SHIFT ingedrukt en druk op een pad om hem direct te wissen.

De APC-faders sturen nog steeds de relatieve diepte per kolomgroep. De MIDImix stelt het basisgeluid in. De kleine onderste en rechter APC-knoppen blijven ongewijzigd.
