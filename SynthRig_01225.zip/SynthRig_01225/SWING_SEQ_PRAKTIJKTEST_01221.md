# SWING SEQ — korte praktijktest voor SynthRig 0.12.21

Doel: bevestigen welke clock- en transportberichten jouw SWING via de gekozen MIDI-input verstuurt. Het programma kan niet uit de ontvangen noten afleiden of ze van handmatig spel, ARP of SEQ komen. Zet daarom de hardware zelf op SEQ.

## 1. Starten

Pak de nieuwe map uit naast de vorige versie en start:

```bash
cd ~/Synth/Python-sunvox/SynthRig_01221
source ../.venv/bin/activate
python synthrig_01221.py --debug-ui --midi-log --apc-clock swing --sync-report swing_sync_01221.json
```

Zet SWING synchronisatie op **INTERNAL**: SWING bepaalt het tempo, SynthRig/APC volgt. De instelling kan per hardware-/firmwareversie op het apparaat of in de configuratiesoftware zitten; volg de bij jouw exemplaar horende handleiding. Gebruik voor de eerste vergelijking SEQ met SCALE 1/16 en een bestaand eenvoudig patroon. Stel TEMPO ongeveer op 120 BPM.

Op de APC kies je met TRACK 2 de SEQ-modus. Zet voor een hoorbare vergelijking bijvoorbeeld een noot aan op stap 1 en stap 9. TRACK 3/4 kiest stappen 1–8 of 9–16. De SWING-sequence en het APC-patroon zijn twee afzonderlijke notenbronnen; bestaande opgeslagen patronen blijven behouden.

## 2. PLAY / START

Start de SWING-sequence. Verwacht:

- De SWING-noten klinken door de synth.
- Onderin het SWING-vak verschijnt SPEELT, de gemeten BPM en APC volgt met stapnummer.
- De APC PLAY-LED en stapweergave gaan mee; de eerste stap start op de eerste ontvangen clockpuls na START.
- De terminal toont `SWING TRANSPORT: start` of `continue`, afhankelijk van wat de hardware werkelijk verstuurt.

Verschijnt **wacht op CLOCK**, dan is wel START/CONTINUE ontvangen maar nog geen clock. Controleer SWING INTERNAL en of de gekozen poort zowel noten als clock verzendt. Alleen noten ontvangen bewijst nog geen clockverbinding. Als helemaal geen transport wordt ontvangen, bevestig dit met `sync`; SynthRig raadt geen START uit de noten.

## 3. Tempo veranderen

Verander het SWING-tempo, bijvoorbeeld van 120 naar 90 BPM. De gemeten BPM hoort mee te veranderen en de APC blijft één stap per zes clockpulsen zetten. De BPM is een schatting uit maximaal 24 intervallen en kan tijdens de overgang kort afwijken.

De APC-temposchuif verandert in SWING-clockmodus het externe tempo niet. SWING SCALE 1/8 of triolen verandert alleen de SWING-nootverdeling; de APC blijft in deze versie op 1/16 staan.

## 4. STOP en hervatten

Stop/pauzeer op de SWING. Als een MIDI STOP binnenkomt, worden APC-noten losgelaten en blijft de positie voor CONTINUE bewaard. Delay/reverb en de ingestelde release mogen uitklinken. Clockpulsen kunnen tijdens STOP blijven binnenkomen; dat mag de APC niet opnieuw starten.

Hervat daarna op de SWING en kijk naar de terminal:

| Ontvangen bericht | SynthRig/APC-gedrag |
|---|---|
| CONTINUE | Verder vanaf de bewaarde pulspositie |
| START | Opnieuw vanaf stap 1 |
| Alleen CLOCK | Geen automatische start van gestopt transport |

Welke knophandeling START of CONTINUE geeft, hangt af van het SWING-gedrag. Het JSON-bestand legt de werkelijk ontvangen berichten vast; deze test verandert de hardwareconfiguratie niet automatisch.

## 5. Clock weg / kabel los

Tijdens actief transport moet na 0,75 seconde zonder clock CLOCK WEG verschijnen en moet de externe APC stoppen. Openstaande noten van SWING en APC krijgen Note Off; release en effecten kunnen nog uitklinken. Een expliciete fout van de MIDI-poort geeft MIDI WEG en stopt de afhankelijke stemmen direct via Note Off.

Bij alleen clockverlies: herstel de clock en stuur een nieuwe START om de fase opnieuw vast te leggen. Terugkerende clockpulsen of CONTINUE hervatten na een timeout niet vanzelf.

Bij MIDI WEG: sluit de SWING opnieuw aan en herstart SynthRig. Automatisch opnieuw verbinden is nog niet aanwezig. SOLO/PANIC en de APC PANIC blijven zelfstandige noodstops.

## 6. Diagnose teruggeven

Sluit af met `q` of Ctrl+C. Het bestand **swing_sync_01221.json** staat in de projectmap. Geef dat bestand samen met je waarneming terug, bijvoorbeeld: “START en STOP komen binnen; na pauze verstuurt PLAY opnieuw START.” Dan kunnen we de volgende opname-/trackerstap op het bevestigde hardwaregedrag bouwen.

Dit rapport bevat geen audiobestand en geen volledige MIDI-opname. De meegeleverde `reports_01221/simulated_sync.json` is uitsluitend een automatisch gesimuleerd testresultaat, niet een meting van jouw SWING.

## Bronnen

- Behringer SWING: https://www.behringer.com/en/products/0715-AAL
- MIDI Association, clock en transport (24 pulsen per kwartnoot): https://midi.org/about-midi-part-3midi-messages
- MIDI Association, START/CONTINUE/STOP: https://midi.org/summary-of-midi-1-0-messages
