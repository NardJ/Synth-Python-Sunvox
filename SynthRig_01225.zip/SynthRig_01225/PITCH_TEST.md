> Historische handleiding uit een eerdere versie; voor de huidige offline-test zie [OFFLINE_TEST.md](OFFLINE_TEST.md).

# Eerste echte audiocontrole van SynthRig 0.9.12

Doe deze tests bij laag luidsprekervolume, in de genoemde volgorde.

## 1. Generator, SIN/SAW en Vibrato zonder filter of ADSR

```bash
cd ~/Synth/Python-sunvox/SynthRig_0912
source ../.venv/bin/activate
python synthrig_0912.py --tonecheck --record
```

Deze test gebruikt alleen SunVox-tracks 0 en 1. Hij speelt vijf opeenvolgende fasen: SIN via Note On, SIN met SET_PITCH 261,63 Hz, SIN met SET_PITCH 130,81 Hz, SAW 261,63 Hz en SIN via Vibrato bij nul amplitude. De console toont telkens de gelezen Waveform-waarde en het programma meldt of de opname werkelijk geluid bevat.

## 2. Volledige synth met onafhankelijke AMP ADSR-gates

```bash
python synthrig_0912.py --pitchcheck --record
```

Dit controleert de normale frequentie C4 = 261,63 Hz, Pitch Bend +2 = 293,66 Hz en −2 = 233,08 Hz, en daarna native Vibrato.

## 3. Eventueel AMP ADSR plus sub/noise

```bash
python synthrig_0912.py --soundcheck --record
```

Controleer vooral of geluid na Note Off volgens de Release-fader uitsterft. Sub en Noise delen sinds 0.9.12 één notenrouter, maar hun audiovolumes blijven afzonderlijk regelbaar.

Upload na stap 1 en 2 de twee nieuwste ZIP-bestanden uit `recordings/` (bij voorkeur met de terminalmeldingen als er waarschuwingen of fouten zijn). Als de kalibratietest nog stil blijft, is de oorzaak nader te onderzoeken en wordt dat niet als een geslaagde test beschouwd.

## 4. Zonder audiokaart: continue beweging controleren (0.9.12)

```bash
python synthrig_0912.py --offline-check
```

De `continuous_..._no_clicks`-metingen in `report.txt` meten de abrupte
sample-overgangen gedurende 81 opeenvolgende pitchwijzigingen. Dit is
specifiek de regressietest voor de hoorbare plopjes bij trackpad en fine-knop.
