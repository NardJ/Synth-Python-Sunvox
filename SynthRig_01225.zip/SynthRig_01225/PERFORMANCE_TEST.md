# SynthRig 0.10.2 — luister- en ontwikkelingstest

## Praktische test (Swing + MIDImix)

1. Zet master laag, kies **OSC1 SIN**, zet OSC2 / sub / noise tijdelijk uit.
2. Speel dezelfde toon heel zacht en daarna hard. Draai **CC58** van uiterst
   links (nagenoeg constant volume) naar rechts (duidelijk verschil).
3. Zet AMP Release kort en zet CC59 eerst maximaal. Speel C3, laat los,
   speel C4, en herhaal onmiddellijk C4; daarna C3 en nogmaals C3.
   **Geen abrupte sprongen** bij de tweede C4/C3: de glide moet vanaf de
   vorige klinkende toonhoogte doorgaan. Linksom op CC59: geen glide.
   Na 2 seconden pauze moet iedere nieuwe noot direct op de eigen toon beginnen.
4. Zet **CC60** aanvankelijk op 0. Houd één SIN-noot lang aan en draai
   geleidelijk helemaal open. De chorus moet nu duidelijker zweven en
   breed klinken. Luister bij voorkeur via stereohoofdtelefoon; draai weer
   helemaal dicht om het verschil te vergelijken.
5. Bij een aangehouden SAW-toon, filter cutoff lager zetten en druk op de
   toetsen toepassen. Als de Swing channel-aftertouch uitstuurt, wordt het
   filter hoorbaar helderder. Poly-aftertouch wordt per toets verwerkt als
   de controller dat MIDI-bericht levert.
6. Herhaal pitchbend, OSC1 fijn, OSC2 fijn en CC1 Modulation op SIN:
   die 0.9.12/0.9.13-functies moeten ongewijzigd werken.

## Offline-ontwerptest

Echte SunVox offline DSP (44.1 kHz, stereo, floating point):

- velocity 24/64/120: RMS groeit meetbaar; gevoeligheid 0%: RMS vrijwel gelijk;
- aftertouch 0 → 127: filter cutoff en hoogfrequente energie stijgen;
- poly-aftertouch op een van twee gelijktijdige noten blijft bij die stem;
- chorus op SIN: groter links/rechts verschil, ook met één noot;
- snelle chorus-mixbewegingen: geen grote sample-discontinuïteiten;
- portamento C4 → C5: oplopend naar de doelnoot;
- C3/C4/C4 en C4/C3/C3 bij snelle herhaling behouden de lopende pitch;
- portamento-geschiedenis vervalt na langere pauze;
- oude oscillator-, LFO-, pitchbend-, Modulation-, ADSR-, filter- en
  polyfonietests blijven geslaagd in beide engine-modi.

Einduitslag in de ontwikkelomgeving: 165/165 per audiomodus; 113/113
Python-tests. Extreme combinaties van vier luid ingestelde oscillatoren
kunnen ook zonder chorus oversturen: de bestaande headroom is een apart
onderwerp voor een volgende audio-level-afweging.

## Extra controle 0.10.2

Zet CC59 maximaal, CC60 minimaal. Behoud de korte AMP Release en OSC1-tuning uit de diagnose; speel C4→C5→C4. De afzonderlijke bronnen (OSC1, OSC2 en sub) moeten allemaal glijden. Controleer ook het opnieuw aanslaan van dezelfde noot. De ingestelde volle octaafglide is nog steeds ongeveer 1 seconde.
