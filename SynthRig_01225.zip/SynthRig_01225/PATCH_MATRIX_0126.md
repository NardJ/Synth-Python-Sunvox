# SynthRig 0.12.6 — PATCH-matrix met twee vaste lagen

Dit is een **testrelease voor headless bediening** op de APC Mini Mk2. De labels
zijn voorlopig; maak nog geen definitieve, geprinte overlay. De SEQ-modus en
alle MIDImix-/SWING-functies uit 0.12.5 blijven beschikbaar.

## Een pad = maximaal één verbinding

De rijen hebben een bron A (eerste laag) en B (tweede laag). De kolommen hebben
een bestemming C (eerste laag) en D (tweede laag).

Een pad heeft exact vijf mogelijke toestanden:

| Padstatus | Betekenis | APC LED |
|---|---|---|
| UIT | Geen verbinding | Uit |
| AC | Bron A → bestemming C | Groen |
| AD | Bron A → bestemming D | Blauw |
| BC | Bron B → bestemming C | Oranje |
| BD | Bron B → bestemming D | Paars |

**Druk dezelfde pad herhaaldelijk in:** UIT → AC → AD → BC → BD → UIT.
**SHIFT + pad:** direct uit. De kleur toont altijd de route. Een gekozen rij
verandert de padkleur niet meer.

Let op: *AC en BD kunnen op hetzelfde fysieke pad dus niet tegelijk bestaan.*
Verschillende pads (ook in dezelfde rij of kolom) blijven onafhankelijk actief.

## Bronnen (de rijen, van onder naar boven)

| Rij | A (laag 1) | B (laag 2) |
|---|---|---|
| 1 | LFO (bestaande LFO) | LFO 2 (½ frequentie, eigen fase) |
| 2 | Filter-envelope | AMP-envelope (Attack/Decay/Sustain/Release) |
| 3 | Velocity | Inverse velocity |
| 4 | Aftertouch | Inverse aftertouch |
| 5 | Modulation CC1 | Inverse modulation CC1 |
| 6 | Keytracking | Omgekeerde keytracking |
| 7 | Gate | Trigger (korte puls bij aanslag) |
| 8 | Bias (+1) | Sample & Hold (stapsgewijs signaal) |

## Bestemmingen (kolommen, van links naar rechts)

| Kolom | C (laag 1) | D (laag 2) |
|---|---|---|
| 1 | OSC1 Pitch | SUB volume |
| 2 | OSC2 Pitch | Noise volume |
| 3 | OSC1 PWM | Filter-envelopehoeveelheid |
| 4 | OSC2 PWM | Keytracking-hoeveelheid |
| 5 | Filter Cutoff | Delay Mix |
| 6 | Resonantie | Reverb Mix |
| 7 | OSC1 Level | Chorus Mix |
| 8 | OSC2 Level | Output Level (max. ±3 dB extra, begrensd) |

De oorspronkelijke modulatie blijft bovenop de MIDImix-basiswaarde werken. De
nieuwe globale effectbestemmingen gebruiken voor polyfone noten het gemiddelde
modulatiesignaal van de aanwezige stemmen. Voor nauwkeurige modulatie van
audio-rate parameters blijven enkele beperkingen van SunVox/control-rate 80 Hz
gelden. Snelle Sample & Hold- of pitchmodulatie kan hoorbare transiënten geven.

## De faders — geen tweede MIDImix

Elke APC-fader hoort permanent bij **zijn eigen kolom**. Je kunt aan die fader
meerdere *rijen* koppelen, ongeacht hun A/B-route. Als bijvoorbeeld LFO →
CUTOFF en KEYTRACK → CUTOFF allebei aanstaan in kolom 5, kan fader 5 beide
modulatiedieptes tegelijk versterken of verzwakken.

Belangrijk: dat gebeurt **relatief**: individuele opgeslagen pad-dieptes blijven
ongewijzigd. De fadergroep heeft een factor 0,0–2,0; bij 1,0 klinkt de route
zoals oorspronkelijk ingesteld. De faders werken in kleine relatieve stappen.
Het eerste CC-bericht (of de SysEx-beginstand) veroorzaakt geen klanksprong.

### Rijen aan een kolomfader koppelen

1. Beweeg fader 5 een klein stukje. De SCENE-lampjes laten **gedurende één
   seconde na de laatste faderbeweging** zien welke rij(en) aan kolom 5 zijn
   gekoppeld. Er zijn geen fader-aanraak- of loslaatberichten.
2. Druk in die seconde op een SCENE-knop om die rij aan de groep toe te voegen
   of eruit te halen. Een SCENE-druk verlengt de tijd met één seconde.
3. Beweeg fader 5 opnieuw. De **geselecteerde verbindingen in kolom 5** krijgen
   tegelijk een andere modulatiediepte, met behoud van hun onderlinge verhouding.
4. Na één seconde toont SCENE weer de normaal geselecteerde rij.

Een nieuw ingeschakelde pad wordt standaard aan de groep van die kolom
gekoppeld. Groepen en versterkingsfactoren worden opgeslagen in sessie en
gebruikerspreset.

**De rechter SCENE-knoppen zijn niet multifunctioneel in SEQ-modus:** daar
selecteren ze zoals voorheen de acht sequencerpatronen. De onderste knoppen
PATCH, SEQ, 1–8, 9–16, PLAY, SAVE, LOAD, PANIC werken als in 0.12.5.
De SHIFT-knop (rechts van PANIC) licht alleen *in het debugvenster* op: op de
fysieke APC heeft SHIFT geen LED.

## Directe test op je APC

1. Zet OSC1 op SAW en houd één toets ingedrukt.
2. Druk PATCH. Druk **onderste rij, kolom 5 eenmaal**: **groen** = LFO →
   Filter Cutoff. Je hoort filterbeweging met de LFO-snelheid van MIDImix.
3. Druk hetzelfde pad opnieuw: **blauw** = LFO → Delay Mix. Druk opnieuw:
   **oranje** = LFO2 → Filter Cutoff. Druk opnieuw: **paars** = LFO2 → Delay.
   Druk nogmaals voor uit.
4. Probeer **bovenste rij, kolom 5 tweemaal**: **blauw** = Bias → Delay Mix.
   Het effect is ook bij één aangehouden noot te horen. Gebruik SHIFT+pad om
   die route direct te verwijderen.
5. Activeer **onderste rij, kolom 5** groen en **rij 6, kolom 5** groen (KEYTRACK
   → Cutoff). Beweeg fader 5. De twee bijbehorende SCENE-LEDs lichten op; ze
   zijn afzonderlijk uit te schakelen met hun rechter SCENE-knoppen.
6. Wissel naar SEQ. De reeds bekende 16-stapssequencer moet ongewijzigd werken.

## Compatibiliteit

Een preset uit **0.12.5** wordt één-op-één als groene AC-verbindingen geladen.
De oude opslagwaarden zijn geldig gebleven: 0–127 betekent AC met die diepte.
Voor AD, BC, BD gebruikt 0.12.6 een versie-uitbreiding van dezelfde 8×8
opslagstructuur. Oude 0.12.5-software begrijpt die nieuwe verbindingen NIET;
gebruik je nieuwe 0.12.6-presetbestanden daarom niet in de oude versie.
De originele 0.12.5-mappen worden bij migratie niet overschreven.

De eerste test is op gesimuleerde APC-MIDI en echte offline SunVox-audio
uitgevoerd. De werkelijke kleuren en SCENE-bediening moeten nog op je fysieke
APC worden bevestigd voordat we vaste overlays ontwerpen.
