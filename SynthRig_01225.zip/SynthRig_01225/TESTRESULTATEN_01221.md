# Testresultaten SynthRig 0.12.21

## Uitgevoerde controles

| Controle | Resultaat |
|---|---|
| Volledige Python-regressiesuite | **287 tests geslaagd** |
| START/downbeat | Geen noot op START; stap 1 op eerste volgende clockpuls |
| Pulsverdeling | Vier volledige 16-stapsloops; één stap per zes pulsen |
| STOP/CONTINUE | Noot los, stap en gedeeltelijke pulspositie behouden |
| Nieuwe START | Oude APC-gates gewist; opnieuw vanaf stap 1 |
| Clock tijdens STOP | BPM meten; geen ongewenste herstart |
| Tempo | 20, 60, 120 en 240 BPM; veranderingen en korte pauze gecontroleerd |
| Gate | Gemeten extern tempo gebruiken; oude Note Off kapt hertrigger niet af |
| Clock-timeout | Geen eerste clock en wegvallende clock; 0,75 s grens gecontroleerd |
| Herstel na timeout | Nieuwe clock/CONTINUE/STOP+CONTINUE starten niet; verse START herstelt fase |
| MIDI-input weg | OSError/RuntimeError/gesloten poort opgevangen; alleen betrokken noten los; één foutmelding/teller |
| Zonder APC | SWING-nootroutering en timeout werken ook zelfstandig |
| Gewoon handmatig toetsen spelen | Zonder transport geen clock-timeout op vastgehouden toetsen |
| APC interne clock | Extern START/STOP grijpt niet in; gedeelde noot blijft bij de juiste bron |
| Eigen APC-bediening | Geen verzonnen inkomende transporttellers; gereedzetten wacht op master |
| Diagnose | Werkelijke tellers, bronpoort, maximaal 32 events; atomair JSON-bestand |
| Upgrade | 0.12.20 krijgt prioriteit; aanwezige 0.12.21-bestanden worden niet overschreven |
| Tk/UDP synchronisatie | Werkelijke vensters en UDP; START, BPM, STOP, CONTINUE, clockverlies en terugkerende clock geslaagd |
| Virtuele/hardware-LED-opdrachten | APC PLAY aan/uit en stapstatus gecontroleerd via MIDI-outputobject en GUI |
| GUI/zoom | Nieuwe regel past in bestaande layout op 50%, 90% en 100%; geen canvas-itemgroei |
| ADSR-regressie | Alle 16 presets, vier faders, pickup en zoom geslaagd in echte Tk/UDP |
| SOLO-regressie | 16/16 geselecteerde presets; 5 sessiestand-PANIC-cycli zonder LED-wijzigingen |
| Bronvergelijking | SunVox-DSP-code alleen versieteksten anders; ADSR-geometrie, mappings en fabriekspresets identiek aan 0.12.20 |
| Aflevering | ZIP-integriteit, Python-syntax en nieuwe tests/startfile uit afzonderlijk uitgepakte ZIP gecontroleerd |

## Reikwijdte en bestanden

De SWING-input, MIDI-poortfouten en MIDI-output zijn gesimuleerd. De tests gebruiken de echte inputhulpfuncties uit de startfile, echte Tk-canvassen en localhost-UDP, met FakeSlot als SunVox-engine voor de GUI-integratie. Er waren hier geen fysieke SWING, MIDImix of APC aangesloten. De timingcorrecties zijn dus softwarematig gecontroleerd; het werkelijk verzonden hardwaretransport bevestig je met `SWING_SEQ_PRAKTIJKTEST_01221.md`.

`reports_01221/python_tests.log` bevat de volledige regressiesuite. `gui_sync.log`, `gui_adsr.log`, `gui_solo_session.log` en `gui_solo_presets.log` bevatten de GUI-resultaten. `simulated_sync.json` is duidelijk gemarkeerde gesimuleerde input en geen meting van jouw hardware.

`GUI_SWING_SYNC_01221.png` is een echte Tk-schermafdruk uit de simulatie. De SunVox-DSP-audiotests zijn niet opnieuw uitgevoerd: de DSP-code is buiten versieteksten ongewijzigd. De sequencer-noot- en gatewijzigingen zijn via input-/routerings- en GUI-integratietests gecontroleerd.

Historische verslagen en schermafdrukken in het pakket horen bij hun eigen versienummer. Er zijn geen nieuwe dependencies voor de gebruiker toegevoegd; Pillow/Xvfb dienen alleen voor de GUI-tests.
