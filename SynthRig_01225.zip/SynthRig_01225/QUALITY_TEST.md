> Historische handleiding uit een eerdere versie; voor de huidige offline-test zie [OFFLINE_TEST.md](OFFLINE_TEST.md).

# Korte handleiding: SynthRig 0.9.12

**Eerst**:

```bash
cd ~/Synth/Python-sunvox/SynthRig_0912
source ../.venv/bin/activate
python synthrig_0912.py --qualitycheck --record
```

De opname wordt automatisch beëindigd en direct geanalyseerd.

**Daarna**: open het bestand `recordings/synthrig_..._quality_report.txt`.
Dezelfde bestanden worden ook aan de opname-ZIP toegevoegd.

Het rapport laat zien:
- `voice1_sin` tot `voice4_sin` en `voice1_osc2_sin` tot `voice4_osc2_sin`;
- `wave_switch_saw` en `wave_switch_back_sin`;
- `stage_generator`, `stage_dc_blocker`, `stage_osc_gain`, `stage_filter`, `stage_amp_adsr`, `stage_full_chain`;
- `adsr_attack_slow`, `adsr_release_tail`;
- `poly_one`, `poly_four`.

Let vooral op het verschil in de **tweede harmonische (H2)** tussen
`stage_generator` en `stage_full_chain`. Een hoog H2 in de Generator-tap
betekent iets anders dan harmonischen die pas later verschijnen.

Een audio-opname met ongewenste systeemgeluiden kan onjuiste uitslagen geven.

**Upload na de test één ZIP** uit `recordings/`. Die is voldoende om alle
fasen, WAV en analyse in samenhang te beoordelen.
