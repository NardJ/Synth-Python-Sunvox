# SynthRig 0.11.1 — preset- en hardwarebedieningstest

De volgende controles worden automatisch uitgevoerd via `tests/test_0110.py`, `tests/test_0111.py`, plus de offline SunVox-testengine:

- Er bestaan precies 16 geldig gebouwde fabriekspresets met unieke namen.
- BANK LEFT/RIGHT doorloopt 1–16 met wraparound, zonder eigen presets aan het einde van de bank toe te voegen.
- SOLO korter dan 1,5 seconde activeert PANIC op het moment van loslaten; langer ingedrukt vasthouden en loslaten resulteert in SAVE.
- Een lange SOLO-druk zonder geselecteerd slot schrijft niets weg en toont een waarschuwing.
- `save_slot` bewaart een gebruikersoverschrijving atomair in `slot_XX.json`; fabrieksdata zijn onveranderlijk. `restore_factory` verwijdert uitsluitend de gebruikersoverschrijving.
- De LED-teller schrijft MUTE-noten 1,4,...,22 en REC-noten 3,6,...,24. Na circa 1 seconde worden de oscillator- en bron-LEDs hersteld.
- CC47/48 zijn correct toegewezen aan Delay/Reverb, met soft takeover na laden.
- Oudere presets en sessiebestanden zonder deze twee mappingtargets worden opgewaardeerd met behoud van de eerder ingestelde FX-mix.
- Een bestaande 0.11.0-installatie naast de 0.11.1-map wordt niet-destructief gemigreerd; doelbestanden worden nooit overschreven.
- Met native SunVox zijn alle 16 presets ook op werkelijke vierstemmige audio en headroom gecontroleerd, alsmede de delay- en reverb-uitklank.

**Resultaten:** 195/195 SunVox-native, 195/195 SunVox-events, 134/134 Python-regressies geslaagd in de aangeleverde offline omgeving.

**Niet fysiek getest:** reactiesnelheid, LED-output en SOLO-lange-druk op jouw echte MIDImix. De tests gebruiken gesimuleerde MIDI-berichten en een gesimuleerde MIDI-uitgang. Bevestig het gedrag bij de eerste luistertest.
