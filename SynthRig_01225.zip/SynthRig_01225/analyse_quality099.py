#!/usr/bin/env python3
"""Meet SynthRig 0.9.12 kwaliteits-ZIP (qualitycheck/wavecheck): stemtonen, harmonischen, gains, ADSR.

WAV is Linux sink-monitor, dus het tijdstempel kan iets achterlopen op MIDI.
Waarschuwingen bij gebrek aan audio zijn geen 'PASS'.
"""
from __future__ import annotations
import argparse
from array import array
import io
import json
import math
from pathlib import Path
import sys
import wave
import zipfile
from analyse_tonecheck import spectrum


def load(path):
    with zipfile.ZipFile(path) as z:
        wav=next((n for n in z.namelist() if n.endswith('.wav')),None)
        logs=next((n for n in z.namelist() if n.endswith('.jsonl')),None)
        if not wav or not logs:raise ValueError('ZIP moet WAV en JSONL bevatten')
        events=[json.loads(s) for s in z.read(logs).splitlines() if s]
        with wave.open(io.BytesIO(z.read(wav))) as w:
            if w.getsampwidth()!=2:raise ValueError('Alleen s16 PCM')
            rate=w.getframerate();channels=w.getnchannels()
            pcm=array('h');pcm.frombytes(w.readframes(w.getnframes()))
            if sys.byteorder!='little':pcm.byteswap()
        return rate,pcm[::channels],events


def amplitude(samples,rate,start,end):
    start=max(0,int(start*rate));end=min(len(samples),int(end*rate))
    chunk=samples[start:end]
    if not chunk:return None
    rms=math.sqrt(sum(int(x)**2 for x in chunk)/len(chunk))/32768
    peak=max(abs(int(x)) for x in chunk)/32768
    return {'rms_dbfs':round(20*math.log10(max(1e-12,rms)),2),
            'peak_dbfs':round(20*math.log10(max(1e-12,peak)),2),
            'clipped':sum(abs(int(x))>=32760 for x in chunk)}


def analyze(path,save=True):
    rate,pcm,events=load(path)
    phases=[e for e in events if e['event']=='quality_step']
    warnings=[e['data'] for e in events if e['event']=='quality_warning']
    report={'version':'0.9.12','source_zip':str(path),'audio_seconds':round(len(pcm)/rate,2),
            'sample_rate':rate,'stages_measured':[], 'checks':[],'warnings':warnings}
    def check(label,status,detail):
        report['checks'].append({'check':label,'status':status,'detail':detail})
    by_label={}
    for e in phases:
        data=e['data'];t=e['t'];duration=float(data['duration'])
        # Rec timestamps are only approximations of acoustic onset; skip 0.42s.
        volume=amplitude(pcm,rate,t+.40,t+min(duration-.10,1.13))
        # The older tonecheck FFT assumes nonzero audio and divides by
        # fundamental magnitude; never feed it silence.
        metrics=(spectrum(pcm,rate,t) if duration>=1.15 and volume and
                 volume['rms_dbfs']>-65 else None)
        record={'label':data['label'],'kind':data.get('kind'), 'start_s':t,
                'duration_s':duration,'setup':data,'spectrum':metrics,'amplitude':volume}
        report['stages_measured'].append(record)
        by_label[data['label']]=record
        if data.get('waveform_expected') is not None:
            status='PASS' if data['waveform_expected']==data.get('waveform_readback') else 'FAIL'
            check(data['label']+' waveform',status,
                  f"requested={data['waveform_expected']}, readback={data.get('waveform_readback')}")
        if data.get('expected_hz') and metrics:
            cents=1200*math.log2(max(1e-5,metrics['dominant_hz'])/data['expected_hz'])
            record['cents_error']=round(cents,1)
            check(data['label']+' frequency', 'PASS' if abs(cents)<=35 else
                  ('FAIL' if data.get('kind')=='wave_calibration' else 'WARN'),
                  f"expected={data['expected_hz']:.2f}Hz, measured={metrics['dominant_hz']:.2f}Hz ({cents:+.1f}c)")
        if volume:
            check(data['label']+' audible','PASS' if volume['rms_dbfs']>-58 else 'FAIL',
                  f"RMS={volume['rms_dbfs']:.1f}dBFS")
            if volume['clipped']>0:
                check(data['label']+' clipping','FAIL',f"{volume['clipped']} clipped samples")
    # SIN harmonic diagnosis; do not assert specific THD below the raw generator.
    for label in ('voice1_sin','voice2_sin','voice3_sin','voice4_sin',
                  'wave_switch_back_sin','stage_generator','stage_full_chain',
                  'wave_osc1_sin','wave_osc2_sin'):
        item=by_label.get(label)
        if item and item['spectrum']:
            h=item['spectrum']['harmonic_2_db']
            if h is not None:
                check(label+' 2nd harmonic','PASS' if h < -30 else 'WARN',f'H2={h:+.1f} dBc')
    a=by_label.get('adsr_attack_slow')
    if a:
        t=a['start_s']
        early=amplitude(pcm,rate,t+.10,t+.28)
        late=amplitude(pcm,rate,t+1.2,t+1.52)
        if early and late:
            gain=late['rms_dbfs']-early['rms_dbfs']
            check('ADSR attack rise', 'PASS' if gain>4 else 'WARN',
                  f'late-early={gain:+.1f} dB (audio delay may distort estimate)')
    r=by_label.get('adsr_release_tail')
    if r:
        t=r['start_s']
        early=amplitude(pcm,rate,t+.12,t+.38)
        late=amplitude(pcm,rate,t+1.82,t+2.18)
        if early and late:
            difference=late['rms_dbfs']-early['rms_dbfs']
            check('ADSR release fades', 'PASS' if difference<-5 else 'WARN',
                  f'late-early={difference:+.1f} dB')
    one=by_label.get('poly_one');four=by_label.get('poly_four')
    if one and four and one['amplitude'] and four['amplitude']:
        delta=four['amplitude']['rms_dbfs']-one['amplitude']['rms_dbfs']
        check('4-voice level','PASS' if delta>1 else 'WARN',f'4-voice vs 1-voice: {delta:+.1f} dB')
    for stage in ('generator','dc_blocker','osc_gain','filter','amp_adsr','full_chain'):
        if 'stage_'+stage not in by_label:
            check('tap '+stage,'SKIP','No stage recording; wrapper may not support safe rewiring')
    if not phases:check('qualitycheck','FAIL','Geen quality_step-events gevonden')
    report['counts']={k:sum(c['status']==k for c in report['checks']) for k in ('PASS','WARN','FAIL','SKIP')}
    lines=[f"SynthRig 0.9.12 QUALITY REPORT — {Path(path).name}",
           f"Audio {report['audio_seconds']:.2f}s @ {rate} Hz · phases {len(phases)}",
           'LET OP: monitor-WAV niet sample-precies gesynchroniseerd; andere PC-audio kan meetellen.', '']
    for item in report['stages_measured']:
        s=item['spectrum'] or {};a=item['amplitude'] or {}
        lines.append(f"{item['label']:<26} RMS={a.get('rms_dbfs','?'):>7} dBFS   "
                     f"Hz={s.get('dominant_hz','?'):>7}  H2={s.get('harmonic_2_db','?')} dBc")
    lines.extend(['','Controlepunten:'])
    for c in report['checks']:
        lines.append(f"[{c['status']:4}] {c['check']}: {c['detail']}")
    lines.append(f"\nTotaal: {report['counts']}. WARN vereist beoordeling, is geen bewezen fout.")
    reporttext='\n'.join(lines)+'\n'
    print(reporttext)
    if save:
        path=Path(path)
        txt=path.with_name(path.stem+'_quality_report.txt')
        js=path.with_name(path.stem+'_quality_report.json')
        txt.write_text(reporttext,encoding='utf8')
        js.write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf8')
        with zipfile.ZipFile(path,'a',compression=zipfile.ZIP_DEFLATED,compresslevel=1) as z:
            for file in (txt,js):
                # Archived only once for a given run.
                if file.name not in z.namelist():z.write(file,arcname=file.name)
        print('Rapport:',txt,'\nDelen:',path)
    return report

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('zip',help='recordings/synthrig_....zip')
    parser.add_argument('--no-save',action='store_true')
    options=parser.parse_args()
    analyze(options.zip,save=not options.no_save)
