# SynthRig 0.12.8 — kwaliteitsrelease

- APC: de 64 pads worden als gewone Tkinter Canvas-rechthoeken getekend,
  niet langer als glad geïnterpoleerde polygonen. De rest van de afgeronde
  controllerkaders blijft behouden.
- Optie `--matrix-audit` voor volledige 8×8×4-route-audit met echte SunVox PCM.
- Per route CSV/JSON: bron, bestemming, kleurtoestand, afzondering,
  werkelijke DSP-controllerwijziging, audio-RMS, spectrumverschil en piekniveau.
- De 16 modulatiebronnen apart gestimuleerd/gecontroleerd.
- Per audiomodus vijf extra echte PCM-stresstests: dubbele cutoff-modulatie,
  verwijdering van één route, tegengestelde dieptes, clipping en snelle
  pitchmodulatie zonder grote sample-discontinuïteit.
- De 0.12.7-audio-engine, sequencer, MIDImix en MIDI-mapping zijn **ongewijzigd**.
- Nieuwe pytest/unittest-controles voor 256 exacte routecombinaties en
  gewijzigde GUI-tekenmethode.

## Uitkomst

- Routering + SunVox-controller: 256/256 per audiomodus.
- Meetbaar PCM-verschil: 240/256 per audiomodus.
- NOISE LEVEL: 16/16 routes per modus **onbeslist**: SunVox-controller
  wordt gezet, maar solo-noise geeft in de test geen audiouitgang.
- Alle overige reguliere audioregressies: 239/239 per modus.
- Python-tests: 197/197. Native GUI-control: 64/64 rechthoeken.

Dit is **geen** claim dat alle 256 combinaties muzikaal bruikbaar zijn.
