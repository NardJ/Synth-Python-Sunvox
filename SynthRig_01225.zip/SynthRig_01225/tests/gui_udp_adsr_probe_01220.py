"""Real Tk + MIDI/UDP envelope integration. Run under xvfb-run if headless."""
import socket
import tkinter as tk
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace

from mido import Message
from midimix_debug import MidiMixMonitor, ASSIGNMENTS, read_assignments
from synthrig.adsr_preview import AMP_CCS
from synthrig.debug import OptionalMidiMixDebug
from synthrig.fixed_controls import FixedControls
from synthrig.presets import PresetManager
from synthrig.session_state import apply_state, default_state
from test_synthrig import FakeSlot
from synthrig.engine09 import SynthRig


class Wire:
    send = OptionalMidiMixDebug.send
    send_values = OptionalMidiMixDebug.send_values

    def __init__(self, port):
        self.process = SimpleNamespace(poll=lambda: None)
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.target = ('127.0.0.1', port)


root = tk.Tk()
ASSIGNMENTS.update(read_assignments('config/midimix_091.json'))
window = MidiMixMonitor(root, 0)
wire = Wire(window.socket.getsockname()[1])
root.update()


def flush():
    window.poll()
    root.update()


def curve():
    scale = window.canvas.ui_scale
    return [round(x / scale, 5) for x in window.canvas.coords(window.amp_curve)]


try:
    assert window.canvas.itemcget(window.amp_curve, 'state') == 'hidden'
    with TemporaryDirectory() as temp:
        controls = FixedControls()
        rig = SynthRig(FakeSlot(), offline=True)
        apply_state(rig, controls, default_state(controls))
        presets = PresetManager(controls, temp)

        def send_state():
            wire.send_values({str(cc): controls.target_raw[spec['target']]
                              for cc, spec in controls.mappings.items()})
            flush()

        send_state()
        assert window.canvas.itemcget(window.amp_curve, 'state') == 'normal'
        # The envelope is behind every rail, thumb, readout and label.
        stack = list(window.canvas.find_all())
        for cc in AMP_CCS:
            for item in window.fader_parts[cc][1:]:
                assert stack.index(window.amp_curve) < stack.index(item)
        count = len(stack)
        curves = []
        for slot in range(16):
            presets.load(str(slot + 1), rig)
            send_state()
            curves.append(tuple(curve()))
        assert len(set(curves)) > 4, 'presets did not change the displayed envelope'
        print('PASS: startup and all 16 factory presets via software-values UDP')

        before = curve()
        raw = controls.target_raw['amp.attack']
        distant = 127 if raw < 64 else 0
        controls.last_physical.pop(19, None)
        controls.arm_pickup()
        target, applied = controls.resolve(19, distant)
        assert target is None and applied.startswith('pickup ')
        wire.send(Message('control_change', control=19, value=distant), applied)
        flush()
        assert curve() == before
        assert window.physical_values[19] == distant
        print('PASS: physical fader movement during pickup leaves software curve unchanged')

        # Each accepted ADSR CC goes through the same resolver and UDP message as live MIDI.
        controls.pickup.clear()
        for cc in AMP_CCS:
            before = curve()
            raw = 127 if window.values[cc] < 64 else 0
            target, applied = controls.resolve(cc, raw)
            rig.set_parameter(target, raw)
            wire.send(Message('control_change', control=cc, value=raw), applied)
            flush()
            assert curve() != before, f'CC {cc} did not change envelope'
        print('PASS: all four applied MIDI faders update the curve')

        before = curve()
        for zoom in (.5, 1., .9):
            window.set_zoom(zoom)
            root.update()
            assert curve() == before
            window.update_control(19, 33)
            root.update()
            assert curve()[0::2] == sorted(curve()[0::2])
            before = curve()
        assert len(window.canvas.find_all()) == count, 'canvas items leaked during updates'
        print('PASS: live zoom and repeated updates preserve geometry and item count')

        # Useful visual inspection output: actual Tk canvas, not a redrawn mockup.
        apply_state(rig, controls, default_state(controls))
        send_state()
        if '--capture' in __import__('sys').argv:
            from PIL import ImageGrab
            root.update()
            x, y = root.winfo_rootx(), root.winfo_rooty()
            image = ImageGrab.grab(bbox=(x, y, x + root.winfo_width(), y + root.winfo_height()))
            image.save('GUI_ADSR_01220.png')
finally:
    wire.sock.close()
    window.close()
