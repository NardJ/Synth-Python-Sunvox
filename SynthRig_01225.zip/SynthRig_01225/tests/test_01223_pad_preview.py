"""Audition the pressed lane without corrupting pattern, playback or live gates."""
import copy
import tempfile
import unittest

from mido import Message
from synthrig.apc_mk2 import APCminiMk2, PREVIEW_SECONDS
from test_0120 import FakeRig


class PreviewTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.rig = FakeRig()
        self.apc = APCminiMk2(None, self.rig, pattern_dir=self.temp.name, logger=lambda _: None)
        self.press(101)

    def press(self, pad, now=0):
        return self.apc.handle(Message('note_on', channel=0, note=pad, velocity=127), now)

    def test_enabling_step_immediately_plays_lane_pitch_and_velocity(self):
        self.apc.pattern.notes[2] = 67
        self.apc.pattern.velocity[2] = 82
        self.press(16)
        self.assertEqual(self.rig.calls, [('on', 67, 82)])
        self.assertTrue(self.apc.pattern.steps[2][0])
        self.assertFalse(self.apc.playing)
        self.assertEqual(self.apc.step, -1)

    def test_disabling_step_still_auditions_its_pitch(self):
        self.apc.pattern.steps[0][0] = True
        self.press(0)
        self.assertFalse(self.apc.pattern.steps[0][0])
        self.assertEqual(self.rig.calls, [('on', 48, 100)])

    def test_preview_stops_after_quarter_second_even_without_pad_release(self):
        self.press(0, 1)
        self.apc.tick(1 + PREVIEW_SECONDS - .001)
        self.assertEqual(self.rig.calls, [('on', 48, 100)])
        self.apc.tick(1 + PREVIEW_SECONDS)
        self.assertEqual(self.rig.calls[-1], ('off', 48))
        before = list(self.rig.calls)
        self.apc.tick(5)
        self.assertEqual(self.rig.calls, before)
        self.assertIsNone(self.apc.preview_until)

    def test_note_off_and_zero_velocity_release_do_not_toggle_or_retrigger(self):
        self.press(0)
        for kind in ('note_off', 'note_on'):
            self.apc.handle(Message(kind, note=0, velocity=0), .01)
        self.assertTrue(self.apc.pattern.steps[0][0])
        self.assertEqual(self.rig.calls, [('on', 48, 100)])

    def test_repeated_pitch_gets_new_deadline_not_old_note_off(self):
        self.press(0, 0)
        self.press(1, .1)
        self.apc.tick(.25)
        self.assertEqual(self.apc.router.held['preview'], {48})
        self.apc.tick(.351)
        self.assertFalse(self.apc.router.held['preview'])

    def test_new_row_releases_previous_preview_and_uses_new_pitch(self):
        self.press(0, 0)
        self.press(8, .05)
        self.assertEqual(self.rig.calls, [('on', 48, 100), ('off', 48), ('on', 50, 100)])
        self.assertEqual(self.apc.router.held['preview'], {50})

    def test_second_page_and_step_outside_short_loop_use_correct_lane(self):
        self.apc.set_length(4)
        self.press(103)
        self.press(63)
        self.assertTrue(self.apc.pattern.steps[7][15])
        self.assertEqual(self.rig.calls, [('on', 60, 100)])
        self.assertEqual(self.apc.pattern.length, 4)

    def test_preview_does_not_start_or_retime_a_running_sequence(self):
        self.apc.set_length(8)
        self.apc.set_playing(True, 0)
        self.apc.tick(0)
        cursor, due, bpm = self.apc.step, self.apc.next_step, self.apc.pattern.bpm
        self.press(8, .03)
        self.assertTrue(self.apc.playing)
        self.assertEqual((self.apc.step, self.apc.next_step, self.apc.pattern.bpm), (cursor, due, bpm))
        self.apc.tick(.125)
        self.assertEqual(self.apc.step, 1)

    def test_preview_cannot_retrigger_or_extend_a_swing_held_pitch(self):
        self.apc.router.on('swing', 48, 91)
        self.press(0)
        self.apc.tick(1)
        self.assertEqual(self.rig.calls, [('on', 48, 91)])
        self.apc.router.off('swing', 48)
        self.assertEqual(self.rig.calls[-1], ('off', 48))

    def test_preview_cannot_retrigger_or_extend_an_apc_sequence_pitch(self):
        self.apc.router.on('apc', 48, 91)
        self.press(0)
        self.assertIsNone(self.apc.preview_until)
        self.apc.router.off('apc', 48)
        self.assertEqual(self.rig.calls, [('on', 48, 91), ('off', 48)])

    def test_real_swing_note_takes_priority_and_old_preview_timer_cannot_stop_it(self):
        self.press(0)
        self.apc.router.on('swing', 48, 85)
        self.assertEqual(self.rig.calls, [('on', 48, 100), ('on', 48, 85)])
        self.apc.tick(.3)
        self.assertEqual(self.rig.calls[-1], ('on', 48, 85))
        self.assertEqual(self.apc.router.held['swing'], {48})

    def test_next_sequencer_note_keeps_its_own_attack_and_gate(self):
        self.apc.pattern.steps[0][1] = True
        self.apc.set_playing(True, 0)
        self.apc.tick(0)
        self.press(0, .1)
        self.apc.tick(.125)
        self.assertEqual(self.rig.calls, [('on', 48, 100), ('on', 48, 100)])
        self.apc.tick(.2)
        self.assertFalse(self.apc.router.held['apc'])
        self.apc.tick(.4)
        self.assertEqual(self.rig.calls.count(('off', 48)), 1)

    def test_real_note_of_different_pitch_releases_preview_first(self):
        self.press(0)
        self.apc.router.on('apc', 60, 90)
        self.assertEqual(self.rig.calls, [('on', 48, 100), ('off', 48), ('on', 60, 90)])
        self.apc.tick(.3)
        self.assertEqual(self.apc.router.held['apc'], {60})

    def test_four_busy_voices_skip_preview_without_losing_the_pad_edit(self):
        self.rig.active_notes = {60:0, 62:1, 64:2, 65:3}
        self.rig.voices = [None] * 4
        result = self.press(0)
        self.assertEqual(self.rig.calls, [])
        self.assertTrue(self.apc.pattern.steps[0][0])
        self.assertIn('stemmen bezet', result)

    def test_patch_grid_never_auditions(self):
        self.press(100)
        self.press(0)
        self.assertEqual(self.rig.calls, [])

    def test_control_buttons_and_wrong_midi_channel_do_not_audition(self):
        self.press(102);self.press(103)
        self.press(122);self.press(112)
        self.apc.handle(Message('note_on', channel=1, note=0, velocity=127), 0)
        self.assertEqual(self.rig.calls, [])

    def test_mode_switch_stop_bank_load_and_close_cancel_preview(self):
        for action in ('patch', 'stop', 'bank', 'load', 'close'):
            with self.subTest(action=action):
                self.press(101)
                self.press(0)
                if action == 'patch': self.press(100)
                elif action == 'stop': self.apc.set_playing(False, 0)
                elif action == 'bank': self.press(113)
                elif action == 'load': self.apc.load_pattern(silent=True)
                else: self.apc.close()
                self.assertFalse(self.apc.router.held['preview'])
                self.assertIsNone(self.apc.preview_until)

    def test_save_contains_pattern_edits_but_no_preview_state(self):
        self.press(0)
        data = copy.deepcopy(self.apc.pattern.dump())
        self.apc.save_pattern()
        self.apc.load_pattern(silent=True)
        self.assertEqual(self.apc.pattern.dump(), data)
        self.assertNotIn('preview_note', data)
        self.assertFalse(self.apc.router.held['preview'])


if __name__ == '__main__':unittest.main()
