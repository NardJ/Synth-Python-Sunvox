"""Real Tk/UDP, actual LED commands, queued scene blink and uninterrupted play."""
import json,socket,time,tkinter as tk,sys
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
from mido import Message
from midimix_debug import MidiMixMonitor,ASSIGNMENTS,read_assignments
from synthrig.debug import OptionalMidiMixDebug
from synthrig.apc_mk2 import APCminiMk2,Pattern
from synthrig.fixed_controls import FixedControls
from synthrig.session_state import default_state,apply_state
from test_synthrig import FakeSlot
from synthrig.engine09 import SynthRig

class Output:
    def __init__(self):self.sent=[]
    def send(self,msg):self.sent.append(msg)
class Wire:
    send_apc_status=OptionalMidiMixDebug.send_apc_status
    send_swing=OptionalMidiMixDebug.send_swing
    def __init__(self,port):
        self.process=SimpleNamespace(poll=lambda:None)
        self.sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        self.target=('127.0.0.1',port)

root=tk.Tk();ASSIGNMENTS.update(read_assignments('config/midimix_091.json'))
window=MidiMixMonitor(root,0);wire=Wire(window.socket.getsockname()[1]);root.update()
try:
    with TemporaryDirectory() as temp:
        rig=SynthRig(FakeSlot(),offline=True);controls=FixedControls()
        apply_state(rig,controls,default_state(controls))
        out=Output();apc=APCminiMk2(out,rig,pattern_dir=temp,logger=lambda _:None)
        apc.mode='seq';apc.pattern.length=4
        apc.pattern.steps[0]=[True]*16;apc.pattern.ties[0]=[True]*16
        for bank,note in ((1,60),(2,67)):
            p=Pattern(length=8,bpm=90);p.notes[0]=note;p.steps[0][0]=True
            (Path(temp)/f'apc_{bank+1:02d}.json').write_text(json.dumps(p.dump()))
        panel=window.apc_monitor;now=time.monotonic()
        def press(bank,at):return apc.handle(Message('note_on',note=112+bank,velocity=127),at)
        def show(at):
            apc.tick(at);wire.send_apc_status(apc.display_snapshot())
            wire.send_swing(rig.swing_ui_state());window.poll();root.update()
        apc.set_playing(True,now);show(now)
        before=len(out.sent);press(1,now+.03);show(now+.03)
        assert apc.bank==0 and apc.pending_bank==1 and apc.playing
        assert set(rig.active_notes)=={48}
        assert 'P01 → P02' in panel.canvas.itemcget(panel.mode_text,'text')
        assert panel.canvas.itemcget(panel.scene_shapes[0],'fill')=='#44b772'
        assert panel.canvas.itemcget(panel.scene_shapes[1],'fill')=='#ffb75d'
        assert not any(m.type=='note_on' and m.note==104 and m.velocity==0 for m in out.sent[before:])
        if '--capture' in sys.argv:
            from PIL import ImageGrab
            w=panel.window;x,y=w.winfo_rootx(),w.winfo_rooty()
            ImageGrab.grab(bbox=(x,y,x+w.winfo_width(),y+w.winfo_height())).save('GUI_LIVE_PATTERN_01225.png')
        print('PASS: selecting P02 keeps P01 note, PLAY LED and clock active; queue arrow and amber pending button appear')
        show(now+.125);show(now+.25);show(now+.281)
        assert apc.last_button[112] and not apc.last_button[113]
        assert panel.canvas.itemcget(panel.scene_shapes[1],'fill')=='#38434e'
        show(now+.375);show(now+.5)
        assert apc.bank==1 and apc.pending_bank is None and apc.step==0 and apc.playing
        assert set(rig.active_notes)=={60}
        assert apc.pattern.bpm==120 and apc.pattern.length==8
        assert 'P02' in panel.canvas.itemcget(panel.mode_text,'text')
        assert '→' not in panel.canvas.itemcget(panel.mode_text,'text')
        assert panel.canvas.itemcget(panel.scene_shapes[1],'fill')=='#44b772'
        assert not apc.last_button[112] and apc.last_button[113]
        print('PASS: real pending LED blinks; loop boundary releases old gate, starts P02/step1, keeps 120 BPM and transfers active indication')
        press(2,now+.51);press(1,now+.52);show(now+.52)
        assert apc.pending_bank is None and apc.bank==1 and apc.playing
        print('PASS: current pattern button cancels the pending choice without audio/transport interruption')
        press(2,now+.53);apc.set_playing(False,now+.54);show(now+.54)
        assert apc.pending_bank is None
        press(2,now+.55);show(now+.55)
        assert apc.bank==2 and apc.pattern.bpm==90 and not apc.playing
        print('PASS: STOP cancels queue; selecting while stopped immediately loads the stored tempo')
        apc.set_playing(True,now+.6);show(now+.6);press(0,now+.61);show(now+.61)
        count=len(panel.canvas.find_all())
        for zoom in (.5,1,.9):
            window.set_zoom(zoom);root.update()
            assert panel.canvas.bbox(panel.mode_text)[2]<700*panel.canvas.ui_scale
        assert len(panel.canvas.find_all())==count
        print('PASS: active/pending title fits 50/100/90 percent zoom with no new canvas items')
finally:wire.sock.close();window.close()
