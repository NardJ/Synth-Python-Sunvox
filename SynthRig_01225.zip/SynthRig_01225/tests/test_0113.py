"""0.11.3: avoid orphaned held voices after stealing release tails.

Derived from two user-recorded chord cases where every Note On had a Note Off,
yet B4 or E4 kept playing after the active-note mapping went empty.
"""
import unittest
from types import SimpleNamespace
from unittest.mock import patch
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from test_09 import FakeSlot
from synthrig import engine09


class StuckChordRegression(unittest.TestCase):
    def setUp(self):
        self.rig=engine09.SynthRig(FakeSlot(),offline=True)
        self.rig.amp['release']=.13  # original MIDI captures (130 ms)
        self.clock=[100.0]
        self.context=patch.object(engine09,'time',SimpleNamespace(monotonic=lambda:self.clock[0]))
        self.context.start()
        self.addCleanup(self.context.stop)

    def advance(self,dt):
        self.clock[0]+=dt
        self.rig.tick(now=self.clock[0],force=True)

    def assert_no_orphans(self):
        for v in self.rig.voices:
            if v.note is not None and v.released is None:
                self.assertEqual(self.rig.active_notes.get(v.note),v.index,
                                 f'voice {v.index} note {v.note} is orphaned')

    def exercise(self,held_note):
        r=self.rig
        r.note_on(held_note,75)            # released tail starts in voice 0
        self.advance(.01)
        r.note_off(held_note)
        self.advance(.01)                 # tail still physically playing
        r.note_on(held_note,81)           # same pitch NEW key, voice 1
        self.advance(.01)
        r.note_on(60,90)                  # voice 2
        self.advance(.01)
        r.note_on(67,88)                  # voice 3
        self.advance(.01)
        self.assertEqual(r.active_notes[held_note],1)
        r.note_on(69,86)                  # steals OLD released tail, voice 0
        self.assertEqual(r.active_notes[held_note],1,
                         'Voice-stealing removed mapping belonging to another voice')
        self.assert_no_orphans()
        self.advance(.03)
        r.note_off(held_note)
        self.assertIsNotNone(r.voices[1].released,
                             'Note Off must reach the actually held note')
        for note in (60,67,69):r.note_off(note)
        self.assertEqual(r.active_notes,{})
        self.advance(.5)
        self.assertTrue(all(v.note is None for v in r.voices))

    def test_recording_one_b4_does_not_hang(self):
        self.exercise(71)

    def test_recording_two_e4_does_not_hang(self):
        self.exercise(64)

    def test_no_orphan_during_repeated_chords(self):
        r=self.rig
        for chord in ((60,64,67,71),(64,67,71,74),(60,64,67,71),
                      (64,67,71,74),(60,64,67,72),(64,67,71,74)):
            for n in chord:
                r.note_on(n,70)
                self.advance(.012)
                self.assert_no_orphans()
            for n in chord:
                r.note_off(n)
                self.advance(.02)
                self.assert_no_orphans()
        self.advance(.6)
        self.assertEqual(r.active_notes,{})
        self.assertTrue(all(v.note is None for v in r.voices))

if __name__=='__main__':unittest.main()
