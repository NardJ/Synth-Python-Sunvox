"""Quantized live pattern choice: no transport stop, phase reset or seam I/O."""
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from mido import Message
from synthrig.apc_mk2 import APCminiMk2,Pattern
from test_0120 import FakeRig,FakeOut


class Rig(FakeRig):
    def panic(self):self.calls.append(('panic',))


class LivePatternTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.rig,self.out=Rig(),FakeOut()
        self.apc=APCminiMk2(self.out,self.rig,pattern_dir=self.temp.name,logger=lambda _:None)
        self.apc.mode='seq';self.apc.pattern.length=4;self.apc.pattern.steps[0][0]=True
        self.store(1,60,8,90);self.store(2,67,16,75)

    def store(self,bank,note,length=4,bpm=120):
        p=Pattern(length=length,bpm=bpm);p.notes[0]=note;p.steps[0][0]=True
        path=Path(self.temp.name)/f'apc_{bank+1:02d}.json'
        path.write_text(json.dumps(p.dump()))
        return path

    def press(self,bank,now=.03):
        return self.apc.handle(Message('note_on',note=112+bank,velocity=127),now)

    def start(self):self.apc.set_playing(True,0);self.apc.tick(0)

    def finish(self,bank=0):
        for _ in range(32):
            if self.apc.bank!=bank:return
            self.apc.tick(self.apc.next_step)
        self.fail('queued pattern did not become active')

    def test_selection_during_playback_keeps_current_pattern_notes_and_cursor(self):
        self.start();before=list(self.rig.calls);pattern=self.apc.pattern;due=self.apc.next_step
        self.press(1)
        self.assertTrue(self.apc.playing)
        self.assertIs(self.apc.pattern,pattern)
        self.assertEqual((self.apc.bank,self.apc.step,self.apc.next_step),(0,0,due))
        self.assertEqual(self.rig.calls,before)
        self.assertEqual(self.apc.pending_bank,1)

    def test_target_enters_on_loop_boundary_at_first_step_and_same_tempo(self):
        self.start();self.press(1)
        for at in (.125,.25,.375):
            self.apc.tick(at);self.assertEqual(self.apc.bank,0)
        self.apc.tick(.5)
        self.assertEqual((self.apc.bank,self.apc.step,self.apc.pattern.length),(1,0,8))
        self.assertTrue(self.apc.playing)
        self.assertEqual((self.apc.pattern.bpm,self.apc.next_step),(120,.625))
        self.assertEqual(self.rig.calls[-1],('on',60,100))
        self.assertIsNone(self.apc.pending_bank)

    def test_last_valid_choice_replaces_previous_pending_pattern(self):
        self.start();self.press(1);self.press(2,.04);self.finish()
        self.assertEqual(self.apc.bank,2)
        self.assertNotIn(('on',60,100),self.rig.calls)
        self.assertEqual(self.rig.calls[-1],('on',67,100))

    def test_pressing_active_pattern_cancels_queue_without_reloading_edits(self):
        self.start();pattern=self.apc.pattern;self.press(1);self.press(0,.04)
        self.assertIsNone(self.apc.pending_bank)
        self.assertIs(self.apc.pattern,pattern)
        self.apc.tick(.5)
        self.assertEqual(self.apc.bank,0)
        self.assertTrue(self.apc.playing)

    def test_select_while_stopped_loads_immediately_with_saved_tempo(self):
        self.press(1)
        self.assertEqual((self.apc.bank,self.apc.pattern.bpm),(1,90))
        self.assertFalse(self.apc.playing)
        self.assertEqual(self.rig.calls,[])

    def test_target_is_read_before_boundary_and_not_again_at_seam(self):
        self.start();path=self.store(1,60);self.press(1)
        path.write_text('corrupted after prefetch')
        with patch.object(Path,'read_text',side_effect=AssertionError('I/O on musical seam')):
            self.finish()
        self.assertEqual(self.apc.bank,1)
        self.assertEqual(self.rig.calls[-1],('on',60,100))

    def test_reselect_pending_slot_refreshes_its_snapshot(self):
        self.start();self.press(1);self.store(1,62);self.press(1,.04);self.finish()
        self.assertEqual(self.rig.calls[-1],('on',62,100))

    def test_bad_target_keeps_current_audio_and_existing_valid_queue(self):
        self.start();self.press(1)
        for content in ('null','{}','invalid json'):
            (Path(self.temp.name)/'apc_03.json').write_text(content)
            with self.assertRaises(ValueError):self.press(2,.04)
            self.assertTrue(self.apc.playing)
            self.assertEqual(self.apc.pending_bank,1)
            self.assertEqual(self.apc.bank,0)

    def test_empty_slot_is_an_empty_playing_pattern_not_transport_stop(self):
        self.start();self.press(7);self.finish()
        self.assertEqual(self.apc.bank,7)
        self.assertTrue(self.apc.playing)
        self.assertEqual(self.apc.step,0)
        self.assertFalse(any(any(row) for row in self.apc.pattern.steps))

    def test_target_blink_and_active_led_follow_real_midi_commands(self):
        self.apc.pattern.length=16;self.start();self.press(1)
        self.assertTrue(self.apc.last_button[112]);self.assertTrue(self.apc.last_button[113])
        self.apc.tick(.281)
        self.assertTrue(self.apc.last_button[112]);self.assertFalse(self.apc.last_button[113])
        self.apc.tick(.531)
        self.assertTrue(self.apc.last_button[112]);self.assertTrue(self.apc.last_button[113])
        sent={(m.channel,m.note):m.velocity for m in self.out.messages if m.type=='note_on'}
        self.assertEqual(sent[(0,112)],1);self.assertEqual(sent[(0,113)],1)
        self.assertEqual(self.apc.status()['pending_bank'],2)

    def test_shift_length_overlay_does_not_replace_pattern_queue(self):
        self.start();self.press(1)
        self.apc.handle(Message('note_on',note=122,velocity=127),.04)
        self.assertEqual(self.apc.pending_bank,1)
        self.assertEqual([self.apc.last_button[n] for n in (112,113,114)],[True,False,False])
        self.apc.handle(Message('note_off',note=122),.05)
        self.assertTrue(self.apc.last_button[113])

    def test_stop_panic_and_close_cancel_queue_and_no_later_surprise_switch(self):
        for action in ('stop','panic','close'):
            self.start();self.press(1)
            if action=='stop':self.apc.set_playing(False,.04)
            elif action=='panic':self.apc.handle(Message('note_on',note=107,velocity=127),.04)
            else:self.apc.close()
            self.assertIsNone(self.apc.pending_bank)
            self.assertFalse(self.apc.playing)
            self.assertEqual(self.apc.bank,0)

    def test_external_clock_transition_does_not_reset_pulse_counter_or_transport(self):
        self.apc.set_clock('swing',0);self.apc.swing_clock(Message('start'),0)
        self.apc.swing_clock(Message('clock'),0);self.press(1,.001)
        for tick in range(1,24):
            self.apc.swing_clock(Message('clock'),tick/48)
            self.assertEqual(self.apc.bank,0)
        self.apc.swing_clock(Message('clock'),.5)
        self.assertEqual((self.apc.bank,self.apc.step),(1,0))
        self.assertEqual(self.apc.swing_sync.position,25)
        self.assertEqual(self.apc.swing_sync.counts['start'],1)

    def test_external_stop_and_clock_timeout_cancel_queue(self):
        for cause in ('stop','timeout'):
            self.apc.set_clock('swing',0);self.apc.swing_clock(Message('start'),0)
            self.apc.swing_clock(Message('clock'),.01);self.press(1,.02)
            if cause=='stop':self.apc.swing_clock(Message('stop'),.03)
            else:self.apc.tick(.8)
            self.assertIsNone(self.apc.pending_bank)
            self.assertFalse(self.apc.playing)

    def test_select_before_first_external_clock_sets_armed_pattern_immediately(self):
        self.apc.set_clock('swing',0);self.apc.set_playing(True,0);self.press(1,.01)
        self.assertEqual(self.apc.bank,1);self.assertIsNone(self.apc.pending_bank)
        self.apc.swing_clock(Message('start'),.02);self.apc.swing_clock(Message('clock'),.03)
        self.assertEqual(self.rig.calls[-1],('on',60,100))

    def test_live_fader_tempo_is_taken_at_transition_not_at_request_time(self):
        self.start();self.press(1)
        self.apc.handle(Message('control_change',control=56,value=0),.04)
        self.finish()
        self.assertEqual(self.apc.pattern.bpm,60)
        data=json.loads((Path(self.temp.name)/'apc_02.json').read_text())
        self.assertEqual(data['bpm'],90)

    def test_each_pattern_uses_its_own_loop_length_after_switch(self):
        for length in (4,8,16):
            self.apc.set_playing(False,0);self.apc.bank=0
            self.apc.pattern=Pattern(length=length);self.apc.pattern.steps[0][0]=True
            self.start();self.press(1);self.finish()
            self.assertEqual(self.apc.pattern.length,8)
            self.press(2,self.apc.next_step-.01);self.finish(bank=1)
            self.assertEqual(self.apc.pattern.length,16)

    def test_old_tied_gate_is_released_at_seam_without_panic(self):
        self.apc.pattern.steps[0]=[True]*16;self.apc.pattern.ties[0]=[True]*16
        self.start();self.press(1);self.finish()
        self.assertEqual(self.rig.calls,[('on',48,100),('off',48),('on',60,100)])
        self.assertNotIn(('panic',),self.rig.calls)

    def test_shared_swing_gate_survives_the_pattern_transition(self):
        self.apc.router.on('swing',48,90)
        self.apc.pattern.steps[0]=[True]*16;self.apc.pattern.ties[0]=[True]*16
        self.start();self.press(1);self.finish()
        self.assertNotIn(('off',48),self.rig.calls)
        self.assertEqual(self.apc.router.held['swing'],{48})

    def test_same_pitch_new_pattern_starts_with_fresh_attack_not_old_tie(self):
        self.store(1,48)
        self.apc.pattern.steps[0]=[True]*16;self.apc.pattern.ties[0]=[True]*16
        self.start();self.press(1);self.finish()
        self.assertEqual(self.rig.calls,[('on',48,100),('off',48),('on',48,100)])

    def test_save_while_queued_still_saves_current_slot_and_not_target(self):
        self.start();self.press(1)
        path=Path(self.temp.name)/'apc_02.json';before=path.read_bytes()
        self.apc.save_pattern(.04)
        self.assertTrue((Path(self.temp.name)/'apc_01.json').exists())
        self.assertEqual(path.read_bytes(),before)
        self.assertEqual(self.apc.pending_bank,1)

    def test_pending_state_is_not_saved_and_new_pattern_opens_first_page(self):
        self.start();self.apc.page=1;self.press(1)
        self.assertNotIn('pending_bank',self.apc.pattern.dump())
        self.finish()
        self.assertEqual(self.apc.page,0)

    def test_small_internal_polling_jitter_does_not_accumulate_as_tempo_drift(self):
        self.start()
        for step in range(1,65):
            self.apc.tick(step*.125+.004)
            self.assertAlmostEqual(self.apc.next_step,(step+1)*.125)

    def test_long_internal_stall_does_not_emit_a_burst_of_missed_steps(self):
        self.apc.pattern.steps[0]=[True]*16
        self.start();self.rig.calls.clear()
        self.apc.tick(2)
        self.assertEqual(len([c for c in self.rig.calls if c[0]=='on']),1)
        self.assertEqual(self.apc.next_step,2.125)


if __name__=='__main__':unittest.main()
