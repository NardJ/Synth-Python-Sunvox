"""0.12.15: real production BANK handler -> PresetManager -> 16 MIDI LEDs.

Unlike 0.11.1 helper test, exercise every preset slot and the actual
dispatch function used by the running application. Run standalone as well.
"""
import json
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
from unittest.mock import patch
from mido import Message
from test_synthrig import FakeSlot
from synthrig.engine09 import SynthRig
from synthrig.fixed_controls import FixedControls
from synthrig.midimix_events import handle_bank_press
from synthrig.midimix_hw import MidiMixLEDs, desired_leds
from synthrig.presets import PresetManager,factory_presets
from synthrig.session_state import default_state,apply_state


class Output:
    def __init__(self): self.sent=[]
    def send(self,msg): self.sent.append(msg)


class Monitor:
    def __init__(self): self.presets=[];self.values=[]
    def send_preset(self,p,led_snapshot=None):
        self.presets.append(dict(p))
        self.last_led_snapshot=led_snapshot
    def send_values(self,v):self.values.append(dict(v))


class BankFullIntegration(unittest.TestCase):
    def setUp(self):
        self.temp=TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.controls=FixedControls()
        self.rig=SynthRig(FakeSlot(),offline=True)
        apply_state(self.rig,self.controls,default_state(self.controls))
        self.pm=PresetManager(self.controls,self.temp.name)
        self.out=Output()
        self.led=MidiMixLEDs(self.out,self.controls)
        self.monitor=Monitor()
        self.dirty=[]
        self.led.sync(self.controls.button_state(self.rig),force=True)

    def press(self,note,typ='note_on',vel=127,led=True):
        return handle_bank_press(Message(typ,channel=0,note=note,velocity=vel),
                                 self.controls,self.pm,self.rig,
                                 self.led if led else None,self.monitor,
                                 lambda:self.dirty.append(True))

    def assert_overlay(self,slot):
        commands=self.out.sent[-16:]
        self.assertEqual(len(commands),16)
        self.assertTrue(all(m.type=='note_on' and m.channel==0 for m in commands))
        expected=tuple(self.controls.factory_wave_notes)+(3,6,9,12,15,18,21,24)
        self.assertEqual(tuple(m.note for m in commands),expected)
        self.assertEqual(tuple(m.velocity for m in commands),
                         tuple([127]*slot+[0]*(16-slot)))
        self.assertTrue(self.led._overlay)

    def test_16_forward_bank_presses_emit_all_16_led_counts(self):
        self.assertIsNone(self.pm.selection()['slot'])
        for slot in range(1,17):
            self.assertIn('geladen',self.press(26))
            self.assertEqual(self.pm.selection()['slot'],slot)
            self.assert_overlay(slot)
            self.assertEqual(self.monitor.presets[-1]['slot'],slot)
            self.assertEqual(len(self.monitor.values),slot)
            self.assertTrue(self.controls.pickup)
        self.assertEqual(len(self.dirty),16)

    def test_reverse_bank_starts_at_sixteen_and_wraps(self):
        self.press(25)
        self.assertEqual(self.pm.selection()['slot'],16)
        self.assert_overlay(16)
        self.press(26)
        self.assertEqual(self.pm.selection()['slot'],1)
        self.assert_overlay(1)

    def test_releases_and_other_messages_do_not_change_presets(self):
        for args in [('note_on',0,26),('note_off',0,26),
                     ('note_on',127,3),('note_on',127,27)]:
            before=len(self.out.sent)
            self.assertIsNone(self.press(args[2],args[0],args[1]))
            self.assertEqual(len(self.out.sent),before)
        self.assertIsNone(self.pm.selection()['slot'])

    def test_flash_survives_unrelated_force_sync_and_returns_to_real_leds(self):
        self.press(26)
        flash=list(self.out.sent[-16:])
        self.led.sync(self.controls.button_state(self.rig),force=True)
        self.assertEqual(self.out.sent[-16:],flash)
        # Do not depend on an actual sleep or OS timer.
        self.led.preset_until=0
        self.led.tick(self.controls.button_state(self.rig))
        self.assertFalse(self.led._overlay)
        final={m.note:m.velocity>0 for m in self.out.sent[-16:]}
        expected=desired_leds(self.controls,self.controls.button_state(self.rig))
        for note in flash:
            self.assertEqual(final[note.note],expected[note.note])

    def test_next_flash_restarts_one_second_countdown(self):
        with patch('synthrig.midimix_hw.time.monotonic',return_value=100.0):
            self.press(26)
            self.assertEqual(self.led.preset_until,101.0)
        with patch('synthrig.midimix_hw.time.monotonic',return_value=100.8):
            self.press(26)
            self.assertEqual(self.led.preset_until,101.8)
            self.led.tick(self.controls.button_state(self.rig))
            self.assert_overlay(2)
        with patch('synthrig.midimix_hw.time.monotonic',return_value=101.81):
            self.led.tick(self.controls.button_state(self.rig))
        self.assertFalse(self.led._overlay)

    def test_no_led_output_presets_still_change(self):
        self.assertIn('geladen',self.press(26,led=False))
        self.assertEqual(self.pm.selected,0)
        self.assertEqual(len(self.out.sent),16)  # only initial hardware sync

    def test_user_slot_preserved_on_bank_transition_and_save(self):
        self.press(26)
        self.controls.target_raw['filter.cutoff']=101
        self.rig.set_parameter('filter.cutoff',101)
        self.pm.save_slot(self.rig)
        self.press(26)
        self.press(25)
        self.assertEqual(self.pm.selection()['slot'],1)
        self.assertTrue(self.pm.selection()['user'])
        self.assertEqual(self.controls.target_raw['filter.cutoff'],101)
        self.assertEqual(factory_presets(self.controls)[0][1]['raw']['filter.cutoff'],49)

    def test_no_stuck_notes_after_bank_with_active_chord(self):
        for n in (60,64,67):self.rig.note_on(n,90)
        self.press(26)
        self.assertFalse(self.rig.active_notes)

    def test_event_handler_ignores_off_bank_channels(self):
        # MIDImix bank is channel 0.  Future multi-device routing must not
        # interpret an APC Note 26 as a bank command.
        msg=Message('note_on',channel=1,note=26,velocity=127)
        self.assertIsNone(handle_bank_press(msg,self.controls,self.pm,self.rig,
                                             self.led,self.monitor))
        self.assertEqual(self.pm.selected,-1)

    def test_rig_script_uses_this_production_handler(self):
        source=(Path(__file__).resolve().parents[1]/'synthrig_01219.py').read_text()
        self.assertIn('handle_bank_press(msg,controls,presets,rig,',source)

if __name__=='__main__':unittest.main()

# Later regression tests cannot rely on any test file import side effects.
class PhysicalLedProbeTests(unittest.TestCase):
    def test_selftest_shows_one_eight_sixteen_then_clears(self):
        from synthrig.midimix_led_selftest import run_led_test
        o=Output();c=FixedControls();messages=[]
        run_led_test(o,c,pause=lambda _sec:None,report=messages.append)
        flash=o.sent
        assert [sum(x.velocity>0 for x in flash[k:k+16]) for k in (0,16,32)] == [1,8,16]
        self.assertEqual(len(messages),4)
        self.assertEqual({m.velocity for m in flash[-16:]},{0})
        self.assertEqual({m.note for m in flash[-16:]},set(c.factory_wave_notes)|set(c.source_notes)|c.reserved)

    def test_clean_shutdown_during_flash_turns_all_leds_off(self):
        c=FixedControls();o=Output();leds=MidiMixLEDs(o,c)
        leds.show_preset(16)
        leds.clear()
        self.assertFalse(leds._overlay)
        self.assertEqual({m.velocity for m in o.sent[-16:]},{0})

    def test_hardware_write_error_is_visible_but_presets_still_load(self):
        class FailingLED:
            def show_preset(self,number):raise OSError('MIDI output disconnected')
        from synthrig.midimix_events import handle_bank_press
        with TemporaryDirectory() as tmp:
            c=FixedControls();r=SynthRig(FakeSlot(),offline=True)
            apply_state(r,c,default_state(c));p=PresetManager(c,tmp)
            reports=[]
            msg=Message('note_on',note=26,velocity=127)
            output=handle_bank_press(msg,c,p,r,FailingLED(),diagnostic=reports.append)
            self.assertIn('geladen',output)
            self.assertEqual(p.selected,0)
            self.assertIn('NIET verzonden',reports[-1])
