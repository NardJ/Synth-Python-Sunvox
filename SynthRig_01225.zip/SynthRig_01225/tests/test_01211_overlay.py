"""0.12.11: physical overlay, source excitation, migration and safety."""
import unittest
from pathlib import Path
from synthrig.mod_matrix import (SOURCES_B,DESTINATIONS_D,blank_matrix,encode,
                                 migrate_state_matrix,MATRIX_LAYOUT,ModMatrix)
from synthrig.session_state import default_state,load_state,apply_state,capture_state
from synthrig.fixed_controls import FixedControls
from synthrig.engine09 import SynthRig
from tests.test_pitch096 import FakeSlot

class OverlayRevision(unittest.TestCase):
    def test_overlay_order_and_uniqueness(self):
        self.assertEqual(SOURCES_B[2:6],('MOD ENV','LFO 3','SMOOTH RANDOM','NOTE RAMP'))
        self.assertEqual(DESTINATIONS_D[3],'LFO RATE')
        self.assertEqual(DESTINATIONS_D[7],'DELAY FEEDBACK')
        self.assertEqual(len(set(SOURCES_B)),8)
    def test_legacy_routes_are_archived_not_reinterpreted(self):
        state=default_state(FixedControls())
        state.pop('mod_matrix_layout')
        state['mod_matrix'][2][4]=encode(2,94)   # inverse velocity -> cutoff
        state['mod_matrix'][3][3]=encode(1,120)  # aftertouch -> old key amount
        state['mod_matrix'][7][7]=encode(1,114)  # bias -> old output level
        state['mod_matrix'][7][4]=encode(0,120)  # unaffected bias -> cutoff
        migrated,archived=migrate_state_matrix(state)
        self.assertEqual(migrated['mod_matrix_layout'],MATRIX_LAYOUT)
        self.assertEqual(len(archived),3)
        self.assertEqual(migrated['mod_matrix'][7][4],120)
        self.assertTrue(all(migrated['mod_matrix'][r][c] is None for r,c in ((2,4),(3,3),(7,7))))
        self.assertIn('VEL INVERSE',{r['source'] for r in archived})
        self.assertIn('OUTPUT LEVEL',{r['destination'] for r in archived})
        done,again=migrate_state_matrix(migrated)
        self.assertFalse(again)
        self.assertEqual(done['mod_legacy_routes'],archived)
    def test_new_sources_move_as_expected(self):
        rig=SynthRig(FakeSlot())
        rig.note_on(60,100)
        voice=rig.voices[0]
        t=voice.started
        voice.patch_mod_env.on(t)
        values_early=rig._patch_sources(voice,t+.003,.3)
        values_later=rig._patch_sources(voice,t+.055,.3)
        self.assertGreater(values_later[10],values_early[10])
        self.assertTrue(-1<=values_later[11]<=1)
        self.assertTrue(-1<=values_later[12]<=1)
        self.assertGreater(values_later[13],values_early[13])
        # The new random source is continuous across its time-cell boundary.
        x=rig._patch_sources(voice,t+.010,0)[12]
        y=rig._patch_sources(voice,t+.0101,0)[12]
        self.assertLess(abs(x-y),.02)
    def test_lfo_rate_and_feedback_controller_safety(self):
        rig=SynthRig(FakeSlot())
        rig.set_parameter('lfo.rate',75)
        rig.note_on(60,110)
        m=blank_matrix();m[7][3]=encode(1,127) # BIAS -> LFO RATE
        m[7][7]=encode(1,127)                 # BIAS -> feedback
        rig.load_mod_matrix(m)
        for _ in range(28):rig.tick(now=rig._last_tick+.016,force=True)
        self.assertGreater(rig._effective_lfo_rate,rig.lfo_rate)
        self.assertLessEqual(rig._effective_lfo_rate,14)
        self.assertLessEqual(rig.last_delay_feedback,180)
        self.assertNotEqual(rig.last_delay_feedback,105)
        rig.load_mod_matrix(blank_matrix())
        for _ in range(65):rig.tick(now=rig._last_tick+.016,force=True)
        self.assertAlmostEqual(rig._effective_lfo_rate,rig.lfo_rate,places=3)
        self.assertAlmostEqual(rig.last_delay_feedback,105,delta=1)
    def test_gui_no_unwanted_technical_phrases(self):
        code=(Path(__file__).resolve().parents[1]/'synthrig'/'apc_monitor.py').read_text()
        for text in ('MODUS  PATCH','Rij {src+1}','Pad: UIT','SCENE = bronrij'):
            self.assertNotIn(text,code)

if __name__=='__main__':unittest.main()
