"""16 muzikale fabriekspatches; gebruikersslots blijven voorrang houden."""
import json
import unittest
from tempfile import TemporaryDirectory
from pathlib import Path
from synthrig.fixed_controls import FixedControls
from synthrig.presets import (PresetManager,factory_presets,FACTORY_MATRIX_ROUTES,
                               FACTORY_SOUND_GUIDE,factory_route_summary,validate_preset)
from synthrig.mod_matrix import decode,VARIANTS,ModMatrix

class MusicalFactoryPresets(unittest.TestCase):
    def setUp(self):
        self.controls=FixedControls()

    def test_all_16_have_distinctive_routed_sounds_and_no_duplicate_pad(self):
        factory=factory_presets(self.controls)
        self.assertEqual(len(factory),16)
        self.assertEqual(len(FACTORY_MATRIX_ROUTES),16)
        self.assertEqual(len(FACTORY_SOUND_GUIDE),16)
        palettes=set()
        for i,(name,state) in enumerate(factory,1):
            self.assertTrue(name)
            parsed=validate_preset(state,self.controls)
            cells=[(r,c,decode(value)) for r,row in enumerate(parsed['mod_matrix'])
                   for c,value in enumerate(row) if value is not None]
            self.assertEqual(len(cells),len(FACTORY_MATRIX_ROUTES[i-1]))
            self.assertTrue(2<=len(cells)<=3)
            self.assertEqual(len(set((r,c) for r,c,_ in cells)),len(cells))
            self.assertTrue(all(depth!=64 for _,_,(_,depth) in cells))
            for r,c,(variant,depth) in cells:
                palettes.add(VARIANTS[variant])
                self.assertIn(r,parsed['mod_groups']['rows'][c])
                self.assertEqual(parsed['mod_matrix_layout'],'v2')
            self.assertEqual(len(factory_route_summary(i)),len(cells))
        self.assertEqual(palettes,{'AC','AD','BC','BD'})

    def test_musical_modulation_math_is_not_just_leds(self):
        src=[.8,.7,.9,.8,.8,.75,1.,1.,.6,.7,.8,.7,.8,.8,1.,.7]
        for slot,(name,state) in enumerate(factory_presets(self.controls),1):
            mx=ModMatrix()
            mx.load(state['mod_matrix'])
            mx.load_groups(state['mod_groups'])
            offsets=mx.offsets(src)
            self.assertEqual(len(offsets),16)
            self.assertTrue(any(abs(x)>.005 for x in offsets),f'Slot {slot}: {name}')
            dests={r['col']-1+(8 if r['variant'][1]=='D' else 0)
                   for r in factory_route_summary(slot)}
            self.assertTrue(all(abs(x)<1e-8 for n,x in enumerate(offsets) if n not in dests))

    def test_user_preset_slot_overrides_new_factory_without_overwrite(self):
        with TemporaryDirectory() as root:
            p=PresetManager(self.controls,root)
            original_name,original=factory_presets(self.controls)[4]
            self.assertEqual(original_name,'Soft Pad')
            override=dict(original)
            override['raw']=dict(original['raw'])
            override['raw']['filter.cutoff']=103
            path=Path(root)/'slot_05.json'
            path.write_text(json.dumps({'format':'SynthRig slot 1','slot':5,
                                        'name':'Eigen Klank','state':override}))
            items=p.slots()
            self.assertEqual(items[4][1],'Eigen Klank')
            self.assertTrue(items[4][3])
            self.assertEqual(items[4][2]['raw']['filter.cutoff'],103)
            self.assertEqual(factory_presets(self.controls)[4][1]['raw']['filter.cutoff'],75)
            self.assertTrue(path.is_file())

if __name__=='__main__':unittest.main()
