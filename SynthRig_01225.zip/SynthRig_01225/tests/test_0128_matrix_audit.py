"""Matrix audit 0.12.8: systematic route/isolation and GUI regression."""
from pathlib import Path
import unittest
from synthrig.mod_matrix import ModMatrix,blank_matrix,encode,decode
from synthrig.matrix_audit0128 import NAMES,SOURCE_NAMES,VARIANTS

class ExhaustiveRouting(unittest.TestCase):
    def test_256_pad_routes_exactly_one_active_target(self):
        self.assertEqual(len(NAMES),16)
        self.assertEqual(len(SOURCE_NAMES),16)
        count=0
        for row in range(8):
            for col in range(8):
                for variant in range(4):
                    m=ModMatrix(); grid=blank_matrix()
                    grid[row][col]=encode(variant,127)
                    m.load(grid)
                    src=row+(8 if variant>=2 else 0)
                    dst=col+(8 if variant%2 else 0)
                    vals=[0.]*16;vals[src]=1.
                    actual=m.offsets(vals)
                    self.assertEqual(actual[dst],1.0)
                    self.assertEqual(sum(abs(x)>1e-9 for x in actual),1)
                    vals[src]=0
                    self.assertEqual(m.offsets(vals),[0.]*16)
                    self.assertEqual(decode(m.grid[row][col]),(variant,127))
                    count+=1
        self.assertEqual(count,256)
    def test_four_states_still_one_route_per_pad(self):
        m=ModMatrix()
        for i in range(4):self.assertEqual(m.cycle(4,5),encode(i))
        self.assertIsNone(m.cycle(4,5))
    def test_gui_uses_uninterpolated_rectangles_for_64_pads(self):
        source=(Path(__file__).resolve().parents[1]/'synthrig'/'apc_monitor.py').read_text()
        self.assertIn("c.create_rectangle(x,y,x+PAD_W,y+PAD_H,fill=PAD_OFF",source)
        self.assertNotIn("self.rect(x,y,x+PAD_W,y+PAD_H,PAD_OFF",source)

if __name__=='__main__':unittest.main()
