"""Recorder-tests: geen audiohardware en geen PulseAudio nodig."""
import json
import math
from pathlib import Path
import sys
import tempfile
import time
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from synthrig.recording import AudioDebugRecorder
from synthrig.pwm import PWM


class RecorderTests(unittest.TestCase):
    def test_wav_and_events_are_created(self):
        # Testbron schrijft 1 seconde 441Hz stereo PCM zonder hardware.
        code = (
            "import sys, math, struct; "
            "b=bytearray(); "
            "[(lambda v: b.extend(struct.pack('<hh',v,v)))(int(14000*math.sin(2*math.pi*441*i/44100))) "
            " for i in range(44100)]; "
            "sys.stdout.buffer.write(b); sys.stdout.flush()"
        )
        with tempfile.TemporaryDirectory() as directory:
            rec = AudioDebugRecorder(directory, capture_command=[sys.executable, '-c', code])
            self.assertTrue(rec.start())
            self.assertFalse(rec.start())
            rec.log('midi_swing', {'note': 60, 'velocity': 110})
            rec.reader.join(timeout=5.0)
            self.assertFalse(rec.reader.is_alive())
            result = rec.stop()
            self.assertGreater(result['recorded_audio_seconds'], .9)
            self.assertGreater(result['peak_sample_approx'], 12000)
            import wave
            with wave.open(str(rec.wav_path), 'rb') as wav:
                self.assertEqual(wav.getframerate(), 44100)
                self.assertEqual(wav.getnchannels(), 2)
                self.assertEqual(wav.getnframes(), 44100)
            events = [json.loads(line) for line in rec.events_path.read_text().splitlines()]
            self.assertEqual(events[0]['event'], 'record_start')
            self.assertEqual(events[1]['data']['note'], 60)
            self.assertEqual(events[-1]['event'], 'record_stop')
            self.assertIsNone(result['capture_error'])
            self.assertTrue(rec.csv_path.is_file())
            self.assertTrue(rec.bundle_path.is_file())
            self.assertIn('metadata', result)
            self.assertIn('audio_first_pcm_read_t_approx', result)
            self.assertIn('approx_max_abs_dc_offset', result)
            self.assertEqual(result['event_counts']['midi_swing'], 1)
            import zipfile
            with zipfile.ZipFile(rec.bundle_path) as bundle:
                self.assertEqual(len(bundle.namelist()), 5)
            from analyse_debug import load, summarize
            summary, events, windows = load(rec.bundle_path)
            self.assertTrue(windows)
            self.assertIn('PWM-ticks:', summarize(summary, events, windows))
            self.assertIsNone(rec.stop())

    def test_pwm_observation_does_not_change_phase(self):
        from types import SimpleNamespace
        from synthrig.pwm_observe import pwm_snapshot
        pwm = PWM()
        pwm.depth = .3
        pwm.phase = .15
        pwm.rate = 1.1
        rig = SimpleNamespace(pwm=pwm, wave_selection={1: 3, 2: 1})
        first = pwm_snapshot(rig)
        self.assertEqual(pwm.phase, .15)
        self.assertEqual(first['rate_hz'], 1.1)
        self.assertNotEqual(first['effective_width']['1'], .5)
        self.assertEqual(first, pwm_snapshot(rig))

    def test_state_and_actual_pwm_write_logging(self):
        from test_synthrig import FakeSlot
        from synthrig.engine import SynthRig
        from synthrig.controls import load_mappings
        from synthrig.diagnostics import state_snapshot, run_pwm_check
        slot = FakeSlot()
        rig = SynthRig(slot, load_mappings())
        snap = state_snapshot(rig)
        self.assertIn('native_duty', snap['osc']['1'])
        self.assertIn('resonance_native', snap['filter'])
        trace = []
        ticks = []
        rig.pwm_trace = lambda d: trace.append(d)
        rig.pwm_tick_trace = lambda d: ticks.append(d)
        rig.set_parameter('osc1.waveform', 127)
        rig.set_parameter('pwm.depth', 80)
        rig.pwm.last_time = 100.0
        rig.tick_pwm(now=100.1, force=True)
        self.assertTrue(trace)
        self.assertIn('native_duty_written', trace[-1])
        self.assertTrue(ticks)
        # Dit testscenario vereist geen echte SunVox of MIDI-poort.
        class FakeRecorder:
            def __init__(self): self.events = []
            def log(self, kind, data=None): self.events.append((kind,data))
        recorder = FakeRecorder()
        run_pwm_check(rig, recorder, .015, .015, .015)
        stages=[d['name'] for k,d in recorder.events if k=='test_stage']
        self.assertEqual(stages, ['basis_zonder_pwm','pwm_aan','pwm_weer_uit'])
        self.assertEqual(rig.active_notes,{})


class ReadbackTests(unittest.TestCase):
    def test_readback_delayed_and_waveform_expectations(self):
        from test_synthrig import FakeSlot
        from synthrig.engine import SynthRig
        from synthrig.controls import load_mappings
        from synthrig.diagnostics import ReadbackAudit, run_pwm_onset_check
        slot=FakeSlot(); rig=SynthRig(slot,load_mappings())
        class Rec:
            def __init__(self): self.events=[]
            def log(self,event,data=None): self.events.append((event,data))
        rec=Rec(); audit=ReadbackAudit(rig,rec,delays=(0,))
        rig.set_parameter('osc1.waveform',127)
        audit.schedule('test')
        audit.poll()
        self.assertIn('match',[x['status'] for e,d in rec.events if e=='readback_audit' for x in d['controls']])
        run_pwm_onset_check(rig,rec,seconds_pwm=.014,seconds_off=.012)
        names=[d['name'] for k,d in rec.events if k=='test_stage']
        self.assertEqual(names,['pwm_vanaf_noot','zelfde_noot_pwm_uit'])
        self.assertFalse(rig.active_notes)
        self.assertEqual(rig.pwm.depth,0)


if __name__ == '__main__':
    unittest.main()
