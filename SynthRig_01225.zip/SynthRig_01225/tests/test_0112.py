"""Software master gain without using MIDI mappings or preset values."""
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import json
import math
import socket
import unittest
from test_09 import FakeSlot
from synthrig.engine09 import SynthRig
from synthrig.output_gain import valid_gain,load_gain,save_gain
from synthrig.fixed_controls import FixedControls
from synthrig.session_state import capture_state,default_state,apply_state
from synthrig.presets import PresetManager
from synthrig.debug import OptionalMidiMixDebug

class OutputGain(unittest.TestCase):
    def setUp(self):
        self.slot=FakeSlot()
        self.rig=SynthRig(self.slot,offline=True)

    def test_all_routes_go_through_single_output_stage(self):
        self.assertEqual([edge for edge in self.slot.links if edge[1]==0],[(self.rig.output_amp,0)])
        for mod in (self.rig.vib_mod,self.rig.delay_module,self.rig.reverb_module):
            self.assertIn((mod,self.rig.output_amp),self.slot.links)
        for chorus in (p for p in self.rig.chorus):
            self.assertNotIn((chorus,0),self.slot.links)

    def test_gain_range_and_native_amp_scaling(self):
        self.rig.set_output_gain_db(6)
        self.rig.tick(now=self.rig._last_tick+.5,force=True)
        self.assertEqual(self.rig.output_gain_db,6)
        self.assertGreater(self.rig._last_output_volume,256)
        self.assertLessEqual(self.rig._last_output_volume,1024)
        self.rig.set_output_gain_db(-6)
        self.rig.tick(now=self.rig._last_tick+.5,force=True)
        self.assertLess(self.rig._last_output_volume,256)
        for value in (-6.1,9.5,math.nan,math.inf):
            with self.assertRaises(ValueError):self.rig.set_output_gain_db(value)

    def test_gain_is_never_in_preset_or_midimix_mapping(self):
        controls=FixedControls()
        self.assertEqual(len(controls.mappings),33)
        apply_state(self.rig,controls,default_state(controls))
        self.rig.set_output_gain_db(6)
        before=capture_state(self.rig,controls)
        self.assertNotIn('output_gain',str(before))
        with TemporaryDirectory() as d:
            presets=PresetManager(controls,d)
            presets.load('9',self.rig)
            self.assertEqual(self.rig.output_gain_db,6)
            apply_state(self.rig,controls,before)
            self.assertEqual(self.rig.output_gain_db,6)

    def test_gain_persistent_but_independent(self):
        with TemporaryDirectory() as d:
            file=Path(d)/'output_gain.json'
            self.assertEqual(load_gain(file),0)
            save_gain(file,3.5)
            self.assertEqual(load_gain(file),3.5)
            self.assertEqual(json.loads(file.read_text())['schema'],1)
            file.write_text('{"schema":1,"db":99}')
            self.assertEqual(load_gain(file),0)
            for value in (float('nan'),True,50):
                with self.assertRaises(ValueError):valid_gain(value)

    def test_feedback_commands_accept_only_local_gain_messages(self):
        # Exercises the same UDP protocol as the interactive debug window.
        obj=OptionalMidiMixDebug.__new__(OptionalMidiMixDebug)
        obj.sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        source=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        wrong=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        try:
            obj.sock.bind(('127.0.0.1',0));obj.sock.setblocking(False)
            source.bind(('127.0.0.1',0));wrong.bind(('127.0.0.1',0))
            obj.target=source.getsockname()
            obj.process=SimpleNamespace(poll=lambda:None)
            dest=obj.sock.getsockname()
            source.sendto(json.dumps({'kind':'set_output_gain','db':3.5}).encode(),dest)
            wrong.sendto(json.dumps({'kind':'set_output_gain','db':9}).encode(),dest)
            source.sendto(json.dumps({'kind':'set_output_gain','db':100}).encode(),dest)
            source.sendto(json.dumps({'kind':'set_output_gain','db':'4'}).encode(),dest)
            self.assertEqual(obj.poll_commands(),[3.5])
        finally:
            obj.sock.close();source.close();wrong.close()
