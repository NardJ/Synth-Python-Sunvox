"""0.12.3: APC slider geometry and paired monitor zoom."""
import unittest
from synthrig.apc_monitor import PAD_LEFT, PAD_W, PAD_STEP_X, FADER_XS, FADER_TOP, FADER_BOTTOM, W, H
from synthrig.window_layout import monitor_layout, LEFT_H, RIGHT_H
from midimix_debug import FADER_TOP as MIDIFADER_TOP, FADER_BOTTOM as MIDIFADER_BOTTOM


class ApcGuiTests(unittest.TestCase):
    def test_apc_faders_align_with_pads(self):
        for index in range(8):
            self.assertEqual(FADER_XS[index], PAD_LEFT+PAD_STEP_X*index+PAD_W/2)
        self.assertGreater(FADER_XS[8], FADER_XS[7])

    def test_apc_faders_align_with_midimix(self):
        self.assertEqual((FADER_TOP,FADER_BOTTOM),(MIDIFADER_TOP,MIDIFADER_BOTTOM))
        self.assertEqual(LEFT_H, RIGHT_H)
        self.assertEqual(H, RIGHT_H)

    def test_both_monitors_scale_together(self):
        for screen in [(1366,768),(1600,900),(1920,1080),(2560,1440)]:
            previous=None
            for zoom in (.5,.7,.9,1.0):
                L=monitor_layout(*screen, zoom=zoom)
                self.assertEqual(L.right_x, L.left_x+L.left_w+L.gap)
                self.assertLessEqual(L.right_x+L.right_w,screen[0])
                self.assertLessEqual(L.top_y+L.right_h+35,screen[1])
                self.assertAlmostEqual(L.right_w/L.left_w,720/1170,delta=.02)
                if previous: self.assertGreaterEqual(L.scale,previous)
                previous=L.scale

    def test_zoom_out_of_bounds_rejected(self):
        with self.assertRaises(ValueError): monitor_layout(1920,1080,zoom=1.3)
        with self.assertRaises(ValueError): monitor_layout(1920,1080,zoom=.1)


if __name__=='__main__':unittest.main()
