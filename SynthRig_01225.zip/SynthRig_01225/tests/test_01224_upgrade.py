"""Exercise the released launcher: newest sibling wins; current data survives."""
import shutil
import subprocess
import sys
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory


class Upgrade01224Tests(unittest.TestCase):
    def test_01223_data_is_preferred_and_existing_01224_is_preserved(self):
        source = Path(__file__).resolve().parents[1]
        files = ('state/last_session.json', 'presets/user/slot_01.json',
                 'patterns/apc_01.json', 'state/output_gain.json')
        with TemporaryDirectory() as temp:
            base = Path(temp)
            new = base / 'SynthRig_01224'
            new.mkdir()
            shutil.copy2(source / 'synthrig_01224.py', new)
            for directory in ('synthrig', 'config'):
                shutil.copytree(source / directory, new / directory,
                                ignore=shutil.ignore_patterns('__pycache__'))
            for version in ('01222', '01223'):
                for filename in files:
                    path = base / ('SynthRig_' + version) / filename
                    path.parent.mkdir(parents=True, exist_ok=True)
                    path.write_text('{"origin":"' + version + '"}')
            command = [sys.executable, 'synthrig_01224.py', '--list-controls']
            subprocess.run(command, cwd=new, check=True, capture_output=True)
            for filename in files:
                self.assertEqual((new / filename).read_text(), '{"origin":"01223"}')
                (new / filename).write_text('{"origin":"current"}')
            subprocess.run(command, cwd=new, check=True, capture_output=True)
            for filename in files:
                self.assertEqual((new / filename).read_text(), '{"origin":"current"}')


if __name__ == '__main__':
    unittest.main()
