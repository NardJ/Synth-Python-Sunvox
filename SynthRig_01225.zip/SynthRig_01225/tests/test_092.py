"""Regressietests van persistente MIDI-knoppen en fysieke LED-feedback."""
import sys
import unittest
from pathlib import Path
from unittest.mock import Mock
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from test_09 import FakeSlot
from synthrig.engine09 import SynthRig
from synthrig.fixed_controls import FixedControls
from synthrig.midimix_hw import desired_leds, MidiMixLEDs, describe_midi
import mido


class TestMidiMix092(unittest.TestCase):
    def setUp(self):
        self.controls=FixedControls()
        self.rig=SynthRig(FakeSlot())

    def test_leds_mirror_default_engine_state(self):
        leds=desired_leds(self.controls,self.controls.button_state(self.rig))
        self.assertTrue(leds[7])  # OSC1 SAW
        self.assertTrue(leds[22]) # OSC2 PULSE
        self.assertFalse(leds[1]) # OSC1 SIN
        for n in (3,6,9,12):self.assertTrue(leds[n])
        for n in (15,18,21,24):self.assertFalse(leds[n])
        self.assertEqual(len(leds),16)

    def test_press_and_release_do_not_undo_waveform(self):
        # Real MIDImix: pressed note_on positive velocity, release note_off/vel0.
        note_on=mido.Message('note_on',note=1,velocity=127)
        note_off=mido.Message('note_off',note=1,velocity=0)
        for msg in (note_on,note_off):
            if msg.type=='note_on' and msg.velocity>0:
                self.controls.on_note(msg.note,self.rig)
        self.assertEqual(self.rig.wave_selection[1],0)
        state=desired_leds(self.controls,self.controls.button_state(self.rig))
        self.assertTrue(state[1]);self.assertFalse(state[7])

    def test_rec_source_toggle_persists_while_button_released(self):
        self.controls.on_note(3,self.rig)
        state=self.controls.button_state(self.rig)
        self.assertFalse(state['enabled']['osc1'])
        self.assertFalse(desired_leds(self.controls,state)[3])
        self.controls.on_note(3,self.rig)
        self.assertTrue(desired_leds(self.controls,self.controls.button_state(self.rig))[3])

    def test_midi_out_sends_note_on_127_and_note_on_zero(self):
        out=Mock()
        hw=MidiMixLEDs(out,self.controls)
        hw.sync(self.controls.button_state(self.rig),force=True)
        msgs=[call.args[0] for call in out.send.call_args_list]
        self.assertEqual(len(msgs),16)
        self.assertTrue(all(m.type=='note_on' and m.channel==0 for m in msgs))
        self.assertEqual({m.note for m in msgs if m.velocity==127},{7,22,3,6,9,12})
        self.assertEqual({m.note for m in msgs if m.velocity==0},set(hw.last)-{7,22,3,6,9,12})
        self.controls.on_note(1,self.rig)
        out.reset_mock()
        hw.sync(self.controls.button_state(self.rig))
        msgs=[call.args[0] for call in out.send.call_args_list]
        self.assertEqual({(m.note,m.velocity) for m in msgs},{(1,127),(7,0)})
        out.reset_mock()
        hw.sync(self.controls.button_state(self.rig))
        out.send.assert_not_called()
        hw.sync(self.controls.button_state(self.rig),force=True)
        self.assertEqual(out.send.call_count,16)
        out.reset_mock()
        hw.clear()
        self.assertEqual(out.send.call_count,16)
        self.assertTrue(all(m.args[0].velocity==0 for m in out.send.call_args_list))

    def test_message_format_shows_note_press_and_release(self):
        on=mido.Message('note_on',channel=0,note=3,velocity=127)
        off=mido.Message('note_on',channel=0,note=3,velocity=0)
        cc=mido.Message('control_change',control=16,value=63)
        self.assertIn('druk',describe_midi(on))
        self.assertIn('los',describe_midi(off))
        self.assertIn('cc=16',describe_midi(cc))

if __name__=='__main__':unittest.main()
