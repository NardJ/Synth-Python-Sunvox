"""0.12.2: shared window placement and live coordinate scaling regressions."""
import unittest
from synthrig.window_layout import monitor_layout
from synthrig.scaled_canvas import ScaledCanvas


class LayoutTests(unittest.TestCase):
    def test_1935_side_by_side_unscaled(self):
        a = monitor_layout(1935, 1156)
        self.assertEqual(a.scale, 1.0)
        self.assertEqual((a.left_w, a.right_w), (1170, 720))
        self.assertGreaterEqual(a.right_x - (a.left_x+a.left_w), 10)
        self.assertLessEqual(a.right_x+a.right_w, 1935)
        self.assertLessEqual(a.top_y+a.left_h+35, 1156)

    def test_1600_screen_scales_both_monitors(self):
        a = monitor_layout(1600, 900)
        self.assertLess(a.scale, 1.0)
        self.assertGreater(a.scale, .7)
        self.assertEqual(a.right_x, a.left_x+a.left_w+a.gap)
        self.assertLessEqual(a.right_x+a.right_w+15, 1600)
        self.assertLessEqual(a.top_y+a.left_h+35, 900)

    def test_small_screen_does_not_overlap(self):
        a = monitor_layout(1366, 768)
        self.assertGreater(a.right_x, a.left_x+a.left_w)
        self.assertLess(a.right_x+a.right_w, 1366)
        self.assertLessEqual(a.top_y+a.left_h+35, 768)

    def test_screen_dimensions_checked(self):
        with self.assertRaises(ValueError):monitor_layout(0,1080)

    def test_scaled_canvas_is_canvas_subclass(self):
        self.assertTrue(issubclass(ScaledCanvas, __import__('tkinter').Canvas))


if __name__=='__main__':unittest.main()
