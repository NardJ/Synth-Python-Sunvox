"""Live input helper -> actual MIDI LED commands -> UDP -> real Tk canvases.

All SWING messages in this test are simulated. No physical hardware test.
"""
import json
import socket
import sys
import time
import tkinter as tk
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace

from mido import Message
from midimix_debug import MidiMixMonitor, ASSIGNMENTS, read_assignments
from synthrig.debug import OptionalMidiMixDebug
from synthrig.apc_mk2 import APCminiMk2
from synthrig.swing_sync import SwingSync, handle_swing_input, tick_swing_input
from synthrig.fixed_controls import FixedControls
from synthrig.session_state import default_state, apply_state
from test_synthrig import FakeSlot
from synthrig.engine09 import SynthRig


class Output:
    def __init__(self):
        self.sent = []
    def send(self, message):
        self.sent.append(message)


class Wire:
    send_sync = OptionalMidiMixDebug.send_sync
    send_apc_status = OptionalMidiMixDebug.send_apc_status
    send_values = OptionalMidiMixDebug.send_values
    send_swing = OptionalMidiMixDebug.send_swing

    def __init__(self, port):
        self.process = SimpleNamespace(poll=lambda: None)
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.target = ('127.0.0.1', port)


root = tk.Tk()
ASSIGNMENTS.update(read_assignments('config/midimix_091.json'))
window = MidiMixMonitor(root, 0)
wire = Wire(window.socket.getsockname()[1])
root.update()
try:
    with TemporaryDirectory() as temp:
        rig = SynthRig(FakeSlot(), offline=True)
        controls = FixedControls()
        apply_state(rig, controls, default_state(controls))
        sync = SwingSync(port='SIMULATED INPUT — not physical SWING')
        output = Output()
        apc = APCminiMk2(output, rig, pattern_dir=temp, clock='swing',
                         logger=lambda _: None, swing_sync=sync)
        apc.mode = 'seq'
        apc.pattern.steps[0] = [True] * 16
        now = time.monotonic()
        wire.send_values({cc: controls.target_raw[spec['target']]
                          for cc, spec in controls.mappings.items()})

        def send_status(at):
            tick_swing_input(rig, sync, apc, at)
            state = sync.snapshot(at)
            state.update(apc_clock=apc.clock, apc_connected=True,
                         apc_playing=apc.playing, apc_step=apc.step + 1)
            snapshot = apc.display_snapshot()
            snapshot['sync'] = sync.snapshot(at)
            wire.send_apc_status(snapshot)
            wire.send_sync(state)
            wire.send_swing(rig.swing_ui_state())
            window.poll()
            root.update()
            return window.canvas.itemcget(window.sync_label, 'text')

        def feed(kind, at, **kwargs):
            handle_swing_input(Message(kind, **kwargs), rig, sync, apc, at)

        feed('start', now)
        assert 'wacht op CLOCK' in send_status(now)
        feed('note_on', now + .001, note=60, velocity=90)
        for tick in range(48):
            feed('clock', now + .01 + tick / 48)
        now += 1.01
        text = send_status(now)
        assert '120.0 BPM' in text and 'SPEELT' in text and 'APC volgt' in text
        assert apc.step == 7
        assert 'stap 08/16' in window.apc_monitor.canvas.itemcget(window.apc_monitor.status_text, 'text')
        assert any(m.type == 'note_on' and m.note == 104 and m.velocity > 0 for m in output.sent)
        print('PASS: START waiting, first-clock downbeat, 120 BPM, APC pad/PLAY LEDs and both Tk displays')

        if '--capture' in sys.argv:
            from PIL import ImageGrab
            x, y = root.winfo_rootx(), root.winfo_rooty()
            ImageGrab.grab(bbox=(x, y, x + root.winfo_width(), y + root.winfo_height())).save('GUI_SWING_SYNC_01221.png')

        feed('stop', now + .01)
        assert 'STOP' in send_status(now + .01)
        self_step = apc.step
        feed('continue', now + 1)
        feed('clock', now + 1.01)
        assert apc.step == (self_step + 1) % 16
        assert 'SPEELT' in send_status(now + 1.01)
        print('PASS: STOP releases APC gate; CONTINUE resumes the preserved step through live input path')

        text = send_status(now + 1.8)
        assert 'CLOCK WEG' in text
        assert 'CLOCK WEG' in window.apc_monitor.canvas.itemcget(window.apc_monitor.status_text, 'text')
        assert not rig.active_notes and not apc.playing
        assert not any(apc.router.held.values())
        play = [m for m in output.sent if m.type == 'note_on' and m.note == 104][-1]
        assert play.velocity == 0
        print('PASS: timeout releases notes, clears hardware PLAY LED and shows CLOCK WEG in both windows')

        feed('clock', now + 1.9)
        assert 'CLOCK TERUG' in send_status(now + 1.9)
        assert not apc.playing
        print('PASS: returning clock is observed without unexpected playback; fresh START required')

        before = len(window.canvas.find_all())
        for zoom in (.5, 1, .9):
            window.set_zoom(zoom)
            send_status(now + 2)
            box = window.canvas.bbox(window.sync_label)
            assert box[2] < 840 * window.canvas.ui_scale
        assert len(window.canvas.find_all()) == before
        print('PASS: sync line fits existing layout at 50/100/90 percent zoom; no canvas item growth')
        report = Path('reports_01221/simulated_sync.json')
        sync.save_report(report, clock_source='swing', now=now + 2)
        saved = json.loads(report.read_text())
        assert saved['sync']['counts']['timeouts'] == 1
        assert saved['sync']['counts']['start'] == 1
        print('PASS: atomic diagnostic JSON contains observed transport/clock counts and one timeout')
finally:
    wire.sock.close()
    window.close()
