"""0.12.19: unselected session PANIC must not emit or mirror LED changes.

This checks the real button release path, not merely the preset helper. The
old 0.12.18 code forced a full LED refresh on every note_off, including SOLO.
"""
import unittest
from tempfile import TemporaryDirectory
from mido import Message
from test_synthrig import FakeSlot
from synthrig.engine09 import SynthRig
from synthrig.fixed_controls import FixedControls
from synthrig.midimix_hw import MidiMixLEDs, sync_leds_for_button
from synthrig.preset_buttons import SoloSaveButton
from synthrig.presets import PresetManager
from synthrig.session_state import default_state,apply_state
from synthrig.solo_actions import panic_and_show_active_preset


class Output:
    def __init__(self): self.sent=[]
    def send(self,msg): self.sent.append(msg)


class Monitor:
    def __init__(self):self.calls=[]
    def send_preset(self,info,led_snapshot=None):self.calls.append((info,led_snapshot))


class SessionSoloLEDTests(unittest.TestCase):
    def setUp(self):
        self.tmp=TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.controls=FixedControls()
        self.rig=SynthRig(FakeSlot(),offline=True)
        apply_state(self.rig,self.controls,default_state(self.controls))
        self.presets=PresetManager(self.controls,self.tmp.name)
        self.output=Output()
        self.leds=MidiMixLEDs(self.output,self.controls)
        self.monitor=Monitor()
        self.solo=SoloSaveButton(threshold=1.5)
        self.leds.sync(self.controls.button_state(self.rig),force=True)

    def press_and_release(self,hold=.1):
        down=Message('note_on',note=self.controls.panic_note,velocity=127)
        up=Message('note_off',note=self.controls.panic_note,velocity=0)
        self.assertIsNone(self.solo.feed(down,10))
        self.assertFalse(sync_leds_for_button(self.leds,self.controls.button_state(self.rig),down,self.controls.panic_note))
        gesture=self.solo.feed(up,10+hold)
        if gesture=='panic':
            panic_and_show_active_preset(self.rig,None,self.presets,self.leds,self.monitor)
        elif gesture=='save':
            # No selected slot means saving raises; should not trigger an LED refresh.
            with self.assertRaises(ValueError):self.presets.save_slot(self.rig)
        self.assertFalse(sync_leds_for_button(self.leds,self.controls.button_state(self.rig),up,self.controls.panic_note))
        self.leds.tick(self.controls.button_state(self.rig))
        return gesture

    def test_unselected_short_solo_panics_without_any_led_or_gui_change(self):
        self.assertEqual(self.presets.selected,-1)
        for number in range(4):
            self.rig.note_on(60+number,100)
            before_messages=list(self.output.sent)
            before_snapshot=self.leds.display_snapshot().copy()
            self.assertEqual(self.press_and_release(),'panic')
            self.assertFalse(self.rig.active_notes)
            self.assertEqual(self.output.sent,before_messages)
            self.assertEqual(self.leds.display_snapshot(),before_snapshot)
            self.assertIsNone(self.monitor.calls[-1][0]['slot'])
            self.assertEqual(self.monitor.calls[-1][1],before_snapshot)

    def test_selected_slot_still_shows_number_and_restores(self):
        for number in (1,8,11,16):
            with self.subTest(number=number):
                self.presets.selected=number-1
                self.assertEqual(self.press_and_release(),'panic')
                self.assertEqual(self.leds.display_snapshot()['preset'],number)
                self.assertEqual(sum(self.leds.display_snapshot()['notes'].values()),number)
                self.assertEqual(self.monitor.calls[-1][1]['preset'],number)
                self.leds.preset_until=0
                self.leds.tick(self.controls.button_state(self.rig))
                self.assertFalse(self.leds.display_snapshot()['overlay'])

    def test_unselected_long_solo_no_led_changes(self):
        before=list(self.output.sent)
        self.assertEqual(self.press_and_release(1.6),'save')
        self.assertEqual(self.output.sent,before)

    def test_normal_button_release_still_forces_led_refresh(self):
        before=len(self.output.sent)
        msg=Message('note_off',note=int(self.controls.factory_wave_notes[0]),velocity=0)
        self.assertTrue(sync_leds_for_button(self.leds,self.controls.button_state(self.rig),msg,self.controls.panic_note))
        self.assertGreater(len(self.output.sent),before)

    def test_other_midi_types_do_not_sync_leds(self):
        before=len(self.output.sent)
        self.assertFalse(sync_leds_for_button(self.leds,self.controls.button_state(self.rig),
             Message('control_change',control=10,value=37),self.controls.panic_note))
        self.assertEqual(len(self.output.sent),before)


if __name__=='__main__':unittest.main()
