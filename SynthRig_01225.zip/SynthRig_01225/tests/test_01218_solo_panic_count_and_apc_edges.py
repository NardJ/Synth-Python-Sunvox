"""0.12.18: full SOLO short press -> hard PANIC + 16 physical/GUI LEDs.

Both functions must happen on ONE release, not a double press. Long hold
continues to mean SAVE and never triggers PANIC.
"""
import unittest
from tempfile import TemporaryDirectory
from types import SimpleNamespace
from unittest.mock import patch
from mido import Message
from test_synthrig import FakeSlot
from synthrig.engine09 import SynthRig
from synthrig.fixed_controls import FixedControls
from synthrig.midimix_hw import MidiMixLEDs, desired_leds
from synthrig.preset_buttons import SoloSaveButton
from synthrig.presets import PresetManager
from synthrig.session_state import default_state, apply_state
from synthrig.solo_actions import panic_and_show_active_preset
from synthrig.apc_mk2 import APCminiMk2
from sunvox.api import NOTECMD


class Output:
    def __init__(self): self.sent=[]
    def send(self,m): self.sent.append(m)


class GUI:
    def __init__(self):self.calls=[]
    def send_preset(self,info,led_snapshot=None):
        self.calls.append((info,led_snapshot))


class SoloPanicCount(unittest.TestCase):
    def setUp(self):
        self.tmp=TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.c=FixedControls()
        self.r=SynthRig(FakeSlot(),offline=True)
        apply_state(self.r,self.c,default_state(self.c))
        self.pm=PresetManager(self.c,self.tmp.name)
        self.out=Output();self.leds=MidiMixLEDs(self.out,self.c)
        self.gui=GUI();self.solo=SoloSaveButton(threshold=1.5)

    def release(self, secs):
        self.assertIsNone(self.solo.feed(Message('note_on',note=27,velocity=127),10.0))
        return self.solo.feed(Message('note_off',note=27,velocity=0),10.0+secs)

    def test_short_is_single_panic_and_count_all_16(self):
        for n in range(1,17):
            with self.subTest(preset=n):
                self.pm.selected=n-1
                self.r.note_on(60,100)
                before_clean=sum(int(e[1])==int(NOTECMD.CLEAN_SYNTHS) for e in self.r.slot.events)
                self.assertEqual(self.release(.12),'panic')
                result=panic_and_show_active_preset(self.r,None,self.pm,self.leds,self.gui)
                self.assertIn('PANIC',result)
                self.assertFalse(self.r.active_notes)
                clean=sum(int(e[1])==int(NOTECMD.CLEAN_SYNTHS) for e in self.r.slot.events)
                self.assertEqual(clean,before_clean+1)
                snapshot=self.leds.display_snapshot()
                self.assertEqual(snapshot['preset'],n)
                self.assertTrue(snapshot['overlay'])
                self.assertEqual(sum(snapshot['notes'].values()),n)
                self.assertEqual([msg.velocity>0 for msg in self.out.sent[-16:]],
                                 [i<n for i in range(16)])
                self.assertEqual(self.gui.calls[-1][0]['slot'],n)
                self.assertEqual(self.gui.calls[-1][1],snapshot)
                self.leds.preset_until=0
                self.leds.tick(self.c.button_state(self.r))
                self.assertFalse(self.leds.display_snapshot()['overlay'])
                self.assertEqual(self.leds.display_snapshot()['notes'],
                        {str(k):v for k,v in desired_leds(self.c,self.c.button_state(self.r)).items()})

    def test_long_press_stays_save_without_panic(self):
        self.pm.selected=0
        self.r.note_on(60,100)
        self.assertEqual(self.release(1.51),'save')
        self.assertTrue(self.r.active_notes)
        self.assertFalse(self.leds.display_snapshot()['overlay'])
        self.assertFalse(self.gui.calls)

    def test_short_panic_without_selected_preset_never_invents_number(self):
        self.pm.selected=-1
        self.r.note_on(60,100)
        self.assertEqual(self.release(.1),'panic')
        panic_and_show_active_preset(self.r,None,self.pm,self.leds,self.gui)
        self.assertFalse(self.r.active_notes)
        self.assertIsNone(self.leds.display_snapshot()['preset'])
        self.assertEqual(len(self.out.sent),0)

    def test_solo_panic_stops_apc_transport_and_held_notes_too(self):
        self.pm.selected=10
        apc=APCminiMk2(None,self.r,pattern_dir=self.tmp.name,logger=lambda _:None)
        self.addCleanup(apc.close)
        apc.router.on('swing',60,100)
        apc.router.on('apc',62,100)
        apc.set_playing(True)
        panic_and_show_active_preset(self.r,apc,self.pm,self.leds,self.gui)
        self.assertFalse(apc.playing)
        self.assertEqual(apc.router.held,{'swing':set(),'apc':set(),'preview':set()})
        self.assertFalse(self.r.active_notes)
        self.assertEqual(self.leds.display_snapshot()['preset'],11)

    def test_solo_retry_during_active_overlay_resets_counter_and_deadline(self):
        self.pm.selected=1
        with patch('synthrig.midimix_hw.time.monotonic',return_value=100.):
            panic_and_show_active_preset(self.r,None,self.pm,self.leds,self.gui)
        self.pm.selected=12
        with patch('synthrig.midimix_hw.time.monotonic',return_value=100.3):
            panic_and_show_active_preset(self.r,None,self.pm,self.leds,self.gui)
        self.assertEqual(self.leds.display_snapshot()['preset'],13)
        self.assertEqual(sum(self.leds.display_snapshot()['notes'].values()),13)
        with patch('synthrig.midimix_hw.time.monotonic',return_value=101.01):
            self.leds.tick(self.c.button_state(self.r))
        self.assertTrue(self.leds.display_snapshot()['overlay'])
        with patch('synthrig.midimix_hw.time.monotonic',return_value=101.31):
            self.leds.tick(self.c.button_state(self.r))
        self.assertFalse(self.leds.display_snapshot()['overlay'])

    def test_led_output_failure_cannot_prevent_panic(self):
        self.pm.selected=1
        self.r.note_on(60,100)
        self.leds.output.send=lambda m: (_ for _ in ()).throw(OSError('port disconnected'))
        log=[]
        panic_and_show_active_preset(self.r,None,self.pm,self.leds,self.gui,log.append)
        self.assertFalse(self.r.active_notes)
        self.assertTrue(any('niet verzonden' in s for s in log))


class APCGeometry(unittest.TestCase):
    def test_scene_and_track_button_shapes_are_not_splined_polygons(self):
        # This is a code invariant verified without a video device; under Xvfb
        # the actual Tk items are also checked in the GUI smoke test.
        from pathlib import Path
        import inspect
        from synthrig.apc_monitor import APCMonitor
        source=inspect.getsource(APCMonitor.draw_static)
        self.assertIn("block=self.rect(628,y,670,y+34,PAD_OFF,'#687785')",source)
        self.assertIn("block=self.rect(x,594,x+PAD_W,624,PAD_OFF,'#657481')",source)
        self.assertIn("self.shift_shape=self.rect(627,594,670,624,PAD_OFF,'#657481')",source)

if __name__=='__main__':unittest.main()
