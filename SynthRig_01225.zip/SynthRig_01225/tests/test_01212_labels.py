"""Matrix overlay constraints and uniform footer placement."""
import unittest
from pathlib import Path
from synthrig.apc_labels import ROW_LABELS, COLUMN_LABELS, LABEL_FONT, MAX_LABEL_CELLS, validate_labels

class OverlayLabels(unittest.TestCase):
    def test_all_32_labels_are_at_most_eight_monospace_positions(self):
        self.assertTrue(validate_labels())
        self.assertEqual(MAX_LABEL_CELLS,8)
        self.assertEqual(LABEL_FONT, 'DejaVu Sans Mono')
        self.assertEqual(sum(len(x) for x in ROW_LABELS+COLUMN_LABELS),32)
        self.assertTrue(all(0<len(x)<=8 for pair in ROW_LABELS+COLUMN_LABELS for x in pair))
    def test_meaning_remains_unchanged(self):
        from synthrig.mod_matrix import SOURCES, SOURCES_B, DESTINATIONS, DESTINATIONS_D
        self.assertEqual(SOURCES[0], 'LFO')
        self.assertEqual(SOURCES_B[4], 'SMOOTH RANDOM')
        self.assertEqual(DESTINATIONS[0], 'OSC1 PITCH')
        self.assertEqual(DESTINATIONS_D[7], 'DELAY FEEDBACK')
        self.assertEqual(COLUMN_LABELS[0][0], 'O1 PITCH')
    def test_unified_apc_footer(self):
        src=(Path(__file__).resolve().parents[1]/'synthrig'/'apc_monitor.py').read_text()
        self.assertIn("self.footer_status=self.txt(34,1020",src)
        self.assertIn("self.footer_event=self.txt(34,1048",src)
        self.assertNotIn('self.fader_status_label=',src)
        self.assertNotIn('self.action_text=',src)
    def test_unified_midimix_footer(self):
        src=(Path(__file__).resolve().parents[1]/'midimix_debug.py').read_text()
        self.assertIn('self.status_id = self.draw_text(34, 1020',src)
        self.assertIn("self.event_id = self.draw_text(34, 1048",src)
        self.assertIn("self.apc_id=self.draw_text(W-34, 1020",src)

if __name__=='__main__':unittest.main()
