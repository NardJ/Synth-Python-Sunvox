"""Test de analyseberekeningen onafhankelijk van SunVox/ALSA."""
import contextlib
import io
import json
from pathlib import Path
import sys
import tempfile
from types import ModuleType, SimpleNamespace
import unittest
import wave
import zipfile
from array import array

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
try:
    from sunvox.api import Slot
except ImportError:
    sunvox = ModuleType('sunvox')
    api = ModuleType('sunvox.api')
    api.Slot = object
    api.init = lambda *args: 1
    api.deinit = lambda: None
    api.NOTECMD = SimpleNamespace(NOTE_OFF=128, SET_PITCH=133)
    sunvox.api = api
    sys.modules['sunvox'] = sunvox
    sys.modules['sunvox.api'] = api

from test_dc_oscillators import analyse_wav
from vergelijk_dc_oscillators import compare


class DcAnalysisTests(unittest.TestCase):
    def test_stereo_dc_is_measured_per_channel(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'stereo.wav'
            rate = 2000
            values = array('h')
            for _ in range(rate * 4):
                values.extend((int(0.06 * 32768), int(-0.04 * 32768)))
            with wave.open(str(path), 'wb') as f:
                f.setframerate(rate)
                f.setnchannels(2)
                f.setsampwidth(2)
                f.writeframes(values.tobytes())
            stage = {'osc': 1, 'width_percent': 25, 'native_requested': 64,
                     'native_readback': 64, 'note_on_s': 0, 'note_off_s': 3.5}
            report = analyse_wav(path, [stage], True)
            result = report['results'][0]
            self.assertAlmostEqual(result['dc_channel_signed'][0], 0.06, delta=0.001)
            self.assertAlmostEqual(result['dc_channel_signed'][1], -0.04, delta=0.001)
            self.assertAlmostEqual(result['dc_abs_mean_channels'], 0.05, delta=0.001)
            self.assertAlmostEqual(result['dc_mean_signed'], 0.01, delta=0.001)

    def test_comparator_requires_correct_off_on_order(self):
        with tempfile.TemporaryDirectory() as tmp:
            paths = []
            for enabled, value in ((False, .06), (True, .004)):
                p = Path(tmp) / ('on.zip' if enabled else 'off.zip')
                with zipfile.ZipFile(p, 'w') as z:
                    z.writestr('dummy_osc_dc_analysis.json', json.dumps({
                        'dc_blocker_enabled': enabled,
                        'results': [{'osc': 1, 'width_percent': 25,
                                     'dc_abs_mean_channels': value}],
                    }))
                paths.append(p)
            with contextlib.redirect_stdout(io.StringIO()) as output:
                compare(*paths)
            self.assertIn('93.3%', output.getvalue())
            with self.assertRaises(ValueError):
                compare(*paths[::-1])


if __name__ == '__main__':
    unittest.main()
