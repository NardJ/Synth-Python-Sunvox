"""0.12.13: overlay-size and model topology regression (review is editorial)."""
import unittest
from synthrig.apc_labels import ROW_LABELS,COLUMN_LABELS,validate_labels
from synthrig.mod_matrix import SOURCES,SOURCES_B,DESTINATIONS,DESTINATIONS_D,encode,decode

class OverlayRouteReview(unittest.TestCase):
    def test_all_labels_fit_eight_monospace_characters(self):
        self.assertTrue(validate_labels())
        self.assertEqual(sum(len(p) for p in ROW_LABELS+COLUMN_LABELS),32)
        self.assertTrue(all(1<=len(s)<=8 for pair in ROW_LABELS+COLUMN_LABELS for s in pair))
    def test_all_256_route_identities_unchanged(self):
        routes=set()
        for row in range(8):
            for col in range(8):
                for variant in range(4):
                    src=(SOURCES,SOURCES_B)[variant>=2][row]
                    dst=(DESTINATIONS,DESTINATIONS_D)[variant%2][col]
                    self.assertEqual(decode(encode(variant,86)),(variant,86))
                    routes.add((row,col,variant,src,dst))
        self.assertEqual(len(routes),256)

if __name__=='__main__':unittest.main()
