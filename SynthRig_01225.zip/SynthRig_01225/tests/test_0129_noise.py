"""Prevent the sub pitch events from stealing noise on the shared event track."""
import unittest
from pathlib import Path
from synthrig.engine09 import SynthRig
from synthrig.tracks098 import voice_track
from sunvox.api import NOTECMD
from test_09 import FakeSlot

class SharedSubNoiseRouting(unittest.TestCase):
    def setUp(self):
        self.slot=FakeSlot(); self.rig=SynthRig(self.slot,pitch_lfo_mode='events')
        self.rig.note_on(60,110);self.voice=self.rig.voices[0]
    def test_sub_initial_pitch_targets_shared_router(self):
        tr=voice_track(0,'sub_noise')
        pitch=[e for e in self.slot.events if e[1]==NOTECMD.SET_PITCH and e[0]==tr]
        self.assertEqual(len(pitch),1)
        self.assertEqual(pitch[0][3],self.voice.sub_router+1)
        self.assertNotEqual(pitch[0][3],self.voice.sub+1)
        self.assertIn((self.voice.sub_router,self.voice.noise),self.slot.links)
    def test_continuous_pitchbend_keeps_router_target(self):
        self.slot.events.clear()
        self.rig.pitch_bend=.75
        self.rig.tick(force=True)
        track=voice_track(0,'sub_noise')
        pitch=[e for e in self.slot.events if e[0]==track and e[4] in (5,6)]
        self.assertTrue(pitch)
        self.assertTrue(all(e[3]==self.voice.sub_router+1 for e in pitch))
    def test_note_off_stops_shared_router(self):
        self.slot.events.clear()
        self.rig.all_notes_off()
        track=voice_track(0,'sub_noise')
        offs=[e for e in self.slot.events if e[0]==track and e[1]==NOTECMD.NOTE_OFF]
        self.assertTrue(offs)
        self.assertEqual(offs[-1][3],self.voice.sub_router+1)

if __name__=='__main__':unittest.main()
