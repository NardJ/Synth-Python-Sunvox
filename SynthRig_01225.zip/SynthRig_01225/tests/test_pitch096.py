"""0.9.6: Native Vibrato routing, midi pitch calibration, smoothing and A/B."""
from pathlib import Path
import sys,unittest,math
import mido
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from test_09 import FakeSlot
from synthrig.engine09 import (SynthRig, SmoothParameter, midi_frequency,
                              sunvox_pitch_from_hz, VIBRATO_MAX_NATIVE_AMP)
from sunvox.api import NOTECMD

class Pitch096(unittest.TestCase):
    def setUp(self):
        self.s=FakeSlot()
        self.r=SynthRig(self.s)
    def test_absolute_midi_pitch(self):
        for midi,f in ((36,65.40639),(60,261.62556),(69,440.0)):
            self.assertAlmostEqual(midi_frequency(midi),f,places=4)
            calc=self.r._native_pitch(midi)
            translated=2**((30720-calc)/3072)*16.333984375
            self.assertAlmostEqual(translated,f,delta=f*.00012)
        self.r.note_on(36,100)
        self.assertIn(self.r._native_pitch(24),[e[5] for e in self.s.events if e[1]==NOTECMD.SET_PITCH])
    def test_native_route_and_zero_amplitudes(self):
        self.assertIn((self.r.vib_lfo,self.r.vib_mod),self.s.links)
        self.assertIn((self.r.vib_mod,self.r.output_amp),self.s.links)
        self.assertTrue(all((v.velocity_amp,self.r.vib_lfo) in self.s.links for v in self.r.voices))
        self.assertFalse(any((v.adsr,0) in self.s.links for v in self.r.voices))
        for tag,mod in (('lfo',self.r.vib_lfo),('mod',self.r.vib_mod)):
            idx=self.r.vib_ctl[tag+'_amplitude'][0]
            self.assertEqual(self.s.get_module_ctl_value(mod,idx,0),0)
            unit=self.r.vib_ctl[tag+'_unit'][0]
            self.assertEqual(self.s.get_module_ctl_value(mod,unit,0),0)
    def test_depth_ramps_up_down_and_no_80hz_pitch_events(self):
        self.r.note_on(60,100)
        self.s.events.clear()
        self.r.set_parameter('lfo.pitch_depth',127)
        for _ in range(18):self.r.tick(now=self.r._last_tick+.016,force=True)
        idx=self.r.vib_ctl['lfo_amplitude'][0]
        self.assertEqual(self.s.get_module_ctl_value(self.r.vib_lfo,idx,0),VIBRATO_MAX_NATIVE_AMP)
        self.assertFalse([e for e in self.s.events if e[1]==NOTECMD.SET_PITCH])
        self.r.set_parameter('lfo.pitch_depth',0)
        for _ in range(25):self.r.tick(now=self.r._last_tick+.016,force=True)
        self.assertEqual(self.s.get_module_ctl_value(self.r.vib_lfo,idx,0),0)
    def test_pitch_bend_is_still_direct(self):
        self.r.note_on(60,100)
        self.s.events.clear()
        self.r.handle_swing(mido.Message('pitchwheel',pitch=8191))
        events=[e for e in self.s.events if e[1]==0 and e[4]==5]
        self.assertEqual(len(events),3)
        self.assertEqual(events[0][5],512)
    def test_lfo_speed_native_hz64(self):
        self.r.set_parameter('lfo.rate',110)
        self.r.tick(now=self.r._last_tick+.02,force=True)
        freq=self.s.get_module_ctl_value(self.r.vib_lfo,self.r.vib_ctl['lfo_frequency'][0],0)
        self.assertAlmostEqual(freq/64,self.r.lfo_rate,delta=.02)
    def test_legacy_route_stays_available_for_ab(self):
        s=FakeSlot();r=SynthRig(s,pitch_lfo_mode='events')
        self.assertIsNone(r.vib_lfo)
        self.assertIn((r.voices[0].velocity_amp,r.output_amp),s.links)
        r.note_on(60,100)
        s.events.clear()
        r.set_parameter('lfo.pitch_depth',127)
        r.tick(now=r._last_tick+.083,force=True)
        self.assertGreater(len([e for e in s.events if e[1]==0 and e[4] in (5,6)]),0)
    def test_filter_cutoff_moves_gradually(self):
        self.r.set_parameter('filter.cutoff',0)
        before=self.s.get_module_ctl_value(self.r.voices[0].filt,self.r.voices[0].ctls['cutoff'][0],0)
        for _ in range(40):self.r.tick(now=self.r._last_tick+.016,force=True)
        lower=self.s.get_module_ctl_value(self.r.voices[0].filt,self.r.voices[0].ctls['cutoff'][0],0)
        self.assertLess(lower,before)
        self.r.set_parameter('filter.cutoff',127)
        first=self.s.get_module_ctl_value(self.r.voices[0].filt,self.r.voices[0].ctls['cutoff'][0],0)
        self.assertLess(first,14000)
        for _ in range(30):self.r.tick(now=self.r._last_tick+.016,force=True)
        self.assertAlmostEqual(self.s.get_module_ctl_value(self.r.voices[0].filt,self.r.voices[0].ctls['cutoff'][0],0),14000,delta=2)
    def test_smoother_approaches_exact_zero(self):
        p=SmoothParameter(value=12,tau=.045)
        for _ in range(60):p.update(0,.016)
        self.assertEqual(p.value,0)

if __name__=='__main__':unittest.main()
