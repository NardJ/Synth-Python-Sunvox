"""Synthetic recording exercises the standalone diagnosis program (no hardware)."""
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
import wave
import zipfile
from array import array
import math
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from analyse_lfo_check import extract

class LfoAnalysisTests(unittest.TestCase):
    def test_reads_recording_zip_and_six_phases(self):
        sr=8000
        length=10
        samples=array('h',[int(10000*math.sin(2*math.pi*261.625*i/sr))
                           for i in range(length*sr)])
        wav=io.BytesIO()
        with wave.open(wav,'wb') as w:
            w.setnchannels(1);w.setsampwidth(2);w.setframerate(sr)
            w.writeframes(samples.tobytes())
        times=(.3,1.6,3.1,4.6,6.1,7.6)
        values=(0,15,45,85,127,0)
        events=[{'t':0.,'event':'record_start','data':{'metadata':{'pitch_lfo_mode':'native'}}}]
        events.extend({'t':time,'event':'lfo_check_step','data':{'label':f'diepte {depth}','pitch_depth':depth}}
                      for time,depth in zip(times,values))
        with tempfile.TemporaryDirectory() as d:
            zpath=Path(d)/'test.zip'
            with zipfile.ZipFile(zpath,'w') as z:
                z.writestr('example.wav',wav.getvalue())
                z.writestr('example.jsonl','\n'.join(json.dumps(e) for e in events))
            meta,rows=extract(zpath)
        self.assertEqual(meta['pitch_lfo_mode'],'native')
        self.assertEqual(len(rows),6)
        self.assertAlmostEqual(rows[0]['median_frequency_hz'],261.625,delta=1)
        self.assertLess(rows[0]['frequency_span_cents'],15)

if __name__=='__main__':unittest.main()
