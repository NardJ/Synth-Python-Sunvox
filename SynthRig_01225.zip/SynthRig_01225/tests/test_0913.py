"""0.9.13: CC1 - fijnere Vibrato-regeling met behoud van hoorbare diepte."""
import sys
import math
import unittest
from pathlib import Path
from types import SimpleNamespace as NS
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from test_09 import FakeSlot
from synthrig.engine09 import SynthRig, MOD_EXP_NATIVE_AMP, MOD_SMOOTH_SECONDS

class ModulationTests(unittest.TestCase):
    def setUp(self):
        self.slot=FakeSlot()
        self.rig=SynthRig(self.slot)
        self.rig.note_on(60,110)
    def test_only_cc1_uses_exponential_amplitude(self):
        a=self.rig.lookup(self.rig.vib_mod,'Exponential amplitude')
        b=self.rig.lookup(self.rig.vib_lfo,'Exponential amplitude')
        self.assertEqual(self.slot.get_module_ctl_value(self.rig.vib_mod,a[0],0),1)
        self.assertEqual(self.slot.get_module_ctl_value(self.rig.vib_lfo,b[0],0),0)
    def test_modulation_has_high_resolution_with_same_full_depth(self):
        self.assertEqual(MOD_EXP_NATIVE_AMP,64)
        self.assertGreaterEqual(MOD_SMOOTH_SECONDS,.08)
        for cc,expected in [(0,0),(32,32),(64,45),(127,64)]:
            self.rig.handle_swing(NS(type='control_change',control=1,value=cc))
            self.rig.tick(now=self.rig._last_tick+1.0,force=True)
            val=self.rig._last_vibrato_native['mod_amp']
            self.assertLessEqual(abs(val-expected),2,(cc,val,expected))
    def test_cc1_never_sends_generator_pitch_or_note_retrigger(self):
        self.slot.events.clear()
        from sunvox.api import NOTECMD
        for cc in list(range(128))+list(reversed(range(128))):
            self.rig.handle_swing(NS(type='control_change',control=1,value=cc))
            self.rig.tick(now=self.rig._last_tick+.015,force=True)
        self.assertEqual(self.rig.pitch_bend,0.)
        self.assertFalse([x for x in self.slot.events if x[1]==NOTECMD.SET_PITCH or 1<=x[1]<=127])
        self.assertIn(60,self.rig.active_notes)

if __name__=='__main__':unittest.main()
