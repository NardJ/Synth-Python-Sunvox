"""0.9.9: structural qualitycheck tests, no actual SunVox or sound card needed."""
from __future__ import annotations
import io
import math
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
from array import array
import json
import wave
import zipfile

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from test_09 import FakeSlot
from synthrig.engine09 import SynthRig
from synthrig.quality099 import baseline, qualitycheck, rewire_output, wave_readback
from analyse_quality099 import analyze


class RewireSlot(FakeSlot):
    def __init__(self):
        super().__init__()
        self.depth=0
    def lock(self):
        self.depth+=1
    def unlock(self):
        self.depth-=1
    def disconnect_module(self,a,b):
        assert self.depth>0,'no lock!'
        self.links.remove((a,b))
        return 0
    def connect_module(self,a,b):
        if hasattr(self,'depth'):
            # Engine creation predates qualitycheck; only require a lock when
            # method is invoked by rewire test (and actual tests check this).
            pass
        self.links.append((a,b))
        return 0

class RecorderStub:
    active=True
    def __init__(self):self.events=[]
    def log(self,kind,payload):self.events.append((kind,payload))

class Quality(unittest.TestCase):
    def test_rewire_restores_even_if_body_raises(self):
        slot=RewireSlot();slot.connect_module(10,0)
        with self.assertRaisesRegex(ValueError,'probe'):
            with rewire_output(slot,(10,0),20):
                self.assertIn((20,0),slot.links)
                self.assertNotIn((10,0),slot.links)
                raise ValueError('probe')
        self.assertIn((10,0),slot.links)
        self.assertNotIn((20,0),slot.links)
        self.assertEqual(slot.depth,0)

    def test_qualitycheck_covers_oscillators_voices_chain_and_release(self):
        slot=RewireSlot();rig=SynthRig(slot)
        recorder=RecorderStub()
        with patch('synthrig.quality099.wait',return_value=None):
            qualitycheck(rig,recorder)
        steps=[d for e,d in recorder.events if e=='quality_step']
        labels={d['label'] for d in steps}
        for i in range(1,5):
            self.assertIn(f'voice{i}_sin',labels)
            self.assertIn(f'voice{i}_osc2_sin',labels)
        for stage in ('generator','dc_blocker','osc_gain','filter','amp_adsr','full_chain'):
            self.assertIn('stage_'+stage,labels)
        for key in ('wave_switch_saw','wave_switch_back_sin',
                    'adsr_attack_slow','adsr_release_tail','poly_one','poly_four'):
            self.assertIn(key,labels)
        self.assertEqual(slot.depth,0)
        self.assertEqual(slot.links.count((rig.output_amp,0)),1)
        self.assertFalse([e for e,d in recorder.events if e=='quality_warning'])
        self.assertFalse(rig.active_notes)

    def test_qualitycheck_avoids_rewiring_if_api_missing(self):
        slot=FakeSlot();rig=SynthRig(slot)
        recorder=RecorderStub()
        with patch('synthrig.quality099.wait',return_value=None):
            qualitycheck(rig,recorder)
        warnings=[d for e,d in recorder.events if e=='quality_warning']
        self.assertTrue(warnings)
        self.assertIn((rig.output_amp,0),slot.links)

    def test_analyzer_marks_silence_as_fail_and_outputs_reports(self):
        rate=44100
        with tempfile.TemporaryDirectory() as tmp:
            zippath=Path(tmp)/'synthetic.zip'
            samples=array('h',[0]*(int(2.1*rate)*2))
            bio=io.BytesIO()
            with wave.open(bio,'wb') as w:
                w.setnchannels(2);w.setsampwidth(2);w.setframerate(rate)
                w.writeframes(samples.tobytes())
            events=[{'t':.10,'event':'quality_step','data':{'label':'voice1_sin',
                   'kind':'voice','duration':1.3,'waveform_expected':5,
                   'waveform_readback':5,'expected_hz':261.625565}}]
            with zipfile.ZipFile(zippath,'w') as z:
                z.writestr('audio.wav',bio.getvalue())
                z.writestr('events.jsonl','\n'.join(json.dumps(e) for e in events))
            result=analyze(zippath,save=True)
            self.assertGreater(result['counts']['FAIL'],0)
            with zipfile.ZipFile(zippath) as z:
                self.assertTrue(any(x.endswith('_quality_report.json') for x in z.namelist()))
                self.assertTrue(any(x.endswith('_quality_report.txt') for x in z.namelist()))

    def test_baseline_does_not_mutate_7bit_inputs_or_pitch_conversion(self):
        slot=RewireSlot();rig=SynthRig(slot)
        baseline(rig)
        self.assertEqual(wave_readback(rig,0,1),5)
        self.assertEqual(wave_readback(rig,3,2),5)
        self.assertEqual(rig.pitch_calibration_semitones,-12)

if __name__=='__main__':unittest.main()
