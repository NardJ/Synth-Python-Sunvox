"""UI regression for the APC column header placement."""
import unittest
from synthrig.apc_monitor import (PAD_LEFT, PAD_TOP, PAD_STEP_X, PAD_STEP_Y,
                                   PAD_H, PAD_W, COL_LABEL_Y1, COL_LABEL_Y2, COL_DEPTH_Y, FADER_XS)

class APCColumnHeaderTests(unittest.TestCase):
    def test_column_headers_above_pad_grid(self):
        self.assertLess(COL_LABEL_Y2 + 10, PAD_TOP)
        self.assertGreater(COL_LABEL_Y1, 144)  # below instruction line
        self.assertLess(PAD_TOP + 7*PAD_STEP_Y+PAD_H, COL_DEPTH_Y)
        self.assertLess(COL_DEPTH_Y, 578)  # before track buttons

    def test_faders_remain_aligned_to_columns(self):
        for col in range(8):
            self.assertEqual(FADER_XS[col], PAD_LEFT+col*PAD_STEP_X+PAD_W/2)

if __name__=='__main__': unittest.main()
