"""0.9.12: fasevaste 05/06-effecten in plaats van herhaalde SET_PITCH."""
from __future__ import annotations
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from test_09 import FakeSlot
from sunvox.api import NOTECMD
from synthrig.tracks098 import voice_track
from synthrig.engine09 import SynthRig

class PhaseSafePitchTests(unittest.TestCase):
    def setUp(self):
        self.slot = FakeSlot()
        self.rig = SynthRig(self.slot)
        self.rig.note_on(60, 110)

    def updates(self):
        return [event for event in self.slot.events
                if event[1] == 0 and event[4] in (5, 6)]

    def test_bend_up_down_and_zero_have_no_repeated_setpitch_or_retrigger(self):
        for raw,fx,amount in ((8191,5,512),(-8192,6,512),(0,5,0)):
            self.slot.events.clear()
            self.rig.handle_swing(SimpleNamespace(type='pitchwheel',pitch=raw))
            self.assertEqual(len(self.updates()),3)
            self.assertEqual([(event[4],event[5]) for event in self.updates()],[(fx,amount)]*3)
            self.assertFalse([event for event in self.slot.events
                              if event[1] == NOTECMD.SET_PITCH or 1 <= event[1] <= 127])
            self.assertIn(60,self.rig.active_notes)

    def test_both_finetune_controls_preserve_generator_phase(self):
        for oscillator in (1, 2):
            self.slot.events.clear()
            self.rig.set_parameter(f'osc{oscillator}.finetune',127)
            expected=self.rig.voices[0].o1 if oscillator==1 else self.rig.voices[0].o2
            self.assertEqual([(e[3],e[4],e[5]) for e in self.updates()],[(expected+1,5,256)])
            self.assertFalse([e for e in self.slot.events if e[1]==NOTECMD.SET_PITCH])
            self.slot.events.clear()
            self.rig.set_parameter(f'osc{oscillator}.finetune',64)
            self.assertEqual([(e[4],e[5]) for e in self.updates()],[(5,0)])

    def test_polyphony_sends_effect_to_all_four_voices(self):
        for note in (64,67,72):
            self.rig.note_on(note,100)
        self.slot.events.clear()
        self.rig.handle_swing(SimpleNamespace(type='pitchwheel',pitch=-4096))
        effects=self.updates()
        self.assertEqual(len(effects),12)
        self.assertEqual({e[0] for e in effects},{voice_track(i,role) for i in range(4) for role in ("osc1","osc2","sub_noise")})
        self.assertTrue(all(e[4]==6 and e[5]==256 for e in effects))

    def test_waveform_switch_rebases_once_then_bends_with_effect(self):
        self.rig.handle_swing(SimpleNamespace(type='pitchwheel',pitch=8191))
        self.slot.events.clear()
        self.rig.set_waveform_index(1,0)
        first=self.rig.voices[0]
        init=[e for e in self.slot.events
              if e[1]==NOTECMD.SET_PITCH and e[3]==first.o1+1]
        glide=[e for e in self.updates() if e[3]==first.o1+1]
        self.assertEqual(len(init),1)
        self.assertEqual(init[0][5],self.rig._native_pitch(60))
        self.assertEqual([(e[4],e[5]) for e in glide],[(5,512)])

    def test_only_init_uses_setpitch(self):
        initial=[e for e in self.slot.events if e[1]==NOTECMD.SET_PITCH]
        self.assertEqual(len(initial),3)
        self.slot.events.clear()
        for i in range(40):
            self.rig.handle_swing(SimpleNamespace(type='pitchwheel',pitch=-8192+i*410))
        self.assertFalse([e for e in self.slot.events if e[1]==NOTECMD.SET_PITCH])
        self.assertFalse([e for e in self.slot.events if 1<=e[1]<=127])

if __name__=='__main__': unittest.main()
