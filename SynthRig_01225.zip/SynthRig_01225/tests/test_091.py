"""0.9.1 regressies voor vaste MIDImix en onafhankelijke oscillator-gains.

Geen SunVox DLL of MIDI-hardware nodig; FakeSlot controleert de aanroepen.
"""
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from test_09 import FakeSlot
from synthrig.engine09 import SynthRig, MASTER_MAX
from synthrig.fixed_controls import FixedControls, VALID_CC,KNOB_CC,FADER_CC

class FixedLayoutTests(unittest.TestCase):
    def setUp(self):
        self.controls=FixedControls()

    def test_full_layout_unique_targets_and_real_midi_cc(self):
        m=self.controls.mappings
        self.assertTrue(m.keys()<=VALID_CC)
        self.assertEqual(len(m),33)
        self.assertEqual(len(set(v['target'] for v in m.values())),33)
        self.assertEqual(len(set(sum((list(row) for row in KNOB_CC),[])+list(FADER_CC))),33)
        self.assertEqual(set(),VALID_CC-set(m))
        self.assertEqual([m[cc]['target'] for cc in (19,23,27,31)],
                         ['amp.attack','amp.decay','amp.sustain','amp.release'])
        self.assertEqual([m[cc]['target'] for cc in (49,53,57,61,62)],
                         ['sub.level','osc1.level','osc2.level','noise.level','master.level'])
        self.assertEqual(m[16]['target'],'filter.cutoff')
        self.assertEqual(m[17]['target'],'filter.resonance')
        self.assertEqual(m[50]['target'],'osc1.semitones')
        self.assertEqual(m[54]['target'],'osc2.semitones')
        self.assertEqual(m[52]['target'],'osc1.pulse_width')
        self.assertEqual(m[56]['target'],'osc2.pulse_width')
        self.assertEqual(m[46]['target'],'pwm.depth')
        self.assertEqual(m[29]['target'],'pwm.rate')

    def test_no_page_changes_or_automatic_soft_takeover(self):
        self.assertFalse(hasattr(self.controls,'change'))
        self.controls.target_raw['amp.attack']=80
        t,_=self.controls.resolve(19,10)
        self.assertEqual(t,'amp.attack')
        self.controls.target_raw['amp.attack']=80  # simuleer laden van externe preset
        self.controls.arm_pickup(['amp.attack'])
        t,msg=self.controls.resolve(19,15)
        self.assertIsNone(t)
        self.assertIn('pickup',msg)
        t,_=self.controls.resolve(19,80)
        self.assertEqual(t,'amp.attack')

    def test_button_controls_waveforms_independently(self):
        rig=SynthRig(FakeSlot())
        for i,note in enumerate((1,4,7,10,13,16,19,22)):
            result=self.controls.on_note(note,rig)
            osc=1 if i<4 else 2
            self.assertEqual(rig.wave_selection[osc],i%4)
            self.assertIn('golfvorm',result)
        # SOLO-mode: MUTE-rij kan andere note-nummers sturen.
        self.controls.on_note(2,rig)
        self.assertEqual(rig.wave_selection[1],0)
        self.controls.on_note(23,rig)
        self.assertEqual(rig.wave_selection[2],3)

    def test_source_mutes_are_independent_of_levels(self):
        rig=SynthRig(FakeSlot())
        rig.set_parameter('osc1.level',105)
        old=rig.osc1_level
        self.controls.on_note(3,rig)  # REC1
        self.assertFalse(rig.source_enabled['osc1'])
        self.assertEqual(rig.osc1_level,old)
        self.controls.on_note(3,rig)
        self.assertTrue(rig.source_enabled['osc1'])
        self.assertEqual(rig.osc1_level,old)
        for note,source in ((6,'osc2'),(9,'sub'),(12,'noise')):
            self.controls.on_note(note,rig)
            self.assertFalse(rig.source_enabled[source])
        self.assertTrue(self.controls.button_state(rig)['enabled']['osc1'])

    def test_bank_reserved_rec_no_effect_and_panic(self):
        rig=SynthRig(FakeSlot())
        rig.note_on(60,98)
        before=rig.snapshot()['active_notes']
        for note in (15,18,21,24,25,26):
            self.controls.on_note(note,rig)
            self.assertEqual(before,rig.snapshot()['active_notes'])
        self.controls.on_note(27,rig)
        self.assertEqual(rig.active_notes,{})

class VolumeTests(unittest.TestCase):
    def setUp(self):
        self.slot=FakeSlot()
        self.rig=SynthRig(self.slot)

    def gain(self,osc):
        v=self.rig.voices[0]
        ctl=v.ctls[f'vol{osc}'][0]
        return self.slot.get_module_ctl_value(v.a1 if osc==1 else v.a2,ctl,0)

    def test_two_oscillators_sound_without_crossfade_at_default(self):
        self.assertGreater(self.gain(1),0)
        self.assertGreater(self.gain(2),0)
        self.assertFalse(hasattr(self.rig,'vco_mix'))
        self.assertEqual(self.slot.vol,round(MASTER_MAX*96/127))
        with self.assertRaises(ValueError):
            self.rig.set_parameter('osc.mix',64)

    def test_fader_one_does_not_change_oscillator_two(self):
        gain2=self.gain(2)
        self.rig.set_parameter('osc1.level',0)
        self.assertEqual(self.gain(1),0)
        self.assertEqual(self.gain(2),gain2)
        self.rig.set_parameter('osc2.level',0)
        self.assertEqual(self.gain(1),0)
        self.assertEqual(self.gain(2),0)

    def test_mute_does_not_rewrite_fader_and_unmute_restores_volume(self):
        self.rig.set_parameter('osc1.level',102)
        expected=self.gain(1)
        self.rig.set_source_enabled('osc1',False)
        self.assertEqual(self.gain(1),0)
        self.rig.set_source_enabled('osc1',True)
        self.assertEqual(self.gain(1),expected)

    def test_master_midi_range_has_max_256(self):
        self.rig.set_parameter('master.level',0)
        self.assertEqual(self.slot.vol,0)
        self.rig.set_parameter('master.level',127)
        self.assertEqual(self.slot.vol,256)

    def test_four_voices_still_have_independent_filters_and_adsr(self):
        for n in (60,64,67,72):self.rig.note_on(n,100)
        self.assertEqual(len(self.rig.active_notes),4)
        self.assertEqual(len({v.filt for v in self.rig.voices}),4)
        self.assertEqual(len({v.adsr for v in self.rig.voices}),4)
        self.assertTrue(all(v.dc1 is not None and v.dc2 is not None for v in self.rig.voices))

if __name__=='__main__':unittest.main()
