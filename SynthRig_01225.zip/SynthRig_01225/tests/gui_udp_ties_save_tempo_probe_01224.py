"""Real Tk/UDP of physical SAVE LED, tempo label and tied-step palette."""
import socket,time,tkinter as tk,sys
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
from unittest.mock import patch
from mido import Message
from midimix_debug import MidiMixMonitor,ASSIGNMENTS,read_assignments
from synthrig.debug import OptionalMidiMixDebug
from synthrig.apc_mk2 import APCminiMk2,CYAN
from synthrig.fixed_controls import FixedControls
from synthrig.session_state import default_state,apply_state
from test_synthrig import FakeSlot
from synthrig.engine09 import SynthRig

class Output:
    def __init__(self):self.sent=[]
    def send(self,msg):self.sent.append(msg)
class Wire:
    send_apc_status=OptionalMidiMixDebug.send_apc_status
    def __init__(self,port):
        self.process=SimpleNamespace(poll=lambda:None)
        self.sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        self.target=('127.0.0.1',port)

root=tk.Tk();ASSIGNMENTS.update(read_assignments('config/midimix_091.json'))
window=MidiMixMonitor(root,0);wire=Wire(window.socket.getsockname()[1]);root.update()
try:
    with TemporaryDirectory() as temp:
        rig=SynthRig(FakeSlot(),offline=True);controls=FixedControls()
        apply_state(rig,controls,default_state(controls))
        out=Output();apc=APCminiMk2(out,rig,pattern_dir=temp,logger=lambda _:None)
        panel=window.apc_monitor;now=time.monotonic()
        def press(n,at):return apc.handle(Message('note_on',note=n,velocity=127),at)
        def show(at):
            apc.tick(at);wire.send_apc_status(apc.display_snapshot());window.poll();root.update()
        press(101,now)
        press(0,now);press(1,now+.01);press(122,now+.02);press(1,now+.03)
        apc.handle(Message('note_off',note=122),now+.04)
        apc.handle(Message('control_change',control=56,value=0),now+.05)
        show(now+.1)
        assert apc.pattern.tied(0,1) and apc.last_color[1]==CYAN
        shape=dict(panel.pad_shapes)[1]
        assert panel.canvas.itemcget(shape,'fill')=='#27d7ed'
        assert panel.canvas.itemcget(panel.fader_labels[-1],'text')=='TEMPO'
        assert panel.canvas.itemcget(panel.fader_text[-1],'text')=='60.0 BPM'
        assert '60.0 BPM' in panel.canvas.itemcget(panel.status_text,'text')
        assert 'langzamer' in panel.canvas.itemcget(panel.seq_help,'text')
        print('PASS: pad/tie gestures produce cyan real LED command and matching Tk color; TEMPO label and 60 BPM visible')
        press(105,now+.2);show(now+.2)
        sent={(m.channel,m.note):m.velocity for m in out.sent if m.type=='note_on'}
        assert sent[(0,105)]==1
        assert panel.canvas.itemcget(panel.track_shapes[5],'fill')=='#7fe1a6'
        assert panel.canvas.itemcget(panel.track_text[5],'text')=='OK'
        if '--capture' in sys.argv:
            from PIL import ImageGrab
            w=panel.window;x,y=w.winfo_rootx(),w.winfo_rooty()
            ImageGrab.grab(bbox=(x,y,x+w.winfo_width(),y+w.winfo_height())).save('GUI_TIES_SAVE_TEMPO_01224.png')
        show(apc.save_until+.001)
        assert not apc.last_button[105]
        assert panel.canvas.itemcget(panel.track_text[5],'text')=='SAVE'
        print('PASS: successful save -> actual note 105 LED on and green OK in Tk -> off after one second')
        with patch('synthrig.apc_mk2.os.replace',side_effect=OSError('test write failure')):
            try:press(105,now+1.3)
            except OSError:pass
        show(now+1.31)
        assert not apc.last_button[105]
        assert panel.canvas.itemcget(panel.track_text[5],'text')=='SAVE'
        assert 'SAVE MISLUKT' in panel.canvas.itemcget(panel.footer_event,'text')
        print('PASS: failed save has no success LED/OK and displays SAVE MISLUKT')
        apc.set_clock('swing',now+1.4);show(now+1.4)
        assert 'TEMPO via SWING' in panel.canvas.itemcget(panel.seq_help,'text')
        assert panel.canvas.itemcget(panel.fader_text[-1],'text')=='SWING'
        count=len(panel.canvas.find_all())
        for zoom in (.5,1,.9):
            window.set_zoom(zoom);show(now+1.4)
            assert panel.canvas.bbox(panel.mode_hint)[2]<620*panel.canvas.ui_scale
            assert panel.canvas.bbox(panel.seq_help)[2]<690*panel.canvas.ui_scale
        assert len(panel.canvas.find_all())==count
        print('PASS: external-tempo hint and new help text fit at 50/100/90 percent zoom; no canvas item growth')
finally:wire.sock.close();window.close()
