"""APC Mk2 introduction and MIDImix physical-position regression tests."""
from synthrig.mod_matrix import ModMatrix
import tempfile
import unittest
import mido
from synthrig.apc_mk2 import APCminiMk2, APC_INTRODUCTION, parse_fader_introduction
from synthrig.fixed_controls import FixedControls, VALID_CC

class FakeRig:
    def __init__(self):self.mod_matrix=ModMatrix()
    def tick(self,**kwargs):pass
    def set_parameter(self,*args): pass
    def note_on(self,*args): pass
    def note_off(self,*args): pass
    def all_notes_off(self): pass
class FakePort:
    def __init__(self): self.messages=[]
    def send(self,m): self.messages.append(m)
class TestIntroduction(unittest.TestCase):
    def build(self,output=None):
        temp=tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        return APCminiMk2(output,FakeRig(),pattern_dir=temp.name,logger=lambda _:None)
    def reply(self,values):
        return mido.Message('sysex',data=(0x47,0x7f,0x4f,0x61,0,4,*values))
    def test_intro_first_sent_message_before_leds(self):
        o=FakePort(); a=self.build(o)
        self.assertEqual(o.messages[0].type,'sysex')
        self.assertEqual(tuple(o.messages[0].data),APC_INTRODUCTION)
        self.assertEqual(a.display_snapshot()['faders'],[None]*9)
    def test_all_nine_faders_from_reply_without_note_side_effects(self):
        o=FakePort(); a=self.build(o)
        values=[0,10,20,30,40,50,60,70,127]
        self.assertIsNotNone(a.handle(self.reply(values)))
        self.assertEqual(a.display_snapshot()['faders'],values)
        self.assertEqual(a.display_snapshot()['fader_intro_status'],'received')
        self.assertEqual(a.pattern.bpm,120.0)
        self.assertEqual(a.pattern.notes,[48,50,52,53,55,57,59,60])
    def test_excludes_other_sysex(self):
        o=FakePort(); a=self.build(o)
        for data in ((0x47,0x7f,0x4e,0x61,0,4,*([3]*9)),
                     (0x47,0x7f,0x4f,0x60,0,4,*([3]*9)),
                     (0x47,0x7f,0x4f,0x61,0,4,*([3]*8)),
                     (0x43,0x7f,0x4f,0x61,0,4,*([3]*9))):
            self.assertIsNone(a.handle(mido.Message('sysex',data=data)))
        self.assertEqual(a.faders,[None]*9)
    def test_fader_cc_after_query_wins_against_late_reply(self):
        a=self.build(FakePort())
        a.handle(mido.Message('control_change',channel=0,control=48,value=105))
        a.handle(self.reply([3]*9))
        self.assertEqual(a.faders[0],105)
        self.assertEqual(a.faders[1:],[3]*8)
    def test_no_reply_times_out_but_midi_remains_usable(self):
        a=self.build(FakePort())
        a.tick(a.fader_intro_requested_at+3.0)
        self.assertEqual(a.fader_intro_status,'no_response')
        a.handle(mido.Message('control_change',control=54,value=81))
        self.assertEqual(a.faders[6],81)
    def test_without_output_fallback(self):
        a=self.build(None)
        self.assertEqual(a.fader_intro_status,'unavailable')
        self.assertEqual(a.faders,[None]*9)
        a.handle(mido.Message('control_change',control=55,value=99))
        self.assertEqual(a.faders[7],99)
    def test_soft_takeover_on_send_all_physical_snapshot(self):
        c=FixedControls()
        for spec in c.mappings.values(): c.target_raw[spec['target']]=64
        c.arm_pickup()
        self.assertEqual(len(VALID_CC),33)
        for cc in sorted(VALID_CC):
            target,_=c.resolve(cc,0)
            self.assertIsNone(target)
        self.assertEqual(len(c.last_physical),33)
        self.assertTrue(all(x==64 for x in c.target_raw.values()))

if __name__=='__main__':unittest.main()
