"""Geen audiohardware nodig; FakeSlot test alle SunVox-API aanroepen op hoofdlijnen."""
import os
import sys
import unittest
from pathlib import Path
from types import ModuleType, SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
# Fake sunvox only if the native package is unavailable in the test environment.
try:
    from sunvox.api import NOTECMD
except ImportError:
    sunvox = ModuleType('sunvox')
    api = ModuleType('sunvox.api')
    api.NOTECMD = SimpleNamespace(NOTE_OFF=128, SET_PITCH=133)
    sunvox.api = api
    sys.modules['sunvox'] = sunvox
    sys.modules['sunvox.api'] = api

from synthrig.controls import load_mappings, DEFAULT_CONFIG
from synthrig.engine import SynthRig, choose_wave_index
from synthrig.pwm import PWM


class FakeSlot:
    ctl_defs = {
        'ADSR': [
            ('Volume',0,256,0,256), ('Attack (ms)',0,10000,0,20),
            ('Decay (ms)',0,10000,0,200), ('Sustain level',0,256,0,128),
            ('Release (ms)',0,10000,0,200), ('Sustain',0,2,0,1),
            ('On NoteON',0,2,0,2), ('On NoteOFF',0,2,0,2),
            ('Mode',0,2,0,1),
        ],
        'Generator': [('Waveform', 0, 8, 0, 0), ('Duty cycle', 0, 256, 0, 128)],
        'MultiSynth': [('Transpose', 0, 256, -128, 128), ('Finetune', 0, 512, -256, 256)],
        'Amplifier': [('Volume', 0, 512, 0, 256),('Balance',0,256,0,128)],
        'Flanger': [('Dry',0,256,0,256),('Wet',0,256,0,128),
                    ('Feedback',0,256,0,128),('Delay',8,1000,0,200),
                    ('Response',0,256,0,2),('LFO freq',0,512,0,8),
                    ('LFO amp',0,256,0,32),('LFO waveform',0,1,0,0),
                    ('Set LFO phase',0,256,0,0),('LFO freq unit',0,6,0,0)],
        'Echo': [('Dry',0,256,0,256),('Wet',0,256,0,40),
                 ('Feedback',0,256,0,128),('Delay',0,256,0,256),
                 ('Delay unit',0,6,0,0),('Filter',0,2,0,0),
                 ('F.freq',0,22000,0,2000)],
        'Reverb': [('Dry',0,256,0,256),('Wet',0,256,0,40),
                   ('Feedback',0,256,0,256),('Damp',0,256,0,128),
                   ('Stereo width',0,256,0,256),('Room size',0,128,0,16)],
        'DC Blocker': [('Mono', 0, 1, 0, 0)],
        'Vibrato': [('Volume',0,256,0,256),('Amplitude',0,256,0,16),
                    ('Frequency',1,2048,0,256),('Channels',0,1,0,0),
                    ('Set phase',0,256,0,0),('Frequency unit',0,6,0,0),
                    ('Exponential amplitude',0,1,0,0)],
        'Filter': [
            ('Frequency', 80, 16000, 0, 8000), ('Resonance', 0, 1530, 0, 0),
            ('Type', 0, 7, 0, 0), ('Mix', 0, 256, 0, 256),
            ('Mode', 0, 4, 0, 0), ('Roll-off', 0, 4, 0, 1),
            ('Response', 0, 256, 0, 1),
        ],
    }

    def __init__(self):
        self.types = {}
        self.values = {}
        self.set_calls = []
        self.events = []
        self.links = []
        self.modules = 1
        self.vol = 0

    def new_module(self, type_name, name, *args):
        module = self.modules
        self.modules += 1
        self.types[module] = type_name
        for i, ctl in enumerate(self.ctl_defs[type_name]):
            self.values[(module,i)] = ctl[4]
        return module

    def connect_module(self, source, target):
        self.links.append((source,target))
        return 0

    def volume(self, level):
        self.vol = level
    def set_event_t(self, *args):
        pass
    def get_number_of_module_ctls(self,module):
        return len(self.ctl_defs[self.types[module]])
    def spec(self,module,ctl):
        return self.ctl_defs[self.types[module]][ctl]
    def get_module_ctl_name(self,module,ctl):
        return self.spec(module,ctl)[0].encode()
    def get_module_ctl_min(self,module,ctl,scaled):
        return self.spec(module,ctl)[1]
    def get_module_ctl_max(self,module,ctl,scaled):
        return self.spec(module,ctl)[2]
    def get_module_ctl_offset(self,module,ctl):
        return self.spec(module,ctl)[3]
    def get_module_ctl_value(self,module,ctl,scaled):
        return self.values[(module,ctl)]
    def set_module_ctl_value(self,module,ctl,value,scaled):
        assert self.spec(module,ctl)[1] <= value <= self.spec(module,ctl)[2]
        self.values[(module,ctl)] = value
        self.set_calls.append((module,ctl,value))
        return 0
    def send_event(self,*args):
        self.events.append(args)


def midi_cc(cc,value):
    return SimpleNamespace(type='control_change',control=cc,value=value)


class PureUnitTests(unittest.TestCase):
    def test_map_and_waves(self):
        mapping=load_mappings(DEFAULT_CONFIG)
        self.assertEqual(mapping[28]['target'],'osc1.pulse_width')
        self.assertEqual(mapping[46]['target'],'osc2.pulse_width')
        self.assertEqual(mapping[47]['target'],'pwm.depth')
        self.assertEqual(mapping[29]['target'],'pwm.rate')
        self.assertNotIn(24, mapping)
        self.assertNotIn(58, mapping)
        self.assertEqual(choose_wave_index(0),0)
        self.assertEqual(choose_wave_index(127),3)
        self.assertEqual(choose_wave_index(32,0),0) # hysterese
        self.assertEqual(choose_wave_index(34,0),1)
        self.assertEqual(choose_wave_index(95,3),3)
        self.assertEqual(choose_wave_index(93,3),2)

    def test_pwm_calculation(self):
        p=PWM()
        self.assertEqual(p.advance(1.),{1:.5,2:.5})
        p.set_width(1,.3)
        self.assertAlmostEqual(p.advance(2.)[1],.3)
        p.depth=.2
        p.rate=1.
        p.phase=0
        self.assertAlmostEqual(p.advance(2.25)[1],.5)
        self.assertAlmostEqual(p.advance(2.25)[2],.7)
        p.set_width(1,.1)
        self.assertGreaterEqual(p.advance(2.5)[1],.1)
        self.assertLessEqual(p.advance(2.75)[1],.9)

    def test_pulse_width_on_fake_engine(self):
        s=FakeSlot()
        rig=SynthRig(s,load_mappings(),diagnose=False)
        # switch OSC1 to PULSE, then change width with physical CC28
        rig.handle_midimix(midi_cc(52,127))
        rig.handle_midimix(midi_cc(28,0))
        lo=s.get_module_ctl_value(rig.osc1,rig.duty1[0],0)
        rig.handle_midimix(midi_cc(28,127))
        hi=s.get_module_ctl_value(rig.osc1,rig.duty1[0],0)
        self.assertGreater(hi,lo)
        self.assertAlmostEqual(lo,26,delta=2)
        self.assertAlmostEqual(hi,230,delta=2)
        # PWM updates cause further duty changes in Pulse, not other waveforms
        rig.handle_midimix(midi_cc(28,64))
        rig.handle_midimix(midi_cc(47,100))
        rig.handle_midimix(midi_cc(29,127))
        rig.pwm.phase=0
        rig.pwm.last_time=100.
        rig.tick_pwm(now=100.04,force=True)
        first=s.get_module_ctl_value(rig.osc1,rig.duty1[0],0)
        rig.tick_pwm(now=100.09,force=True)
        second=s.get_module_ctl_value(rig.osc1,rig.duty1[0],0)
        self.assertNotEqual(first,second)
        # OSC2 still PULSE by default, with base at 50%.
        self.assertEqual(rig.wave_selection[2],3)

    def test_previous_07_behaviour(self):
        slot=FakeSlot()
        rig=SynthRig(slot, load_mappings())
        rig.note_on(60,100)
        self.assertEqual(slot.vol,128)  # veilig opstartniveau
        self.assertEqual(len(rig.active_notes),1)
        rig.note_off(60)
        self.assertEqual(len(rig.active_notes),0)
        rig.handle_midimix(midi_cc(16,60))
        rig.handle_midimix(midi_cc(17,100))
        self.assertTrue(slot.get_module_ctl_value(rig.filt,rig.cutoff[0],0)>80)
        self.assertTrue(slot.get_module_ctl_value(rig.filt,rig.resonance[0],0)>0)
        rig.handle_midimix(midi_cc(50,127))
        self.assertEqual(rig.osc_tuning[1]['semitones'],24)
        rig.handle_midimix(midi_cc(62,0))
        self.assertEqual(slot.vol,0)
        rig.handle_midimix(midi_cc(62,127))
        self.assertEqual(slot.vol,256)
        rig.handle_midimix(midi_cc(62,64))
        self.assertEqual(slot.vol,round(256*64/127))




class DcBlockerTests(unittest.TestCase):
    def test_each_oscillator_has_own_blocker_before_mixer_and_filter(self):
        a=FakeSlot()
        rig=SynthRig(a,load_mappings(),dc_blocker=True)
        self.assertNotEqual(rig.dc_blocker1,rig.dc_blocker2)
        for osc,blocker,amp in ((rig.osc1,rig.dc_blocker1,rig.amp1),
                                 (rig.osc2,rig.dc_blocker2,rig.amp2)):
            self.assertIn((osc,blocker),a.links)
            self.assertIn((blocker,amp),a.links)
            self.assertNotIn((osc,amp),a.links)
            self.assertNotIn((blocker,rig.filt),a.links)
        self.assertIn((rig.amp1,rig.filt),a.links)
        self.assertIn((rig.amp2,rig.filt),a.links)
        self.assertIn((rig.filt,0),a.links)
        self.assertNotIn((rig.filt,rig.dc_blocker1),a.links)
        self.assertNotIn((rig.filt,rig.dc_blocker2),a.links)

    def test_a_b_reference_without_blockers(self):
        b=FakeSlot()
        rig=SynthRig(b,load_mappings(),dc_blocker=False)
        self.assertIsNone(rig.dc_blocker1)
        self.assertIsNone(rig.dc_blocker2)
        self.assertIn((rig.osc1,rig.amp1),b.links)
        self.assertIn((rig.osc2,rig.amp2),b.links)
        self.assertIn((rig.amp1,rig.filt),b.links)
        self.assertIn((rig.amp2,rig.filt),b.links)
        self.assertIn((rig.filt,0),b.links)

if __name__=='__main__':
    unittest.main()
