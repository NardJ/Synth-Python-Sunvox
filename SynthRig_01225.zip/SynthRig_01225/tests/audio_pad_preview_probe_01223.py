"""Targeted native SunVox PCM check for all eight pad pitches, on AND off.

No audio hardware or MIDI device needed. Uses the existing offline audio
driver; does not run the entire historical DSP regression suite.
"""
import json
from pathlib import Path
from tempfile import TemporaryDirectory

import numpy as np
from mido import Message
import sunvox.dll as dll
from sunvox.api import Slot, init, deinit
from sunvox.types import INIT_FLAG
from synthrig.engine09 import SynthRig
from synthrig.apc_mk2 import APCminiMk2
from synthrig.offline0102 import OfflineAudio, RATE, rms, estimate_pitch, apply_baseline


checks = []
for mode in ('native', 'events'):
    flags = int(INIT_FLAG.OFFLINE | INIT_FLAG.AUDIO_FLOAT32 | INIT_FLAG.ONE_THREAD | INIT_FLAG.NO_DEBUG_OUTPUT)
    assert init(None, RATE, 2, flags) >= 0
    try:
        with Slot() as slot, TemporaryDirectory() as temp:
            rig = SynthRig(slot, offline=True, pitch_lfo_mode=mode)
            apply_baseline(rig)
            for key in ('chorus','delay','reverb'):rig.set_parameter('effects.'+key,0)
            assert slot.play() >= 0
            with OfflineAudio(rig, dll) as driver:
                apc = APCminiMk2(None, rig, pattern_dir=temp, logger=lambda _: None)
                apc.handle(Message('note_on', note=101, velocity=127), driver.clock)
                driver.render(.3)
                for row, note in enumerate(apc.pattern.notes):
                    for enabled in (True, False):
                        apc.handle(Message('note_on', note=row*8, velocity=127), driver.clock)
                        chunks = []
                        for _ in range(40):
                            chunks.append(driver.render(.01))
                            apc.tick(driver.clock)
                        audio = np.concatenate(chunks)
                        tone = audio[round(.04*RATE):round(.20*RATE), 0]
                        tail = audio[round(.35*RATE):, 0]
                        measured = estimate_pitch(tone)
                        expected = 440 * 2 ** ((note - 69) / 12)
                        level, quiet = rms(tone), rms(tail)
                        ok = (measured is not None and abs(measured-expected)<2.5 and level>1e-4
                              and quiet<level*.02 and not rig.active_notes
                              and apc.pattern.steps[row][0] == enabled and not apc.playing)
                        entry = {'mode':mode,'midi_note':note,'step_enabled':enabled,
                                 'expected_hz':round(expected,3),
                                 'measured_hz':round(measured,3) if measured else None,
                                 'tone_rms':float(level),'tail_rms':float(quiet),
                                 'status':'PASS' if ok else 'FAIL'}
                        checks.append(entry)
                        print(entry,flush=True)
                apc.close()
    finally:
        deinit()
report = {'format':'SynthRig pad audition native PCM 1','version':'0.12.23',
          'PASS':sum(c['status']=='PASS' for c in checks),
          'FAIL':sum(c['status']=='FAIL' for c in checks),'checks':checks}
path = Path('reports_01223/audio_preview.json')
path.parent.mkdir(exist_ok=True)
path.write_text(json.dumps(report,indent=2)+'\n')
print('NATIVE AUDIO SUMMARY',report['PASS'],report['FAIL'],flush=True)
if report['FAIL']:raise SystemExit(1)
