"""MIDImix CC47/48, sixteen slots, LED status and long-press save regression."""
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import unittest
from test_synthrig import FakeSlot
from synthrig.engine09 import SynthRig
from synthrig.fixed_controls import FixedControls
from synthrig.session_state import default_state,apply_state,load_state,capture_state
from synthrig.presets import PresetManager,factory_presets
from synthrig.preset_buttons import SoloSaveButton
from synthrig.midimix_hw import MidiMixLEDs


class FakeOutput:
    def __init__(self):self.sent=[]
    def send(self,m):self.sent.append(m)


class V0111(unittest.TestCase):
    def setUp(self):
        self.temp=TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.rig=SynthRig(FakeSlot(),offline=True)
        self.controls=FixedControls()
        apply_state(self.rig,self.controls,default_state(self.controls))
        self.pm=PresetManager(self.controls,self.temp.name)

    def test_sixteen_distinct_valid_factory(self):
        self.assertEqual(len(factory_presets(self.controls)),16)
        self.assertEqual(len(self.pm.slots()),16)
        self.assertEqual(len(set(n for n,s in factory_presets(self.controls))),16)

    def test_bank_wraps_just_sixteen(self):
        self.pm.step(-1,self.rig)
        self.assertEqual(self.pm.selection()['slot'],16)
        self.pm.step(1,self.rig)
        self.assertEqual(self.pm.selection()['slot'],1)

    def test_save_slot_overwrites_user_not_factory(self):
        self.pm.load('9',self.rig)
        factory_name=factory_presets(self.controls)[8][0]
        self.rig.set_parameter('osc1.level',22)
        self.controls.target_raw['osc1.level']=22
        self.assertIn('opgeslagen',self.pm.save_slot(self.rig))
        self.assertTrue(self.pm.selection()['user'])
        self.pm.load('9',self.rig)
        self.assertEqual(self.controls.target_raw['osc1.level'],22)
        self.assertEqual(len(factory_presets(self.controls)),16)
        self.pm.restore_factory(9,self.rig)
        self.assertEqual(self.pm.selection()['name'],factory_name)
        self.assertFalse(self.pm.selection()['user'])

    def test_no_slot_save_requires_selection(self):
        with self.assertRaisesRegex(ValueError,'Kies eerst'):self.pm.save_slot(self.rig)

    def test_old_preset_state_migrates(self):
        old=default_state(self.controls)
        for cc in ('47','48'):old['layout_targets'].pop(cc)
        for target in ('effects.delay','effects.reverb'):old['raw'].pop(target)
        old['fx']={'delay':47,'reverb':89}
        from synthrig.presets import validate_preset
        fixed=validate_preset(old,self.controls)
        self.assertEqual(fixed['raw']['effects.delay'],47)
        self.assertEqual(fixed['raw']['effects.reverb'],89)
        dest=Path(self.temp.name)/'legacy.json'
        import json
        dest.write_text(json.dumps(old))
        loaded=load_state(dest,self.controls)
        self.assertEqual(loaded['raw']['effects.delay'],47)

    def test_cc47_48_are_live_and_soft_pickup(self):
        self.assertEqual(self.controls.mappings[47]['target'],'effects.delay')
        self.assertEqual(self.controls.mappings[48]['target'],'effects.reverb')
        self.pm.load('5',self.rig)
        self.assertIn(47,self.controls.pickup)
        self.assertIn(48,self.controls.pickup)
        target,_=self.controls.resolve(48,0)
        self.assertIsNone(target)
        target,_=self.controls.resolve(48,72)
        self.assertEqual(target,'effects.reverb')
        self.rig.set_parameter(target,72)
        self.assertEqual(round(self.rig.reverb_mix*127),72)

    def test_solo_short_press_panic_long_save_release(self):
        button=SoloSaveButton(1.5)
        def note(d):return SimpleNamespace(type='note_on',note=27,velocity=127 if d else 0)
        self.assertIsNone(button.feed(note(True),1.0))
        self.assertEqual(button.feed(note(False),1.4),'panic')
        self.assertIsNone(button.feed(note(True),2.0))
        self.assertIsNone(button.feed(note(True),2.4))
        self.assertEqual(button.feed(note(False),3.55),'save')
        self.assertIsNone(button.feed(note(False),3.56))

    def test_led_unary_count_and_restore(self):
        out=FakeOutput();leds=MidiMixLEDs(out,self.controls)
        state=self.controls.button_state(self.rig)
        leds.sync(state)
        leds.show_preset(12,duration=0.01)
        self.assertEqual(len(out.sent[-16:]),16)
        self.assertEqual(sum(msg.velocity>0 for msg in out.sent[-16:]),12)
        self.assertEqual(set(msg.note for msg in out.sent[-16:]),set([1,4,7,10,13,16,19,22,3,6,9,12,15,18,21,24]))
        # Overlay not disturbed by normal LED calls.
        count=len(out.sent)
        leds.sync(state,force=True)
        self.assertEqual(len(out.sent),count)
        leds.preset_until=0
        leds.tick(state)
        self.assertFalse(leds._overlay)
        self.assertGreater(len(out.sent),count)

    def test_fx_persist_consistent_with_controller(self):
        self.rig.set_parameter('effects.delay',51)
        self.rig.set_parameter('effects.reverb',30)
        state=capture_state(self.rig,self.controls)
        self.assertEqual(state['raw']['effects.delay'],state['fx']['delay'])
        self.assertEqual(state['raw']['effects.reverb'],state['fx']['reverb'])

if __name__=='__main__':unittest.main()

class MigrationTests(unittest.TestCase):
    def test_migration_copies_only_missing_standard_user_data(self):
        from synthrig.upgrade0111 import migrate_0110
        with TemporaryDirectory() as d:
            parent=Path(d);old=parent/'SynthRig_0110';new=parent/'SynthRig_0111'
            (old/'presets'/'user').mkdir(parents=True)
            (old/'state').mkdir(parents=True)
            (old/'state'/'last_session.json').write_text('{"a":1}')
            (old/'presets'/'user'/'favorite.json').write_text('old')
            actions=migrate_0110(new,old,new/'state'/'last_session.json',new/'presets'/'user')
            self.assertEqual(len(actions),2)
            (new/'presets'/'user'/'favorite.json').write_text('new')
            self.assertEqual(migrate_0110(new,old,new/'state'/'last_session.json',new/'presets'/'user'),[])
            self.assertEqual((new/'presets'/'user'/'favorite.json').read_text(),'new')
