"""SynthRig 0.9.3: sessieherstel, soft takeover, Swing pitchbend/modulation."""
import sys
import json
import tempfile
from pathlib import Path
import unittest
import mido
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from test_09 import FakeSlot
from synthrig.engine09 import SynthRig
from synthrig.fixed_controls import FixedControls
from synthrig.session_state import default_state,apply_state,save_state,load_state,capture_state


class SessionTests(unittest.TestCase):
    def setUp(self):
        self.rig=SynthRig(FakeSlot())
        self.controls=FixedControls()
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path=Path(self.temp.name)/'state'/'last_session.json'

    def test_defaults_cover_every_mapped_control(self):
        defaults=default_state(self.controls)
        targets={spec['target'] for spec in self.controls.mappings.values()}
        self.assertEqual(set(defaults['raw']),targets)
        apply_state(self.rig,self.controls,defaults)
        self.assertEqual(self.controls.target_raw['master.level'],110)
        self.assertEqual(self.rig.slot.vol,round(256*110/127))

    def test_persist_restore_wave_mutes_and_raw(self):
        apply_state(self.rig,self.controls,default_state(self.controls))
        cc,_=self.controls.resolve(53,77)
        self.rig.set_parameter(cc,77)
        cc,_=self.controls.resolve(62,127)
        self.rig.set_parameter(cc,127)
        self.controls.on_note(1,self.rig)  # SIN OSC1
        self.controls.on_note(9,self.rig)  # SUB OFF
        save_state(self.path,self.rig,self.controls)
        self.assertTrue(self.path.is_file())
        new_controls=FixedControls()
        loaded=load_state(self.path,new_controls)
        new_rig=SynthRig(FakeSlot())
        apply_state(new_rig,new_controls,loaded,pickup=True)
        self.assertEqual(new_rig.osc1_level,77/127)
        self.assertEqual(new_rig.slot.vol,256)
        self.assertEqual(new_rig.wave_selection[1],0)
        self.assertFalse(new_rig.source_enabled['sub'])
        self.assertIn(53,new_controls.pickup)
        self.assertEqual(new_controls.target_raw['osc1.level'],77)
        self.assertFalse(self.path.with_name('.last_session.json.tmp').exists())

    def test_pickup_does_not_erase_saved_value(self):
        apply_state(self.rig,self.controls,default_state(self.controls),pickup=True)
        original=self.rig.osc1_level
        for raw in (10,20,40):
            target,desc=self.controls.resolve(53,raw)
            self.assertIsNone(target)
            self.assertTrue(desc.startswith('pickup'))
        self.assertEqual(self.controls.target_raw['osc1.level'],102)
        self.assertEqual(self.rig.osc1_level,original)
        target,_=self.controls.resolve(53,110)
        self.assertEqual(target,'osc1.level')
        self.assertEqual(self.controls.target_raw['osc1.level'],110)
        self.assertNotIn(53,self.controls.pickup)

    def test_broken_state_is_ignored(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        self.path.write_text('{"broken":',encoding='utf8')
        self.assertIsNone(load_state(self.path,self.controls))
        self.path.write_text(json.dumps({**default_state(self.controls),
                                          'layout_targets':{'16':'wrong'}}),encoding='utf8')
        self.assertIsNone(load_state(self.path,self.controls))

    def test_buttons_still_work_with_pickup(self):
        apply_state(self.rig,self.controls,default_state(self.controls),pickup=True)
        self.controls.on_note(1,self.rig)
        self.controls.on_note(6,self.rig)
        self.assertEqual(self.rig.wave_selection[1],0)
        self.assertFalse(self.rig.source_enabled['osc2'])


class SwingTests(unittest.TestCase):
    def setUp(self):
        self.slot=FakeSlot()
        self.rig=SynthRig(self.slot)

    def actual_pitch(self,voice,osc):
        # 0.9.12: SET_PITCH initieert alleen de basis; 05/06 zijn relatieve bends.
        from sunvox.api import NOTECMD
        mod = voice.o1 if osc==1 else (voice.o2 if osc==2 else voice.sub_router)
        pitches=[e[5] for e in self.slot.events
                 if e[1]==NOTECMD.SET_PITCH and e[3]==mod+1]
        if not pitches: return None
        base = (self.rig._native_pitch(voice.note)-pitches[-1])/256
        bends = [e for e in self.slot.events if e[1]==0 and e[3]==mod+1
                 and e[4] in (5,6)]
        return base + ((1 if bends[-1][4]==5 else -1)*bends[-1][5]/256 if bends else 0)

    def test_pitchbend_both_oscillators_and_sub(self):
        self.rig.note_on(60,110)
        voice=self.rig.voices[0]
        baseline=[self.actual_pitch(voice,j) for j in (1,2,3)]
        self.assertEqual(baseline,[-12,0,-24])
        self.assertIn((voice.sub_router,voice.sub),self.slot.links)
        self.rig.handle_swing(mido.Message('pitchwheel',pitch=8191))
        pitched=[self.actual_pitch(voice,j) for j in (1,2,3)]
        for orig,new in zip(baseline,pitched):
            self.assertAlmostEqual(new-orig,2.0,places=2)
        self.rig.handle_swing(mido.Message('pitchwheel',pitch=-8192))
        low=[self.actual_pitch(voice,j) for j in (1,2,3)]
        for orig,new in zip(baseline,low):
            self.assertAlmostEqual(new-orig,-2.0,places=2)
        self.rig.handle_swing(mido.Message('pitchwheel',pitch=0))
        self.assertEqual([self.actual_pitch(voice,j) for j in (1,2,3)],baseline)
        self.assertIn(60,self.rig.active_notes)

    def test_modulation_cc1_independent_of_midimix_lfo_pitch_knob(self):
        self.rig.note_on(60,100)
        self.rig.handle_swing(mido.Message('control_change',control=1,value=127))
        self.assertEqual(self.rig.mod_wheel,1.0)
        self.assertEqual(self.rig.lfo_pitch,0)
        self.rig.tick(now=self.rig._last_tick+.05,force=True) # mod phase quarter cycle
        voice=self.rig.voices[0]
        # In 0.9.6 gebruikt CC1 het native audio Vibrato-effect; de
        # Generator ontvangt dus geen 80Hz SET_PITCH-events meer.
        self.assertAlmostEqual(self.actual_pitch(voice,1),-12,delta=.01)
        self.assertAlmostEqual(self.actual_pitch(voice,3),-24,delta=.01)
        mod=self.rig.vib_mod
        ctl=self.rig.vib_ctl['mod_amplitude'][0]
        self.assertGreater(self.slot.get_module_ctl_value(mod,ctl,0),0)
        self.rig.handle_swing(mido.Message('control_change',control=1,value=0))
        self.assertEqual(self.rig.mod_wheel,0)
        # 0.9.13: CC1 heeft een bewust langere anti-click smoothing
        # (~160ms), dus de controller wordt pas later exact nul.
        for _ in range(45):self.rig.tick(now=self.rig._last_tick+.025,force=True)
        self.assertEqual(self.slot.get_module_ctl_value(mod,ctl,0),0)
        self.assertAlmostEqual(self.actual_pitch(voice,1),-12,delta=.01)
        self.assertAlmostEqual(self.actual_pitch(voice,3),-24,delta=.01)

    def test_other_swing_cc_ignored_and_notes_work(self):
        self.rig.handle_swing(mido.Message('control_change',control=74,value=100))
        self.assertEqual(self.rig.mod_wheel,0)
        self.rig.handle_swing(mido.Message('note_on',note=60,velocity=100))
        self.assertIn(60,self.rig.active_notes)
        self.rig.handle_swing(mido.Message('note_off',note=60,velocity=0))
        self.assertNotIn(60,self.rig.active_notes)

if __name__=='__main__':unittest.main()
