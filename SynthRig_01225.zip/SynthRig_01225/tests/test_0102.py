"""0.10.2: pitch-effect tracks cannot share track 0 with timeline activity."""
import unittest
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from synthrig.tracks098 import voice_track
from synthrig.engine09 import SynthRig
from test_09 import FakeSlot

class RecycledPitchTracks(unittest.TestCase):
    def test_pitch_roles_never_use_track_zero(self):
        self.assertEqual(voice_track(0,'amp_gate'),0)
        self.assertEqual({voice_track(i,r) for i in range(4) for r in ('osc1','osc2','sub_noise')},set(range(4,16)))

    def test_initial_tuning_is_in_set_pitch_not_late_bend(self):
        slot=FakeSlot();rig=SynthRig(slot,offline=True)
        rig.set_parameter('osc1.semitones',56)
        rig.set_parameter('osc1.finetune',55)
        rig.note_on(60,100)
        voice=rig.voices[rig.active_notes[60]]
        self.assertEqual(voice.last_pitch[1],voice.pitch_base[1])
        self.assertEqual(voice.pitch_base[1],round((-3.14)*256))
        from sunvox.api import NOTECMD
        initial=[e for e in slot.events if e[0]==voice_track(0,'osc1') and e[1]==NOTECMD.SET_PITCH]
        self.assertTrue(initial)

if __name__=='__main__': unittest.main()
