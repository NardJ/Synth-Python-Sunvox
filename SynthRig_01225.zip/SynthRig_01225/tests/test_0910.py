"""0.9.10→0.9.11: golfinitialisatie, vertraagde events, toonhoogte per golf, wavecheck."""
from __future__ import annotations
import sys
import unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from test_09 import FakeSlot
from sunvox.api import NOTECMD
from synthrig.engine09 import SynthRig, DEFAULT_WAVE_PITCH_OFFSETS, midi_frequency
from synthrig.quality099 import wavecheck

class DelayedSlot(FakeSlot):
    drop_wave_writes=0
    def set_module_ctl_value(self,module,ctl,value,scaled):
        if self.types[module]=='Generator' and self.get_module_ctl_name(module,ctl)==b'Waveform' and self.drop_wave_writes>0:
            self.drop_wave_writes-=1
            self.set_calls.append((module,ctl,value))
            return 0
        return super().set_module_ctl_value(module,ctl,value,scaled)

class RecorderStub:
    active=True
    def __init__(self):self.events=[]
    def log(self,event,data):self.events.append((event,data))

class Test0910(unittest.TestCase):
    def test_startup_per_voice_waveforms_confirmed(self):
        r=SynthRig(FakeSlot())
        self.assertEqual(r.waveform_mismatches(),[])
        self.assertEqual(len(r.waveform_readback()),4)
        self.assertTrue(all(v['osc1_actual']==1 and v['osc2_actual']==2 for v in r.waveform_readback()))

    def test_retries_dropped_waveform_writes_within_timeout(self):
        slot=DelayedSlot();r=SynthRig(slot)
        slot.drop_wave_writes=4
        r.set_waveform_index(1,0)
        # A dropped write should eventually be resent, not declared success.
        self.assertTrue(r.ensure_waveforms(timeout=.4))
        self.assertFalse(r.waveform_mismatches())
        self.assertTrue(all(v['osc1_actual']==5 for v in r.waveform_readback()))

    def test_strict_failed_readback_raises_clear_error(self):
        slot=DelayedSlot();r=SynthRig(slot)
        slot.drop_wave_writes=10000
        r.set_waveform_index(1,0)
        with self.assertRaisesRegex(RuntimeError,'kon niet worden bevestigd'):
            r.ensure_waveforms(timeout=.07,strict=True,retry_interval=.01)

    def test_wave_change_back_to_original_reapplies_dropped_value(self):
        slot=DelayedSlot();r=SynthRig(slot)
        slot.drop_wave_writes=8
        r.set_waveform_index(1,0)  # dropped for all voices
        self.assertTrue(r.waveform_mismatches())
        slot.drop_wave_writes=0
        r.set_waveform_index(1,0)  # same index must still send
        self.assertEqual(r.waveform_mismatches(),[])

    def test_per_waveform_pitch_and_bend_preserve_relative_interval(self):
        slot=FakeSlot();r=SynthRig(slot)
        r.set_waveform_index(1,0)   # SIN
        r.set_waveform_index(2,2)   # SAW
        r.note_on(60,100)
        v=r.voices[0]
        pitches=[e for e in slot.events if e[1]==NOTECMD.SET_PITCH]
        self.assertEqual(pitches[0][5],r._native_pitch(60))
        self.assertEqual(pitches[1][5],r._native_pitch(48))
        # Omschakelen met aangehouden noot moet retunen, niet alleen GUI-state.
        slot.events.clear()
        r.set_waveform_index(2,0)
        new=[e for e in slot.events if e[1]==NOTECMD.SET_PITCH and e[3]==v.o2+1]
        self.assertTrue(new)
        self.assertEqual(new[-1][5],r._native_pitch(60))
        # A4 = 440Hz blijft het referentiepunt; SunVox-uitvoer nog real-world te meten.
        self.assertAlmostEqual(midi_frequency(69),440.)

    def test_wavecheck_analysis_marks_incorrect_octave_as_failure(self):
        import io,json,tempfile,wave,math,zipfile
        from array import array
        from analyse_quality099 import analyze
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'calibration.zip'
            sr=44100
            audio=array('h', [round(13000*math.sin(2*math.pi*130.8128*n/sr))
                               for n in range(2*sr)])
            # Archive mono WAV; analyzer checks both mono and stereo.
            bio=io.BytesIO()
            with wave.open(bio,'wb') as w:
                w.setnchannels(1);w.setsampwidth(2);w.setframerate(sr)
                w.writeframes(audio.tobytes())
            e={'t':.1,'event':'quality_step','data':{
                'label':'wave_osc1_tri','kind':'wave_calibration','duration':1.4,
                'expected_hz':261.625565,'waveform_expected':0,'waveform_readback':0}}
            with zipfile.ZipFile(path,'w') as z:
                z.writestr('wave.wav',bio.getvalue());z.writestr('log.jsonl',json.dumps(e)+'\n')
            report=analyze(path,save=False)
            self.assertTrue(any(c['status']=='FAIL' and 'frequency' in c['check'] for c in report['checks']))

    def test_offset_configuration_and_validation(self):
        self.assertEqual(DEFAULT_WAVE_PITCH_OFFSETS['SAW'],0.)
        r=SynthRig(FakeSlot(),wave_pitch_offsets={'TRI':4.0})
        self.assertEqual(r.wave_pitch_offsets['TRI'],4.0)
        with self.assertRaises(ValueError):SynthRig(FakeSlot(),wave_pitch_offsets={'UNKNOWN':12})

    def test_wavecheck_logs_eight_phases_and_pitch_offset(self):
        r=SynthRig(FakeSlot()); recorder=RecorderStub()
        with patch('synthrig.quality099.wait',return_value=None):
            wavecheck(r,recorder)
        steps=[data for kind,data in recorder.events if kind=='quality_step']
        self.assertEqual(len(steps),8)
        self.assertEqual({(d['osc'],d['waveform_expected']) for d in steps},
                         {(osc,wave) for osc in (1,2) for wave in (5,0,1,2)})
        self.assertTrue(all(d['waveform_readback']==d['waveform_expected'] for d in steps))
        self.assertEqual({d['pitch_extra_semis'] for d in steps if d['waveform_expected']==1},{0.0})
        self.assertEqual(r.active_notes,{})

if __name__=='__main__':unittest.main()
