"""0.9.8: enforce the 16-track boundary and note-off module routing.
These tests do NOT substitute for actual audio validation on SunVox.
"""
from pathlib import Path
import sys, unittest
from unittest.mock import patch
import itertools
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from test_09 import FakeSlot
from synthrig.engine09 import SynthRig
from synthrig.tracks098 import voice_track, send_checked, MAX_EVENT_TRACKS
from sunvox.api import NOTECMD

class StrictFakeSlot(FakeSlot):
    def send_event(self,*args):
        if not (isinstance(args[0],int) and 0 <= args[0]<MAX_EVENT_TRACKS):
            raise AssertionError(f"Invalid SunVox track: {args[0]}")
        return super().send_event(*args)

class Track098(unittest.TestCase):
    def test_track_matrix_complete_and_unique(self):
        by_voice=[[voice_track(i,role) for role in ("osc1","osc2","sub_noise","amp_gate")]
                  for i in range(4)]
        self.assertEqual(sorted(sum(by_voice,[])),list(range(16)))
        for wrong in (-1,16,40,41):
            with self.assertRaises(ValueError):send_checked(StrictFakeSlot(),wrong,61)

    def test_polyphony_note_on_pitch_note_off_all_within_bounds(self):
        slot=StrictFakeSlot();rig=SynthRig(slot)
        for note in (48,52,55,60):rig.note_on(note,100)
        notes=[e for e in slot.events if 1<=e[1]<=127]
        self.assertEqual(len(notes),16)
        for i,voice in enumerate(rig.voices):
            self.assertIn((voice.sub_router,voice.noise),slot.links)
            self.assertEqual({e[0] for e in notes if e[3] in
                (voice.r1+1,voice.r2+1,voice.sub_router+1,voice.adsr+1)},
                {voice_track(i,k) for k in ("osc1","osc2","sub_noise","amp_gate")})
        rig.handle_swing(type('Msg',(),{'type':'pitchwheel','pitch':4096})())
        for note in (48,52,55,60):rig.note_off(note)
        last_events=slot.events[-4:]
        self.assertEqual({e[0] for e in last_events},{voice_track(i,"amp_gate") for i in range(4)})
        for event in last_events:
            self.assertEqual(event[1],NOTECMD.NOTE_OFF)
            self.assertNotEqual(event[3],0) # explicitly addressed to ADSR, not last pitch event
        for v in rig.voices:rig._stop_voice(v)
        self.assertTrue(all(0 <= e[0] < 16 for e in slot.events))

    def test_waveform_retrigger_stops_explicit_note_router(self):
        slot=StrictFakeSlot();rig=SynthRig(slot)
        rig.note_on(60,90)
        v=rig.voices[0]
        before=len(slot.events)
        rig.set_waveform_index(1,0)
        new_events=slot.events[before:]
        self.assertTrue(any(e[0]==voice_track(0,"osc1") and e[1]==NOTECMD.NOTE_OFF
                            and e[3]==v.r1+1 for e in new_events))

    def test_tonecheck_isolated_valid_tracks(self):
        from synthrig.calibration098 import tonecheck
        slot=StrictFakeSlot();rig=SynthRig(slot)
        ticks=itertools.count()
        with patch('synthrig.calibration098.time.monotonic',side_effect=lambda:next(ticks)*.83),\
             patch('synthrig.calibration098.time.sleep',return_value=None):
            tonecheck(slot,rig)
        self.assertTrue(any(e[1]==NOTECMD.SET_PITCH for e in slot.events))
        self.assertTrue(all(0<=e[0]<16 for e in slot.events))
        self.assertTrue(any(e[0]==0 and e[1]==61 for e in slot.events))
        self.assertTrue(any(e[0]==1 and e[1]==61 for e in slot.events))

if __name__=='__main__': unittest.main()
