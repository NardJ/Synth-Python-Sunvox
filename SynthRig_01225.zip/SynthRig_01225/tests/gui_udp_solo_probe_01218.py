"""Xvfb smoke: ONE SOLO short press -> PANIC -> MIDI -> UDP -> Tk numbered LEDs."""
import socket
import tkinter as tk
from pathlib import Path
from types import SimpleNamespace
from tempfile import TemporaryDirectory
from PIL import ImageGrab
from mido import Message
from midimix_debug import MidiMixMonitor, MUTE_NOTES, REC_NOTES, AMBER, RED
from synthrig.debug import OptionalMidiMixDebug
from synthrig.midimix_hw import MidiMixLEDs
from synthrig.solo_actions import panic_and_show_active_preset
from synthrig.preset_buttons import SoloSaveButton
from synthrig.fixed_controls import FixedControls
from synthrig.presets import PresetManager
from synthrig.engine09 import SynthRig
from synthrig.session_state import apply_state, default_state
from test_synthrig import FakeSlot

class Output:
    def __init__(self):self.sent=[]
    def send(self,msg):self.sent.append(msg)

class Wire:
    send_preset=OptionalMidiMixDebug.send_preset
    send=OptionalMidiMixDebug.send
    send_state=OptionalMidiMixDebug.send_state
    send_values=OptionalMidiMixDebug.send_values
    send_midimix_leds=OptionalMidiMixDebug.send_midimix_leds
    def __init__(self,target):
        self.process=SimpleNamespace(poll=lambda:None)
        self.sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        self.target=target

root=tk.Tk()
probe=socket.socket();probe.bind(('127.0.0.1',0));port=probe.getsockname()[1];probe.close()
monitor=MidiMixMonitor(root,port)
root.update()
assert all(monitor.apc_monitor.canvas.type(i)=='rectangle' for i in monitor.apc_monitor.scene_shapes)
wire=Wire(('127.0.0.1',port))
c=FixedControls(); gesture=SoloSaveButton()
with TemporaryDirectory() as d:
    rig=SynthRig(FakeSlot(),offline=True)
    apply_state(rig,c,default_state(c))
    pm=PresetManager(c,d)
    out=Output(); leds=MidiMixLEDs(out,c)
    for n in range(1,17):
        pm.selected=n-1
        rig.note_on(60,90)
        assert gesture.feed(Message('note_on',channel=0,note=27,velocity=127),100.0) is None
        assert gesture.feed(Message('note_off',channel=0,note=27,velocity=0),100.15)=='panic'
        before=len(out.sent)
        panic_and_show_active_preset(rig,None,pm,leds,wire)
        # Match the rest of the live MIDI loop AFTER gesture processing:
        # the Note Off event and persistent button-state update must NOT
        # overwrite the one-second numeric LED overlay.
        wire.send(Message('note_off',channel=0,note=27,velocity=0), 'PANIC')
        wire.send_state(c.button_state(rig))
        leds.sync(c.button_state(rig),force=True)
        assert not rig.active_notes and len(out.sent)==before+16
        monitor.poll();root.update()
        assert monitor.led_overlay and monitor.led_preset==n
        assert sum(monitor.midimix_leds.get(k,False) for k in MUTE_NOTES+REC_NOTES)==n
        for i in range(16):
            key=('mute' if i<8 else 'rec')+f'_{i%8}'
            item,_=monitor.button_parts[key]
            assert monitor.canvas.itemcget(monitor.preset_number_parts[key],'text')==str(i+1)
            assert (monitor.canvas.itemcget(item,'fill')==(AMBER if i<8 else RED))==(i<n)
        if n==11:
            root.update()
            path=Path('reports_01220/solo_preset11.png')
            path.parent.mkdir(parents=True,exist_ok=True)
            x,y=monitor.root.winfo_rootx(),monitor.root.winfo_rooty()
            w,h=monitor.canvas.winfo_width(),monitor.canvas.winfo_height()
            ImageGrab.grab(bbox=(x,y,x+w,y+h)).save(path)
            print('SCREENSHOT',path)
    leds.preset_until=0
    leds.tick(c.button_state(rig))
    wire.send_midimix_leds(leds.display_snapshot())
    monitor.poll();root.update()
    assert not monitor.led_overlay
    assert all(not monitor.canvas.itemcget(t,'text') for t in monitor.preset_number_parts.values())
print('PASS: 16 SOLO short presses, PANIC, real MIDI-count, UDP, Tk mirror, scene rectangles, restore')
wire.sock.close();monitor.close()
