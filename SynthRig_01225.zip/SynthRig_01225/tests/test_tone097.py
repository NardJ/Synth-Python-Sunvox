import math,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from analyse_tonecheck import spectrum

class ToneFFT(unittest.TestCase):
    def test_sine_and_saw(self):
        rate=8192; n=rate*2; freq=256
        sine=[int(8000*math.sin(2*math.pi*freq*t/rate)) for t in range(n)]
        saw=[int(6000*(2*(freq*t/rate%1)-1)) for t in range(n)]
        a=spectrum(sine,rate,.1);b=spectrum(saw,rate,.1)
        # Spectrum requires >=32768 samples; current fixtures below length.
        self.assertIsNone(a);self.assertIsNone(b)
    def test_fft_with_correct_length(self):
        rate=44100;f=263;N=rate*2
        mono=[int(7500*math.sin(2*math.pi*f*i/rate)) for i in range(N)]
        result=spectrum(mono,rate,.3)
        self.assertAlmostEqual(result['dominant_hz'],f,delta=2.0)
        self.assertLess(result['harmonic_2_db'],-25)

if __name__=='__main__':unittest.main()

class ToneIsolation(unittest.TestCase):
    def test_direct_generator_calibration_uses_real_readback_and_note_events(self):
        from unittest.mock import patch
        import itertools
        from test_09 import FakeSlot
        from synthrig.engine09 import SynthRig
        from synthrig.calibration098 import tonecheck
        from sunvox.api import NOTECMD
        class Rec:
            active=True
            def __init__(self):self.events=[]
            def log(self,name,data):self.events.append((name,data))
        slot=FakeSlot();rig=SynthRig(slot)
        recorder=Rec()
        # Time runs virtually: exercise routing/event API without audio hardware.
        ticks=itertools.count()
        with patch('synthrig.calibration098.time.monotonic',side_effect=lambda:next(ticks)*.83), \
             patch('synthrig.calibration098.time.sleep',return_value=None):
            tonecheck(slot,rig,recorder)
        phases=[d for event,d in recorder.events if event=='tonecheck_step']
        self.assertEqual(len(phases),5)
        self.assertEqual([d['waveform_readback'] for d in phases],[5,5,5,1,5])
        self.assertEqual([d['effect_chain'] for d in phases],[False,False,False,False,True])
        self.assertGreaterEqual(len([e for e in slot.events if e[1]==NOTECMD.SET_PITCH]),4)
        generators=[m for m,name in slot.types.items() if name=='Generator']
        self.assertGreaterEqual(len(generators),14)
