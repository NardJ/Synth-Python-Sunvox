"""Xvfb: no selected preset => PANIC but NO physical or GUI LED changes."""
import socket
import tkinter as tk
from tempfile import TemporaryDirectory
from types import SimpleNamespace
from mido import Message
from midimix_debug import MidiMixMonitor, MUTE_NOTES, REC_NOTES
from synthrig.debug import OptionalMidiMixDebug
from synthrig.midimix_hw import MidiMixLEDs, sync_leds_for_button
from synthrig.solo_actions import panic_and_show_active_preset
from synthrig.preset_buttons import SoloSaveButton
from synthrig.fixed_controls import FixedControls
from synthrig.presets import PresetManager
from synthrig.engine09 import SynthRig
from synthrig.session_state import apply_state, default_state
from test_synthrig import FakeSlot

class Output:
    def __init__(self):self.sent=[]
    def send(self,msg):self.sent.append(msg)

class Wire:
    send_preset=OptionalMidiMixDebug.send_preset
    send=OptionalMidiMixDebug.send
    send_state=OptionalMidiMixDebug.send_state
    send_midimix_leds=OptionalMidiMixDebug.send_midimix_leds
    def __init__(self,target):
        self.process=SimpleNamespace(poll=lambda:None)
        self.sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        self.target=target

root=tk.Tk()
probe=socket.socket();probe.bind(('127.0.0.1',0));port=probe.getsockname()[1];probe.close()
window=MidiMixMonitor(root,port)
wire=Wire(('127.0.0.1',port))
root.update()
with TemporaryDirectory() as temp:
    c=FixedControls();rig=SynthRig(FakeSlot(),offline=True)
    apply_state(rig,c,default_state(c))
    pm=PresetManager(c,temp)
    assert pm.selected==-1
    out=Output();leds=MidiMixLEDs(out,c)
    leds.sync(c.button_state(rig),force=True)
    wire.send_midimix_leds(leds.display_snapshot())
    wire.send_state(c.button_state(rig))
    window.poll();root.update()
    initial_led=leds.display_snapshot()
    initial_gui_led=dict(window.midimix_leds)
    def button_visual():
        result={}
        for key in [f'mute_{i}' for i in range(8)]+[f'rec_{i}' for i in range(8)]:
            item,_=window.button_parts[key]
            result[key]=window.canvas.itemcget(item,'fill')
        return result
    initial_visual=button_visual()
    gesture=SoloSaveButton()
    for i in range(5):
        rig.note_on(60+i,80)
        before=len(out.sent)
        down=Message('note_on',channel=0,note=27,velocity=127)
        up=Message('note_off',channel=0,note=27,velocity=0)
        assert gesture.feed(down,100+i*10) is None
        assert sync_leds_for_button(leds,c.button_state(rig),down,c.panic_note) is False
        assert gesture.feed(up,100+i*10+.1)=='panic'
        panic_and_show_active_preset(rig,None,pm,leds,wire)
        assert sync_leds_for_button(leds,c.button_state(rig),up,c.panic_note) is False
        wire.send(up,'PANIC')
        wire.send_state(c.button_state(rig))
        leds.tick(c.button_state(rig))
        window.poll();root.update()
        assert not rig.active_notes
        assert len(out.sent)==before, 'SOLO created physical MIDI LED messages'
        assert leds.display_snapshot()==initial_led
        assert window.midimix_leds==initial_gui_led
        assert button_visual()==initial_visual
        assert not window.led_overlay
    print('PASS: 5 unselected SOLO PANIC cycles: zero LED changes physically and in Tk GUI')
wire.sock.close();window.close()
