"""0.9.5: guard against double pitch control and silent recordings."""
import importlib.util
from pathlib import Path
import sys,unittest
import mido
from sunvox.api import NOTECMD
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from test_09 import FakeSlot
from synthrig.engine09 import SynthRig, midi_frequency, sunvox_pitch_from_hz

class Pitch095(unittest.TestCase):
    def setUp(self):
        self.s=FakeSlot();self.r=SynthRig(self.s)
        self.r.note_on(60,100);self.v=self.r.voices[0]

    def sp(self):
        return [ev for ev in self.s.events if ev[1]==NOTECMD.SET_PITCH]

    def bends(self):
        return [ev for ev in self.s.events if ev[1]==0 and ev[4] in (5,6)]

    def test_initial_pitch_is_absolute_and_sub_one_octave_lower(self):
        self.assertEqual(len(self.sp()),3)
        self.assertEqual([e[3] for e in self.sp()],
                         [self.v.o1+1,self.v.o2+1,self.v.sub_router+1])
        self.assertEqual([e[5] for e in self.sp()],
                         [self.r._native_pitch(48),self.r._native_pitch(60),self.r._native_pitch(36)])
        self.assertTrue(all(e[2]==129 for e in self.sp()))

    def test_all_multisynth_controls_are_static_during_bend(self):
        def vals():
            return [self.s.get_module_ctl_value(mod,self.v.ctls[name][0],0)
                for mod,name in ((self.v.r1,'transpose1'),(self.v.r1,'fine1'),
                                 (self.v.r2,'transpose2'),(self.v.r2,'fine2'),
                                 (self.v.sub_router,'sub_transpose'),
                                 (self.v.sub_router,'sub_fine'))]
        baseline=vals()
        self.s.events.clear()
        self.r.handle_swing(mido.Message('pitchwheel',pitch=8191))
        self.assertEqual(vals(),baseline)
        self.assertEqual(len(self.bends()),3)
        self.assertEqual([(ev[4],ev[5]) for ev in self.bends()],[(5,512)]*3)
        self.assertEqual(len([ev for ev in self.s.events if 1<=ev[1]<=127]),0)
        self.s.events.clear()
        self.r.handle_swing(mido.Message('pitchwheel',pitch=0))
        self.assertEqual(vals(),baseline)
        self.assertEqual([(ev[4],ev[5]) for ev in self.bends()],[(5,0)]*3)

    def test_retune_changes_no_note_on_and_preserves_voice(self):
        self.s.events.clear()
        self.r.set_parameter('osc1.semitones',127)
        self.assertEqual(len(self.bends()),1)
        self.assertEqual((self.bends()[0][4],self.bends()[0][5]),(5,6144))
        self.assertEqual(self.r.active_notes[60],0)
        self.assertFalse([e for e in self.s.events if 1<=e[1]<=127])

    def test_waveform_change_retunes_newly_triggered_note(self):
        self.r.handle_swing(mido.Message('pitchwheel',pitch=8191))
        self.s.events.clear()
        self.r.set_waveform_index(1,0)
        sp=[e for e in self.sp() if e[3]==self.v.o1+1]
        self.assertEqual(len(sp),1)
        self.assertEqual(sp[0][5],self.r._native_pitch(60))
        bend=[ev for ev in self.bends() if ev[3]==self.v.o1+1]
        self.assertEqual((bend[-1][4],bend[-1][5]),(5,512))

    def test_no_pitch_events_when_no_note_held(self):
        self.r.all_notes_off()
        self.s.events.clear()
        self.r.handle_swing(mido.Message('pitchwheel',pitch=8191))
        self.assertEqual(self.sp(),[])

    def test_audio_silence_detection(self):
        path=Path(__file__).resolve().parents[1]/'synthrig_0125.py'
        spec=importlib.util.spec_from_file_location('check095',path)
        mod=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        silent={'recorded_audio_seconds':7,'capture_error':None,
                'rms_by_second':{str(i):{'rms_dbfs_approx':None} for i in range(7)}}
        self.assertFalse(mod.check_pitch_recording(silent)[0])
        loud={**silent,'rms_by_second':{'1':{'rms_dbfs_approx':-26.0}}}
        self.assertTrue(mod.check_pitch_recording(loud)[0])
        too_quiet={**silent,'rms_by_second':{'1':{'rms_dbfs_approx':-75.0}}}
        self.assertFalse(mod.check_pitch_recording(too_quiet)[0])

if __name__=='__main__':unittest.main()
