import unittest
import tempfile
from pathlib import Path
import mido
from synthrig.mod_matrix import ModMatrix,validate_matrix,blank_matrix,signed_depth,DEFAULT_DEPTH
from synthrig.apc_mk2 import APCminiMk2
from synthrig.session_state import default_state,load_state,capture_state,apply_state,save_state
from synthrig.fixed_controls import FixedControls
from synthrig.presets import validate_preset

class FakeRig:
    def __init__(self):self.mod_matrix=ModMatrix();self.calls=[]
    def note_on(self,*a):pass
    def note_off(self,*a):pass
    def all_notes_off(self):pass
    def tick(self,**kw):pass

class MatrixTests(unittest.TestCase):
    def test_strict_shape(self):
        for invalid in ([],{},[[None]],[[None]*8]*7,[[9]*8]*7+[['x']*8],[[None]*8]*7+[[512]*8]):
            with self.assertRaises(ValueError):validate_matrix(invalid)
    def test_source_and_destination_independent(self):
        m=ModMatrix();m.toggle(0,0);m.toggle(1,0);m.toggle(0,1)
        self.assertEqual(m.grid[0][0],DEFAULT_DEPTH)
        self.assertIsNotNone(m.grid[1][0]);self.assertIsNotNone(m.grid[0][1])
        m.toggle(0,0);self.assertIsNone(m.grid[0][0])
        self.assertTrue(m.has_routes())
    def test_real_bipolar_depth(self):
        m=ModMatrix();m.toggle(0,4)
        m.set_depth(0,4,0)
        self.assertAlmostEqual(m.offsets([1]+[0]*7)[4],-1)
        m.set_depth(0,4,127)
        self.assertAlmostEqual(m.offsets([1]+[0]*7)[4],1)
        self.assertEqual(signed_depth(64),0)
    def test_apc_pad_toggles_connection_and_scene_selects_fader_source(self):
        rig=FakeRig()
        with tempfile.TemporaryDirectory() as folder:
            a=APCminiMk2(None,rig,pattern_dir=folder,logger=lambda *_:None)
            press=lambda n:a.handle(mido.Message('note_on',note=n,velocity=127))
            press(4);press(12) # LFO -> cutoff; filter ENV -> cutoff
            self.assertEqual(rig.mod_matrix.grid[0][4],DEFAULT_DEPTH)
            self.assertEqual(rig.mod_matrix.grid[1][4],DEFAULT_DEPTH)
            self.assertEqual(a.selected_source,1)
            press(119) # bottom scene next to physical LFO row
            self.assertEqual(a.selected_source,0)
            self.assertEqual(a.bank,0) # pattern unaffected
    def test_relative_fader_changes_group_gain_without_overwriting_depth(self):
        rig=FakeRig()
        with tempfile.TemporaryDirectory() as folder:
            a=APCminiMk2(None,rig,pattern_dir=folder,logger=lambda *_:None)
            a.handle(mido.Message('note_on',note=4,velocity=127))
            a.handle(mido.Message('control_change',control=52,value=10),now=10.)
            self.assertEqual(rig.mod_matrix.grid[0][4],DEFAULT_DEPTH)
            a.handle(mido.Message('control_change',control=52,value=15),now=10.1)
            self.assertEqual(rig.mod_matrix.grid[0][4],DEFAULT_DEPTH)
            self.assertGreater(rig.mod_matrix.groups['gains'][4],1.)

    def test_preset_load_rearms_fader_previous(self):
        rig=FakeRig()
        with tempfile.TemporaryDirectory() as folder:
            a=APCminiMk2(None,rig,pattern_dir=folder,logger=lambda *_:None)
            a.handle(mido.Message('note_on',note=4,velocity=127))
            a.handle(mido.Message('control_change',control=52,value=86),now=4.)
            a.handle(mido.Message('control_change',control=52,value=91),now=4.1)
            replacement=blank_matrix();replacement[0][4]=30
            rig.mod_matrix.load(replacement)
            a.refresh()
            self.assertFalse(a.patch_pickup[4])
            a.handle(mido.Message('control_change',control=52,value=92),now=4.2)
            self.assertEqual(rig.mod_matrix.grid[0][4],30)

    def test_ninth_fader_does_not_change_tempo_in_patch(self):
        rig=FakeRig()
        with tempfile.TemporaryDirectory() as folder:
            a=APCminiMk2(None,rig,pattern_dir=folder,logger=lambda *_:None)
            a.handle(mido.Message('control_change',control=56,value=127))
            self.assertEqual(a.pattern.bpm,120.0)
            a.handle(mido.Message('note_on',note=101,velocity=127))
            a.handle(mido.Message('control_change',control=56,value=127))
            self.assertEqual(a.pattern.bpm,180.0)

    def test_preset_schema_preserves_matrix(self):
        c=FixedControls(); data=default_state(c)
        matrix=blank_matrix();matrix[0][4]=86;matrix[7][0]=127
        data['mod_matrix']=matrix
        checked=validate_preset(data,c)
        self.assertEqual(checked['mod_matrix'],matrix)
        old=default_state(c);old.pop('mod_matrix')
        self.assertEqual(validate_preset(old,c)['mod_matrix'],blank_matrix())
