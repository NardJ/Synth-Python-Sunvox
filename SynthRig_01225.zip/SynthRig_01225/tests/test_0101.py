"""0.10.1: regression tests for partially completed glides and audible chorus."""
import sys
from pathlib import Path
import unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from test_09 import FakeSlot
from synthrig.engine09 import SynthRig

class PortamentoRetrigger(unittest.TestCase):
    def setUp(self):
        self.rig=SynthRig(FakeSlot(),offline=True)
        self.rig.set_parameter('performance.portamento',127)

    def at(self,when,fn,*args):
        with patch('synthrig.engine09.time.monotonic',return_value=when):
            return fn(*args)

    def test_retrigger_same_pitch_keeps_current_glide_not_target(self):
        t=100.0
        self.at(t,self.rig.note_on,48,100)
        self.at(t+.4,self.rig.note_off,48)
        self.at(t+.5,self.rig.note_on,60,100)
        v=self.rig.voices[self.rig.active_notes[60]]
        self.assertAlmostEqual(v.glide_from,-12)
        self.rig.tick(now=t+.75,force=True)
        self.at(t+.75,self.rig.note_off,60)
        self.at(t+.8,self.rig.note_on,60,100)
        v2=self.rig.voices[self.rig.active_notes[60]]
        self.assertAlmostEqual(v2.glide_from,-9,places=2)
        self.assertAlmostEqual(v2.glide_seconds,.75,places=2)

    def test_repeat_during_note_on_first_voice_captures_pitch_before_reset(self):
        t=100.0
        self.at(t,self.rig.note_on,48,100)
        self.at(t+.2,self.rig.note_on,60,100)
        self.at(t+.45,self.rig.note_on,60,100)
        v=self.rig.voices[self.rig.active_notes[60]]
        self.assertAlmostEqual(v.glide_from,-9,places=2)

    def test_held_release_pitch_survives_voice_cleanup_for_short_pause(self):
        t=100.0
        self.at(t,self.rig.note_on,48,100)
        self.at(t+.2,self.rig.note_off,48)
        v=self.rig.voices[0]
        self.rig._stop_voice(v)
        self.at(t+.6,self.rig.note_on,60,100)
        self.assertAlmostEqual(self.rig.voices[self.rig.active_notes[60]].glide_from,-12)

    def test_history_expires_after_long_pause(self):
        t=100.0
        self.at(t,self.rig.note_on,48,100)
        self.at(t+.2,self.rig.note_off,48)
        self.at(t+2.0,self.rig.note_on,60,100)
        self.assertEqual(self.rig.voices[self.rig.active_notes[60]].glide_from,0)

    def test_chorus_reaches_new_wet_depth_without_affecting_old_knobs(self):
        self.rig.set_parameter('effects.chorus',127)
        for _ in range(130):
            self.rig.tick(now=self.rig._last_tick+.02,force=True)
        self.assertEqual(self.rig._last_chorus_wet,172)
        self.rig.all_notes_off()
        self.assertIsNone(self.rig._previous_voice)

if __name__=='__main__':
    unittest.main()
