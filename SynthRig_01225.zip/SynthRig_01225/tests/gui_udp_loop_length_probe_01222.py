"""Real Tk/UDP + MIDI gestures for loop length; simulated hardware/audio."""
import socket
import sys
import time
import tkinter as tk
from tempfile import TemporaryDirectory
from types import SimpleNamespace

from mido import Message
from midimix_debug import MidiMixMonitor, ASSIGNMENTS, read_assignments
from synthrig.debug import OptionalMidiMixDebug
from synthrig.apc_mk2 import APCminiMk2, DIM, GREEN
from synthrig.fixed_controls import FixedControls
from synthrig.session_state import default_state, apply_state
from test_synthrig import FakeSlot
from synthrig.engine09 import SynthRig


class Output:
    def __init__(self):self.sent = []
    def send(self, message):self.sent.append(message)


class Wire:
    send_sync = OptionalMidiMixDebug.send_sync
    send_apc_status = OptionalMidiMixDebug.send_apc_status
    send_values = OptionalMidiMixDebug.send_values

    def __init__(self, port):
        self.process = SimpleNamespace(poll=lambda: None)
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.target = ('127.0.0.1', port)


root = tk.Tk()
ASSIGNMENTS.update(read_assignments('config/midimix_091.json'))
window = MidiMixMonitor(root, 0)
wire = Wire(window.socket.getsockname()[1])
root.update()
try:
    with TemporaryDirectory() as temp:
        rig = SynthRig(FakeSlot(), offline=True)
        controls = FixedControls()
        apply_state(rig, controls, default_state(controls))
        output = Output()
        apc = APCminiMk2(output, rig, pattern_dir=temp, logger=lambda _: None)
        panel = window.apc_monitor
        now = time.monotonic()

        def press(note):
            return apc.handle(Message('note_on', note=note, velocity=127), now)

        def release_shift():
            apc.handle(Message('note_off', note=122), now)

        def show(at):
            apc.tick(at)
            snapshot = apc.display_snapshot()
            snapshot['sync'] = apc.swing_sync.snapshot(at)
            state = dict(snapshot['sync'])
            state.update(apc_clock=apc.clock, apc_connected=True,
                         apc_playing=apc.playing, apc_step=apc.step + 1,
                         apc_length=apc.pattern.length)
            wire.send_apc_status(snapshot)
            wire.send_sync(state)
            window.poll()
            root.update()

        press(101)  # SEQ
        press(0)  # step 1, bottom lane, MIDI 48
        press(4)  # step 5: kept but excluded when loop is 4
        wire.send_values({cc: controls.target_raw[spec['target']]
                          for cc, spec in controls.mappings.items()})
        press(122)
        press(112)  # SHIFT + top right scene = length 4
        show(now)
        assert panel.canvas.itemcget(panel.scene_title, 'text') == 'LENGTE'
        labels = [panel.canvas.itemcget(item, 'text') for item in panel.scene_number_texts]
        assert labels == ['4', '8', '16', '', '', '', '', '']
        assert 'LOOP 4 STAPPEN' in panel.canvas.itemcget(panel.mode_text, 'text')
        assert '/4' in panel.canvas.itemcget(panel.status_text, 'text')
        assert apc.last_color[4] == DIM
        assert panel.canvas.itemcget(panel.col_text[4][0], 'fill') == '#657380'
        sent = {(m.channel, m.note): m.velocity for m in output.sent if m.type == 'note_on'}
        assert sent[(0,112)] > 0 and sent[(0,113)] == 0 and sent[(0,114)] == 0
        print('PASS: physical SHIFT/scene gesture -> selected length LED -> UDP labels 4/8/16 and LOOP 4 header')

        count = len(panel.canvas.find_all())
        apc.set_playing(True, now)
        for step in range(12):
            show(now + step * .125)
            assert apc.step == step % 4
            assert f'stap {apc.step+1:02d}/4' in panel.canvas.itemcget(panel.status_text, 'text')
            assert '/4' in window.canvas.itemcget(window.sync_label, 'text')
        print('PASS: 3 internal-clock loops, both monitors show 1–4 and never 5–16')

        if '--capture' in sys.argv:
            from PIL import ImageGrab
            top = panel.window
            x, y = top.winfo_rootx(), top.winfo_rooty()
            ImageGrab.grab(bbox=(x,y,x+top.winfo_width(),y+top.winfo_height())).save('GUI_APC_LOOP4_01222.png')

        release_shift()
        show(now + 1.4)
        assert panel.canvas.itemcget(panel.scene_title, 'text') == 'PATROON'
        assert [panel.canvas.itemcget(item, 'text') for item in panel.scene_number_texts] == list('12345678')
        press(105)  # SAVE
        other = APCminiMk2(None, rig, pattern_dir=temp, logger=lambda _: None)
        assert other.pattern.length == 4 and other.pattern.steps[0][4]
        for note, length in ((113,8),(114,16)):
            press(122);press(note);release_shift()
            show(now + 1.4)
            assert apc.pattern.length == length
            assert f'LOOP {length} STAPPEN' in panel.canvas.itemcget(panel.mode_text, 'text')
            assert apc.last_color[4] == GREEN or apc.step == 4
        print('PASS: release restores pattern labels; SAVE/reload retains length and hidden step; 8/16 restore notes')

        now += 2
        apc.set_clock('swing', now)
        press(122);press(112);release_shift()
        apc.swing_clock(Message('start'), now)
        for tick in range(49):
            at = now + .01 + tick / 48
            apc.swing_clock(Message('clock'), at)
            show(at)
            assert apc.step == (tick // 6) % 4
            assert '/4' in window.canvas.itemcget(window.sync_label, 'text')
        assert len(panel.canvas.find_all()) == count
        print('PASS: SWING-clock loop wraps at 4 with six pulses per step and matching monitor denominator')

        for zoom in (.5, 1, .9):
            window.set_zoom(zoom)
            show(at)
            assert panel.canvas.bbox(panel.mode_hint)[2] < 620 * panel.canvas.ui_scale
        print('PASS: unchanged canvas item count and readable loop controls at 50/100/90 percent zoom')
finally:
    wire.sock.close()
    window.close()
