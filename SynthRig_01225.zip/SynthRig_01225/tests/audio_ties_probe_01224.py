"""Native SunVox PCM: ties remove gate gaps and reattacks, including loop wrap."""
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import numpy as np
import sunvox.dll as dll
from sunvox.api import Slot,init,deinit
from sunvox.types import INIT_FLAG
from synthrig.engine09 import SynthRig
from synthrig.apc_mk2 import APCminiMk2
from synthrig.offline0102 import OfflineAudio,RATE,rms,apply_baseline

checks=[]
for mode in ('native','events'):
    flags=int(INIT_FLAG.OFFLINE|INIT_FLAG.AUDIO_FLOAT32|INIT_FLAG.ONE_THREAD|INIT_FLAG.NO_DEBUG_OUTPUT)
    assert init(None,RATE,2,flags)>=0
    try:
        with Slot() as slot,TemporaryDirectory() as temp:
            rig=SynthRig(slot,offline=True,pitch_lfo_mode=mode)
            apply_baseline(rig)
            for key in ('chorus','delay','reverb'):rig.set_parameter('effects.'+key,0)
            assert slot.play()>=0
            with OfflineAudio(rig,dll) as driver:
                apc=APCminiMk2(None,rig,pattern_dir=temp,logger=lambda _:None)
                apc.pattern.notes[0]=60
                apc.pattern.length=4
                attacks=[]
                original=rig.note_on
                def record(note,velocity):
                    attacks.append(note)
                    return original(note,velocity)
                rig.note_on=record
                def render(seconds):
                    chunks=[]
                    end=driver.clock+seconds
                    while driver.clock<end-.001:
                        apc.tick(driver.clock)
                        chunks.append(driver.render(.005))
                    apc.tick(driver.clock)
                    return np.concatenate(chunks)[:,0]
                for bpm in (60,120,180):
                    for tied in (False,True):
                        apc.set_playing(False,driver.clock)
                        rig.all_notes_off();driver.render(.1)
                        apc.pattern.bpm=bpm
                        apc.pattern.steps[0]=[False]*16
                        apc.pattern.ties[0]=[False]*16
                        apc.pattern.steps[0][0:2]=[True,True]
                        apc.pattern.ties[0][1]=tied
                        attacks.clear()
                        apc.set_playing(True,driver.clock)
                        step=60/bpm/4
                        audio=render(step*2+.15)
                        steady=rms(audio[round(step*.20*RATE):round(step*.45*RATE)])
                        gap=rms(audio[round(step*.70*RATE):round(step*.90*RATE)])
                        tail=rms(audio[-round(.035*RATE):])
                        expected=1 if tied else 2
                        ok=(len(attacks)==expected and steady>1e-4 and tail<steady*.02
                            and (gap>steady*.4 if tied else gap<steady*.02))
                        entry={'mode':mode,'bpm':bpm,'tied':tied,'attacks':len(attacks),
                               'mid_step_rms':gap,'tail_rms':tail,'status':'PASS' if ok else 'FAIL'}
                        checks.append(entry);print(entry,flush=True)
                for length in (4,16):
                    apc.set_playing(False,driver.clock)
                    rig.all_notes_off();driver.render(.1)
                    apc.pattern.bpm=120
                    apc.pattern.length=length
                    apc.pattern.steps[0]=[True]*16
                    apc.pattern.ties[0]=[True]*16
                    attacks.clear()
                    apc.set_playing(True,driver.clock)
                    audio=render(length*.125*2+.02)
                    boundary=length*.125
                    seam=rms(audio[round((boundary-.02)*RATE):round((boundary+.02)*RATE)])
                    continuous=len(attacks)==1 and seam>1e-4 and bool(rig.active_notes)
                    apc.set_playing(False,driver.clock)
                    tail=render(.1)
                    ok=continuous and rms(tail[-round(.03*RATE):])<1e-6 and not rig.active_notes
                    entry={'mode':mode,'all_tied_loop_length':length,'attacks':len(attacks),
                           'loop_seam_rms':seam,'status':'PASS' if ok else 'FAIL'}
                    checks.append(entry);print(entry,flush=True)
                apc.close()
    finally:deinit()
report={'version':'0.12.24','PASS':sum(c['status']=='PASS' for c in checks),
        'FAIL':sum(c['status']=='FAIL' for c in checks),'checks':checks}
path=Path('reports_01224/audio_ties.json');path.parent.mkdir(exist_ok=True)
path.write_text(json.dumps(report,indent=2)+'\n')
print('TIE AUDIO SUMMARY',report['PASS'],report['FAIL'],flush=True)
if report['FAIL']:raise SystemExit(1)
