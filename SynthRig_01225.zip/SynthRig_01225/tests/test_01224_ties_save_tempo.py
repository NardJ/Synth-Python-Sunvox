"""Legato ties across step/loop boundaries, honest SAVE acknowledgement, tempo."""
import copy
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from mido import Message
from synthrig.apc_mk2 import APCminiMk2, Pattern, CYAN, GREEN
from test_0120 import FakeRig, FakeOut


class TiesSaveTempoTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.rig, self.out = FakeRig(), FakeOut()
        self.apc = APCminiMk2(self.out, self.rig, pattern_dir=self.temp.name, logger=lambda _: None)
        self.press(101)

    def press(self, note, now=0):
        return self.apc.handle(Message('note_on', note=note, velocity=127), now)

    def tied_pair(self):
        self.apc.pattern.steps[0][0:2] = [True, True]
        self.apc.pattern.ties[0][1] = True

    def calls(self, kind):
        return [c for c in self.rig.calls if c[0] == kind]

    def test_shift_second_pad_toggles_tie_without_toggling_either_note(self):
        self.apc.pattern.steps[0][0:2] = [True, True]
        before = copy.deepcopy(self.apc.pattern.steps)
        self.press(122);self.press(1)
        self.assertTrue(self.apc.pattern.tied(0,1))
        self.assertEqual(self.apc.last_color[1], CYAN)
        self.assertEqual(self.apc.pattern.steps, before)
        self.press(1)
        self.assertFalse(self.apc.pattern.tied(0,1))
        self.assertEqual(self.apc.last_color[1], GREEN)

    def test_invalid_tie_requires_both_adjacent_notes_and_changes_nothing(self):
        before = self.apc.pattern.dump()
        self.press(122)
        result = self.press(1)
        self.assertIn('zet eerst',result)
        self.assertEqual(self.apc.pattern.dump(),before)
        self.assertEqual(self.rig.calls,[])

    def test_normal_off_removes_incoming_tie(self):
        self.tied_pair()
        self.press(1)
        self.assertFalse(self.apc.pattern.steps[0][1])
        self.assertFalse(self.apc.pattern.ties[0][1])

    def test_tied_pair_is_one_attack_and_one_final_note_off(self):
        self.tied_pair();self.apc.set_playing(True,0)
        for now in (0,.1,.125,.19):self.apc.tick(now)
        self.assertEqual(self.rig.calls,[('on',48,100)])
        self.apc.tick(.2)
        self.assertEqual(self.rig.calls,[('on',48,100),('off',48)])

    def test_untied_equal_notes_remain_two_separate_attacks(self):
        self.apc.pattern.steps[0][0:2] = [True,True]
        self.apc.set_playing(True,0)
        for now in (0,.1,.125,.2):self.apc.tick(now)
        self.assertEqual(self.rig.calls,[('on',48,100),('off',48),('on',48,100),('off',48)])

    def test_three_step_tie_has_one_attack_and_last_step_gate(self):
        self.apc.pattern.steps[0][0:3] = [True]*3
        self.apc.pattern.ties[0][1:3] = [True]*2
        self.apc.set_playing(True,0)
        for now in (0,.1,.125,.2,.25,.31):self.apc.tick(now)
        self.assertEqual(self.rig.calls,[('on',48,100)])
        self.apc.tick(.32)
        self.assertEqual(self.rig.calls[-1],('off',48))

    def test_all_tied_loop_is_continuous_until_stop_for_all_lengths(self):
        for length in (4,8,16):
            self.apc.set_playing(False,0)
            self.apc.set_length(length)
            self.apc.pattern.steps[0] = [True]*16
            self.apc.pattern.ties[0] = [True]*16
            self.rig.calls.clear()
            self.apc.set_playing(True,0)
            for step in range(length*2):self.apc.tick(step*.125)
            self.assertEqual(self.rig.calls,[('on',48,100)])
            self.apc.set_playing(False,length*.25)
            self.assertEqual(self.rig.calls[-1],('off',48))

    def test_last_step_can_tie_into_first_but_first_start_still_attacks(self):
        self.apc.set_length(4)
        self.apc.pattern.steps[0][0] = self.apc.pattern.steps[0][3] = True
        self.apc.pattern.ties[0][0] = True
        self.apc.set_playing(True,0)
        for now in (0,.1,.125,.25,.375,.49,.5,.57):self.apc.tick(now)
        self.assertEqual(self.rig.calls,[('on',48,100),('off',48),('on',48,100),('off',48)])

    def test_external_clock_jitter_does_not_cut_tie_before_next_pulse_boundary(self):
        self.apc.set_clock('swing',0);self.tied_pair()
        self.apc.swing_clock(Message('start'),0)
        self.apc.swing_clock(Message('clock'),.001)
        self.apc.tick(.13)
        self.assertEqual(self.rig.calls,[('on',48,100)])
        for tick in range(1,7):self.apc.swing_clock(Message('clock'),.14+tick*.001)
        self.assertEqual(self.apc.step,1)
        self.assertEqual(self.calls('on'),[('on',48,100)])

    def test_stop_releases_tied_note_and_continue_has_fresh_gate(self):
        self.apc.set_clock('swing',0);self.tied_pair()
        self.apc.swing_clock(Message('start'),0)
        for tick in range(6):self.apc.swing_clock(Message('clock'),tick/48)
        self.apc.swing_clock(Message('stop'),.11)
        self.assertFalse(self.apc.router.held['apc'])
        self.apc.swing_clock(Message('continue'),1)
        self.apc.swing_clock(Message('clock'),1.01)
        self.assertEqual(self.calls('on'),[('on',48,100),('on',48,100)])

    def test_deleting_tie_target_live_cannot_leave_sustained_note(self):
        self.tied_pair();self.apc.set_playing(True,0);self.apc.tick(0)
        self.apc.pattern.steps[0][1] = False
        self.apc.tick(.125)
        self.assertFalse(self.apc.router.held['apc'])
        self.assertEqual(self.rig.calls[-1],('off',48))

    def test_changing_lane_pitch_breaks_tie_between_different_pitches(self):
        self.tied_pair();self.apc.set_playing(True,0);self.apc.tick(0)
        self.apc.pattern.notes[0] = 60
        self.apc.tick(.125)
        self.assertEqual(self.rig.calls,[('on',48,100),('off',48),('on',60,100)])

    def test_tied_note_recovers_after_engine_reset_instead_of_remaining_silent(self):
        from test_synthrig import FakeSlot
        from synthrig.engine09 import SynthRig
        rig=SynthRig(FakeSlot(),offline=True)
        apc=APCminiMk2(None,rig,pattern_dir=self.temp.name,logger=lambda _:None)
        apc.pattern.steps[0][0:2]=[True,True]
        apc.pattern.ties[0][1]=True
        apc.set_playing(True,0);apc.tick(0)
        self.assertIn(48,rig.active_notes)
        rig.all_notes_off()  # preset/session application can reset DSP gates
        apc.tick(.125)
        self.assertIn(48,rig.active_notes)
        apc.close()

    def test_duplicate_pitch_lanes_do_not_cut_a_valid_same_lane_tie(self):
        self.tied_pair()
        self.apc.pattern.notes[1] = 48
        self.apc.pattern.steps[1][0] = True
        self.apc.set_playing(True,0)
        for now in (0,.1,.125,.19):self.apc.tick(now)
        self.assertEqual(self.rig.calls,[('on',48,100)])
        self.apc.tick(.2)
        self.assertEqual(self.rig.calls[-1],('off',48))

    def test_same_pitch_on_another_lane_does_not_create_a_false_tie(self):
        self.apc.pattern.steps[0][0] = True
        self.apc.pattern.notes[1] = 48
        self.apc.pattern.steps[1][1] = self.apc.pattern.ties[1][1] = True
        self.apc.set_playing(True,0)
        for now in (0,.1,.125,.2):self.apc.tick(now)
        self.assertEqual(len(self.calls('on')),2)

    def test_shared_swing_note_survives_apc_tie_stop(self):
        self.apc.router.on('swing',48,90)
        self.tied_pair();self.apc.set_playing(True,0);self.apc.tick(0)
        self.apc.set_playing(False,.01)
        self.assertEqual(self.rig.calls,[('on',48,90)])

    def test_save_led_only_lights_after_successful_atomic_replace(self):
        import os
        replace = os.replace
        def checked_replace(src,dest):
            self.assertFalse(self.apc.last_button[105])
            return replace(src,dest)
        with patch('synthrig.apc_mk2.os.replace',side_effect=checked_replace):self.press(105,5)
        self.assertTrue(self.apc.save_confirmed)
        self.assertTrue(self.apc.last_button[105])
        deadline=self.apc.save_until
        self.apc.tick(deadline-.001)
        self.assertTrue(self.apc.last_button[105])
        self.apc.tick(deadline)
        self.assertFalse(self.apc.last_button[105])
        sent=[m.velocity for m in self.out.messages if m.type=='note_on' and m.note==105]
        self.assertEqual(sent[-2:],[1,0])

    def test_failed_save_is_not_acknowledged_and_preserves_old_file(self):
        self.press(105,0)
        path=Path(self.temp.name)/'apc_01.json'
        before=path.read_bytes()
        self.apc.pattern.steps[0][0]=True
        with patch('synthrig.apc_mk2.os.replace',side_effect=OSError('disk test failure')):
            with self.assertRaises(OSError):self.press(105,.1)
        self.assertFalse(self.apc.save_confirmed)
        self.assertFalse(self.apc.last_button[105])
        self.assertIn('SAVE MISLUKT',self.apc.last_action)
        self.assertEqual(path.read_bytes(),before)
        self.assertFalse(path.with_suffix('.json.tmp').exists())

    def test_repeated_save_restarts_confirmation_timer(self):
        self.press(105,0);self.press(105,.8)
        self.apc.tick(1.1)
        self.assertTrue(self.apc.last_button[105])
        self.apc.tick(self.apc.save_until+.001)
        self.assertFalse(self.apc.last_button[105])

    def test_slow_disk_still_gets_full_confirmation_after_write_finishes(self):
        with patch('synthrig.apc_mk2.time.monotonic',side_effect=(50,52)):
            self.press(105,5)
        self.assertEqual(self.apc.save_until,8)
        self.apc.tick(7.999)
        self.assertTrue(self.apc.last_button[105])
        self.apc.tick(8)
        self.assertFalse(self.apc.last_button[105])

    def test_save_reload_keeps_ties_length_and_tempo(self):
        self.tied_pair();self.apc.set_length(4);self.apc.pattern.bpm=60
        self.press(105)
        self.apc.pattern=Pattern()
        self.apc.load_pattern(silent=True)
        self.assertEqual((self.apc.pattern.length,self.apc.pattern.bpm),(4,60))
        self.assertTrue(self.apc.pattern.tied(0,1))

    def test_legacy_patterns_default_to_untied_and_malformed_ties_reject(self):
        data=Pattern().dump();data.pop('ties')
        self.assertFalse(any(any(row) for row in Pattern.parse(data).ties))
        for ties in (None,[],[[False]*15 for _ in range(8)],[[2]*16 for _ in range(8)]):
            bad=Pattern().dump();bad['ties']=ties
            with self.assertRaises(ValueError):Pattern.parse(bad)

    def test_internal_tempo_fader_slows_down_and_preserves_next_grid_boundary(self):
        self.apc.set_playing(True,0);self.apc.tick(0)
        self.apc.handle(Message('control_change',control=56,value=0),.03)
        self.assertEqual(self.apc.pattern.bpm,60)
        self.apc.tick(.125)
        self.assertEqual(self.apc.next_step,.375)
        self.apc.tick(.25)
        self.assertEqual(self.apc.step,1)
        self.apc.tick(.375)
        self.assertEqual(self.apc.step,2)

    def test_swing_tempo_is_not_overwritten_by_apc_master_fader(self):
        self.apc.set_clock('swing',0)
        before=self.apc.pattern.bpm
        result=self.apc.handle(Message('control_change',control=56,value=0),0)
        self.assertEqual(self.apc.pattern.bpm,before)
        self.assertIn('SWING',result)


if __name__=='__main__':unittest.main()
