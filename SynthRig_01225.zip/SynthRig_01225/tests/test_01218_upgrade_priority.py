"""0.12.18 newest available user state, APC patterns and global gain (0.12.19)."""
import unittest
from pathlib import Path


class UpgradePriority(unittest.TestCase):
    def test_all_three_migrations_prefer_01217(self):
        source=(Path(__file__).resolve().parents[1]/'synthrig_01219.py').read_text()
        self.assertEqual(source.count("('SynthRig_01218','SynthRig_01217','SynthRig_01216'"),3)
        self.assertIn('if src.is_file() and not state_path.exists()',
            (Path(__file__).resolve().parents[1]/'synthrig'/'upgrade0111.py').read_text())

if __name__=='__main__':unittest.main()
