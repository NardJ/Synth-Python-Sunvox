"""0.9.11: TRI octaafcorrectie en offline-audiotest gereedschap."""
from __future__ import annotations
import math
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from test_09 import FakeSlot
from synthrig.engine09 import SynthRig,DEFAULT_WAVE_PITCH_OFFSETS,midi_frequency
from synthrig.offline0100 import estimate_pitch,rms,spectral_high_ratio

class Test0911(unittest.TestCase):
    def test_tri_offset_is_zero_default(self):
        self.assertEqual(DEFAULT_WAVE_PITCH_OFFSETS,
                         {'SIN':12.,'TRI':0.,'SAW':0.,'PULSE':12.})

    def test_tri_pitch_event_matches_midi_note(self):
        from sunvox.api import NOTECMD
        slot=FakeSlot()
        rig=SynthRig(slot)
        rig.set_waveform_index(1,1)  # TRI
        rig.note_on(60,100)
        v=rig.voices[0]
        pitches=[e for e in slot.events if e[1]==NOTECMD.SET_PITCH and e[3]==v.o1+1]
        self.assertTrue(pitches)
        self.assertEqual(pitches[-1][5],rig._native_pitch(48))

    def test_fft_finds_octave_error_unbiased(self):
        import numpy as np
        rate=44100
        t=np.arange(round(rate*.45))/rate
        a=np.sin(2*np.pi*523.2511*t)
        measured=estimate_pitch(a,rate)
        self.assertAlmostEqual(measured,523.2511,delta=1.)
        self.assertGreater(abs(1200*math.log2(measured/midi_frequency(60))),1150)

    def test_fft_detects_correct_c4(self):
        import numpy as np
        t=np.arange(round(44100*.45))/44100
        s=np.sin(2*np.pi*midi_frequency(60)*t)
        self.assertAlmostEqual(estimate_pitch(s),midi_frequency(60),delta=1)
        self.assertGreater(rms(s),.6)

    def test_fft_reports_silence(self):
        import numpy as np
        self.assertIsNone(estimate_pitch(np.zeros(10000)))

    def test_brightness_ratio_distinguishes_harmonics(self):
        import numpy as np
        t=np.arange(44100)/44100
        a=np.sin(2*np.pi*262*t)
        b=a+.8*np.sin(2*np.pi*262*8*t)
        self.assertGreater(spectral_high_ratio(b),spectral_high_ratio(a)*100)

if __name__=='__main__':unittest.main()
