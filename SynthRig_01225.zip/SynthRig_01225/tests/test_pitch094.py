"""SunVox SET_PITCH tests for SynthRig 0.9.5.
These assert real API command structure, not actual audio output."""
from pathlib import Path
import sys
import unittest
import mido
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from test_09 import FakeSlot
from synthrig.tracks098 import voice_track
from synthrig.engine09 import SynthRig, midi_frequency, sunvox_pitch_from_hz
from sunvox.api import NOTECMD

class Pitch094Tests(unittest.TestCase):
    def setUp(self):
        self.s=FakeSlot()
        self.r=SynthRig(self.s,pitch_lfo_mode='events')
        self.r.note_on(60,100)
        self.v=self.r.voices[0]

    def pitches(self):
        return [ev for ev in self.s.events if ev[1]==0 and ev[4] in (5,6)]

    def test_bend_sends_pitch_to_held_voice_without_note_retrigger(self):
        self.s.events.clear()
        self.r.handle_swing(mido.Message('pitchwheel',pitch=8191))
        ev=self.pitches()
        self.assertEqual(len(ev),3)
        self.assertEqual([e[0] for e in ev],[voice_track(0,role) for role in ("osc1","osc2","sub_noise")])
        self.assertEqual([e[3] for e in ev],[self.v.o1+1,self.v.o2+1,self.v.sub_router+1])
        self.assertEqual([(e[4],e[5]) for e in ev],[(5,512)]*3)
        self.assertFalse(any(1<=e[1]<=127 for e in self.s.events))
        self.assertEqual(self.r.active_notes[60],0)
        self.assertEqual(self.v.last_pitch,{1:512,2:512,3:-2560}) # sub -12 +2
        self.s.events.clear()
        self.r.handle_swing(mido.Message('pitchwheel',pitch=0))
        self.assertEqual(len(self.pitches()),3)
        self.assertEqual(self.v.last_pitch,{1:0,2:0,3:-3072})

    def test_modulation_issues_pitch_events_only_while_playing(self):
        self.r.handle_swing(mido.Message('control_change',control=1,value=127))
        self.s.events.clear()
        self.r.tick(now=self.r._last_tick+0.05,force=True)
        self.assertEqual(len(self.pitches()),3)
        self.assertEqual(self.v.last_pitch[1],round(.4*256))
        self.assertEqual(self.v.last_pitch[3],round((-12+.4)*256))
        self.r.all_notes_off()
        self.s.events.clear()
        self.r.tick(now=self.r._last_tick+.05,force=True)
        self.assertEqual(self.pitches(),[])

    def test_generator_route_targets_absolute_pitch_and_tuning(self):
        self.s.events.clear()
        self.r.handle_swing(mido.Message('pitchwheel',pitch=8191))
        got=self.pitches()
        self.assertEqual([e[3] for e in got],[self.v.o1+1,self.v.o2+1,self.v.sub_router+1])
        self.assertEqual([(e[4],e[5]) for e in got],[(5,512)]*3)

    def test_multiple_notes_only_active_voices(self):
        self.r.note_on(64,100)
        self.s.events.clear()
        self.r.handle_swing(mido.Message('pitchwheel',pitch=-8192))
        self.assertEqual(len(self.pitches()),6)
        self.assertEqual({e[0] for e in self.pitches()},{voice_track(i,role) for i in range(2) for role in ("osc1","osc2","sub_noise")})
        self.assertFalse(any(1<=e[1]<=127 for e in self.s.events))

if __name__=='__main__':
    unittest.main()
