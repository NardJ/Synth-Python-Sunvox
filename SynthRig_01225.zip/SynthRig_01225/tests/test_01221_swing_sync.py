"""SWING transport, actual input routing and clock-loss note ownership."""
import json
import tempfile
import unittest
from pathlib import Path

from mido import Message
from synthrig.apc_mk2 import APCminiMk2
from synthrig.swing_sync import SwingSync, handle_swing_input, tick_swing_input, read_swing_messages
from test_0120 import FakeRig


class Rig(FakeRig):
    def handle_swing(self, msg):
        if msg.type == 'note_on' and msg.velocity:
            self.note_on(msg.note, msg.velocity)
        elif msg.type in ('note_on', 'note_off'):
            self.note_off(msg.note)


class SyncTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.rig = Rig()
        self.sync = SwingSync(port='Test SWING USB')
        self.apc = APCminiMk2(None, self.rig, pattern_dir=self.temp.name,
                              clock='swing', logger=lambda _: None, swing_sync=self.sync)
        self.apc.pattern.steps[0] = [True] * 16

    def feed(self, kind, now, **kw):
        handle_swing_input(Message(kind, **kw), self.rig, self.sync, self.apc, now)

    def test_start_plays_first_step_on_first_clock_never_on_start_message(self):
        self.feed('start', 0)
        self.assertEqual(self.apc.step, -1)
        self.assertFalse(self.rig.calls)
        self.feed('clock', .01)
        self.assertEqual(self.apc.step, 0)
        self.assertEqual(self.rig.calls, [('on', 48, 100)])
        for i in range(1, 6):
            self.feed('clock', .01 + i / 48)
        self.assertEqual(self.apc.step, 0)
        self.feed('clock', .01 + 6 / 48)
        self.assertEqual(self.apc.step, 1)

    def test_four_complete_loops_keep_six_clock_pulses_per_step(self):
        self.feed('start', 0)
        for tick in range(16 * 4 * 6):
            self.feed('clock', tick / 48)
            self.assertEqual(self.apc.step, (tick // 6) % 16)
        self.assertEqual(len([c for c in self.rig.calls if c[0] == 'on']), 64)

    def test_stop_continue_preserves_step_and_partial_step_clock_position(self):
        self.feed('start', 0)
        for tick in range(9):
            self.feed('clock', tick / 48)
        self.feed('stop', .2)
        self.assertFalse(self.apc.playing)
        self.assertEqual(self.apc.step, 1)
        self.assertFalse(self.apc.router.held['apc'])
        self.feed('continue', 2)
        for tick in range(3):
            self.feed('clock', 2.01 + tick / 48)
        self.assertEqual(self.apc.step, 1)
        self.feed('clock', 2.01 + 3 / 48)
        self.assertEqual(self.apc.step, 2)

    def test_fresh_start_clears_old_gates_and_rewinds(self):
        self.feed('start', 0)
        for tick in range(14):
            self.feed('clock', tick / 48)
        self.feed('start', .3)
        self.assertFalse(self.apc.pending_off)
        self.assertFalse(self.apc.router.held['apc'])
        self.feed('clock', .31)
        self.assertEqual(self.apc.step, 0)

    def test_clock_while_stopped_measures_bpm_without_playing(self):
        for tick in range(49):
            self.feed('clock', tick / 48)
        self.assertFalse(self.apc.playing)
        self.assertEqual(self.sync.bpm, 120)
        self.assertEqual(self.rig.calls, [])

    def test_stop_then_idle_clocks_do_not_create_a_timeout(self):
        self.feed('start', 0)
        self.feed('clock', .01)
        self.feed('stop', .02)
        for tick in range(200):
            self.feed('clock', .03 + tick / 48)
        tick_swing_input(self.rig, self.sync, self.apc, 10)
        self.assertEqual(self.sync.counts['timeouts'], 0)
        self.assertFalse(self.sync.running)

    def test_missing_first_clock_stops_waiting_after_timeout(self):
        self.feed('start', 0)
        tick_swing_input(self.rig, self.sync, self.apc, .74)
        self.assertTrue(self.apc.playing)
        tick_swing_input(self.rig, self.sync, self.apc, .75)
        self.assertFalse(self.apc.playing)
        self.assertEqual(self.sync.snapshot(.75)['transport'], 'lost')

    def test_clock_loss_releases_both_sources_once_without_panic(self):
        self.feed('start', 0)
        self.feed('note_on', .001, note=60, velocity=100)
        self.feed('clock', .01)
        tick_swing_input(self.rig, self.sync, self.apc, .77)
        self.assertFalse(self.apc.playing)
        self.assertFalse(self.apc.pending_off)
        self.assertFalse(any(self.apc.router.held.values()))
        self.assertIn(('off', 60), self.rig.calls)
        self.assertIn(('off', 48), self.rig.calls)
        self.assertNotIn(('panic',), self.rig.calls)
        before = list(self.rig.calls)
        tick_swing_input(self.rig, self.sync, self.apc, 2)
        self.assertEqual(before, self.rig.calls)
        self.assertEqual(self.sync.counts['timeouts'], 1)

    def test_late_clock_does_not_hide_the_gap_or_restart_playback(self):
        self.feed('start', 0)
        self.feed('clock', .01)
        self.feed('clock', 1)
        self.assertEqual(self.sync.counts['timeouts'], 1)
        self.assertFalse(self.apc.playing)
        self.assertTrue(self.sync.snapshot(1)['clock_receiving'])
        self.feed('continue', 1.01)
        self.feed('clock', 1.02)
        self.assertFalse(self.apc.playing)
        self.feed('start', 1.03)
        self.feed('clock', 1.04)
        self.assertTrue(self.apc.playing)
        self.assertEqual(self.apc.step, 0)

    def test_minimum_swing_tempo_does_not_trigger_timeout(self):
        self.feed('start', 0)
        for tick in range(80):
            now = tick * .125  # 20 BPM, 24 PPQN
            self.feed('clock', now)
            tick_swing_input(self.rig, self.sync, self.apc, now + .1)
        self.assertEqual(self.sync.counts['timeouts'], 0)
        self.assertAlmostEqual(self.sync.bpm, 20)

    def test_stop_after_timeout_does_not_make_unknown_phase_valid_again(self):
        self.feed('start', 0)
        self.feed('clock', .01)
        tick_swing_input(self.rig, self.sync, self.apc, .8)
        self.feed('stop', .81)
        self.feed('continue', .82)
        self.feed('clock', .83)
        self.assertFalse(self.apc.playing)
        self.assertTrue(self.sync.lost)

    def test_tempo_estimate_adapts_to_a_tempo_change(self):
        now = 0
        for bpm in (60, 120, 240):
            for _ in range(50):
                now += 60 / (bpm * 24)
                self.feed('clock', now)
            self.assertAlmostEqual(self.sync.bpm, bpm, places=5)

    def test_short_pause_is_not_included_in_resumed_tempo_estimate(self):
        self.feed('start', 0)
        for tick in range(25):
            self.feed('clock', tick / 48)
        self.feed('stop', .51)
        self.feed('continue', .7)
        for tick in range(7):
            self.feed('clock', .71 + tick / 48)
        self.assertAlmostEqual(self.sync.bpm, 120)

    def test_gate_uses_measured_external_tempo(self):
        for tick in range(25):
            self.feed('clock', tick / 24)  # 60 BPM; pattern default is 120
        self.feed('start', 1.01)
        self.feed('clock', 1.02)
        duration = self.apc.pending_off[0][0] - 1.02
        self.assertAlmostEqual(duration, 60 / self.sync.bpm / 4 * self.apc.pattern.gate)

    def test_old_pending_gate_cannot_cut_a_retrigger_short(self):
        self.feed('start', 0)
        self.feed('clock', .01)
        old_off = self.apc.pending_off[0][0]
        for tick in range(1, 7):
            self.feed('clock', .01 + tick * (.05 / 6))
        self.assertEqual(len(self.apc.pending_off), 1)
        self.assertGreater(self.apc.pending_off[0][0], old_off + .001)
        tick_swing_input(self.rig, self.sync, self.apc, old_off + .001)
        self.assertTrue(self.apc.router.held['apc'])

    def test_internal_apc_ignores_external_transport(self):
        self.apc.set_clock('internal', 0)
        self.apc.set_playing(True, 0)
        self.feed('start', .01)
        self.feed('stop', .02)
        tick_swing_input(self.rig, self.sync, self.apc, .03)
        self.assertTrue(self.apc.playing)
        self.assertEqual(self.apc.step, 0)

    def test_internal_apc_keeps_shared_note_when_swing_clock_is_lost(self):
        self.apc.set_clock('internal', 0)
        self.apc.set_playing(True, 0)
        self.apc.router.on('apc', 60, 90)
        self.feed('start', .01)
        self.feed('note_on', .02, note=60, velocity=80)
        self.feed('clock', .03)
        self.apc._watch_swing_clock(.8)
        self.assertTrue(self.apc.playing)
        self.assertEqual(self.apc.router.held['apc'], {60})
        self.assertNotIn(('off', 60), self.rig.calls)

    def test_local_apc_buttons_do_not_fabricate_received_transport(self):
        self.apc.set_playing(True, 0)
        self.feed('clock', .01)
        self.assertEqual(self.apc.step, -1)  # clock alone cannot start the master
        self.apc.set_playing(False, .02)
        self.assertEqual(self.sync.counts['start'], 0)
        self.assertEqual(self.sync.counts['stop'], 0)

    def test_clock_source_switch_releases_notes_and_requires_explicit_start(self):
        self.feed('start', 0)
        self.feed('clock', .01)
        self.apc.set_clock('internal', .02)
        self.assertFalse(self.apc.playing)
        self.assertFalse(self.apc.router.held['apc'])
        self.assertFalse(self.apc.pending_off)

    def test_swing_only_watchdog_releases_notes_without_apc(self):
        handle_swing_input(Message('start'), self.rig, self.sync, now=0)
        handle_swing_input(Message('note_on', note=60, velocity=90), self.rig, self.sync, now=.01)
        handle_swing_input(Message('clock'), self.rig, self.sync, now=.02)
        tick_swing_input(self.rig, self.sync, now=.8)
        self.assertEqual(self.rig.calls, [('on', 60, 90), ('off', 60)])
        self.assertFalse(self.sync.held_notes)

    def test_manual_keys_without_transport_are_not_subject_to_clock_timeout(self):
        handle_swing_input(Message('note_on', note=60, velocity=90), self.rig, self.sync, now=0)
        tick_swing_input(self.rig, self.sync, now=100)
        self.assertEqual(self.rig.calls, [('on', 60, 90)])
        handle_swing_input(Message('note_on', note=60, velocity=0), self.rig, self.sync, now=101)
        self.assertEqual(self.rig.calls[-1], ('off', 60))
        self.assertEqual(self.sync.counts['note_off'], 1)

    def test_report_preserves_observed_counters_and_is_bounded_and_atomic(self):
        for index in range(100):
            self.feed('start', index)
            self.feed('stop', index + .01)
        path = Path(self.temp.name) / 'reports' / 'sync.json'
        self.sync.save_report(path, clock_source='swing', now=101)
        report = json.loads(path.read_text())
        self.assertEqual(report['sync']['counts']['start'], 100)
        self.assertEqual(report['sync']['counts']['stop'], 100)
        self.assertEqual(report['input_port'], 'Test SWING USB')
        self.assertEqual(len(report['recent_events']), 32)
        self.assertFalse(path.with_name('.sync.json.tmp').exists())
        self.sync.save_report(path, clock_source='internal', now=102)
        self.assertEqual(json.loads(path.read_text())['apc_clock_source'], 'internal')

    def test_midi_input_failure_stops_external_apc_and_is_reported_once(self):
        class Gone:
            def iter_pending(self):
                raise OSError('MIDI endpoint disconnected')
        self.feed('start', 0)
        self.feed('clock', .01)
        self.feed('note_on', .02, note=60, velocity=90)
        self.assertEqual(read_swing_messages(Gone(), self.rig, self.sync, self.apc, .03), [])
        self.assertFalse(self.apc.playing)
        self.assertFalse(any(self.apc.router.held.values()))
        self.assertIn('disconnected', self.sync.input_error)
        self.assertFalse(self.sync.snapshot(.03)['clock_receiving'])
        read_swing_messages(Gone(), self.rig, self.sync, self.apc, .04)
        self.assertEqual(self.sync.counts['input_errors'], 1)

    def test_midi_input_failure_without_apc_releases_manual_keys(self):
        class Gone:
            def iter_pending(self):
                raise ValueError('receive() called on closed port')
        handle_swing_input(Message('note_on', note=60, velocity=90), self.rig, self.sync, now=0)
        read_swing_messages(Gone(), self.rig, self.sync, now=1)
        self.assertEqual(self.rig.calls[-1], ('off', 60))

    def test_midi_input_failure_leaves_internal_apc_running(self):
        class Gone:
            def iter_pending(self):
                raise RuntimeError('USB gone')
        self.apc.set_clock('internal', 0)
        self.apc.set_playing(True, 0)
        self.apc.router.on('apc', 60, 90)
        self.feed('note_on', .01, note=60, velocity=90)
        read_swing_messages(Gone(), self.rig, self.sync, self.apc, .02)
        self.assertTrue(self.apc.playing)
        self.assertNotIn(('off', 60), self.rig.calls)

    def test_healthy_port_messages_are_not_counted_until_they_are_processed(self):
        class Port:
            def iter_pending(self):
                yield Message('start')
                yield Message('clock')
        messages = read_swing_messages(Port(), self.rig, self.sync, self.apc, 0)
        self.assertEqual(len(messages), 2)
        self.assertEqual(self.sync.counts['start'], 0)
        for message in messages:
            handle_swing_input(message, self.rig, self.sync, self.apc, 0)
        self.assertEqual(self.sync.counts['start'], 1)
        self.assertEqual(self.sync.counts['clock'], 1)


if __name__ == '__main__':
    unittest.main()
