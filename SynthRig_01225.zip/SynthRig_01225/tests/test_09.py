"""0.9 regressietests zonder SunVox/audiohardware."""
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from test_synthrig import FakeSlot
from synthrig.tracks098 import voice_track
from synthrig.engine09 import SynthRig, VOICES, Envelope

# FakeSlot bevat alle control-definities zelfstandig; geen globale testmutaties.

class Test09(unittest.TestCase):
    def setUp(self):
        self.s=FakeSlot()
        self.r=SynthRig(self.s, dc_blocker=True)
    def test_routing_four_independent_filters_envelopes_and_blockers(self):
        self.assertEqual(len(self.r.voices),VOICES)
        self.assertEqual(len(set(v.filt for v in self.r.voices)),4)
        self.assertEqual(len(set(v.adsr for v in self.r.voices)),4)
        for v in self.r.voices:
            links=self.s.links
            for src,dst in [(v.o1,v.dc1),(v.dc1,v.a1),(v.a1,v.filt),
                            (v.o2,v.dc2),(v.dc2,v.a2),(v.a2,v.filt),
                            (v.sub_router,v.noise),(v.sub,v.sub_gain),(v.sub_gain,v.filt),
                            (v.noise,v.noise_gain),(v.noise_gain,v.filt),
                            (v.filt,v.adsr),(v.adsr,v.velocity_amp),(v.velocity_amp,self.r.vib_lfo)]:
                self.assertIn((src,dst),links)
            self.assertEqual(self.s.get_module_ctl_value(v.adsr,v.ctls['amp_mode'][0],0),1)
        self.assertIn((self.r.vib_lfo,self.r.vib_mod),self.s.links)
        self.assertIn((self.r.vib_mod,self.r.output_amp),self.s.links)
    def test_note_gate_release_delays_generator_stop(self):
        self.r.note_on(60,100)
        i=self.r.active_notes[60]
        self.assertEqual(len([e for e in self.s.events if 1<=e[1]<=127]),4)
        self.r.note_off(60)
        self.assertNotIn(60,self.r.active_notes)
        self.assertEqual(self.s.events[-1][0],voice_track(i,"amp_gate"))
        self.assertEqual(len([e for e in self.s.events if 1<=e[1]<=127]),4)
        self.assertEqual(len([e for e in self.s.events if e[1]==128]),1)
        self.r.tick(now=self.r.voices[i].released + self.r.amp['release']+.5,force=True)
        self.assertIsNone(self.r.voices[i].note)
    def test_polyphony_and_voice_steal(self):
        for note in (60,64,67,72):self.r.note_on(note,90)
        self.assertEqual(len(self.r.active_notes),4)
        self.assertEqual(len(set(self.r.active_notes.values())),4)
        self.r.note_on(75,90)
        self.assertEqual(len(self.r.active_notes),4)
        self.assertIn(75,self.r.active_notes)
    def test_env_and_lfo_and_waveforms(self):
        self.r.note_on(60,80)
        self.r.set_parameter('amp.attack',127)
        self.assertEqual(self.s.get_module_ctl_value(self.r.voices[0].adsr,self.r.voices[0].ctls['amp_attack'][0],0),2000)
        self.r.set_parameter('filter.env_amount',127)
        self.r.set_parameter('filter.attack',64)
        self.r.set_parameter('lfo.pitch_depth',80)
        self.r.set_parameter('lfo.filter_depth',80)
        self.r.set_parameter('lfo.rate',70)
        self.r.tick(now=self.r._last_tick+.035,force=True)
        self.assertTrue(self.r.voices[0].last_cutoff is not None)
        self.r.set_parameter('osc1.waveform',127)
        self.r.set_parameter('osc1.pulse_width',80)
        self.r.set_parameter('pwm.depth',127)
        self.r.tick(now=self.r._last_tick+.05,force=True)
        self.assertEqual(self.r.wave_selection[1],3)
        self.assertTrue(self.r.voices[0].last_duty[1] is not None)
    def test_sub_noise_volume(self):
        v=self.r.voices[0]
        old=self.s.get_module_ctl_value(v.sub_gain,v.ctls['subvol'][0],0)
        self.r.set_parameter('sub.level',127)
        new=self.s.get_module_ctl_value(v.sub_gain,v.ctls['subvol'][0],0)
        self.assertGreater(new,old)
        self.r.set_parameter('noise.level',127)
        self.assertGreater(self.s.get_module_ctl_value(v.noise_gain,v.ctls['noisevol'][0],0),0)
    def test_no_dc_reference(self):
        r=SynthRig(FakeSlot(),dc_blocker=False)
        self.assertIsNone(r.voices[0].dc1)

class TestFilterEnv(unittest.TestCase):
    def test_attack_decay_release(self):
        e=Envelope(.1,.2,.3,.4)
        e.on(10)
        self.assertAlmostEqual(e.value(10.05),.5,places=5)
        self.assertAlmostEqual(e.value(10.3),.3,places=5)
        e.off(10.3)
        self.assertAlmostEqual(e.value(10.5),.15,places=4)
        self.assertEqual(e.value(10.9),0)

if __name__=='__main__':unittest.main()
