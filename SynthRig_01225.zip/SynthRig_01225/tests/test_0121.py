"""0.12.1: Live debug snapshot matches the commands sent to the APC."""
from synthrig.mod_matrix import ModMatrix
import tempfile
import unittest
import mido
from synthrig.apc_mk2 import APCminiMk2, PATCH_TARGETS, YELLOW, CYAN, BLUE

class FakeRig:
    def __init__(self):self.mod_matrix=ModMatrix()
    def tick(self,**kwargs):pass
    def set_parameter(self,*args):pass
    def note_on(self,*args):pass
    def note_off(self,*args):pass
    def all_notes_off(self):pass
class FakeOut:
    def __init__(self):self.messages=[]
    def send(self,msg):self.messages.append(msg)
class FakeControl:
    def __init__(self):self.target_raw={t:0 for _,t in PATCH_TARGETS}
    def arm_pickup(self,*args):pass

class APCMirrorTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.o=FakeOut()
        self.c=FakeControl()
        self.a=APCminiMk2(self.o,FakeRig(),self.c,pattern_dir=self.tmp.name,logger=lambda _:None)

    def press(self,note):
        self.a.handle(mido.Message('note_on',note=note,velocity=127),now=0)

    def test_mirror_reflects_actual_midi_led_messages(self):
        self.press(63)
        frame=self.a.display_snapshot()
        sent={(m.channel,m.note):m.velocity for m in self.o.messages if m.type=='note_on'}
        for note,vel in enumerate(frame['pads']):
            self.assertEqual(vel,sent[(6,note)])
        for note,lit in enumerate(frame['track_leds'],start=100):
            self.assertEqual(lit,bool(sent[(0,note)]))
        for note,lit in enumerate(frame['scene_leds'],start=112):
            self.assertEqual(lit,bool(sent[(0,note)]))
        self.assertEqual(frame['pads'][63],21)  # AC = green, no row-highlight override
        self.assertEqual(frame['columns'][7]['raw'],86)

    def test_seq_page_and_playhead_update_live_revision(self):
        rev=self.a.gui_revision
        self.press(101)
        self.press(0)
        self.press(104)
        self.a.tick(0)
        f=self.a.display_snapshot()
        self.assertGreater(f['revision'],rev)
        self.assertEqual((f['mode'],f['step'],f['page']),('seq',1,1))
        self.assertEqual(f['pads'][0],YELLOW) # active step is yellow
        self.press(103)
        f=self.a.display_snapshot()
        self.assertEqual(f['page'],2)
        self.assertEqual(f['track_leds'][3],True)

    def test_fader_position_only_after_real_input(self):
        self.assertEqual(self.a.display_snapshot()['faders'],[None]*9)
        self.press(101) # BPM fader belongs to SEQ, not PATCH
        self.a.handle(mido.Message('control_change',channel=0,control=56,value=100))
        self.assertEqual(self.a.display_snapshot()['faders'][8],100)
        self.assertEqual(self.a.display_snapshot()['bpm'],round(60+100*120/127,1))

if __name__=='__main__': unittest.main()
