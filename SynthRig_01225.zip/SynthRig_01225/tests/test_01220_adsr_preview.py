"""Relative envelope semantics, including silent and instantaneous extremes."""
import itertools
import unittest

from synthrig.adsr_preview import AMP_CCS, envelope_points


class EnvelopePreviewTests(unittest.TestCase):
    bounds = (58, 665, 492, 775)

    def points(self, a=64, d=64, s=64, r=64):
        return envelope_points(dict(zip(AMP_CCS, (a, d, s, r))), self.bounds)

    def test_unknown_values_do_not_invent_an_envelope(self):
        for missing in AMP_CCS:
            values = {cc: 64 for cc in AMP_CCS if cc != missing}
            self.assertIsNone(envelope_points(values, self.bounds))

    def test_all_corner_combinations_stay_visible_and_ordered(self):
        for raws in itertools.product((0, 1, 64, 127), repeat=4):
            with self.subTest(raws=raws):
                points = self.points(*raws)
                self.assertEqual(points[0], (58, 775))
                self.assertEqual(points[-1], (492, 775))
                self.assertEqual(points[1][1], 665)
                self.assertTrue(all(665 <= y <= 775 for x, y in points))
                self.assertTrue(all(p[0] < q[0] for p, q in zip(points, points[1:])))
                self.assertAlmostEqual(points[3][0] - points[2][0], 434 * .22)

    def test_sustain_is_height_and_does_not_change_any_time_width(self):
        low, high = self.points(s=0), self.points(s=127)
        self.assertEqual([x for x, y in low], [x for x, y in high])
        self.assertEqual([low[i][1] for i in (2, 3)], [775, 775])
        self.assertEqual([high[i][1] for i in (2, 3)], [665, 665])

    def test_each_time_fader_lengthens_its_own_segment(self):
        for index, (start, end) in ((0, (0, 1)), (1, (1, 2)), (3, (3, 4))):
            widths = []
            for raw in range(128):
                values = [64] * 4
                values[index] = raw
                points = self.points(*values)
                widths.append(points[end][0] - points[start][0])
            self.assertTrue(all(a < b for a, b in zip(widths, widths[1:])))


if __name__ == '__main__':
    unittest.main()
