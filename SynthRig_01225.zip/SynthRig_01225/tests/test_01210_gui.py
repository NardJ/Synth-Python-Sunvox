"""GUI label placement, no audio/MIDI dependencies."""
import unittest
from pathlib import Path

class Labels(unittest.TestCase):
    def test_two_distinct_column_label_lines_above_pad(self):
        from synthrig.apc_monitor import PAD_TOP,COL_LABEL_Y1,COL_LABEL_Y2,COL_DEPTH_Y,PAD_STEP_Y,PAD_H
        self.assertLess(COL_LABEL_Y1,COL_LABEL_Y2)
        self.assertLess(COL_LABEL_Y2+10,PAD_TOP)
        self.assertGreater(COL_DEPTH_Y,PAD_TOP+7*PAD_STEP_Y+PAD_H)
    def test_rows_are_right_justified_same_size_as_columns(self):
        s=(Path(__file__).resolve().parents[1]/'synthrig'/'apc_monitor.py').read_text()
        self.assertIn("self.matrix_txt(79,y+PAD_H/2-8,'',anchor='e')",s)
        self.assertIn("self.matrix_txt(x,COL_LABEL_Y1,'')",s)
        self.assertIn("self.matrix_txt(x,COL_LABEL_Y2,'')",s)
        self.assertIn('self.col_depth_text',s)
        from synthrig.apc_labels import LABEL_FONT
        self.assertEqual(LABEL_FONT,'DejaVu Sans Mono')
    def test_audio_engine_not_changed(self):
        from synthrig.mod_matrix import SOURCES,SOURCES_B,DESTINATIONS,DESTINATIONS_D
        self.assertEqual(tuple(map(len,(SOURCES,SOURCES_B,DESTINATIONS,DESTINATIONS_D))),(8,8,8,8))
if __name__=='__main__':unittest.main()
