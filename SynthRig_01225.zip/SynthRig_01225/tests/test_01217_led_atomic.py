"""0.12.18: preset identity and actually transmitted LED mask move atomically."""
import json
import socket
import unittest
from types import SimpleNamespace
from unittest.mock import patch
from mido import Message
from test_synthrig import FakeSlot
from tempfile import TemporaryDirectory
from synthrig.engine09 import SynthRig
from synthrig.fixed_controls import FixedControls
from synthrig.midimix_hw import MidiMixLEDs
from synthrig.midimix_events import handle_bank_press
from synthrig.presets import PresetManager
from synthrig.debug import OptionalMidiMixDebug
from synthrig.session_state import default_state,apply_state


class Out:
    def __init__(self):self.sent=[]
    def send(self, message):self.sent.append(message)


class Bridge:
    def __init__(self):self.calls=[]
    def send_preset(self,info,led_snapshot=None):self.calls.append(('preset',dict(info),led_snapshot))
    def send_values(self,values):self.calls.append(('values',dict(values)))


class AtomicPresetTests(unittest.TestCase):
    def setUp(self):
        self.folder=TemporaryDirectory();self.addCleanup(self.folder.cleanup)
        self.controls=FixedControls()
        self.rig=SynthRig(FakeSlot(),offline=True)
        apply_state(self.rig,self.controls,default_state(self.controls))
        self.pm=PresetManager(self.controls,self.folder.name)
        self.output=Out();self.leds=MidiMixLEDs(self.output,self.controls)
        self.monitor=Bridge()

    def test_16_bank_press_packets_contain_actual_led_count(self):
        for slot in range(1,17):
            handle_bank_press(Message('note_on',channel=0,note=26,velocity=127),
                              self.controls,self.pm,self.rig,self.leds,self.monitor)
            kind,info,snapshot=self.monitor.calls[-2]
            self.assertEqual(kind,'preset')
            self.assertEqual(info['slot'],slot)
            self.assertTrue(snapshot['overlay'])
            self.assertEqual(snapshot['preset'],slot)
            self.assertEqual(sum(snapshot['notes'].values()),slot)
            self.assertEqual([m.velocity>0 for m in self.output.sent[-16:]],
                             [bool(i<slot) for i in range(16)])

    def test_packet_matches_actual_hardware_before_monitor_is_notified(self):
        seen=[]
        class Inspect:
            def send_preset(_,info,led_snapshot=None):
                seen.append((len(self.output.sent),sum(led_snapshot['notes'].values())))
            def send_values(_,values):pass
        handle_bank_press(Message('note_on',channel=0,note=26,velocity=127),
                          self.controls,self.pm,self.rig,self.leds,Inspect())
        self.assertEqual(seen,[(16,1)])

    def test_udp_preset_packet_carries_entire_led_mirror(self):
        receiver=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        receiver.bind(('127.0.0.1',0));receiver.settimeout(1)
        self.addCleanup(receiver.close)
        bridge=OptionalMidiMixDebug.__new__(OptionalMidiMixDebug)
        bridge.process=SimpleNamespace(poll=lambda:None)
        bridge.sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        self.addCleanup(bridge.sock.close)
        bridge.target=receiver.getsockname()
        self.leds.show_preset(11)
        bridge.send_preset({'slot':11,'name':'PWM Strings'},self.leds.display_snapshot())
        data=json.loads(receiver.recvfrom(8192)[0])
        self.assertEqual(data['kind'],'preset')
        self.assertEqual(data['info']['slot'],11)
        self.assertEqual(data['leds']['preset'],11)
        self.assertEqual(sum(data['leds']['notes'].values()),11)

    def test_packet_without_leds_for_terminal_or_initial_sync_still_supported(self):
        receiver=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        receiver.bind(('127.0.0.1',0));receiver.settimeout(1)
        self.addCleanup(receiver.close)
        bridge=OptionalMidiMixDebug.__new__(OptionalMidiMixDebug)
        bridge.process=SimpleNamespace(poll=lambda:None)
        bridge.sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        self.addCleanup(bridge.sock.close)
        bridge.target=receiver.getsockname()
        bridge.send_preset({'slot':None})
        p=json.loads(receiver.recvfrom(8192)[0])
        self.assertNotIn('leds',p)

if __name__=='__main__':unittest.main()
