"""Fixed-overlay APC test release: five states, four routings and scene faders."""
import tempfile
import unittest
import mido
from synthrig.mod_matrix import (ModMatrix, blank_matrix, validate_matrix,
                                 decode,encode,legacy_groups,DEFAULT_DEPTH)
from synthrig.apc_mk2 import APCminiMk2, OFF,GREEN,BLUE,AMBER,PURPLE
from synthrig.fixed_controls import FixedControls
from synthrig.presets import validate_preset
from synthrig.session_state import default_state

class Rig:
    def __init__(self):
        self.mod_matrix=ModMatrix()
        self.tick_calls=0
    def tick(self,**_):self.tick_calls+=1
    def note_on(self,*_):pass
    def note_off(self,*_):pass
    def all_notes_off(self):pass

class Layers(unittest.TestCase):
    def make_apc(self):
        tmp=tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        r=Rig()
        a=APCminiMk2(None,r,pattern_dir=tmp.name,logger=lambda *_:None)
        return a,r
    @staticmethod
    def press(a,n,now=10):a.handle(mido.Message('note_on',note=n,velocity=127),now=now)
    def test_five_colors_and_max_one_route(self):
        a,r=self.make_apc()
        states=[(0,GREEN),(1,BLUE),(2,AMBER),(3,PURPLE),(None,OFF)]
        for variant,color in states:
            self.press(a,4)
            cell=r.mod_matrix.route(0,4)
            self.assertEqual(None if cell is None else cell[0],variant)
            self.assertEqual(a.display_snapshot()['pads'][4],color)
            self.assertLessEqual(sum(r.mod_matrix.grid[0][4] is not None for _ in [1]),1)
        self.assertEqual(len(r.mod_matrix.dump()),8)
    def test_shift_clears_immediately_and_is_visible(self):
        a,r=self.make_apc()
        for _ in range(3):self.press(a,23)
        a.handle(mido.Message('note_on',note=122,velocity=127))
        self.assertTrue(a.display_snapshot()['shift'])
        self.press(a,23)
        self.assertIsNone(r.mod_matrix.grid[2][7])
        a.handle(mido.Message('note_off',note=122,velocity=0))
        self.assertFalse(a.shift)
    def test_four_routes_have_distinct_sources_and_destinations(self):
        m=ModMatrix()
        # Use row 0, column 4, route A/C, A/D, B/C and B/D.
        values=[0.]*16;values[0]=0.5;values[8]=-0.25
        for variant in range(4):
            m.grid[0][4]=encode(variant,127)
            out=m.offsets(values)
            expected_index=4+(8 if variant%2 else 0)
            source=values[8 if variant>=2 else 0]
            self.assertAlmostEqual(out[expected_index],source)
            self.assertTrue(all(abs(v)<1e-9 for i,v in enumerate(out) if i!=expected_index))
    def test_fader_5_controls_key_and_lfo_and_only_column_five(self):
        a,r=self.make_apc()
        self.press(a,4)
        self.press(a,44) # row 5 / note 44 -> keytrack
        # Clear any default scene groups except LFO and KEYTRACK.
        self.assertEqual(set(r.mod_matrix.groups['rows'][4]),{0,5})
        r.mod_matrix.set_depth(0,4,110)
        r.mod_matrix.set_depth(5,4,75)
        depths=(r.mod_matrix.grid[0][4],r.mod_matrix.grid[5][4])
        a.handle(mido.Message('control_change',control=52,value=64),now=20.)
        a.handle(mido.Message('control_change',control=52,value=80),now=20.1)
        self.assertEqual((r.mod_matrix.grid[0][4],r.mod_matrix.grid[5][4]),depths)
        self.assertGreater(r.mod_matrix.groups['gains'][4],1.)
        self.assertEqual(r.mod_matrix.groups['gains'][0],1.)
        selected=0.5
        sources=[0.]*16;sources[0]=selected;sources[5]=selected
        actual=r.mod_matrix.offsets(sources)[4]
        self.assertGreater(actual,0)
    def test_temporary_scene_assignment_and_timeout(self):
        a,r=self.make_apc()
        self.press(a,4)
        self.press(a,44)
        a.handle(mido.Message('control_change',control=52,value=70),now=30.)
        self.assertEqual(a.focus_col,4)
        self.assertTrue(a.display_snapshot()['scene_leds'][7])  # LFO bottom
        self.assertTrue(a.display_snapshot()['scene_leds'][2])  # keytrack row5
        self.press(a,114,now=30.2)   # KEYTRACK row 6 (physical scene 6)
        self.assertNotIn(5,r.mod_matrix.groups['rows'][4])
        a.tick(31.25)
        self.assertIsNone(a.focus_col)
        self.assertEqual(sum(a.display_snapshot()['scene_leds']),1)
    def test_0125_legacy_grid_is_preserved_as_ac(self):
        previous=blank_matrix();previous[7][4]=127
        m=ModMatrix();m.load(previous);m.load_groups(None)
        self.assertEqual(m.dump(),previous)
        self.assertEqual(m.route(7,4),(0,127))
        self.assertIn(7,m.groups['rows'][4])
        preset=default_state(FixedControls());preset.pop('mod_groups',None)
        preset['mod_matrix']=previous
        parsed=validate_preset(preset,FixedControls())
        self.assertEqual(parsed['mod_matrix'],previous)
        self.assertIn(7,parsed['mod_groups']['rows'][4])
    def test_group_configuration_is_validated(self):
        m=ModMatrix()
        with self.assertRaises(ValueError):m.load_groups({'rows':[[9]]+[[]]*7,'gains':[1]*8})
        with self.assertRaises(ValueError):validate_matrix([[512]*8 for _ in range(8)])
        with self.assertRaises(ValueError):decode(-1)
    def test_seq_mode_unchanged(self):
        a,r=self.make_apc()
        self.press(a,101)
        self.press(a,0)
        self.assertTrue(a.pattern.steps[0][0])
        self.press(a,103)
        self.press(a,7)
        self.assertTrue(a.pattern.steps[0][15])
        self.assertEqual(a.page,1)

if __name__=='__main__':unittest.main()
