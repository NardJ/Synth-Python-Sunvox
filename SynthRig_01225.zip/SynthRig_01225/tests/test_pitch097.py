"""Gerichte controles voor 0.9.7: -12 kalibratie, geen wijziging SunVox formule."""
from pathlib import Path
import sys,unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from test_09 import FakeSlot
from synthrig.engine09 import SynthRig, midi_frequency
from sunvox.api import NOTECMD

class Test097(unittest.TestCase):
    def setUp(self):self.slot=FakeSlot();self.rig=SynthRig(self.slot)
    def test_default_calibration_and_pitch_event(self):
        self.assertEqual(self.rig.pitch_calibration_semitones,-12)
        self.rig.note_on(60,110)
        events=[e for e in self.slot.events if e[1]==NOTECMD.SET_PITCH]
        self.assertEqual(len(events),3)
        self.assertEqual(events[0][5],self.rig._native_pitch(48))
        self.assertEqual(events[1][5],self.rig._native_pitch(60))
        self.assertEqual(events[2][5],self.rig._native_pitch(36))
    def test_calibration_user_adjustable(self):
        slot=FakeSlot();rig=SynthRig(slot,pitch_calibration_semitones=0)
        rig.note_on(60,100)
        events=[e for e in slot.events if e[1]==NOTECMD.SET_PITCH]
        self.assertEqual(events[0][5],rig._native_pitch(60))
    def test_waveform_readback(self):
        self.rig.set_waveform_index(1,0)
        for item in self.rig.waveform_readback():
            self.assertEqual(item['osc1_requested'],5)
            self.assertEqual(item['osc1_actual'],5)
    def test_volume_is_unity(self):
        self.assertEqual(self.rig.vibrato_volume_readback(),{'lfo':256,'mod':256})
    def test_pitch_still_formula_correct(self):
        self.assertAlmostEqual(midi_frequency(60),261.625565,places=5)
        native=self.rig._native_pitch(60)
        from math import pow
        self.assertAlmostEqual(pow(2,(30720-native)/3072)*16.333984375,261.625565,delta=.04)

if __name__=='__main__':unittest.main()
