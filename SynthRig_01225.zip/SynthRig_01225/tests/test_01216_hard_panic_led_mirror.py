"""0.12.16 full LED mirror plus hard PANIC source and bank invariants."""
import unittest
from types import SimpleNamespace
from tempfile import TemporaryDirectory
from unittest.mock import patch
from mido import Message
from test_synthrig import FakeSlot
from synthrig.engine09 import SynthRig
from synthrig.fixed_controls import FixedControls
from synthrig.midimix_hw import MidiMixLEDs,desired_leds
from synthrig.midimix_events import handle_bank_press
from synthrig.presets import PresetManager
from synthrig.session_state import default_state,apply_state
from synthrig.apc_mk2 import APCminiMk2
from sunvox.api import NOTECMD


class Out:
    def __init__(self):self.sent=[]
    def send(self,msg):self.sent.append(msg)


class MirrorAndPanic(unittest.TestCase):
    def setUp(self):
        self.tmp=TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.c=FixedControls()
        self.r=SynthRig(FakeSlot(),offline=True)
        apply_state(self.r,self.c,default_state(self.c))
        self.pm=PresetManager(self.c,self.tmp.name)
        self.out=Out()
        self.leds=MidiMixLEDs(self.out,self.c)
        self.leds.sync(self.c.button_state(self.r),force=True)

    def verify_hardware_equals_snapshot(self):
        # Exact state of last MIDI Note-On for every LED matches monitor.
        actual={}
        for msg in self.out.sent:
            actual[msg.note]=msg.velocity>0
        mirror={int(k):v for k,v in self.leds.display_snapshot()['notes'].items()}
        self.assertEqual(actual,mirror)

    def test_bank_16_snapshots_and_restore_no_stale_leds(self):
        for number in range(1,17):
            msg=Message('note_on',channel=0,note=26,velocity=127)
            handle_bank_press(msg,self.c,self.pm,self.r,leds=self.leds)
            state=self.leds.display_snapshot()
            self.assertTrue(state['overlay'])
            self.assertEqual(state['preset'],number)
            self.assertEqual(sum(state['notes'].values()),number)
            self.verify_hardware_equals_snapshot()
            self.leds.preset_until=0.0
            self.leds.tick(self.c.button_state(self.r))
            state=self.leds.display_snapshot()
            self.assertFalse(state['overlay'])
            self.assertIsNone(state['preset'])
            self.assertEqual(state['notes'],{str(k):v for k,v in desired_leds(self.c,self.c.button_state(self.r)).items()})
            self.verify_hardware_equals_snapshot()

    def test_two_quick_bank_presses_only_final_preset_shown_then_restored(self):
        with patch('synthrig.midimix_hw.time.monotonic',return_value=500.):
            for _ in range(2):
                handle_bank_press(Message('note_on',channel=0,note=26,velocity=127),self.c,self.pm,self.r,leds=self.leds)
            self.assertEqual(self.leds.display_snapshot()['preset'],2)
            self.assertEqual(sum(self.leds.display_snapshot()['notes'].values()),2)
        with patch('synthrig.midimix_hw.time.monotonic',return_value=501.01):
            self.leds.tick(self.c.button_state(self.r))
            self.assertFalse(self.leds.display_snapshot()['overlay'])
        self.verify_hardware_equals_snapshot()

    def test_panic_cleans_all_sunvox_buffers_not_only_notes(self):
        self.r.note_on(60,100)
        self.assertTrue(self.r.active_notes)
        self.r.panic()
        self.assertFalse(self.r.active_notes)
        # Clean Synths command is defined officially as 130, module zero.
        self.assertTrue(any((len(evt)>=2 and int(evt[1])==int(NOTECMD.CLEAN_SYNTHS))
                            for evt in self.r.slot.events))
        self.r.note_on(64,100)
        self.assertIn(64,self.r.active_notes)

    def test_apc_panic_uses_same_audio_clean_and_stops_transport(self):
        with TemporaryDirectory() as temp:
            apc=APCminiMk2(None,self.r,pattern_dir=temp,logger=lambda _:None)
            apc.router.on('swing',60,90)
            apc.router.on('apc',62,90)
            apc.set_playing(True)
            apc.preview(0,0)
            apc.handle(Message('note_on',note=107,velocity=127,channel=0))
            self.assertFalse(apc.playing)
            self.assertEqual(apc.router.held,{'swing':set(),'apc':set(),'preview':set()})
            self.assertIsNone(apc.preview_until)
            self.assertFalse(self.r.active_notes)
            self.assertTrue(any(int(e[1])==130 for e in self.r.slot.events))
            apc.close()

    def test_bank_does_not_clean_effect_buffers(self):
        self.r.note_on(60,90)
        before=sum(int(e[1])==130 for e in self.r.slot.events)
        handle_bank_press(Message('note_on',channel=0,note=26,velocity=127),self.c,self.pm,self.r,leds=self.leds)
        after=sum(int(e[1])==130 for e in self.r.slot.events)
        self.assertEqual(before,after)

if __name__=='__main__':unittest.main()
