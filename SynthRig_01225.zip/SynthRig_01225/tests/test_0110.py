"""Preset persistence, A/B restoration and effect routing without MIDI hardware."""
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from test_synthrig import FakeSlot
from synthrig.engine09 import SynthRig
from synthrig.fixed_controls import FixedControls
from synthrig.presets import PresetManager,validate_preset
from synthrig.session_state import capture_state,default_state,apply_state,load_state,save_state


class V0110(unittest.TestCase):
    def setUp(self):
        self.temp=TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.rig=SynthRig(FakeSlot(),offline=True)
        self.controls=FixedControls()
        apply_state(self.rig,self.controls,default_state(self.controls))
        self.p=PresetManager(self.controls,self.temp.name)

    def test_sixteen_factory_presets(self):
        self.assertEqual(len(self.p.slots()),16)
        for ident,name,state in self.p.all():
            validate_preset(state,self.controls)
            self.assertTrue(name)

    def test_preset_load_and_soft_pickup(self):
        self.p.load('5',self.rig)
        self.assertEqual(self.rig.wave_selection[1],1)
        self.assertEqual(round(self.rig.reverb_mix*127),72)
        self.assertEqual(len(self.controls.pickup),len(self.controls.mappings))

    def test_compare_ab_preserves_fx_and_raw(self):
        self.rig.set_parameter('effects.delay',55)
        self.controls.target_raw['osc1.level']=32
        self.p.load('5',self.rig)
        self.assertIn('A:',self.p.compare(self.rig))
        self.assertEqual(round(self.rig.delay_mix*127),55)
        self.assertEqual(self.controls.target_raw['osc1.level'],32)
        self.assertIn('B:',self.p.compare(self.rig))
        self.assertEqual(round(self.rig.reverb_mix*127),72)

    def test_save_load_user(self):
        self.rig.set_parameter('effects.reverb',39)
        self.p.save('Mijn Test Klank',self.rig)
        self.assertIn(('mijn-test-klank','Mijn Test Klank'),self.p.listings())
        self.rig.set_parameter('effects.reverb',0)
        self.p.load('mijn-test-klank',self.rig)
        self.assertEqual(round(self.rig.reverb_mix*127),39)

    def test_no_overwrite_or_path_escape(self):
        self.p.save('Safe',self.rig)
        with self.assertRaises(FileExistsError):self.p.save('Safe',self.rig)
        with self.assertRaises(ValueError):self.p.save('../unsafe',self.rig)

    def test_reject_bad_preset(self):
        state=default_state(self.controls)
        state['fx']['delay']=180
        with self.assertRaises(ValueError):validate_preset(state,self.controls)

    def test_legacy_session_no_fx(self):
        with TemporaryDirectory() as p:
            dest=Path(p)/'state.json'
            old=default_state(self.controls)
            del old['fx']
            dest.write_text(json.dumps(old))
            actual=load_state(dest,self.controls)
            self.assertEqual(actual['fx'],{'delay':0,'reverb':0})

    def test_effects_wet_zero_by_default(self):
        self.assertEqual(self.rig.delay_mix,0)
        self.assertEqual(self.rig.reverb_mix,0)
        self.rig.set_parameter('effects.reverb',127)
        self.assertEqual(self.rig.reverb_mix,1)
        self.rig.set_parameter('effects.delay',64)
        self.assertAlmostEqual(self.rig.delay_mix,64/127)

    def test_audio_bus_wiring_preserves_dry(self):
        slot=self.rig.slot
        self.assertIn((self.rig.vib_mod,self.rig.output_amp),slot.links)
        self.assertIn((self.rig.vib_mod,self.rig.delay_module),slot.links)
        self.assertIn((self.rig.vib_mod,self.rig.reverb_module),slot.links)
        self.assertIn((self.rig.delay_module,self.rig.output_amp),slot.links)
        self.assertIn((self.rig.reverb_module,self.rig.output_amp),slot.links)

if __name__=='__main__':unittest.main()
