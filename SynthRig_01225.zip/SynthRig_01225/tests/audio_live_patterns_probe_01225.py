"""Actual SunVox PCM across queued 4/8/16-step pattern seams."""
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import numpy as np
import sunvox.dll as dll
from sunvox.api import Slot,init,deinit
from sunvox.types import INIT_FLAG
from synthrig.engine09 import SynthRig
from synthrig.apc_mk2 import APCminiMk2,Pattern
from synthrig.offline0102 import OfflineAudio,RATE,rms,estimate_pitch,apply_baseline

checks=[]
for mode in ('native','events'):
    flags=int(INIT_FLAG.OFFLINE|INIT_FLAG.AUDIO_FLOAT32|INIT_FLAG.ONE_THREAD|INIT_FLAG.NO_DEBUG_OUTPUT)
    assert init(None,RATE,2,flags)>=0
    try:
        with Slot() as slot,TemporaryDirectory() as temp:
            rig=SynthRig(slot,offline=True,pitch_lfo_mode=mode)
            apply_baseline(rig)
            for key in ('chorus','delay','reverb'):rig.set_parameter('effects.'+key,0)
            assert slot.play()>=0
            with OfflineAudio(rig,dll) as driver:
                for length in (4,8,16):
                    rig.all_notes_off();driver.render(.2)
                    apc=APCminiMk2(None,rig,pattern_dir=temp,logger=lambda _:None)
                    apc.mode='seq';apc.pattern=Pattern(length=length,bpm=120)
                    apc.pattern.notes[0]=48;apc.pattern.steps[0]=[True]*16;apc.pattern.ties[0]=[True]*16
                    target=Pattern(length=8,bpm=90)
                    target.notes[0]=60;target.steps[0]=[True]*16;target.ties[0]=[True]*16
                    (Path(temp)/'apc_02.json').write_text(json.dumps(target.dump()))
                    trace=[];origin=driver.clock
                    original_on=rig.note_on;original_off=rig.note_off
                    def on(note,velocity):trace.append(('on',note,driver.clock-origin));return original_on(note,velocity)
                    def off(note):trace.append(('off',note,driver.clock-origin));return original_off(note)
                    rig.note_on=on;rig.note_off=off
                    apc.set_playing(True,driver.clock)
                    chunks=[]
                    def render(seconds):
                        end=driver.clock+seconds
                        while driver.clock<end-.001:
                            apc.tick(driver.clock);chunks.append(driver.render(.005))
                        apc.tick(driver.clock)
                    render(.18)
                    apc.select_pattern(1,driver.clock)
                    still_old=apc.playing and apc.bank==0 and 48 in rig.active_notes
                    render(length*.125+.25-.18)
                    audio=np.concatenate(chunks)[:,0]
                    attacks=[event for event in trace if event[0]=='on']
                    new=next((event[2] for event in attacks if event[1]==60),None)
                    ok=False;old_hz=new_hz=seam=None
                    if new is not None:
                        old_hz=estimate_pitch(audio[round(.03*RATE):round(.17*RATE)])
                        new_hz=estimate_pitch(audio[round((new+.03)*RATE):round((new+.18)*RATE)])
                        seam=rms(audio[round((new-.02)*RATE):round((new+.02)*RATE)])
                        old_off=next(event[2] for event in trace if event[0]=='off' and event[1]==48)
                        ok=(still_old and apc.playing and apc.bank==1 and apc.pattern.bpm==120
                            and len(attacks)==2 and abs(new-length*.125)<.04
                            and old_off==new and old_hz is not None and new_hz is not None
                            and abs(old_hz-130.813)<2.5 and abs(new_hz-261.626)<2.5 and seam>1e-3)
                    entry={'mode':mode,'old_loop_length':length,'switch_seconds':new,
                           'old_hz':old_hz,'new_hz':new_hz,'seam_rms':seam,
                           'attacks':len(attacks),'tempo_after':apc.pattern.bpm,
                           'status':'PASS' if ok else 'FAIL'}
                    checks.append(entry);print(entry,flush=True)
                    apc.close();rig.note_on=original_on;rig.note_off=original_off
    finally:deinit()
report={'version':'0.12.25','PASS':sum(c['status']=='PASS' for c in checks),
        'FAIL':sum(c['status']=='FAIL' for c in checks),'checks':checks}
path=Path('reports_01225/audio_live_patterns.json');path.parent.mkdir(exist_ok=True)
path.write_text(json.dumps(report,indent=2)+'\n')
print('LIVE PATTERN AUDIO SUMMARY',report['PASS'],report['FAIL'],flush=True)
if report['FAIL']:raise SystemExit(1)
