import os,socket,tkinter as tk
from pathlib import Path
from midimix_debug import MidiMixMonitor,MUTE_NOTES,REC_NOTES,AMBER,RED
root=tk.Tk()
s=socket.socket();s.bind(('127.0.0.1',0));port=s.getsockname()[1];s.close()
m=MidiMixMonitor(root,port)
root.update()
initial=m.engine_state.copy()
# exact hardware output payload at preset 11 -> buttons must match real sent notes
notes={str(k):i<11 for i,k in enumerate(MUTE_NOTES+REC_NOTES)}
m.set_midimix_leds({'notes':notes,'overlay':True,'preset':11,'revision':16})
root.update()
for i in range(8):
    canvasid,_=m.button_parts[f'mute_{i}']
    assert m.canvas.itemcget(canvasid,'fill')==AMBER
for i in range(8):
    canvasid,_=m.button_parts[f'rec_{i}']
    assert (m.canvas.itemcget(canvasid,'fill')==RED)==(i<3)
# changing engine state must not erase active overlay display
m.set_engine_state({'wave1':1,'wave2':0,'enabled':{'osc1':False,'osc2':False,'sub':False,'noise':False}})
root.update()
for i in range(8):
    item,_=m.button_parts[f'mute_{i}'];assert m.canvas.itemcget(item,'fill')==AMBER
# simulate restore and verify GUI matches complete hardware snapshot
normal={str(k):i in (1,4) for i,k in enumerate(MUTE_NOTES+REC_NOTES)}
m.set_midimix_leds({'notes':normal,'overlay':False,'preset':None,'revision':32})
root.update()
for i,note in enumerate(MUTE_NOTES+REC_NOTES):
    item,_=m.button_parts[f'{"mute" if i<8 else "rec"}_{i%8}']
    expected=AMBER if i<8 else RED
    assert (m.canvas.itemcget(item,'fill')==expected)==normal[str(note)]
print('PASS: MIDImix GUI LED mirror preset 11/16, force state, restore')
m.close()
