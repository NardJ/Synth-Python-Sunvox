"""Run with xvfb-run: full BANK -> hardware MIDI -> UDP -> Tk Canvas test."""
import json
import socket
import tkinter as tk
from pathlib import Path
from types import SimpleNamespace
from tempfile import TemporaryDirectory
from PIL import ImageGrab
from mido import Message
from midimix_debug import MidiMixMonitor,MUTE_NOTES,REC_NOTES,AMBER,RED
from synthrig.debug import OptionalMidiMixDebug
from synthrig.midimix_hw import MidiMixLEDs
from synthrig.midimix_events import handle_bank_press
from synthrig.fixed_controls import FixedControls
from synthrig.presets import PresetManager
from synthrig.engine09 import SynthRig
from synthrig.session_state import apply_state,default_state
from test_synthrig import FakeSlot

class Output:
    def __init__(self):self.sent=[]
    def send(self,msg):self.sent.append(msg)

class Wire:
    send_preset=OptionalMidiMixDebug.send_preset
    send_values=OptionalMidiMixDebug.send_values
    send_midimix_leds=OptionalMidiMixDebug.send_midimix_leds
    def __init__(self,target):
        self.process=SimpleNamespace(poll=lambda:None)
        self.sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        self.target=target

root=tk.Tk()
socket_probe=socket.socket();socket_probe.bind(('127.0.0.1',0));port=socket_probe.getsockname()[1];socket_probe.close()
monitor=MidiMixMonitor(root,port)
root.update()
wire=Wire(('127.0.0.1',port))
control=FixedControls()
with TemporaryDirectory() as folder:
    rig=SynthRig(FakeSlot(),offline=True)
    apply_state(rig,control,default_state(control))
    presets=PresetManager(control,folder)
    out=Output();led=MidiMixLEDs(out,control)
    for number in range(1,17):
        before=len(out.sent)
        handle_bank_press(Message('note_on',channel=0,note=26,velocity=127),
                          control,presets,rig,led,wire)
        assert len(out.sent)-before==16
        monitor.poll();root.update()
        assert monitor.led_overlay and monitor.led_preset==number,(number,monitor.led_preset)
        assert sum(monitor.midimix_leds.get(n,False) for n in MUTE_NOTES+REC_NOTES)==number
        for i in range(16):
            key=('mute' if i<8 else 'rec')+f'_{i%8}'
            button,_=monitor.button_parts[key]
            label=monitor.preset_number_parts[key]
            assert monitor.canvas.itemcget(label,'text')==str(i+1)
            assert (monitor.canvas.itemcget(button,'fill')==(AMBER if i<8 else RED))==(i<number)
        if number==11:
            root.update()
            screenshot=Path('/mnt/data/SynthRig_01218_leds_debug.png')
            # Capture visual proof of actual Tk Canvas, not an illustration.
            x,y=monitor.root.winfo_rootx(),monitor.root.winfo_rooty()
            w,h=monitor.canvas.winfo_width(),monitor.canvas.winfo_height()
            ImageGrab.grab(bbox=(x,y,x+w,y+h)).save(screenshot)
            print('SCREENSHOT',screenshot,flush=True)
    # State changes must not hide an active preset count.
    monitor.set_engine_state({'wave1':1,'wave2':2,'enabled':{}})
    root.update()
    assert monitor.canvas.itemcget(monitor.preset_number_parts['rec_7'],'text')=='16'
    led.preset_until=0
    led.tick(control.button_state(rig))
    wire.send_midimix_leds(led.display_snapshot())
    monitor.poll();root.update()
    assert not monitor.led_overlay
    assert all(not monitor.canvas.itemcget(t,'text') for t in monitor.preset_number_parts.values())
    assert all(monitor.midimix_leds.get(k)==v for k,v in ((int(k),v) for k,v in led.display_snapshot()['notes'].items()))
    print('PASS: 16 BANK->MIDI LED->UDP->Tk counters; visual numbered buttons; restore; state changes',flush=True)
    wire.sock.close();monitor.close()
