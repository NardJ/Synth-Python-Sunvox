"""0.12.0: APC Mk2 protocol, dual MIDI input, note safety, 16-step sequencer."""
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock
import mido

from synthrig.mod_matrix import ModMatrix,DEFAULT_DEPTH
from synthrig.apc_mk2 import (APCminiMk2, NoteRouter, Pattern, choose_control_port,
                              PATCH_TARGETS, PAD_LED_CHANNEL)

class FakeRig:
    def __init__(self):
        self.calls=[];self.mod_matrix=ModMatrix()
    def note_on(self,note,velocity):self.calls.append(('on',note,velocity))
    def note_off(self,note):self.calls.append(('off',note))
    def all_notes_off(self):self.calls.append(('panic',))
    def set_parameter(self,target,raw):self.calls.append(('set',target,raw))
    def tick(self,**kwargs):pass

class FakeOut:
    def __init__(self):self.messages=[]
    def send(self,msg):self.messages.append(msg)

class FakeControls:
    def __init__(self):
        self.target_raw={t:0 for _,t in PATCH_TARGETS};self.pickup=[]
    def arm_pickup(self,targets):self.pickup.append(set(targets))

class APCTests(unittest.TestCase):
    def setup_apc(self,clock='internal'):
        self.folder=tempfile.TemporaryDirectory()
        self.addCleanup(self.folder.cleanup)
        self.rig=FakeRig();self.out=FakeOut();self.controls=FakeControls()
        self.apc=APCminiMk2(self.out,self.rig,self.controls,self.folder.name,clock,logger=lambda _:None)
        return self.apc

    def press(self,note):return self.apc.handle(mido.Message('note_on',note=note,velocity=127),now=0.)

    def test_port_selection_prefers_control(self):
        self.assertEqual(choose_control_port(['APC mini mk2 Notes 2','APC mini mk2 Control 1']),
                         'APC mini mk2 Control 1')
        self.assertIsNone(choose_control_port(['APC mini mk2 Notes 2','APC mini']))

    def test_grid_orientation_protocol(self):
        self.setup_apc()
        pad0=next(m for m in self.out.messages if m.type=='note_on')
        self.assertEqual((pad0.type,pad0.channel,pad0.note),('note_on',PAD_LED_CHANNEL,0))
        self.assertIn(56,[m.note for m in self.out.messages if m.type=='note_on' and m.channel==PAD_LED_CHANNEL])
        self.assertEqual(len([m for m in self.out.messages if m.type=='note_on' and m.channel==PAD_LED_CHANNEL]),64)

    def test_patch_toggles_real_route_without_mutating_midimix(self):
        self.setup_apc()
        self.press(63) # row 7, destination OSC2 level
        self.assertEqual(self.rig.mod_matrix.grid[7][7],DEFAULT_DEPTH)
        self.assertEqual(self.controls.target_raw['OSC2 LEVEL'],0)
        self.press(63)  # next variant, not off
        self.assertEqual(self.rig.mod_matrix.grid[7][7],128+DEFAULT_DEPTH)
        for _ in range(3):self.press(63)
        self.assertIsNone(self.rig.mod_matrix.grid[7][7])

    def test_patch_has_independent_8x8_routing(self):
        self.setup_apc()
        self.assertEqual(len(PATCH_TARGETS),8)
        self.assertEqual(self.apc.mode,'patch')
        self.press(0);self.press(1)
        self.assertEqual(self.rig.mod_matrix.grid[0][0],DEFAULT_DEPTH)
        self.assertEqual(self.rig.mod_matrix.grid[0][1],DEFAULT_DEPTH)

    def test_seq_page_switch_and_16_steps(self):
        self.setup_apc()
        self.press(101)
        self.press(0)
        self.press(103)
        self.press(7)
        self.assertTrue(self.apc.pattern.steps[0][0])
        self.assertTrue(self.apc.pattern.steps[0][15])
        self.assertEqual(self.apc.page,1)

    def test_note_router_keeps_swing_notes(self):
        r=NoteRouter(FakeRig())
        r.on('swing',60,98);r.on('apc',60,110)
        r.off('apc',60)
        self.assertEqual(r.rig.calls,[('on',60,98)])
        r.off('swing',60)
        self.assertEqual(r.rig.calls[-1],('off',60))

    def test_note_router_keeps_apc_notes(self):
        r=NoteRouter(FakeRig())
        r.on('apc',60,110);r.on('swing',60,98)
        r.off('swing',60)
        self.assertEqual(r.rig.calls,[('on',60,110)])
        r.off('apc',60)
        self.assertEqual(r.rig.calls[-1],('off',60))

    def test_pattern_save_load_restore(self):
        self.setup_apc()
        self.press(101);self.press(0)
        self.press(105)
        saved=Path(self.folder.name)/'apc_01.json'
        self.assertTrue(saved.is_file())
        self.apc.pattern.steps[0][0]=False
        self.press(106)
        self.assertTrue(self.apc.pattern.steps[0][0])

    def test_eight_pattern_slots(self):
        self.setup_apc()
        self.press(101);self.press(119) # slot 8 in SEQ
        self.assertEqual(self.apc.bank,7)
        self.press(105)
        self.assertTrue((Path(self.folder.name)/'apc_08.json').exists())

    def test_faders_pitch_velocity_and_tempo(self):
        self.setup_apc();self.press(101)
        self.apc.handle(mido.Message('control_change',control=48,value=127))
        self.assertEqual(self.apc.pattern.notes[0],84)
        self.apc.handle(mido.Message('note_on',note=122,velocity=127))
        self.apc.handle(mido.Message('control_change',control=48,value=45))
        self.assertEqual(self.apc.pattern.velocity[0],45)
        self.apc.handle(mido.Message('note_off',note=122))
        self.apc.handle(mido.Message('control_change',control=56,value=127))
        self.assertEqual(self.apc.pattern.bpm,180)

    def test_tick_plays_and_releases_note(self):
        self.setup_apc()
        self.press(101);self.press(0)
        self.press(104)
        self.apc.tick(0)
        self.assertIn(('on',48,100),self.rig.calls)
        self.apc.tick(.08)
        self.assertIn(('off',48),self.rig.calls)
        self.press(104)
        self.assertFalse(self.apc.playing)

    def test_external_clock_midi(self):
        self.setup_apc(clock='swing')
        self.press(101);self.press(0)
        self.apc.swing_clock(mido.Message('start'),0)
        for i in range(6):self.apc.swing_clock(mido.Message('clock'),.01*i)
        self.assertEqual(self.apc.step,0)
        self.assertIn(('on',48,100),self.rig.calls)
        self.apc.swing_clock(mido.Message('stop'),1)
        self.assertIn(('off',48),self.rig.calls)

    def test_close_turns_off_leds(self):
        self.setup_apc();self.apc.close()
        self.assertEqual(self.out.messages[-1].velocity,0)

    def test_corrupt_pattern_rejected(self):
        self.setup_apc()
        f=Path(self.folder.name)/'apc_01.json'
        f.write_text(json.dumps({'version':1,'notes':[0]}))
        with self.assertRaises((KeyError,ValueError)):self.apc.load_pattern()

    def test_mode_switch_safe_when_no_hardware(self):
        self.setup_apc()
        self.apc.output=None
        self.press(101);self.press(104);self.apc.tick(0.0)
        self.press(100)
        self.apc.close()

if __name__=='__main__':unittest.main()
