"""0.12.15 no-loss upgrade priorities and independent test-running invariants."""
import ast
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from synthrig.upgrade0111 import migrate_0110

ROOT=Path(__file__).resolve().parents[1]

class UpgradeInvariants(unittest.TestCase):
    def test_latest_version_first_in_all_three_migration_lists(self):
        src=(ROOT/'synthrig_01219.py').read_text()
        tree=ast.parse(src)
        lists=[]
        for node in ast.walk(tree):
            if isinstance(node,ast.Tuple):
                values=[e.value for e in node.elts if isinstance(e,ast.Constant) and isinstance(e.value,str)]
                if 'SynthRig_01213' in values and len(values)>10:
                    lists.append(values)
        self.assertEqual(len(lists),3,'sessie, patronen en gain moeten expliciet worden gemigreerd')
        for names in lists:
            self.assertEqual(names[0],'SynthRig_01218')
            self.assertEqual(len(names),len(set(names)))

    def test_prefer_newest_and_preserve_new_files(self):
        with TemporaryDirectory() as folder:
            parent=Path(folder)
            old14=parent/'SynthRig_01214';old13=parent/'SynthRig_01213';new=parent/'SynthRig_01216'
            for p,data in [(old14,'latest'),(old13,'stale')]:
                (p/'state').mkdir(parents=True)
                (p/'state'/'last_session.json').write_text(data)
                (p/'presets'/'user').mkdir(parents=True)
                (p/'presets'/'user'/'slot_09.json').write_text(data)
            args=(new,new/'state'/'last_session.json',new/'presets'/'user')
            migrate_0110(args[0],old14,args[1],args[2])
            migrate_0110(args[0],old13,args[1],args[2])
            self.assertEqual(args[1].read_text(),'latest')
            self.assertEqual((args[2]/'slot_09.json').read_text(),'latest')
            # A pre-existing user edit has priority over ANY archive.
            args[1].write_text('my current work')
            (args[2]/'slot_09.json').write_text('my own saved patch')
            migrate_0110(args[0],old14,args[1],args[2])
            self.assertEqual(args[1].read_text(),'my current work')
            self.assertEqual((args[2]/'slot_09.json').read_text(),'my own saved patch')

    def test_shared_fake_slot_has_adrs_control_without_test_import_side_effect(self):
        # This failed in 0.12.14 when test_0111 was run separately.
        from test_synthrig import FakeSlot
        self.assertIn('ADSR',FakeSlot.ctl_defs)
        self.assertEqual(len(FakeSlot.ctl_defs['ADSR']),9)
        import inspect
        import test_09
        self.assertNotIn("FakeSlot.ctl_defs['ADSR'] =",inspect.getsource(test_09))

if __name__=='__main__':unittest.main()
