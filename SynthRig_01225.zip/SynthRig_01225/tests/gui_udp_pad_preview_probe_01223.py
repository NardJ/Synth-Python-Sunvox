"""Actual engine/FakeSlot -> immediate pad audition -> real Tk/UDP note display."""
import socket
import time
import tkinter as tk
from tempfile import TemporaryDirectory
from types import SimpleNamespace

from mido import Message
from midimix_debug import MidiMixMonitor, ASSIGNMENTS, read_assignments
from synthrig.debug import OptionalMidiMixDebug
from synthrig.apc_mk2 import APCminiMk2
from synthrig.fixed_controls import FixedControls
from synthrig.session_state import default_state, apply_state
from test_synthrig import FakeSlot
from synthrig.engine09 import SynthRig


class Wire:
    send_apc_status = OptionalMidiMixDebug.send_apc_status
    send_swing = OptionalMidiMixDebug.send_swing
    send_values = OptionalMidiMixDebug.send_values
    def __init__(self, port):
        self.process = SimpleNamespace(poll=lambda: None)
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.target = ('127.0.0.1', port)


root = tk.Tk()
ASSIGNMENTS.update(read_assignments('config/midimix_091.json'))
window = MidiMixMonitor(root, 0)
wire = Wire(window.socket.getsockname()[1])
root.update()
try:
    with TemporaryDirectory() as temp:
        rig = SynthRig(FakeSlot(), offline=True)
        controls = FixedControls()
        apply_state(rig, controls, default_state(controls))
        apc = APCminiMk2(None, rig, pattern_dir=temp, logger=lambda _: None)
        now = time.monotonic()

        def press(pad, at):
            return apc.handle(Message('note_on', note=pad, velocity=127), at)

        def show():
            wire.send_apc_status(apc.display_snapshot())
            wire.send_swing(rig.swing_ui_state())
            window.poll();root.update()

        press(101, now)
        press(0, now)
        show()
        assert 48 in rig.active_notes and not apc.playing
        assert window.canvas.itemcget(window.notes_label, 'text') == 'NOTEN  48'
        assert apc.pattern.steps[0][0]
        apc.tick(now + .251)
        show()
        assert not rig.active_notes
        assert window.canvas.itemcget(window.notes_label, 'text') == 'NOTEN  —'
        print('PASS: pad-on immediately sounds through real engine gate path; UDP/Tk shows note 48 and clears after timeout')

        press(0, now + .3)
        show()
        assert 48 in rig.active_notes and not apc.pattern.steps[0][0]
        apc.tick(now + .551)
        assert not rig.active_notes
        print('PASS: turning a step off also auditions without leaving that step enabled')

        apc.handle(Message('control_change', control=48, value=127), now + .6)
        press(1, now + .61)
        show()
        assert 84 in rig.active_notes
        assert window.canvas.itemcget(window.notes_label, 'text') == 'NOTEN  84'
        assert window.apc_monitor.canvas.itemcget(window.apc_monitor.row_text[0][0], 'text') == '84'
        apc.tick(now + .861)
        print('PASS: lane pitch from physical fader is used for both audition and the row/note displays')

        apc.router.on('swing', 84, 90)
        voice = rig.active_notes[84]
        before = len(rig.slot.events)
        press(2, now + .9)
        apc.tick(now + 1.2)
        assert rig.active_notes[84] == voice
        assert len(rig.slot.events) == before
        apc.router.clear('swing')
        print('PASS: a SWING-held pitch is neither retriggered nor cut by preview Note Off')

        for note in (61,63,65,66):apc.router.on('swing',note,90)
        before = dict(rig.active_notes)
        result = press(56, now + 1.3)
        assert rig.active_notes == before and 'stemmen bezet' in result
        assert apc.pattern.steps[7][0]
        apc.router.clear('swing')
        print('PASS: four actual engine voices remain untouched; pad edit survives a skipped busy preview')

        press(0, now + 1.4)
        assert apc.router.held['preview']
        press(107, now + 1.41)
        show()
        assert not rig.active_notes and apc.preview_until is None
        assert any(int(event[1]) == 130 for event in rig.slot.events)
        print('PASS: APC PANIC clears preview, timer and native effect-clean command')
finally:
    wire.sock.close()
    window.close()
