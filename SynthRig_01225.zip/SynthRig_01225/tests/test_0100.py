"""0.10.0 expressive control regression: pure Python FakeSlot and state migration."""
from __future__ import annotations
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import sys
import unittest
from types import SimpleNamespace
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from test_09 import FakeSlot
from synthrig.engine09 import SynthRig
from synthrig.fixed_controls import FixedControls
from synthrig.session_state import default_state,load_state,apply_state


class V0100(unittest.TestCase):
    def setUp(self):
        self.s=FakeSlot()
        self.r=SynthRig(self.s,offline=True)

    def test_three_new_knobs_have_no_existing_mapping_conflicts(self):
        c=FixedControls()
        self.assertEqual({cc:c.mappings[cc]['target'] for cc in (58,59,60)},
                         {58:'performance.velocity',59:'performance.portamento',60:'effects.chorus'})
        self.assertEqual(len(set(x['target'] for x in c.mappings.values())),len(c.mappings))

    def test_velocity_is_normalized_at_input_then_scaled_per_voice(self):
        self.r.set_parameter('performance.velocity',127)
        self.r.note_on(60,26)
        v=self.r.voices[self.r.active_notes[60]]
        small=self.s.get_module_ctl_value(v.velocity_amp,v.ctls['velocity_vol'][0],0)
        self.assertLess(small,70)
        self.assertTrue(all(e[2]==127 for e in self.s.events if 1<=e[1]<=127))
        self.r.note_off(60)
        self.r.note_on(64,127)
        v=self.r.voices[self.r.active_notes[64]]
        self.assertEqual(self.s.get_module_ctl_value(v.velocity_amp,v.ctls['velocity_vol'][0],0),256)

    def test_velocity_disabled_is_level_independent(self):
        self.r.set_parameter('performance.velocity',0)
        self.r.note_on(60,3)
        v=self.r.voices[self.r.active_notes[60]]
        self.assertEqual(self.s.get_module_ctl_value(v.velocity_amp,v.ctls['velocity_vol'][0],0),256)

    def test_performance_portamento_is_phasestable_pitch_event(self):
        self.r.set_parameter('performance.portamento',100)
        self.r.note_on(60,100)
        self.r.note_off(60)
        self.r.note_on(72,100)
        v=self.r.voices[self.r.active_notes[72]]
        self.assertEqual(v.glide_from,-12)
        self.assertGreater(v.glide_seconds,.3)
        self.s.events.clear()
        self.r.tick(now=v.glide_started+.15,force=True)
        self.assertFalse(any(ev[1]==133 for ev in self.s.events))
        self.assertTrue(any(ev[4] in (5,6) for ev in self.s.events))
        self.assertAlmostEqual(self.r._glide_offset(v,v.glide_started+v.glide_seconds),0)

    def test_performance_glide_zero_and_panic_clears_history(self):
        self.r.set_parameter('performance.portamento',0)
        self.r.note_on(60,100)
        self.r.note_on(62,100)
        self.assertEqual(self.r.voices[self.r.active_notes[62]].glide_from,0)
        self.r.all_notes_off()
        self.assertIsNone(self.r._previous_note)

    def test_channel_aftertouch_all_voices_poly_aftertouch_one(self):
        self.r.note_on(60,120)
        self.r.note_on(64,120)
        self.r.handle_swing(SimpleNamespace(type='polytouch',note=60,value=100))
        self.assertGreater(self.r.voices[self.r.active_notes[60]].pressure,.7)
        self.assertEqual(self.r.voices[self.r.active_notes[64]].pressure,0)
        self.r.handle_swing(SimpleNamespace(type='aftertouch',value=127))
        self.assertEqual(self.r.channel_pressure,1.0)
        self.r.handle_swing(SimpleNamespace(type='aftertouch',value=0))
        self.assertEqual(self.r.channel_pressure,0.0)

    def test_chorus_initially_wet_zero_and_softens_control_changes(self):
        self.assertEqual(len(self.r.chorus),2)
        self.assertEqual(len(self.r.chorus_ctl),2)
        for mod,ctl in zip(self.r.chorus,self.r.chorus_ctl):
            self.assertEqual(self.s.get_module_ctl_value(mod,ctl[0],0),0)
        self.r.set_parameter('effects.chorus',127)
        self.assertLessEqual(self.r._last_chorus_wet,172)
        for _ in range(120):self.r.tick(now=self.r._last_tick+.016,force=True)
        self.assertEqual(self.r._last_chorus_wet,172)

    def test_pre_0100_state_migrates_without_losing_existing_parameters(self):
        controls=FixedControls()
        state=default_state(controls)
        for cc in ('58','59','60'):state['layout_targets'].pop(cc)
        for k in ('performance.velocity','performance.portamento','effects.chorus'):
            state['raw'].pop(k)
        state['raw']['osc1.finetune']=80
        state['raw']['filter.cutoff']=62
        state['waveforms']['1']=1
        with TemporaryDirectory() as d:
            path=Path(d)/'old_state.json'
            path.write_text(json.dumps(state),encoding='utf8')
            loaded=load_state(path,controls)
            self.assertIsNotNone(loaded)
            self.assertEqual(loaded['raw']['osc1.finetune'],80)
            self.assertEqual(loaded['raw']['filter.cutoff'],62)
            self.assertEqual(loaded['raw']['performance.portamento'],0)
            apply_state(self.r,controls,loaded,pickup=True)
            self.assertEqual(self.r.wave_selection[1],1)
            self.assertEqual(self.r.osc_tuning[1]['cents'],round(100*((80-64)/63)))
            self.assertEqual(len(controls.target_raw),len(controls.mappings))


if __name__=='__main__':unittest.main()
