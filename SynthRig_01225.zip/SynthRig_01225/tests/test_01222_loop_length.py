"""4/8/16-step playback, hardware gestures and lossless pattern persistence."""
import copy
import json
import tempfile
import unittest
from pathlib import Path

from mido import Message
from synthrig.apc_mk2 import APCminiMk2, Pattern, DIM, GREEN
from test_0120 import FakeRig, FakeOut


class LoopLengthTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.rig, self.out = FakeRig(), FakeOut()
        self.apc = APCminiMk2(self.out, self.rig, pattern_dir=self.temp.name,
                              logger=lambda _: None)
        self.press(101)

    def press(self, note, now=0):
        return self.apc.handle(Message('note_on', note=note, velocity=127), now)

    def release_shift(self):
        self.apc.handle(Message('note_off', note=122), 0)

    def choose(self, length):
        self.press(122)
        self.press({4: 112, 8: 113, 16: 114}[length])
        self.release_shift()

    def test_each_shift_scene_button_selects_length_without_changing_bank(self):
        for length in (4, 8, 16):
            self.choose(length)
            self.assertEqual(self.apc.pattern.length, length)
            self.assertEqual(self.apc.bank, 0)
            self.assertEqual(self.apc.status()['length'], length)

    def test_remaining_shift_scene_buttons_do_not_select_a_pattern_or_stop_playback(self):
        self.apc.set_playing(True, 0)
        self.press(122)
        for note in range(115, 120):
            self.press(note)
        self.assertEqual(self.apc.bank, 0)
        self.assertTrue(self.apc.playing)

    def test_unmodified_scene_buttons_still_select_all_eight_patterns(self):
        for index in range(8):
            self.press(112 + index)
            self.assertEqual(self.apc.bank, index)

    def test_patch_shift_scene_gesture_does_not_change_sequence_length(self):
        self.press(100)
        before = self.apc.rig.mod_matrix.dump()
        self.press(122)
        self.press(112)
        self.assertEqual(self.apc.pattern.length, 16)
        self.assertEqual(before, self.apc.rig.mod_matrix.dump())

    def test_internal_playback_repeats_exactly_the_selected_number_of_steps(self):
        for length in (4, 8, 16):
            with self.subTest(length=length):
                self.apc.set_playing(False, 0)
                self.choose(length)
                self.apc.pattern.steps[0] = [True] * 16
                self.apc.set_playing(True, 0)
                for index in range(length * 3):
                    self.apc.tick(index * .125)
                    self.assertEqual(self.apc.step, index % length)

    def test_only_step_one_note_repeats_once_per_loop_and_hidden_notes_do_not_sound(self):
        self.choose(4)
        self.apc.pattern.steps[0][0] = True
        self.apc.pattern.steps[1][4] = True  # stored step 5 outside loop
        self.apc.pattern.steps[2][15] = True  # stored step 16 outside loop
        self.apc.set_playing(True, 0)
        for index in range(12):
            self.apc.tick(index * .125)
        ons = [call for call in self.rig.calls if call[0] == 'on']
        self.assertEqual(ons, [('on', 48, 100)] * 3)

    def test_swing_clock_loops_4_8_and_16_without_changing_clock_resolution(self):
        self.apc.set_clock('swing', 0)
        for length in (4, 8, 16):
            self.choose(length)
            self.apc.swing_clock(Message('start'), 0)
            for tick in range(length * 6 * 3):
                self.apc.swing_clock(Message('clock'), tick / 48)
                self.assertEqual(self.apc.step, (tick // 6) % length)

    def test_stop_continue_preserves_short_loop_and_partial_step(self):
        self.apc.set_clock('swing', 0)
        self.choose(4)
        self.apc.swing_clock(Message('start'), 0)
        for tick in range(21):
            self.apc.swing_clock(Message('clock'), tick / 48)
        self.assertEqual(self.apc.step, 3)
        self.apc.swing_clock(Message('stop'), .5)
        self.apc.swing_clock(Message('continue'), 1)
        for tick in range(4):
            self.apc.swing_clock(Message('clock'), 1.01 + tick / 48)
        self.assertEqual(self.apc.step, 0)

    def test_shortening_during_playback_releases_out_of_range_gate_and_restarts_on_next_step(self):
        self.apc.pattern.steps[0] = [True] * 16
        self.apc.set_playing(True, 0)
        for index in range(10):
            self.apc.tick(index * .125)
        self.assertEqual(self.apc.step, 9)
        self.assertTrue(self.apc.router.held['apc'])
        self.choose(4)
        self.assertTrue(self.apc.playing)
        self.assertFalse(self.apc.router.held['apc'])
        self.assertFalse(self.apc.pending_off)
        self.apc.tick(10 * .125)
        self.assertEqual(self.apc.step, 0)

    def test_shortening_does_not_cut_shared_swing_note(self):
        self.apc.router.on('swing', 48, 90)
        self.apc.router.on('apc', 48, 90)
        self.apc.step = 12
        self.choose(4)
        self.assertEqual(self.apc.router.held['swing'], {48})
        self.assertNotIn(('off', 48), self.rig.calls)

    def test_changing_length_inside_valid_range_keeps_cursor_and_tempo(self):
        self.apc.step = 2
        self.apc.pattern.bpm = 93
        self.choose(4)
        self.assertEqual(self.apc.step, 2)
        self.choose(16)
        self.assertEqual(self.apc.step, 2)
        self.assertEqual(self.apc.pattern.bpm, 93)

    def test_shortening_returns_to_visible_first_page_without_erasing_notes(self):
        self.apc.page = 1
        self.apc.pattern.steps[0][0] = True
        self.apc.pattern.steps[0][8] = True
        self.apc.pattern.steps[0][15] = True
        before = copy.deepcopy(self.apc.pattern.steps)
        self.choose(4)
        self.assertEqual(self.apc.page, 0)
        self.assertEqual(self.apc.pattern.steps, before)
        self.choose(16)
        self.assertEqual(self.apc.pattern.steps, before)

    def test_outside_loop_data_is_dimmed_in_actual_led_commands(self):
        self.apc.pattern.steps[0][0] = True
        self.apc.pattern.steps[0][4] = True
        self.choose(4)
        self.assertEqual(self.apc.last_color[0], GREEN)
        self.assertEqual(self.apc.last_color[4], DIM)
        sent = {(m.channel, m.note): m.velocity for m in self.out.messages if m.type == 'note_on'}
        self.assertEqual(sent[(6, 4)], DIM)
        self.choose(16)
        self.assertEqual(self.apc.last_color[4], GREEN)

    def test_shift_leds_show_length_then_restore_pattern_bank_led(self):
        self.choose(8)
        self.press(122)
        self.assertEqual([self.apc.last_button[n] for n in range(112, 120)],
                         [False, True, False, False, False, False, False, False])
        self.release_shift()
        self.assertEqual([self.apc.last_button[n] for n in range(112, 120)],
                         [True, False, False, False, False, False, False, False])

    def test_each_pattern_slot_keeps_its_own_length_and_full_step_grid(self):
        for slot, length in enumerate((4, 8, 16)):
            self.press(112 + slot)
            self.choose(length)
            self.apc.pattern.steps[0][15] = True
            self.press(105)  # existing SAVE button
        for slot, length in enumerate((4, 8, 16)):
            self.press(112 + slot)
            self.assertEqual(self.apc.pattern.length, length)
            self.assertTrue(self.apc.pattern.steps[0][15])
            stored = json.loads((Path(self.temp.name) / f'apc_{slot+1:02d}.json').read_text())
            self.assertEqual(stored['length'], length)
            self.assertEqual(len(stored['steps'][0]), 16)

    def test_new_controller_loads_saved_length(self):
        self.choose(4)
        self.press(105)
        other = APCminiMk2(None, FakeRig(), pattern_dir=self.temp.name, logger=lambda _: None)
        self.assertEqual(other.pattern.length, 4)

    def test_legacy_pattern_without_length_defaults_to_sixteen(self):
        data = Pattern().dump()
        data.pop('length')
        data['steps'][0][15] = 1
        legacy = Pattern.parse(data)
        self.assertEqual(legacy.length, 16)
        self.assertTrue(legacy.steps[0][15])

    def test_invalid_lengths_are_rejected_without_mutating_current_pattern(self):
        for value in (None, True, False, '8', 4., 0, 3, 5, 32):
            with self.subTest(value=value):
                before = self.apc.pattern.dump()
                with self.assertRaises(ValueError):
                    self.apc.set_length(value)
                self.assertEqual(self.apc.pattern.dump(), before)
                data = Pattern().dump()
                data['length'] = value
                with self.assertRaises(ValueError):
                    Pattern.parse(data)


if __name__ == '__main__':
    unittest.main()
