# SynthRig 0.12.13

- Alle 32 vaste overlaylabels maximaal **8** monospaced tekens (was 7).
- Eenduidigere afkortingen, zoals `O1 PITCH`, `O1 LEVEL`, `KEYTRACK`, `VELOCITY`, `LFO RATE`, `DLY FDBK`.
- Muzikale bruikbaarheidsanalyse van alle 256 mogelijke matrixroutes toegevoegd (CSV, XLSX apart, Markdown).
- **Geen DSP-, modulatie-, MIDI- of presetsemantiek gewijzigd**. Alle paden en ID's zijn identiek aan 0.12.12.
- Presetmigratie probeert eerst 0.12.12.
