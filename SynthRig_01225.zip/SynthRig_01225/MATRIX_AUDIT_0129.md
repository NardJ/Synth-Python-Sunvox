# Volledige modulatiematrix-audit — 0.12.9

**256 van 256 routes per audiomodus** vertonen een meetbare verandering in
de echte offline SunVox-PCM; geen onbesliste routes. In twee modi:
512/512 routeproeven. Alle controller-/routeringscontroles slagen eveneens.

| Audit | Native | Events |
|---|---:|---:|
| Correct gerouteerde routes | 256/256 | 256/256 |
| Meetbare PCM-verandering | 256/256 | 256/256 |
| Onbeslist | 0 | 0 |
| Gecombineerde audit-stresstests | 5/5 | 5/5 |
| Bestaande offline SunVox-regressies | 239/239 | 239/239 |

De noise-fout uit 0.12.8 was geen foute controllerwaarde maar een fout in
de gedeelde nootrouter/pitch-eventafhandeling. In 0.12.9 is dat opgelost.

## Betekenis van de audiometing

Een constant kunstmatig modulatiesignaal test of een route de bedoelde
destination beïnvloedt en de PCM werkelijk verandert. Dat **bewijst niet**
dat iedere natuurlijke bron op elk moment of iedere patch muzikaal even
duidelijk klinkt. Ook zijn niet alle combinaties van gelijktijdige routes
exhaustief getest. Voor de definitieve fysieke overlay blijft beoordeling
van de muzikale bruikbaarheid noodzakelijk.

Details in de bijgevoegde CSV/JSON en TXT-meetrapporten.
