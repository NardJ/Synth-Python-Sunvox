# SAVE, langzamer spelen en lange noten

## Eerst de APC zelfstandig horen

Druk STOP op de SWING. Start SynthRig met `--apc-clock internal`. Kies SEQ met de tweede kleine knop onder het rooster, **TRACK 2**. Met **TRACK 5** start/stop je de APC.

## SAVE

De zesde kleine knop onder het rooster is **TRACK 6 — SAVE**. Na gelukt opslaan:

- De fysieke knop licht één seconde op.
- De virtuele knop wordt groen met **OK** en keert daarna terug naar SAVE.
- De statusregel meldt welk patroon is opgeslagen.

SAVE bewaart de gekozen patroonplaats: noten, velocity, looplengte, intern tempo en ties. Bij een schrijffout verschijnt SAVE MISLUKT zonder succeslicht. Het is geen bevestiging van een uitlezing uit het geheugen van de SWING; de APC-patronen staan in SynthRig-bestanden.

## Langzamer spelen

De **uiterste rechter APC-fader** is in SEQ de tempofader. Schuif hem omlaag voor een lager tempo, tot 60 BPM; omhoog tot 180 BPM. Het venster noemt hem nu TEMPO en toont er de BPM bij. De acht andere faders veranderen de toonhoogtes van de rijen; met SHIFT verandert daar de velocity.

Gebruik je `--apc-clock swing`, dan volgt de APC het SWING-tempo. Draai dan aan TEMPO op de SWING. Het APC-venster geeft dit aan met SWING onder de tempofader.

## Van twee aanslagen naar één lange noot

Voorbeeld met stap 1 en stap 2:

1. Kies SEQ (TRACK 2) en pagina 1–8 (TRACK 3).
2. Zet de twee pads **helemaal linksonder en direct rechts daarvan** aan. Ze horen bij dezelfde onderste rij en hebben dus dezelfde toonhoogte, standaard MIDI-noot 48.
3. Houd de **SHIFT-knop van de APC** vast.
4. Druk op de **tweede** van die twee pads. Hij wordt **cyaan**. De eerste blijft groen.
5. Laat SHIFT los en druk TRACK 5 — PLAY. Je hoort nu één aanslag met een aangehouden toon over de twee stappen.
6. SHIFT + de tweede pad maakt hem weer groen: opnieuw twee losse aanslagen. TRACK 6 — SAVE bewaart je keuze.

Je verandert met SHIFT + pad de verbinding, niet de aan/uit-stand van de stap. Beide buurnoten moeten eerst aanstaan; anders geeft het venster een aanwijzing. Zonder SHIFT schakelt de pad de stap normaal aan/uit en hoor je de korte voorbeluistering.

## Meer dan twee stappen en de loopgrens

Je kunt op dezelfde manier stap 3 aan stap 2 verbinden, enzovoort. Voor een verbinding van de laatste loopstap naar stap 1 houd je SHIFT vast en druk je op de pad van stap 1. De vorige stap is dan stap 4, 8 of 16, afhankelijk van de gekozen looplengte.

Een nieuwe start geeft altijd een eerste aanslag. Volledig verbonden rondjes kunnen daarna zonder heraanslag blijven klinken. STOP en beide PANIC-functies ruimen de aangehouden noot op. Een gewone aangehouden noot mag na STOP volgens de ingestelde release/effecten uitklinken; PANIC wist ook de effectstaarten.

Ties worden per rij en per stap opgeslagen. Verander je de toonhoogte van de rij tijdens afspelen, dan wordt een oude en nieuwe verschillende toon niet als één gelijke noot behandeld. Je behoudt de gewone 4/8/16-loopkeuze via SHIFT + de bovenste drie knoppen rechts naast het rooster.
