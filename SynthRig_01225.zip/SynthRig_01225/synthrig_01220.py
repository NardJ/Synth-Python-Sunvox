#!/usr/bin/env python3
"""SynthRig 0.12.20: vierstemmig, vaste MIDImix-layout zonder pagina's.

    python synthrig_01220.py --soundcheck
    python synthrig_01220.py --debug-ui
    python synthrig_01220.py --list-controls
"""
from __future__ import annotations
import argparse
from contextlib import ExitStack
import json
import queue
import shutil
from pathlib import Path
import sys
import threading
import time

from synthrig.fixed_controls import FixedControls, DEFAULT_LAYOUT
from synthrig.session_state import (DEFAULT_STATE_PATH,default_state,load_state,apply_state,save_state)
from synthrig.presets import PresetManager, PRESET_DIR
from synthrig.preset_buttons import SoloSaveButton
from synthrig.midimix_events import handle_bank_press
from synthrig.output_gain import DEFAULT_GAIN_FILE,load_gain,save_gain,valid_gain
from synthrig.upgrade0111 import migrate_0110
from synthrig.apc_mk2 import APCminiMk2, choose_control_port

POLL=.002


def terminal(inbox):
    try:
        for line in sys.stdin:
            cmd=line.strip()
            lower=cmd.lower()
            if lower in ('r','m','s','h','q','p','preset') or lower.startswith(('p ','preset ','fx ')):
                inbox.put(cmd)
    except (EOFError,OSError):
        pass


def soundcheck(rig):
    """Een noot, akkoord en een sub/noise-test zonder fysiek MIDI-apparaat."""
    print('Soundcheck 0.12.20: losse noot, akkoord, sub+noise. Begin met laag luidsprekervolume.')
    def advance(seconds):
        until=time.monotonic()+seconds
        while time.monotonic()<until:
            rig.tick()
            time.sleep(.003)
    try:
        rig.set_parameter('master.level',110)
        rig.set_parameter('osc1.level',100)
        rig.set_parameter('osc2.level',75)
        rig.set_source_enabled('osc1',True)
        rig.set_source_enabled('osc2',True)
        rig.set_source_enabled('sub',True)
        rig.set_source_enabled('noise',True)
        rig.set_parameter('sub.level',0)
        rig.set_parameter('noise.level',0)
        rig.set_parameter('filter.cutoff',93)
        rig.set_parameter('amp.attack',20)
        rig.set_parameter('amp.release',60)
        rig.set_parameter('filter.env_amount',65)
        print('A: C3, OSC1 + OSC2 (beide onafhankelijk)')
        rig.note_on(48,96);advance(1.4);rig.note_off(48);advance(.8)
        print('B: C-majeur (3 stemmen)')
        for n in (48,52,55): rig.note_on(n,95)
        advance(2)
        for n in (48,52,55): rig.note_off(n)
        advance(1.4)
        print('C: C3 met sub en noise')
        rig.set_parameter('sub.level',82)
        rig.set_parameter('noise.level',38)
        rig.note_on(48,110);advance(2);rig.note_off(48);advance(1.2)
    finally:
        rig.all_notes_off()


def stresscheck(rig):
    """Korte 4-stemmen test bij hoge mixniveaus; bedoeld voor clippinganalyse."""
    print('WAARSCHUWING: 4-stemmen stresstest, master op maximum!')
    print('ZET HET VOLUME VAN JE LUIDSPREKERS EERST ZEER LAAG.')
    def advance(seconds):
        until=time.monotonic()+seconds
        while time.monotonic()<until:
            rig.tick()
            time.sleep(.003)
    try:
        rig.set_parameter('master.level',127)
        rig.set_parameter('osc1.level',127)
        rig.set_parameter('osc2.level',127)
        rig.set_source_enabled('osc1',True)
        rig.set_source_enabled('osc2',True)
        rig.set_source_enabled('sub',True)
        rig.set_source_enabled('noise',True)
        rig.set_parameter('sub.level',0)
        rig.set_parameter('noise.level',0)
        rig.set_waveform_index(1,2)  # SAW
        rig.set_waveform_index(2,2)  # SAW
        rig.set_parameter('filter.cutoff',127)
        rig.set_parameter('filter.resonance',0)
        rig.set_parameter('filter.env_amount',0)
        rig.set_parameter('amp.attack',0)
        rig.set_parameter('amp.sustain',127)
        print('A: één noot')
        rig.note_on(48,127);advance(1.4);rig.note_off(48);advance(.8)
        print('B: vier stemmen')
        notes=(48,52,55,60)
        for n in notes:rig.note_on(n,127)
        advance(2)
        for n in notes:rig.note_off(n)
        advance(1)
    finally:
        rig.all_notes_off()


def pitchcheck(rig, recorder=None):
    """Reproduceerbare solo-sinus-test van absolute SET_PITCH, zonder andere modulatie."""
    import mido
    def wait(duration):
        deadline=time.monotonic()+duration
        while time.monotonic()<deadline:
            rig.tick()
            time.sleep(.003)
    # Een vaste testpatch, onafhankelijk van MIDImix-positie of opgeslagen presets.
    settings={
        'master.level':110,'osc1.level':110,'osc2.level':0,
        'sub.level':0,'noise.level':0,'osc1.semitones':64,'osc2.semitones':64,
        'osc1.finetune':64,'osc2.finetune':64,
        'amp.attack':0,'amp.decay':0,'amp.sustain':127,'amp.release':12,
        'filter.cutoff':127,'filter.resonance':0,'filter.env_amount':0,
        'filter.keytrack':0,'lfo.pitch_depth':0,'lfo.filter_depth':0,
        'pwm.depth':0,
    }
    rig.all_notes_off()
    rig.handle_swing(mido.Message('pitchwheel',pitch=0))
    rig.handle_swing(mido.Message('control_change',control=1,value=0))
    for key,value in settings.items():
        rig.set_parameter(key,value)
    for source in ('osc1','osc2','sub','noise'):
        rig.set_source_enabled(source,source=='osc1')
    rig.set_waveform_index(1,0) # SIN: grondfrequentie eenvoudig analyseerbaar
    print('Generator-golfvorm readback:',rig.waveform_readback(),flush=True)
    print('Native Vibrato volume readback:',rig.vibrato_volume_readback(),flush=True)
    rig.set_waveform_index(2,0)
    print('PITCHCHECK 0.12.20: zuivere sinus, geen filter/LFO/PWM-modulatie.',flush=True)
    print('Zet eerst het fysieke luidsprekervolume LAAG.',flush=True)
    def step(label,seconds,**kwargs):
        print(label,flush=True)
        if recorder and recorder.active:
            recorder.log('pitchcheck_step',{'label':label,**kwargs})
        wait(seconds)
    try:
        # Even wachten zodat de audiomonitor is gestart.
        wait(.35)
        rig.note_on(60,110)
        step('0–1 s: normale toon',1,pitch_semitones=0)
        rig.handle_swing(mido.Message('pitchwheel',pitch=8191))
        step('1–2 s: +2 halve tonen',1,pitch_semitones=2)
        rig.handle_swing(mido.Message('pitchwheel',pitch=-8192))
        step('2–3 s: -2 halve tonen',1,pitch_semitones=-2)
        rig.handle_swing(mido.Message('pitchwheel',pitch=0))
        step('3–4 s: normale toon',1,pitch_semitones=0)
        rig.handle_swing(mido.Message('control_change',control=1,value=127))
        step('4–6 s: vibrato ±40 cent bij 5 Hz',2,modwheel=127)
        rig.handle_swing(mido.Message('control_change',control=1,value=0))
        step('6–7 s: vibrato uit',1,modwheel=0)
    finally:
        rig.all_notes_off()
        rig.handle_swing(mido.Message('pitchwheel',pitch=0))
        rig.handle_swing(mido.Message('control_change',control=1,value=0))


def lfo_check(rig,recorder=None):
    """Offline MIDI onafhankelijke diagnostiek: 8 sec sinus met LFO-opbouw.

    Let op: test per start één pitch_lfo_mode; draai twee maal met --record.
    """
    import mido
    def hold(seconds):
        until=time.monotonic()+seconds
        while time.monotonic()<until:
            rig.tick()
            time.sleep(.003)
    def mark(name,duration,**data):
        print(f'LFO CHECK: {name} ({duration:.1f}s)',flush=True)
        if recorder and recorder.active: recorder.log('lfo_check_step',{'label':name,**data})
        hold(duration)
    rig.all_notes_off()
    rig.handle_swing(mido.Message('pitchwheel',pitch=0))
    rig.handle_swing(mido.Message('control_change',control=1,value=0))
    config={'master.level':110,'osc1.level':110,'osc2.level':0,
        'sub.level':0,'noise.level':0,'osc1.semitones':64,'osc1.finetune':64,
        'amp.attack':0,'amp.decay':0,'amp.sustain':127,'amp.release':0,
        'filter.cutoff':127,'filter.resonance':0,'filter.env_amount':0,
        'filter.keytrack':0,'lfo.pitch_depth':0,'lfo.filter_depth':0,'pwm.depth':0}
    for k,v in config.items():rig.set_parameter(k,v)
    for source in ('osc1','osc2','sub','noise'):
        rig.set_source_enabled(source,source=='osc1')
    rig.set_waveform_index(1,0)
    print('Generator-golfvorm readback:',rig.waveform_readback(),flush=True)
    # Gebruik 5 Hz LFO, dan zijn fluctuaties meetbaar over korte segmenten.
    # Werkelijk Hz na mapping (0.05*200^(raw/127)) wordt apart gelogd.
    rig.set_parameter('lfo.rate',111)
    print('LFO CHECK: sinus, MIDI 60, LFO',round(rig.lfo_rate,3),'Hz; mode',rig.pitch_lfo_mode)
    print('Luidsprekervolume vooraf LAAG zetten.',flush=True)
    try:
        hold(.3)
        rig.note_on(60,115)
        mark('nul',1.3,pitch_depth=0,rate_hz=rig.lfo_rate)
        for depth,sec in [(15,1.5),(45,1.5),(85,1.5),(127,1.5)]:
            rig.set_parameter('lfo.pitch_depth',depth)
            mark(f'diepte {depth}',sec,pitch_depth=depth,rate_hz=rig.lfo_rate)
        rig.set_parameter('lfo.pitch_depth',0)
        mark('terug naar nul',1.5,pitch_depth=0,rate_hz=rig.lfo_rate)
    finally:
        rig.all_notes_off()
        rig.set_parameter('lfo.pitch_depth',0)


def check_pitch_recording(summary):
    """Signaleer expliciet stilte of foutieve monitoropname; geen valse geslaagd-claim."""
    import math
    if not summary or summary.get('capture_error'):
        return False,'Opname mislukt: '+str((summary or {}).get('capture_error'))
    energy=summary.get('rms_by_second',{})
    db=[row.get('rms_dbfs_approx') for sec,row in energy.items()
        if str(sec).isdigit() and 1 <= int(sec) <= 6 and row.get('rms_dbfs_approx') is not None]
    if summary.get('recorded_audio_seconds',0)<5:
        return False,'Opname te kort: minder dan 5 seconden.'
    if not db or max(db) < -60:
        return False,'De opname is stil of zeer zacht (onder -60 dBFS); controleer Pulse/PipeWire-monitor en SunVox-audio.'
    return True,f'Audio aanwezig: sterkste RMS-seconde {max(db):.1f} dBFS (niet automatisch bewijs van correcte toonhoogte).'


def parse_wave_offsets(raw):
    if not raw:return None
    allowed={'SIN','TRI','SAW','PULSE'}
    result={}
    for item in raw.split(','):
        if '=' not in item:raise ValueError(f'Geen KEY=VALUE: {item!r}')
        name,val=item.split('=',1)
        name=name.strip().upper()
        if name not in allowed or name in result:raise ValueError(f'Ongeldige golfvorm {name!r}')
        value=float(val)
        if not -24 <= value <= 24:raise ValueError(f'Offset {name} buiten -24..+24')
        result[name]=value
    return result


def main():
    p=argparse.ArgumentParser(description='SynthRig 0.12.20 — 4-stemmen synth met reproduceerbare kwaliteitscheck')
    p.add_argument('--debug-ui',action='store_true')
    p.add_argument('--midimix-led-test',action='store_true',help='Fysieke LED-teller testen (1,8,16) zonder synth/MIDI-input')
    p.add_argument('--no-apc',action='store_true',help='Schakel APC Mini Mk2 uit; SynthRig blijft als 0.11.3 spelen')
    p.add_argument('--apc-input',default=None,help='Exacte MIDI-inputnaam voor APC Mk2 Control')
    p.add_argument('--apc-output',default=None,help='Exacte MIDI-outputnaam voor APC Mk2 Control')
    p.add_argument('--apc-clock',choices=('internal','swing'),default='internal',help='APC-sequencer clockbron')
    p.add_argument('--apc-pattern-dir',default='patterns',help='APC-patronen, 8 slots')
    p.add_argument('--preset-dir',default=str(PRESET_DIR),help='Map voor eigen presets')
    p.add_argument('--preset',default=None,help='Laad een preset bij start (nummer of naam)')
    p.add_argument('--list-presets',action='store_true',help='Toon presets zonder MIDI of SunVox')
    p.add_argument('--preset-audit',action='store_true',help='Test alle 16 fabriekspresets offline en schrijf vergelijkingsrapport/WAV')
    p.add_argument('--matrix-audit',action='store_true',help='Controleer 256 matrixroutes via echte offline SunVox PCM en geef CSV/JSON rapport')
    p.add_argument('--offline-check',action='store_true',help='Echte SunVox-DSP-tests zonder MIDI en zonder audioapparaat')
    p.add_argument('--offline-no-wav',action='store_true',help='Schrijf bij --offline-check alleen JSON en TXT')
    p.add_argument('--output-gain-file',default=str(DEFAULT_GAIN_FILE),
                   help='Globale outputgain opgeslagen buiten presets en MIDI-sessie')
    p.add_argument('--output-gain-db',type=float,default=None,
                   help='Startwaarde software outputgain in dB (-6..+9); standaard bewaarde waarde')
    p.add_argument('--state-file',default=str(DEFAULT_STATE_PATH),
                   help='Pad voor de automatisch bewaarde sessie (standaard: state/last_session.json)')
    p.add_argument('--no-state',action='store_true',help='Niet laden of bewaren; oude opstartwijze')
    p.add_argument('--reset-state',action='store_true',help='Negeer bewaarde sessie en begin met standaardwaarden')
    p.add_argument('--wave-offsets',default=None,metavar='SIN=12,TRI=0,SAW=0,PULSE=12',
                   help='Extra pitchcorrectie per golfvorm bovenop --pitch-calibration')
    p.add_argument('--pitch-calibration',type=float,default=-12.0,
                   help='Generator-pitchcorrectie in halve tonen; standaard -12 (0.9.6 was +1 octaaf)')
    p.add_argument('--tonecheck',action='store_true',
                   help='Kale Generator SIN/SAW, gewone Note On en SET_PITCH vergelijken; gebruik --record')
    p.add_argument('--bend-range',type=float,default=2.0,
                   help='Swing Pitch Bend bereik in semitonen (0-12; standaard 2)')
    p.add_argument('--no-leds',action='store_true',help='Geen hardware LED-terugkoppeling naar MIDImix')
    p.add_argument('--pitch-lfo-mode',choices=('native','events'),default='native',
                   help='native=SunVox vibrato DSP (standaard), events=oude 80Hz pitch-events voor A/B')
    p.add_argument('--lfo-check',action='store_true',help='Gecontroleerde LFO-vibratotest; gebruik met --record')
    p.add_argument('--wavecheck',action='store_true',help='SIN/TRI/SAW/PULSE op OSC1 en OSC2 met audiometing; vereist --record')
    p.add_argument('--qualitycheck',action='store_true',help='Automatische 4-voice, SIN/SAW, signaalketen en ADSR test; --record verplicht')
    p.add_argument('--pitchcheck',action='store_true',help='Gecontroleerde noot: sinus, +/-2 semitonen en vibrato; gebruik met --record')
    p.add_argument('--midi-log',action='store_true',help='Toon alle binnenkomende MIDImix MIDI-events en toewijzingen')
    p.add_argument('--diagnose',action='store_true')
    p.add_argument('--layout',default=str(DEFAULT_LAYOUT),help='Vaste MIDImix JSON-mapping')
    p.add_argument('--list-controls',action='store_true',help='Toon alle knoppen, faders en drukknoppen')
    p.add_argument('--noise-check',action='store_true',help='Offline: individuele en gezamenlijke sub/noise-controles')
    p.add_argument('--soundcheck',action='store_true',help='Automatische geluidstest zonder MIDI')
    p.add_argument('--stresscheck',action='store_true',help='4-stemmen stresstest op maximaal niveau; volume laag!')
    p.add_argument('--record',action='store_true',help='Audio opnemen vanaf opstart')
    p.add_argument('--record-dir',default='recordings')
    p.add_argument('--record-source',default=None)
    p.add_argument('--no-dc-blocker',action='store_true',help='Alleen voor diagnostische A/B-tests')
    args=p.parse_args()
    if (args.qualitycheck or args.wavecheck) and not args.record:
        p.error('--qualitycheck en --wavecheck vereisen --record')
    if (args.qualitycheck or args.wavecheck) and args.pitch_lfo_mode!='native':
        p.error('Deze test vereist --pitch-lfo-mode native')
    try:wave_offsets=parse_wave_offsets(args.wave_offsets)
    except ValueError as exc:p.error(str(exc))
    if not -24 <= args.pitch_calibration <= 24:
        p.error('--pitch-calibration moet tussen -24 en +24 liggen')
    if not 0 <= args.bend_range <= 12:
        p.error('--bend-range moet tussen 0 en 12 liggen')
    if args.output_gain_db is not None:
        try:args.output_gain_db=valid_gain(args.output_gain_db)
        except ValueError as exc:p.error(str(exc))
    if args.midimix_led_test:
        from synthrig.midimix_led_selftest import run_hardware_test
        run_hardware_test()
        return
    if args.preset_audit:
        from synthrig.preset_audit01214 import run
        result=run(output_dir=args.record_dir,pitch_lfo_mode=args.pitch_lfo_mode,
                   save_wav=not args.offline_no_wav)
        if result['summary']['FAIL']:
            raise SystemExit(1)
        return
    if args.noise_check:
        from synthrig.noise_regression0129 import run
        result=run(output_dir=args.record_dir,pitch_lfo_mode=args.pitch_lfo_mode,
                   save_wav=not args.offline_no_wav)
        if result['summary']['FAIL']:
            raise SystemExit(1)
        return
    if args.matrix_audit:
        from synthrig.matrix_audit0129 import run
        result=run(output_dir=args.record_dir,pitch_lfo_mode=args.pitch_lfo_mode)
        if result['summary']['FAIL']:
            raise SystemExit(1)
        return
    if args.offline_check:
        from synthrig.offline01216 import run
        result=run(output_dir=args.record_dir,save_wav=not args.offline_no_wav,
                   wave_offsets=wave_offsets,pitch_calibration=args.pitch_calibration,
                   pitch_lfo_mode=args.pitch_lfo_mode)
        if result['summary']['FAIL']:
            raise SystemExit(1)
        return
    project_root=__import__('pathlib').Path(__file__).resolve().parent
    # Prefer the most recent sessions and user presets; never overwrite current files.
    for old in ('SynthRig_01219','SynthRig_01218','SynthRig_01217','SynthRig_01216','SynthRig_01215','SynthRig_01214','SynthRig_01213','SynthRig_01212','SynthRig_01211','SynthRig_01210','SynthRig_0129','SynthRig_0128','SynthRig_0127','SynthRig_0126','SynthRig_0125','SynthRig_0124','SynthRig_0123','SynthRig_0122','SynthRig_0121','SynthRig_0120','SynthRig_0113','SynthRig_0112', 'SynthRig_0111', 'SynthRig_0110'):
        for migration in migrate_0110(project_root,project_root.parent/old,
                                      args.state_file,args.preset_dir,
                                      do_state=not(args.no_state or args.reset_state),
                                      do_presets=True):
            print('UPGRADE:',migration.replace('0.11.0',old.replace('SynthRig_','version ')))
    # Keep the latest APC sequences (0.12.3 first); never overwrite newer files.
    if args.apc_pattern_dir == 'patterns':
        new_patterns=project_root/'patterns'
        for previous in ('SynthRig_01219','SynthRig_01218','SynthRig_01217','SynthRig_01216','SynthRig_01215','SynthRig_01214','SynthRig_01213','SynthRig_01212','SynthRig_01211','SynthRig_01210','SynthRig_0129','SynthRig_0128','SynthRig_0127','SynthRig_0126','SynthRig_0125','SynthRig_0124','SynthRig_0123','SynthRig_0122','SynthRig_0121','SynthRig_0120'):
            old_patterns=project_root.parent/previous/'patterns'
            if old_patterns.is_dir():
                new_patterns.mkdir(parents=True,exist_ok=True)
                for pattern_file in old_patterns.glob('apc_*.json'):
                    dest=new_patterns/pattern_file.name
                    if not dest.exists():
                        shutil.copy2(pattern_file,dest)
                        print('UPGRADE: APC-pattern overgenomen:',dest.name, 'uit', previous)
    # The global +dB output setting is NOT a preset or session parameter.
    # Preserve the latest independent gain preference across this upgrade.
    default_gain=Path(DEFAULT_GAIN_FILE).resolve()
    target_gain=Path(args.output_gain_file).resolve()
    if target_gain==default_gain and not target_gain.exists() and not args.no_state:
        prev_gain=next((project_root.parent/p/'state'/'output_gain.json'
                        for p in ('SynthRig_01219','SynthRig_01218','SynthRig_01217','SynthRig_01216','SynthRig_01215','SynthRig_01214','SynthRig_01213','SynthRig_01212','SynthRig_01211','SynthRig_01210','SynthRig_0129','SynthRig_0128','SynthRig_0127','SynthRig_0126','SynthRig_0125','SynthRig_0124','SynthRig_0123','SynthRig_0122','SynthRig_0121','SynthRig_0120','SynthRig_0113')
                        if (project_root.parent/p/'state'/'output_gain.json').is_file()), None)
        if prev_gain is not None:
            target_gain.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(prev_gain,target_gain)
            print('UPGRADE: outputgain uit vorige versie overgenomen.',flush=True)
    controls=FixedControls(args.layout)
    if args.list_presets:
        pm=PresetManager(controls,args.preset_dir)
        for identifier,name in pm.listings():print(f'{identifier:>16}: {name}')
        return
    if args.list_controls:
        from synthrig.fixed_controls import KNOB_CC,FADER_CC
        print('MIDI-mapping 1.1 · vaste indeling (geen bankpagina’s)')
        for row_idx,row in enumerate(KNOB_CC,1):
            print(f'\nDraaiknoppen rij {row_idx}:')
            for cc in row:
                s=controls.mappings.get(cc)
                print(f'  CC{cc:2d}: {s["label"] if s else "VRIJ (toekomstige functie)"}')
        print('\nSchuiven:')
        for cc in FADER_CC:
            s=controls.mappings.get(cc)
            print(f'  CC{cc:2d}: {s["label"] if s else "VRIJ"}')
        print('\nMUTE 1-4: OSC1 SIN/TRI/SAW/PULSE; MUTE 5-8: OSC2 SIN/TRI/SAW/PULSE')
        print('REC 1-4: OSC1 / OSC2 / SUB / NOISE aan-uit; REC 5-8: vrij')
        print('SOLO kort: PANIC + presetnummer LEDs; SOLO >=1.5 s: save slot; BANK L/R: 16 presets')
        return
    # Pas audio/MIDI importeren wanneer we echt gaan spelen; --list-controls werkt offline.
    import mido
    from sunvox.api import Slot, init, deinit
    from synthrig.engine09 import SynthRig, find_midi_port
    from synthrig.midimix_hw import MidiMixLEDs, describe_midi, sync_leds_for_button
    names=[] if (args.soundcheck or args.stresscheck or args.pitchcheck or args.lfo_check or args.tonecheck or args.qualitycheck or args.wavecheck) else mido.get_input_names()
    swing=find_midi_port(names,'behringer swing')
    midimix=find_midi_port(names,'midi mix','midimix')
    output_names=[] if (args.soundcheck or args.stresscheck or args.pitchcheck or args.lfo_check or args.tonecheck or args.qualitycheck or args.wavecheck or args.no_leds) else mido.get_output_names()
    midimix_out=find_midi_port(output_names,'midi mix','midimix')
    # APC is optional and MUST use its Control endpoint, not the Notes endpoint.
    apc_input=None if args.no_apc or not names else (args.apc_input or choose_control_port(names))
    apc_output=None if args.no_apc or not output_names else (args.apc_output or choose_control_port(output_names))
    if args.apc_input and args.apc_input not in names: p.error('--apc-input bestaat niet: '+args.apc_input)
    if args.apc_output and args.apc_output not in output_names: p.error('--apc-output bestaat niet: '+args.apc_output)
    if not (args.soundcheck or args.stresscheck or args.pitchcheck or args.lfo_check or args.tonecheck or args.qualitycheck or args.wavecheck) and not(swing and midimix):
        raise RuntimeError(f'Swing/MIDImix niet gevonden. Beschikbare poorten: {names}')

    recorder=None
    monitor=None
    leds=None
    if args.record:
        from synthrig.recording import AudioDebugRecorder
        recorder=AudioDebugRecorder(args.record_dir,source=args.record_source)
    if args.debug_ui:
        from synthrig.debug import OptionalMidiMixDebug
        monitor=OptionalMidiMixDebug(args.layout)
    inbox=queue.Queue()
    if not (args.soundcheck or args.stresscheck or args.pitchcheck or args.lfo_check or args.tonecheck or args.qualitycheck or args.wavecheck):
        threading.Thread(target=terminal,args=(inbox,),daemon=True).start()
    try:
        version=init(None,44100,2,0)
        if version<0:raise RuntimeError(f'SunVox init mislukt: {version}')
        try:
            with Slot() as slot:
                rig=SynthRig(slot,diagnose=args.diagnose,dc_blocker=not args.no_dc_blocker,
                             pitch_lfo_mode=args.pitch_lfo_mode,
                             pitch_calibration_semitones=args.pitch_calibration,
                             wave_pitch_offsets=wave_offsets)
                rig.bend_range=args.bend_range
                
                stored=None if (args.no_state or args.reset_state or args.pitchcheck or args.lfo_check or args.tonecheck or args.qualitycheck or args.wavecheck) else load_state(args.state_file,controls)
                state=stored if stored is not None else default_state(controls)
                apply_state(rig,controls,state,pickup=(stored is not None))
                # A manual MIDImix SEND ALL sends 33 regular CC messages, not
                # a special inquiry reply. Always soft-takeover those values:
                # reading positions must never jump a synth parameter.
                controls.arm_pickup()
                # Global gain is intentionally NOT in the patch/preset/session state.
                # It belongs to the final SunVox output bus, after delay/reverb.
                boost=(args.output_gain_db if args.output_gain_db is not None
                       else (0.0 if args.no_state or args.reset_state else load_gain(args.output_gain_file)))
                rig.set_output_gain_db(boost)
                gain_dirty=bool(args.output_gain_db is not None and not args.no_state)
                last_gain_change=time.monotonic()
                def save_gain_if_needed(force=False):
                    nonlocal gain_dirty
                    if args.no_state or not gain_dirty:
                        return
                    if force or time.monotonic()-last_gain_change>=.75:
                        try:
                            save_gain(args.output_gain_file,rig.output_gain_db)
                            gain_dirty=False
                        except OSError as exc:
                            print('WAARSCHUWING: outputgain niet opgeslagen:',exc)
                print(f'Globale software outputgain: {boost:+.1f} dB (niet in presets).')
                presets=PresetManager(controls,args.preset_dir)
                solo_button=SoloSaveButton(threshold=1.5)
                if args.preset:
                    print(presets.load(args.preset,rig))
                if not rig.ensure_waveforms(timeout=.6,strict=False):
                    print('WAARSCHUWING: gespeelde golfvorm nog niet bevestigd; achtergrondcontrole actief.')
                if args.no_state:
                    print('Sessiebewaring UIT: gebruik SEND ALL of beweeg regelaars voor fysieke standen.')
                elif stored:
                    print('Sessiestand hersteld:',args.state_file)
                    print('Soft takeover actief: beweeg een regelaar langs de opgeslagen waarde.')
                else:
                    print('Standaardinstellingen geladen; SEND ALL leest fysieke MIDImix-standen met soft takeover (geen klanksprongen).')
                # Een geluidscheck verandert bewust geen opgeslagen speelsessie.
                save_enabled=not (args.no_state or args.soundcheck or args.stresscheck or args.pitchcheck or args.lfo_check or args.tonecheck or args.qualitycheck or args.wavecheck)
                state_dirty=save_enabled and (args.reset_state or stored is None or args.preset is not None)
                last_change=time.monotonic()
                last_save=time.monotonic()
                def mark_changed():
                    nonlocal state_dirty,last_change
                    if save_enabled:
                        state_dirty=True
                        last_change=time.monotonic()
                def save_if_needed(force=False):
                    nonlocal state_dirty,last_save
                    if not save_enabled or not state_dirty:return
                    now=time.monotonic()
                    if force or (now-last_change>1.0 and now-last_save>2.0):
                        try:
                            save_state(args.state_file,rig,controls)
                            state_dirty=False;last_save=now
                        except OSError as exc:
                            print(f'WAARSCHUWING: kon sessie niet bewaren: {exc}')
                if monitor:
                    monitor.send_page(controls.name,controls.labels())
                    monitor.send_output_gain(rig.output_gain_db)
                    monitor.send_preset(presets.selection())
                    monitor.send_state(controls.button_state(rig))
                    monitor.send_swing(rig.swing_ui_state())
                    monitor.send_values({str(cc):controls.target_raw.get(spec['target'],64)
                                         for cc,spec in controls.mappings.items()})
                if recorder:
                    recorder.start(metadata={'version':'0.12.20','sunvox_version':str(version),
                                             'pitch_calibration':args.pitch_calibration, 'wave_pitch_offsets':rig.wave_pitch_offsets, 'pitch_lfo_mode':args.pitch_lfo_mode, 'scenario':'wavecheck' if args.wavecheck else ('qualitycheck' if args.qualitycheck else ('tonecheck' if args.tonecheck else ('lfo-check' if args.lfo_check else ('pitchcheck' if args.pitchcheck else ('stresscheck' if args.stresscheck else ('soundcheck' if args.soundcheck else 'manual')))))),
                                             'layout':str(args.layout),
                                             'dc_blocker':not args.no_dc_blocker})
                    rig.pwm_trace=lambda data:recorder.log('pwm_written',data)
                    rig.pwm_tick_trace=lambda data:recorder.log('pwm_tick',data)
                    recorder.log('state',rig.snapshot())
                if args.wavecheck:
                    from synthrig.quality099 import wavecheck
                    wavecheck(rig,recorder)
                    return
                if args.qualitycheck:
                    from synthrig.quality099 import qualitycheck
                    qualitycheck(rig,recorder)
                    return
                if args.tonecheck:
                    from synthrig.calibration098 import tonecheck
                    tonecheck(slot,rig,recorder)
                    return
                if args.pitchcheck:
                    pitchcheck(rig,recorder)
                    return
                if args.lfo_check:
                    lfo_check(rig,recorder)
                    return
                if args.soundcheck:
                    soundcheck(rig)
                    return
                if args.stresscheck:
                    stresscheck(rig)
                    return
                print('Swing:',swing,'| MIDImix:',midimix)
                print('Vaste MIDImix layout: 24 knoppen, 9 schuiven, golfvormen via MUTE, bronnen aan/uit via REC.')
                print('16 presets: BANK L/R selecteert; SOLO kort = PANIC + toon preset, SOLO 1,5s = SAVE geselecteerd slot.')
                print('CC47=Delay | CC48=Reverb | SEND ALL leest fysieke MIDImix-standen | Outputgain in debugvenster.')
                print('Terminal: p list/load/save/restore/compare/next/prev | fx delay/reverb 0-127 | r/m/s/h/q')
                try:
                    with ExitStack() as stack:
                        kin=stack.enter_context(mido.open_input(swing))
                        cin=stack.enter_context(mido.open_input(midimix))
                        apc=None;apc_in=None
                        if apc_input:
                            try:
                                apc_in=stack.enter_context(mido.open_input(apc_input))
                                apc_out=None
                                if apc_output:
                                    apc_out=stack.enter_context(mido.open_output(apc_output))
                                apc=APCminiMk2(apc_out,rig,controls,pattern_dir=args.apc_pattern_dir,clock=args.apc_clock)
                                stack.callback(apc.close)
                                print('APC Mini Mk2 actief:',apc_input,'→',apc_output or 'zonder LED-uitgang')
                                print('APC SysEx: beginstanden van 9 faders opgevraagd' if apc.fader_intro_status=='waiting' else 'APC SysEx: posities onbekend; faders pas na beweging bekend')
                                if monitor: monitor.send_apc_status(apc.display_snapshot())
                                print('APC TRACK 1=PARAM 2=SEQ 3/4=PAGE 5=PLAY 6=SAVE 7=LOAD 8=PANIC; SCENE 1..8=PATROON')
                            except (OSError,IOError,RuntimeError) as exc:
                                print('WAARSCHUWING: APC niet beschikbaar:',exc)
                                apc=None;apc_in=None
                        else:
                            print('APC optioneel: niet gevonden of uitgeschakeld (alle 0.11.3-functies blijven actief).')
                        if midimix_out:
                            try:
                                cout=stack.enter_context(mido.open_output(midimix_out))
                                leds=MidiMixLEDs(cout, controls)
                                leds.sync(controls.button_state(rig),force=True)
                                stack.callback(leds.clear)  # ook bij Ctrl+C of een fout
                                print('MIDImix LED-feedback actief via:',midimix_out)
                            except (OSError, IOError, RuntimeError) as e:
                                print(f'WAARSCHUWING: MIDImix MIDI-uitgang niet beschikbaar: {e}')
                        elif not args.no_leds:
                            print('WAARSCHUWING: MIDImix MIDI-uitgang niet gevonden. Geen fysieke LED-feedback.')
                            print('Beschikbare MIDI-uitgangen:',output_names)
                        running=True
                        last_midi_led_revision=-1
                        last_midi_led_resend=0.0
                        last_state=0.0
                        last_gui_state=0.0
                        last_apc_gui=0.0
                        last_apc_rev=-1
                        while running:
                            while not inbox.empty():
                                cmd=inbox.get_nowait()
                                lowered=cmd.lower()
                                if lowered=='q':running=False
                                elif lowered=='h':print('MUTE=golfvorm, REC 1-4=bron mute, SOLO kort=PANIC+toon preset, SOLO lang=SAVE huidig slot, BANK L/R=16 presets; p list/load/save/restore/compare/next/prev; CC47/48=delay/reverb; r/m/s/q')
                                elif lowered=='s':print(json.dumps(rig.snapshot(),indent=2))
                                elif lowered=='m' and recorder and recorder.active:
                                    recorder.log('manual_marker',{'layout':controls.name})
                                elif lowered=='p' or lowered=='preset' or lowered.startswith(('p ','preset ','fx ')):
                                    try:
                                        parts=cmd.split(maxsplit=2)
                                        if parts[0].lower()=='fx':
                                            if len(parts)!=3 or parts[1].lower() not in ('delay','reverb'):
                                                raise ValueError('Gebruik fx delay 0-127 of fx reverb 0-127')
                                            amount=int(parts[2]);
                                            if not 0<=amount<=127:raise ValueError('Effectstand moet 0..127 zijn')
                                            print(rig.set_parameter('effects.'+parts[1].lower(),amount))
                                            controls.target_raw['effects.'+parts[1].lower()]=amount
                                            controls.arm_pickup({'effects.'+parts[1].lower()})
                                            mark_changed()
                                        else:
                                            command=parts[1].lower() if len(parts)>1 else 'list'
                                            argument=parts[2] if len(parts)>2 else ''
                                            if command=='list':
                                                for ident,name in presets.listings():print(f'  {ident:>12}: {name}')
                                            elif command=='load':
                                                if not argument:raise ValueError('Gebruik p load 1 of p load Naam')
                                                print(presets.load(argument,rig));mark_changed()
                                            elif command=='save':
                                                if not argument:raise ValueError('Gebruik p save Mijn Klank')
                                                print(presets.save(argument,rig))
                                            elif command=='restore':
                                                if not argument:raise ValueError('Gebruik p restore 1..16')
                                                print(presets.restore_factory(argument,rig));mark_changed()
                                            elif command=='compare':
                                                print(presets.compare(rig));mark_changed()
                                            elif command in ('next','prev'):
                                                print(presets.step(1 if command=='next' else -1,rig));mark_changed()
                                            else:raise ValueError('p list|load <nummer/naam>|save <naam>|restore <nummer>|compare|next|prev')
                                        if monitor:
                                            monitor.send_preset(presets.selection())
                                            monitor.send_state(controls.button_state(rig))
                                            monitor.send_values({str(cc):controls.target_raw.get(spec['target'],64)
                                                             for cc,spec in controls.mappings.items()})
                                        if leds:leds.sync(controls.button_state(rig),force=True)
                                    except (ValueError,OSError,FileExistsError) as exc:
                                        print('PRESET/FX fout:',exc)
                                elif lowered=='r':
                                    from synthrig.recording import AudioDebugRecorder
                                    if recorder and recorder.active:
                                        rig.pwm_trace=None;rig.pwm_tick_trace=None
                                        print('Diagnose-ZIP:',recorder.stop())
                                    else:
                                        recorder=AudioDebugRecorder(args.record_dir,source=args.record_source)
                                        recorder.start(metadata={'version':'0.12.20','layout':controls.name,
                                                                 'dc_blocker':not args.no_dc_blocker})
                                        rig.pwm_trace=lambda data:recorder.log('pwm_written',data)
                                        rig.pwm_tick_trace=lambda data:recorder.log('pwm_tick',data)
                                        recorder.log('state',rig.snapshot())
                            for msg in kin.iter_pending():
                                if apc and msg.type in ('note_on','note_off'):
                                    if msg.type=='note_on' and msg.velocity>0:
                                        apc.router.on('swing',msg.note,msg.velocity)
                                    else:
                                        apc.router.off('swing',msg.note)
                                else:
                                    rig.handle_swing(msg)
                                if apc and msg.type in ('clock','start','stop','continue'):
                                    apc.swing_clock(msg)
                                if monitor and msg.type in ('pitchwheel','note_on','note_off','control_change','aftertouch','polytouch'):
                                    monitor.send_swing(rig.swing_ui_state(),msg)
                                if args.midi_log and (msg.type=='pitchwheel' or
                                                      (msg.type=='control_change' and msg.control==1) or msg.type in ('aftertouch','polytouch')):
                                    print('SWING:',msg,'→',rig.snapshot()['swing'],flush=True)
                                if recorder and recorder.active and (msg.type in ('note_on','note_off','pitchwheel','aftertouch','polytouch') or
                                        (msg.type=='control_change' and msg.control==1)):
                                    recorder.log('midi_swing',msg.dict())
                            if apc and apc_in:
                                for amsg in apc_in.iter_pending():
                                    try:
                                        response=apc.handle(amsg)
                                        if response and apc.mode=='patch' and ((amsg.type=='note_on' and amsg.velocity>0 and 0<=amsg.note<64) or (amsg.type=='control_change' and 48<=amsg.control<=55)):
                                            mark_changed()  # APC patch edits are part of saved SynthRig session.
                                            if monitor:
                                                monitor.send_values({str(cc):controls.target_raw.get(spec['target'],64)
                                                                     for cc,spec in controls.mappings.items()})
                                        if response and monitor:
                                            monitor.send_apc_status(apc.display_snapshot())
                                        if args.midi_log and response:
                                            print('APC:',response,flush=True)
                                        if recorder and recorder.active:
                                            recorder.log('midi_apc',{'message':amsg.dict(),'applied':response})
                                    except (OSError,ValueError) as exc:
                                        print('APC MIDI fout:',exc,flush=True)
                            for msg in cin.iter_pending():
                                applied=None
                                if args.midi_log:
                                    print('MIDIMIX RAW:',describe_midi(msg),flush=True)
                                gesture=solo_button.feed(msg,time.monotonic())
                                if gesture is not None:
                                    if gesture=='panic':
                                        from synthrig.solo_actions import panic_and_show_active_preset
                                        applied=panic_and_show_active_preset(
                                            rig,apc,presets,leds,monitor,
                                            diagnostic=lambda t:print('MIDImix SOLO:',t,flush=True))
                                    else:
                                        try:
                                            applied=presets.save_slot(rig)
                                            print('OPGESLAGEN:',applied,flush=True)
                                            if leds and presets.selected>=0:
                                                leds.show_preset(presets.selected+1)
                                        except (OSError,ValueError) as exc:
                                            applied='SAVE NIET GELUKT: '+str(exc)
                                            print(applied,flush=True)
                                    if monitor and gesture!='panic':
                                        monitor.send_preset(presets.selection(),
                                            led_snapshot=leds.display_snapshot() if leds else None)
                                elif msg.type=='note_on' and msg.velocity>0:
                                    if msg.note in controls.bank_notes:
                                        try:
                                            applied=handle_bank_press(msg,controls,presets,rig,
                                                                      leds,monitor,mark_changed,
                                                                      lambda t:print("MIDImix preset feedback:",t,flush=True))
                                        except (ValueError,OSError) as exc:
                                            applied='PRESET FOUT: '+str(exc)
                                    elif msg.note!=controls.panic_note:
                                        applied=controls.on_note(msg.note,rig)
                                    if applied:print(f'MIDImix knop note {msg.note} → {applied}',flush=True)
                                    if msg.note in controls.wave_notes or msg.note in controls.source_notes:
                                        mark_changed()
                                    elif args.midi_log and msg.note not in controls.bank_notes and msg.note!=controls.panic_note:
                                        print(f'  Note {msg.note}: geen toegewezen actie',flush=True)
                                elif msg.type=='control_change':
                                    target,desc=controls.resolve(msg.control,msg.value)
                                    if target is not None:
                                        applied=rig.set_parameter(target,msg.value)
                                        mark_changed()
                                        print(f'CC{msg.control}={msg.value} → {applied}')
                                    else:
                                        applied=desc
                                if monitor:
                                    monitor.send(msg,applied)
                                    if msg.type in ('note_on','note_off'):
                                        monitor.send_state(controls.button_state(rig))
                                if leds and msg.type in ('note_on','note_off'):
                                    # SOLO volgt uitsluitend de gesture-logica: geen gekozen
                                    # preset = PANIC zonder ook maar een LED-opdracht.
                                    # Een gewone knop mag nog steeds een refresh veroorzaken.
                                    try:
                                        sync_leds_for_button(leds,controls.button_state(rig),msg,
                                                             solo_note=controls.panic_note)
                                    except (OSError, IOError, RuntimeError) as e:
                                        print(f'WAARSCHUWING: LED-terugkoppeling gestopt: {e}')
                                        leds=None
                                if recorder and recorder.active:
                                    recorder.log('midi_midimix',{'message':msg.dict(),'applied':applied})
                            if monitor:
                                for db in monitor.poll_commands():
                                    if db != rig.output_gain_db:
                                        print(rig.set_output_gain_db(db),flush=True)
                                        gain_dirty=True
                                        last_gain_change=time.monotonic()
                            rig.tick()
                            now=time.monotonic()
                            if apc: apc.tick(now)
                            if monitor and apc and apc.gui_revision != last_apc_rev and now-last_apc_gui >= .075:
                                monitor.send_apc_status(apc.display_snapshot())
                                last_apc_gui=now
                                last_apc_rev=apc.gui_revision
                            if leds:
                                leds.tick(controls.button_state(rig))
                                # Eenmalig bij wijziging, en tijdens de 1s preset-telling
                                # elke 150ms opnieuw: UDP is best-effort en de fysieke LEDs
                                # worden onafhankelijk rechtstreeks per MIDI aangestuurd.
                                if monitor and (leds.revision!=last_midi_led_revision or
                                                (leds._overlay and now-last_midi_led_resend>=.15)):
                                    monitor.send_midimix_leds(leds.display_snapshot())
                                    last_midi_led_revision=leds.revision
                                    last_midi_led_resend=now
                            if monitor and now-last_gui_state>1:
                                monitor.send_state(controls.button_state(rig))
                                monitor.send_values({str(cc):controls.target_raw.get(spec['target'],64)
                                                     for cc,spec in controls.mappings.items()})
                                monitor.send_output_gain(rig.output_gain_db)
                                monitor.send_apc_status(apc.display_snapshot() if apc else {'connected':False})
                                last_gui_state=now
                            if recorder and recorder.active and now-last_state>.5:
                                recorder.log('state',rig.snapshot());last_state=now
                            save_if_needed()
                            save_gain_if_needed()
                            time.sleep(POLL)
                finally:
                    save_if_needed(force=True)
                    save_gain_if_needed(force=True)
                rig.all_notes_off()
        finally:
            deinit()
    except KeyboardInterrupt:
        print('\nStoppen...')
    finally:
        if recorder and recorder.active:
            summary=recorder.stop()
            print('Diagnose-ZIP:',summary.get('bundle') if summary else None)
            if args.pitchcheck or args.lfo_check or args.tonecheck or args.qualitycheck or args.wavecheck:
                ok,reason=check_pitch_recording(summary)
                print((('WAVECHECK' if args.wavecheck else ('QUALITYCHECK' if args.qualitycheck else ('TONECHECK' if args.tonecheck else 'PITCHCHECK'))) + (' AUDIO: OK — ' if ok else ' AUDIO: FOUT — '))+reason)
                if (args.qualitycheck or args.wavecheck) and summary and summary.get('bundle'):
                    try:
                        from analyse_quality099 import analyze
                        report=analyze(summary['bundle'],save=True)
                        if report['counts']['FAIL']:
                            print('Audiocontrole: er zijn afwijkingen. Bekijk het rapport in de ZIP.')
                    except Exception as exc:
                        print('QUALITYCHECK analyse mislukt:',exc)
                        raise SystemExit(3) from exc
                if not ok:
                    print('De audiotest is NIET geslaagd; deel de diagnose-ZIP.')
                    raise SystemExit(2)
        elif args.pitchcheck or args.lfo_check or args.tonecheck or args.qualitycheck or args.wavecheck:
            print('Geen audio-opname gecontroleerd: gebruik een automatische test met --record.')
        if monitor:monitor.close()

if __name__=='__main__':main()
