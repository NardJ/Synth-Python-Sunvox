# SynthRig 0.10.2 — portamento-eventrouting en oscillator-tuning

## Diagnose en oorzaak

De MIDI-/WAV-opname uit de gebruikerssessie op 31 oktober 2026 liet zien:
- CC59=127 werd correct als 1,000 seconde per octaaf ontvangen;
- de suboscillator volgde de glide terwijl OSC1 op een vaste toon kon blijven;
- de aangeleverde patch had OSC1 semitones=-3, cents=-14, korte AMP Release,
  filterenv en resonantie. De toenmalige neutrale audiotests misten deze situatie.

Offline konden we dit reproduceren op de originele 0.10.1. Bij hergebruik
van stem 1 werden op de SunVox virtuele track 0 wel pitch-effecten verstuurd,
maar bereikten die de OSC1-audio niet betrouwbaar. Met een andere track werkte
dezelfde patch volledig. Daarom zijn in 0.10.2 de trackrollen herverdeeld:

| Rol | 0.10.1 | 0.10.2 |
| --- | --- | --- |
| AMP ADSR gate | 12-15 | 0-3 |
| OSC1 pitch | 0-3 | 4-7 |
| OSC2 pitch | 4-7 | 8-11 |
| SUB / NOISE | 8-11 | 12-15 |

Bijkomend wordt oscillator-tuning direct meegenomen in de eenmalige
SET_PITCH bij NOTE ON. Een live CC- of pitchbendwijziging wordt nog steeds
met de fasebehoudende SunVox-effecten 05/06 toegepast. De pitchbend- en
fine-tuningbediening blijven op hun bestaande MIDI-CC's.

## Nieuwe tests

`--offline-check` gebruikt `synthrig/offline0102.py` en voegt 7 controles toe:
OSC1, OSC2, sub elk op exact tijdsverloop en stemhergebruik; plus een
gecombineerde headroom-check. Getest met de bewaarde diagnoseparameters.

Verificatie hier: 172/172 native DSP, 172/172 DSP events, 115/115 Python.
Dit vervangt geen laatste luistertest op de fysieke Linux-audioomgeving.

## Gebruik

```bash
cd ~/Synth/Python-sunvox/SynthRig_0102
source ../.venv/bin/activate
python synthrig_0102.py --debug-ui --midi-log
# of geautomatiseerd zonder hardware:
python synthrig_0102.py --offline-check --offline-no-wav
python synthrig_0102.py --offline-check --pitch-lfo-mode events --offline-no-wav
python -m unittest discover -s tests
```

Versies naast elkaar installeren. Oude sessies blijven compatibel.
