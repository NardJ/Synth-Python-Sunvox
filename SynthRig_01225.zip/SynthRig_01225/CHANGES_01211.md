# SynthRig 0.12.11 — vaste overlay, betere modulatiebronnen, rustige APC-monitor

## Wat verandert er?

- Het APC-debugvenster toont alleen de twee rijlabels, twee kolomlabels, het 8×8-grid, de bestaande hardwareknoppen en de faders met waarden. Uitleg als ‘MODUS PATCH’, ‘Rij ...’, ‘Pad: ...’ en ‘SCENE = ...’ is verwijderd. De bestaande kleurcodering en de PATCH/SEQ-modusknoppen op de APC blijven functioneren.
- De acht bronnen van **laag 1** en acht bestemmingen van **laag 1** veranderen niet.
- **Laag 2 bronnen**: op rij 3–6 vervangen we VEL INVERSE, TOUCH INVERSE, MOD INVERSE, KEY INVERSE door een zelfstandige MOD ENV, LFO 3, SMOOTH RANDOM en NOTE RAMP.
- **Laag 2 bestemmingen**: kolom 4 wordt LFO RATE in plaats van KEYTRACK AMOUNT; kolom 8 wordt DELAY FEEDBACK in plaats van OUTPUT LEVEL.
- MOD ENV werkt bij iedere Note On/Off onafhankelijk van de filter- en amplitude-envelope. De standaardvorm is A=35 ms, D=400 ms, S=22%, R=300 ms. NOTE RAMP loopt bij een nieuwe noot van 0 naar 1 in 1,2 seconde. Die vormen zijn nu nog niet op aparte MIDImix-regelaars toegewezen.
- LFO 3 is een zelfstandige sinusfase op circa 27% van de effectieve LFO1-snelheid; SMOOTH RANDOM vloeit zonder scherpe sprongen tussen langzaam wisselende toevalswaarden.
- LFO RATE beïnvloedt de drie Python-LFO's en de native pitch-LFO met een begrensde en afgevlakte snelheid. DELAY FEEDBACK regelt de native Echo-feedback met een veiligheidsgrens van 180 controller-eenheden. De afzonderlijke software-outputgain blijft ongewijzigd.

## Presets en sessies uit 0.12.10

Deze uitwisseling wijzigt de betekenis van **zes oude laag-2-functies**. Daarom is een stille omzetting niet acceptabel.

- Routes die hetzelfde betekenen blijven behouden, met hun modulatiediepte en fadergroep.
- Routes die naar een van de vier verwijderde inverse-bronnen of twee verwijderde bestemmingen wijzen, worden bij het inlezen **gedeactiveerd** en met hun oude bron, bestemming, kleur en diepte gearchiveerd in `mod_legacy_routes`.
- De terminal meldt het aantal gearchiveerde routes. Het oude preset- en sessiebestand wordt niet overschreven bij de migratie; de archivering wordt opgeslagen wanneer je later de sessie of preset bewaart.
- De bediening van de 16 preset-slots, BANK, PANIC/SAVE, MIDImix, Swing en sequencer blijft verder gelijk.

### Kleurcodes van de pads (ongewijzigd)

- Uit = geen verbinding
- Groen = rij laag 1 naar kolom laag 1 (AC)
- Blauw = rij laag 1 naar kolom laag 2 (AD)
- Oranje = rij laag 2 naar kolom laag 1 (BC)
- Paars = rij laag 2 naar kolom laag 2 (BD)

Elke pad bevat nog altijd **maximaal één** route.

## Audiotests

- Python-regressies: 208/208.
- Bestaande SunVox-audiotests: 239/239 in native en 239/239 in events.
- Gerichte A/B PCM-tests voor LFO RATE, DELAY FEEDBACK, geen clipping: 3/3 per modus.
- Complete matrix-audit: 256 correcte route/parametercontroles per modus. 254/256 routes leveren in het gekozen meetvenster een meetbare audioverandering. De twee onbesliste routes zijn FILTER ENV → DELAY FEEDBACK en AMP ENV → DELAY FEEDBACK; hiervoor veranderen de controllerwaarden correct, maar het korte audioscenario levert onvoldoende RMS-/spectraalverschil voor een individueel akoestisch PASS. De aparte BIAS → DELAY FEEDBACK-test laat een hoorbare echo-staartverandering zien.

Dit bevestigt niet dat alle combinaties in alle mogelijke patches muzikaal zinvol zijn. De uiteindelijke fysieke overlay-labels kunnen na verdere luisterproeven worden vastgesteld.
