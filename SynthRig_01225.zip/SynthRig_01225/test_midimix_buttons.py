#!/usr/bin/env python3
"""MIDImix input en LED-output verifiëren zonder SunVox of synthese."""
import argparse
import json
from pathlib import Path
import time
from datetime import datetime
import mido
from synthrig.midimix_hw import describe_midi
def find_midi_port(names,*markers):
    return next((n for n in names if any(m in n.lower() for m in markers)),None)


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--seconds',type=float,default=20)
    p.add_argument('--led-test',action='store_true')
    p.add_argument('--out-dir',default='recordings')
    args=p.parse_args()
    inputs=mido.get_input_names()
    outputs=mido.get_output_names()
    input_name=find_midi_port(inputs,'midi mix','midimix')
    output_name=find_midi_port(outputs,'midi mix','midimix')
    print('MIDI-inputs:',inputs)
    print('MIDI-outputs:',outputs)
    if not input_name:
        raise SystemExit('Geen MIDImix MIDI-input gevonden; controleer verbinding/poortnaam.')
    print('MIDImix input:',input_name,'| output:',output_name or '(niet gevonden)')
    outpath=Path(args.out_dir)
    outpath.mkdir(parents=True,exist_ok=True)
    logpath=outpath/('midimix_buttons_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.jsonl')
    with mido.open_input(input_name) as midi_in, logpath.open('w',encoding='utf8') as log:
        midi_out=None
        if args.led_test and output_name:
            midi_out=mido.open_output(output_name)
        elif args.led_test:
            print('Geen output; LED-test onmogelijk, inputregistratie werkt wel.')
        try:
            if midi_out:
                notes=[1,4,7,10,13,16,19,22,3,6,9,12,15,18,21,24]
                print('LED-test: iedere LED kort aan en uit ...')
                for note in notes:
                    midi_out.send(mido.Message('note_on',channel=0,note=note,velocity=127))
                    time.sleep(.12)
                    midi_out.send(mido.Message('note_on',channel=0,note=note,velocity=0))
                print('LED-test voltooid.')
            print('Druk nu op MUTE1, MUTE3 en REC1 en laat de knoppen los.')
            print('Standaard: MUTE1=note 1, MUTE3=note 7, REC1=note 3.')
            start=time.monotonic()
            while time.monotonic()-start<args.seconds:
                for msg in midi_in.iter_pending():
                    item={'t':round(time.monotonic()-start,3),'midi':msg.dict()}
                    print(f'{item["t"]:7.3f}  {describe_midi(msg)}',flush=True)
                    log.write(json.dumps(item)+'\n');log.flush()
                time.sleep(.002)
        finally:
            if midi_out:
                midi_out.close()
    print('Logbestand:',logpath)

if __name__=='__main__':main()
