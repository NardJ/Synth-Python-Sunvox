# Wijzigingen SynthRig 0.12.12

- Maximaal zeven tekens per APC-bron- of bestemmingslabel; één monospaced lettertype voor beide assen.
- Dubbele laaglabels (A/B en C/D) blijven zichtbaar; rijen rechts uitgelijnd, kolommen boven de pads.
- Uniforme statusbalk onderaan beide monitoren; permanente status + tijdelijk event, geen dubbele faderstatus in de APC-controllertekening.
- MIDImix- en Swing-events verschijnen op dezelfde eventregel onderaan in plaats van naast de hoofdstatus of midden in de controller.
- Geen wijzigingen in geluid, modulatie- of sequencerlogica.
- Migratie gebruikt nu 0.12.11 als meest recente bron voor sessies, gebruikerspresets, APC-patronen en outputgain.
