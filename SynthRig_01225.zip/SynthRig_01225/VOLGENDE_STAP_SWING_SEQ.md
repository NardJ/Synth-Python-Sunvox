# Sequencerontwikkeling na 0.12.21

De eerste softwarestap is uitgevoerd: clock-/transportdiagnose, correcte eerste stap en CONTINUE, clock-timeout en afhandeling van een verdwenen SWING-input. De fysieke bevestiging gebeurt met `SWING_SEQ_PRAKTIJKTEST_01221.md` en het bestand dat `--sync-report` op jouw rig maakt.

Daarna: SWING SEQ tijdens afspelen opnemen als noten, velocity en nootlengtes op de bevestigde clock. Begin met één partij en een expliciete looplengte van 16 stappen; daarna 32/64, quantisatie, rusten/ties en overdub. Neem MIDI-afspelen op, zonder aan te nemen dat het interne SWING-patroongeheugen uitleesbaar is.

Vervolgens: bewerking van het opgenomen patroon via APC/tracker en opslag bij de sessie, daarna export naar native SunVox-patronen en arrangement. Ontwerp daarbij expliciet hoe noten worden toegewezen aan de vier bestaande audiostemmen. De SWING kan meer gelijktijdige noten uitsturen dan deze rig stemmen heeft; opname en afspelen moeten voice stealing bewust behandelen.

SWING blijft de fysieke invoer/SEQ-bediening. SynthRig voegt opname, opslag en patroonbewerking toe. SunVox verzorgt synthese en later het tracker-arrangement. De actuele versie bevat nog geen MIDI-patroonrecorder.
