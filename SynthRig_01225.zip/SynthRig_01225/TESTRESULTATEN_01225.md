# Testresultaten SynthRig 0.12.25

| Controle | Resultaat |
|---|---|
| Volledige Python-regressiesuite | **375 tests geslaagd** |
| Gerichte echte SunVox-audio: live wissel | **6/6 cases geslaagd**: 4/8/16-loop in native/events-modus |
| Native-audioregressies | **16/16 tiecases en 32/32 previewcases geslaagd** |
| Timing overgang | Nieuwe toon op de loopgrens; vrijgeven oude gate en starten nieuwe noot op hetzelfde driver-tijdstip |
| Native PCM-controle | Oude en nieuwe toonhoogte gemeten; audio aanwezig rond overgang; geen transportstop; huidig tempo behouden |
| Interne polling | Kleine jitter stapelt niet op; lange stall produceert geen noten-burst |
| Voorselectie | Actieve data/cursor/clock blijven tijdens kiezen intact; laatste geldige keuze telt |
| Annuleren | Huidige knop, STOP, PANIC, close en externe clockstop/-verlies gecontroleerd |
| Clockmodi | Interne clock en SWING; bij SWING blijven pulsteller en aantal ontvangen STARTs onveranderd |
| Looplengte | Overgang na huidige 4/8/16 stappen; doel begint bij 1 met zijn eigen lengte |
| Tempo | Live BPM blijft behouden, ook na faderwijziging terwijl keuze klaarstaat; stilstaand laden gebruikt opgeslagen BPM |
| Bestanden | Vooraf ingelezen snapshot; geen read op overgang; invalide file verandert actieve of eerder voorbereide keuze niet |
| Leeg patroon | Clock blijft lopen met een leeg rooster |
| Gates en ties | Oude aangehouden gate los; nieuwe eigen aanslag; SWING-gedeelde noot blijft beschermd |
| SAVE | Bewaart actuele plaats, niet de voorselectie; keuzestatus staat niet in patroonbestand |
| Echte Tk/UDP | Knipperende MIDI-scene-opdracht en GUI, keuze-pijl, actieve overdracht, annuleren en stabiele PLAY-LED gecontroleerd |
| GUI/zoom | Patroonkop past op 50%, 90% en 100%; geen canvas-itemgroei |
| GUI-regressies | SAVE/tempo/ties, preview, looplengte, SWING-sync, ADSR en SOLO geslaagd |
| Upgrade | 0.12.24 krijgt prioriteit; aanwezige huidige bestanden blijven behouden |
| Bronvergelijking | Native DSP alleen versieteksten anders; ADSR, mappings, loopkeuzes en factory presets identiek |
| Aflevering | ZIP-integriteit, syntax en nieuwe tests/startfile uit los uitgepakte ZIP gecontroleerd |

## Bereik

De native audiocases gebruiken echte offline SunVox-PCM zonder geluidskaart. In een droge sinus-baseline wordt van een aangehouden lage naar een hoge noot overgeschakeld. De overgangstijd, toonhoogtes, het aantal aanslagen en PCM rond de grens worden gemeten. De volledige historische DSP-suite is niet opnieuw uitgevoerd.

De GUI-tests gebruiken echte Tk-canvassen en localhost-UDP met FakeSlot en gesimuleerde MIDI/LED-uitvoer. De fysieke APC, SWING en MIDImix waren niet aangesloten. De LED-tests bevestigen uitgezonden opdrachten, geen hardware-uitlezing.

Logs staan in `reports_01225/`: `python_tests.log`, `audio_live_patterns.log/json`, `audio_ties.log`, `audio_preview.log`, `gui_live_patterns.log`, `gui_ties_save_tempo.log`, `gui_preview.log`, `gui_loop_length.log`, `gui_sync.log`, `gui_adsr.log`, `gui_solo_session.log` en `gui_solo_presets.log`. `GUI_LIVE_PATTERN_01225.png` is een echte Tk-schermafdruk van een voorselectie.

Gebruik `synthrig_01225.py`. Oudere startfiles en verslagen in het pakket horen bij eerdere releases.
