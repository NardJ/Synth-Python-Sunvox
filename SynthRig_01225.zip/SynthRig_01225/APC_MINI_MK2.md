# APC Mini Mk2 — actuele PATCH-modus in 0.12.5

De oude PARAM-uitleg hieronder hoort bij 0.12.4 en is achterhaald.
Lees **PATCH_MATRIX_0125.md** voor de nieuwe, echte modulatiematrix.
De SEQ-uitleg blijft van toepassing.

---

# SynthRig 0.12.2 — AKAI APC Mini Mk2

Deze release bevat de **eerste echte integratie** met de APC Mini Mk2. De
bestaande Swing, MIDImix, 16 presets en SunVox-audio-engine blijven behouden.

## Aansluiten en starten

Sluit eerst je SWING, MIDImix en APC Mini Mk2 aan. Sluit Ableton of andere
software die de APC bestuurt voordat je SynthRig start.

```bash
cd ~/Synth/Python-sunvox/SynthRig_0120
source ../.venv/bin/activate
python synthrig_0122.py --debug-ui --midi-log
```

SynthRig zoekt automatisch het **Control**-MIDI-input- en outputendpoint van
de **APC mini mk2**, niet het aparte **Notes**-endpoint. De APC is optioneel:
zonder APC werkt de synthesizer gewoon door. Als automatische herkenning
mislukt, bekijk eerst de beschikbare MIDI-poorten met:

```bash
python -c 'import mido; print("IN:", mido.get_input_names()); print("OUT:", mido.get_output_names())'
```

Stel daarna desgewenst `--apc-input 'exacte naam'` en
`--apc-output 'exacte naam'` in. Met `--no-apc` zet je de integratie uit.

## De acht knoppen direct onder de 8×8 matrix

| Knop van links | Functie |
|---|---|
| 1 (MIDI noot 100) | PATCH-modus: modulatie-/parameterdieptes |
| 2 (101) | SEQ-modus: 16-staps sequencer |
| 3 (102) | Pagina 1: stappen 1–8 |
| 4 (103) | Pagina 2: stappen 9–16 |
| 5 (104) | PLAY/STOP van APC-sequencer |
| 6 (105) | Patroon opslaan naar `patterns/apc_XX.json` |
| 7 (106) | Patroon uit bestand laden / wijzigingen ongedaan maken |
| 8 (107) | PANIC: sequencer stoppen en alle klinkende noten afbreken |

De **acht SCENE-knoppen rechts van de matrix** kiezen patroon 1 t/m 8.
Bij wisselen van patroon stopt de sequencer eerst, zodat er geen noten blijven hangen.

## PARAM-modus (op het apparaat nog PATCH-knop): 8 modulatie-/parameterregelingen

**Belangrijk:** dit is een *eerste digitale patch-/modulatieregeling*, nog geen
volledig vrij patchpanel dat willekeurige SunVox-modules fysiek of via DSP
met elkaar verbindt. Die vrije signal-routing bouwen we in een latere fase.

- Iedere **kolom** bestuurt één bestaande synthparameter.
- Iedere **rij** bepaalt de sterkte: onderste pad = 0%, bovenste = 100%.
- Een blauwe LED toont de gekozen stand; grijze LED's de tussenliggende niveaus.
- De instelling verandert direct in de echte SunVox-engine en wordt opgeslagen
  als onderdeel van de bestaande SynthRig-sessie.
- Presetopslag met lange SOLO-druk op MIDImix werkt ook voor deze instellingen.
- Voor gekoppelde MIDImix-draaiknoppen geldt daarna weer *soft takeover*.

| Kolom van links | Parameter |
|---|---|
| 1 | LFO → toonhoogte |
| 2 | LFO → filter |
| 3 | Filter envelope → filter |
| 4 | Keyboard tracking → filter |
| 5 | LFO → PWM |
| 6 | Velocity-gevoeligheid |
| 7 | Delay-mix |
| 8 | Reverb-mix |

## SEQ-modus: acht melodische lanes en 16 stappen

- Iedere **rij** is één noot-lane (onderaan lane 1, bovenaan lane 8).
- Iedere **kolom** is één stap; kies met de onderste knoppen 3 en 4 of je
  stappen 1–8 of 9–16 bewerkt.
- Tik op een pad om de noot bij die stap aan/uit te zetten.
- Groen = actieve stap, geel/oranje = afspeelpositie.
- Standaardnoten van onder naar boven: MIDI 48, 50, 52, 53, 55, 57, 59 en 60.
- De **eerste acht APC-faders** wijzigen in SEQ-modus de toonhoogtes van de acht
  lanes, van MIDI 36 tot 84. De fysieke faderpositie is hierbij direct leidend.
- **SHIFT vasthouden + fader 1–8** regelt de velocity van de bijbehorende lane,
  van 1 t/m 127. SHIFT + de SCENE 6/7 knoppen wordt **niet** door SynthRig gebruikt:
  de APC kan dan namelijk naar zijn eigen hardware Drum- of Note-modus schakelen.
- De **negende/masterfader** wijzigt het tempo (60–180 BPM) bij interne klok.
  Standaard is 120 BPM; stappen zijn zestiende noten, gate = 55%.
- Druk onderste knop 5 (PLAY) om te starten of te stoppen.
- Druk onderste knop 6 (SAVE) om je patroon te bewaren. Er zijn **8 patronen**, elk
  met 16 stappen, niet te verwarren met de **16 klankpresets** op de MIDImix.
- Patronen worden bewaard in `patterns/apc_01.json` t/m `apc_08.json`.
  Er wordt **niet automatisch opgeslagen** bij iedere wijziging; druk SAVE.

## Samen met de Behringer SWING

Standaard heeft de APC een **eigen interne klok**. Je kunt tijdens het
spelen gewoon noten op de Swing blijven spelen.

Wanneer je de Swing als klokmaster gebruikt:

```bash
python synthrig_0122.py --debug-ui --apc-clock swing
```

De APC-sequencer volgt dan de MIDI Clock (24 pulsen per kwartnoot) en
Start/Stop-berichten van de SWING. Start op de APC alleen bereidt de
sequencer voor: er komen pas stappen als Swing Clock arriveert.
De masterfader op de APC regelt in deze modus **niet** het tempo.

De APC en SWING delen een beschermde MIDI-notenrouter: een Note Off van de
sequencer stopt geen nog ingedrukte SWING-toets met dezelfde MIDI-noot.

## Eerste hardwaretest

1. Start SynthRig met alle drie controllers aangesloten. Controleer of in
   de terminal `APC Mini Mk2 actief` staat en of de RGB-pads reageren.
2. Druk op de tweede knop onder het APC-grid (SEQ).
3. Tik linksonder op de matrix (lane 1, stap 1). Die pad wordt groen.
4. Tik twee kolommen naar rechts op dezelfde onderste rij voor stap 3.
5. Druk op de vijfde onderste knop: je hoort nu een herhalend patroon.
6. Kies met knop 4 de tweede pagina en voeg daar stappen toe.
7. Druk op knop 5 om te stoppen. Druk vervolgens op knop 6 (SAVE).
8. Ga met knop 1 naar PATCH; verander bijvoorbeeld de reverb in kolom 8.
9. Bespeel ondertussen je Swing en controleer dat MIDI-noten normaal stoppen.

**Belangrijke grenzen:** de echte APC-hardware is nog niet lokaal aangesloten
geweest; de MIDI- en LED-protocoltests zijn gesimuleerd. Ook is dit nog geen
volledig 64-kruispunten modulatiepatchpanel. Dat laatste vraagt nieuwe
modulatieverbindingen binnen de engine en verdient een afzonderlijke ontwerpfase.


## Nieuw sinds 0.12.4: schermindeling

De APC-monitor staat rechts van de MIDImix-monitor met afgeronde kaders. De acht APC-faders staan onder de padkolommen en op dezelfde hoogte als de MIDImix-faders. Je kunt **beide vensters tegelijk** schalen met Ctrl + Plus, Ctrl + Min en Ctrl + 0 (maximaal schermpassend). De monitor blijft alleen-lezen, behalve de Output Gain in het MIDImix-venster.

## Nieuw in 0.12.4: faders uitlezen

Bij het starten verstuurt SynthRig een Introduction-SysEx naar de APC Control-uitgang en verwerkt de negen fysieke faderwaarden uit het antwoord. Ze worden uitsluitend getoond en beïnvloeden nooit zelf de sequencer of het geluid. Als er geen antwoord komt, laat het venster onbekende standen zien totdat je de faders beweegt.

De MIDImix is anders: druk eenmaal op de fysieke SEND ALL-knop voor een momentopname van alle 33 regelaars. Soft takeover voorkomt ongewenste klanksprongen.
